-- Add lab availability scheduling fields
ALTER TABLE "labs"
ADD COLUMN "unavailableUntil" TIMESTAMP(3),
ADD COLUMN "deactivationNever" BOOLEAN NOT NULL DEFAULT false;
