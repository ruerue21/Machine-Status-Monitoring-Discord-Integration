-- Add equipment out-of-order window fields
ALTER TABLE "equipment"
  ADD COLUMN "outOfOrderUntil" TIMESTAMP(3),
  ADD COLUMN "outOfOrderNever" BOOLEAN NOT NULL DEFAULT false;

-- Normalize old MAINTENANCE state into OUT_OF_ORDER and remove enum value
ALTER TYPE "EquipmentStatus" RENAME TO "EquipmentStatus_old";

CREATE TYPE "EquipmentStatus" AS ENUM ('AVAILABLE', 'OUT_OF_ORDER');

ALTER TABLE "equipment"
  ALTER COLUMN "status" DROP DEFAULT,
  ALTER COLUMN "status" TYPE "EquipmentStatus"
  USING (
    CASE
      WHEN "status"::text = 'MAINTENANCE' THEN 'OUT_OF_ORDER'::"EquipmentStatus"
      ELSE "status"::text::"EquipmentStatus"
    END
  ),
  ALTER COLUMN "status" SET DEFAULT 'AVAILABLE';

DROP TYPE "EquipmentStatus_old";
