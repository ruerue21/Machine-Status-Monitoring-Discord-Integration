/*
  Warnings:

  - The values [ACTIVE] on the enum `BookingStatus` will be removed. If these variants are still used in the database, this will fail.
  - You are about to drop the column `date` on the `bookings` table. All the data in the column will be lost.
  - You are about to drop the column `equipmentId` on the `bookings` table. All the data in the column will be lost.
  - You are about to drop the column `equipmentId` on the `projects` table. All the data in the column will be lost.
  - You are about to drop the column `timeSlotId` on the `projects` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[mentorId,labId,slotType,date,startTime,endTime]` on the table `time_slots` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `endDate` to the `bookings` table without a default value. This is not possible if the table is not empty.
  - Added the required column `labId` to the `bookings` table without a default value. This is not possible if the table is not empty.
  - Added the required column `startDate` to the `bookings` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "MentorType" AS ENUM ('CONSULTATION', 'LAB');

-- CreateEnum
CREATE TYPE "SlotType" AS ENUM ('CONSULTATION', 'LAB');

-- CreateEnum
CREATE TYPE "ConsultationStatus" AS ENUM ('SCHEDULED', 'COMPLETED', 'CANCELLED', 'ABSENT');

-- CreateEnum
CREATE TYPE "MemberAgreementResignType" AS ENUM ('YEARLY', 'MONTHLY', 'WEEKLY', 'SPECIFIC_DATE');

-- AlterEnum
BEGIN;
CREATE TYPE "BookingStatus_new" AS ENUM ('CONFIRMED', 'COMPLETED', 'CANCELLED', 'ABSENT');
ALTER TABLE "bookings" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "bookings" ALTER COLUMN "status" TYPE "BookingStatus_new" USING ("status"::text::"BookingStatus_new");
ALTER TYPE "BookingStatus" RENAME TO "BookingStatus_old";
ALTER TYPE "BookingStatus_new" RENAME TO "BookingStatus";
DROP TYPE "BookingStatus_old";
ALTER TABLE "bookings" ALTER COLUMN "status" SET DEFAULT 'CONFIRMED';
COMMIT;

-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "ProjectStatus" ADD VALUE 'CONSULTATION_CANCELLED';
ALTER TYPE "ProjectStatus" ADD VALUE 'CONSULTATION_ABSENT';

-- DropForeignKey
ALTER TABLE "bookings" DROP CONSTRAINT "bookings_equipmentId_fkey";

-- DropForeignKey
ALTER TABLE "bookings" DROP CONSTRAINT "bookings_userId_fkey";

-- DropForeignKey
ALTER TABLE "projects" DROP CONSTRAINT "projects_equipmentId_fkey";

-- DropForeignKey
ALTER TABLE "projects" DROP CONSTRAINT "projects_timeSlotId_fkey";

-- DropForeignKey
ALTER TABLE "projects" DROP CONSTRAINT "projects_userId_fkey";

-- DropForeignKey
ALTER TABLE "time_slots" DROP CONSTRAINT "time_slots_mentorId_fkey";

-- AlterTable
ALTER TABLE "bookings" DROP COLUMN "date",
DROP COLUMN "equipmentId",
ADD COLUMN     "bookingGroupId" TEXT,
ADD COLUMN     "cancellationReason" TEXT,
ADD COLUMN     "cancelledBy" INTEGER,
ADD COLUMN     "endDate" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "isArchived" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "labId" INTEGER NOT NULL,
ADD COLUMN     "labMentorId" INTEGER,
ADD COLUMN     "notes" TEXT,
ADD COLUMN     "startDate" TIMESTAMP(3) NOT NULL,
ALTER COLUMN "status" SET DEFAULT 'CONFIRMED',
ALTER COLUMN "userId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "labs" ADD COLUMN     "agreementRequired" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "projects" DROP COLUMN "equipmentId",
DROP COLUMN "timeSlotId",
ADD COLUMN     "isArchived" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "isRescheduled" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "rescheduledFromId" INTEGER,
ALTER COLUMN "userId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "time_slots" ADD COLUMN     "slotType" "SlotType" NOT NULL DEFAULT 'CONSULTATION';

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "agreementCancellations" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "assignedLabIds" INTEGER[],
ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "lastAgreementCancelledAt" TIMESTAMP(3),
ADD COLUMN     "lastAgreementCancelledBy" INTEGER,
ADD COLUMN     "lastLoginAt" TIMESTAMP(3),
ADD COLUMN     "memberAgreementDate" TIMESTAMP(3),
ADD COLUMN     "memberAgreementSigned" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "memberAgreementVersionSigned" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "mentorType" "MentorType",
ADD COLUMN     "verificationTokenExpires" TIMESTAMP(3);

-- CreateTable
CREATE TABLE "agreement_cancellations" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "cancelledBy" INTEGER NOT NULL,
    "reason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "agreement_cancellations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "member_agreement_config" (
    "id" SERIAL NOT NULL,
    "resignType" "MemberAgreementResignType" NOT NULL DEFAULT 'YEARLY',
    "anchorDate" TIMESTAMP(3) NOT NULL,
    "specificDate" TIMESTAMP(3),
    "currentVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "member_agreement_config_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "member_agreement_files" (
    "id" SERIAL NOT NULL,
    "configId" INTEGER NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "fileType" TEXT NOT NULL,
    "displayOrder" INTEGER NOT NULL DEFAULT 0,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "member_agreement_files_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lab_agreement_files" (
    "id" SERIAL NOT NULL,
    "labId" INTEGER NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "fileType" TEXT NOT NULL,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "lab_agreement_files_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lab_agreements" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "labId" INTEGER NOT NULL,
    "signed" BOOLEAN NOT NULL DEFAULT false,
    "signedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "cancellations" INTEGER NOT NULL DEFAULT 0,
    "lastCancelledAt" TIMESTAMP(3),
    "lastCancelledBy" INTEGER,

    CONSTRAINT "lab_agreements_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lab_agreement_cancellations" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "labId" INTEGER NOT NULL,
    "labAgreementId" INTEGER NOT NULL,
    "cancelledBy" INTEGER NOT NULL,
    "reason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "lab_agreement_cancellations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "project_equipment" (
    "id" SERIAL NOT NULL,
    "projectId" INTEGER NOT NULL,
    "equipmentId" INTEGER NOT NULL,

    CONSTRAINT "project_equipment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "consultations" (
    "id" SERIAL NOT NULL,
    "status" "ConsultationStatus" NOT NULL DEFAULT 'SCHEDULED',
    "notes" TEXT,
    "mentorFeedback" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "cancelledBy" INTEGER,
    "cancelledAt" TIMESTAMP(3),
    "cancelReason" TEXT,
    "markedAbsentBy" INTEGER,
    "absentAt" TIMESTAMP(3),
    "absentReason" TEXT,
    "userId" INTEGER,
    "labId" INTEGER NOT NULL,
    "timeSlotId" INTEGER,
    "projectId" INTEGER,

    CONSTRAINT "consultations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "booking_equipment" (
    "id" SERIAL NOT NULL,
    "bookingId" INTEGER NOT NULL,
    "equipmentId" INTEGER NOT NULL,

    CONSTRAINT "booking_equipment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lab_mentor_assignments" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER NOT NULL,
    "labId" INTEGER NOT NULL,
    "mentorType" "MentorType" NOT NULL,
    "schedule" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "lab_mentor_assignments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "lab_agreements_userId_labId_key" ON "lab_agreements"("userId", "labId");

-- CreateIndex
CREATE UNIQUE INDEX "project_equipment_projectId_equipmentId_key" ON "project_equipment"("projectId", "equipmentId");

-- CreateIndex
CREATE UNIQUE INDEX "consultations_timeSlotId_key" ON "consultations"("timeSlotId");

-- CreateIndex
CREATE UNIQUE INDEX "booking_equipment_bookingId_equipmentId_key" ON "booking_equipment"("bookingId", "equipmentId");

-- CreateIndex
CREATE UNIQUE INDEX "lab_mentor_assignments_userId_labId_mentorType_key" ON "lab_mentor_assignments"("userId", "labId", "mentorType");

-- CreateIndex
CREATE INDEX "bookings_cancelledBy_idx" ON "bookings"("cancelledBy");

-- CreateIndex
CREATE UNIQUE INDEX "time_slots_mentorId_labId_slotType_date_startTime_endTime_key" ON "time_slots"("mentorId", "labId", "slotType", "date", "startTime", "endTime");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_lastAgreementCancelledBy_fkey" FOREIGN KEY ("lastAgreementCancelledBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agreement_cancellations" ADD CONSTRAINT "agreement_cancellations_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agreement_cancellations" ADD CONSTRAINT "agreement_cancellations_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "member_agreement_files" ADD CONSTRAINT "member_agreement_files_configId_fkey" FOREIGN KEY ("configId") REFERENCES "member_agreement_config"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreement_files" ADD CONSTRAINT "lab_agreement_files_labId_fkey" FOREIGN KEY ("labId") REFERENCES "labs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreements" ADD CONSTRAINT "lab_agreements_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreements" ADD CONSTRAINT "lab_agreements_labId_fkey" FOREIGN KEY ("labId") REFERENCES "labs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreements" ADD CONSTRAINT "lab_agreements_lastCancelledBy_fkey" FOREIGN KEY ("lastCancelledBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreement_cancellations" ADD CONSTRAINT "lab_agreement_cancellations_labAgreementId_fkey" FOREIGN KEY ("labAgreementId") REFERENCES "lab_agreements"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_agreement_cancellations" ADD CONSTRAINT "lab_agreement_cancellations_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_equipment" ADD CONSTRAINT "project_equipment_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "projects"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "project_equipment" ADD CONSTRAINT "project_equipment_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES "equipment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "projects" ADD CONSTRAINT "projects_rescheduledFromId_fkey" FOREIGN KEY ("rescheduledFromId") REFERENCES "projects"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "projects" ADD CONSTRAINT "projects_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_labId_fkey" FOREIGN KEY ("labId") REFERENCES "labs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_timeSlotId_fkey" FOREIGN KEY ("timeSlotId") REFERENCES "time_slots"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "consultations" ADD CONSTRAINT "consultations_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "projects"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "time_slots" ADD CONSTRAINT "time_slots_mentorId_fkey" FOREIGN KEY ("mentorId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_labId_fkey" FOREIGN KEY ("labId") REFERENCES "labs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_labMentorId_fkey" FOREIGN KEY ("labMentorId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_cancelledBy_fkey" FOREIGN KEY ("cancelledBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_equipment" ADD CONSTRAINT "booking_equipment_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES "bookings"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_equipment" ADD CONSTRAINT "booking_equipment_equipmentId_fkey" FOREIGN KEY ("equipmentId") REFERENCES "equipment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_mentor_assignments" ADD CONSTRAINT "lab_mentor_assignments_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "lab_mentor_assignments" ADD CONSTRAINT "lab_mentor_assignments_labId_fkey" FOREIGN KEY ("labId") REFERENCES "labs"("id") ON DELETE CASCADE ON UPDATE CASCADE;
