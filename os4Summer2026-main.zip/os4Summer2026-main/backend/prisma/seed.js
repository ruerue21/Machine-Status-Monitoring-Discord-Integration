const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcrypt");
const {
  consultationPeerMentorSchedules,
  labPeerMentorSchedules,
  generateTimeSlots,
} = require("../config/peerMentorSchedules");

const prisma = new PrismaClient();

const labsData = [
  {
    name: "Boilermakery",
    description:
      "Funded by the Purdue Student Fee Advisory Board and built by Bechtel Center, The Boilermakery is an interactive makerspace for Purdue students situated on the ground floor of the Bechtel Innovation Design Center. Whether you want to explore usage of simple manufacturing machines, work through the space's overarching interaction project, or just need access to some simple hand tools, The Boilermakery is a free to use for all Purdue students regardless of college or major.",
    location: "Bechtel Center - Room 1",
    isActive: true,
  },
  {
    name: "Electronics",
    description:
      "The Electronics Lab is home to a wide variety of electrical manufacturing equipment, including soldering irons, desoldering stations, a PCB mill, a reflow oven, and every consumable necessary to build a circuit board from start to finish. Users will also find oscilloscopes, signal generators, power supplies, and multimeters to aid in testing and troubleshooting all common electrical components. We are more than happy to answer questions, and we hope to see you in the lab!",
    location: "Bechtel Center - Room 2",
    isActive: true,
  },
  {
    name: "Fabrics",
    description:
      "The Fabrics lab is home to a variety of equipment, workshops, and other opportunities to improve your skills and complete a soft materials project from start to finish. Capabilities include sewing, embroidery, ironing, and cross stitching. Our peer mentors are happy to help and answer questions, and we look forward to seeing you in the lab!",
    location: "Bechtel Center - Room 3",
    isActive: true,
  },
  {
    name: "Hot Works",
    description:
      "The Hot Works space offers a wide range of metalworking equipment and training to help new users learn the essentials of welding, jewelry making, cutting, and designing while providing experienced users with the tools they need to successfully complete projects in these areas. Through the Hot Works space, members can gain access to a variety of welding systems (GTAW, GMAW, SMAW, and Oxy-Acetylene), a fully equipped jewelry-making workbench, and a variety of cutting methods that can accommodate sheet metal as well as tube cutting/coping.",
    location: "Bechtel Center - Room 4",
    isActive: true,
  },
  {
    name: "Metal Working",
    description:
      "Machining is a controlled subtractive manufacturing process which can be used to create high precision parts. Milling uses rotating cutting tools that move around the part removing material to create a variety of features. Turning on a lathe spins the part and moves static cutting tools along to create cylindrical profiles. Drilling is the most basic process and can be performed on both mills and lathes to drill round holes. Our CNC machines use computers to control the movement of the machine to create parts more effectively than possible by hand. The Bechtel Center also offers 5-axis milling and live tooling turning capabilities to allow more complex parts to be made. The main goal of the center is to teach manufacturing techniques, feel free to ask questions!",
    location: "Bechtel Center - Room 5",
    isActive: true,
  },
  {
    name: "Printing and Prototyping",
    description: "No description yet!",
    location: "Bechtel Center - Room 6",
    isActive: true,
  },
  {
    name: "Woodworking",
    description:
      "The Bechtel Innovation Design Center offers access to a combination of modern and traditional woodworking techniques. From custom fixtures and jigs to furniture and artwork, projects of any difficulty can be completed using resources ranging from our assortment of hand planes to our CNC gantry sheet router. Visit the Get Started page to connect with a peer mentor and begin your woodworking project!",
    location: "Bechtel Center - Room 7",
    isActive: true,
  },
];

const equipmentData = [
  // Boilermakery Equipment
  {
    name: "1 Boilermakery Equipment",
    description: "1 Boilermakery Equipment Description",
    labName: "Boilermakery",
  },
  {
    name: "2 Boilermakery Equipment",
    description: "2 Boilermakery Equipment Description",
    labName: "Boilermakery",
  },
  {
    name: "3 Boilermakery Equipment",
    description: "3 Boilermakery Equipment Description",
    labName: "Boilermakery",
  },

  // Electronics Equipment
  {
    name: "1 Electronics Equipment",
    description: "1 Electronics Equipment Description",
    labName: "Electronics",
  },
  {
    name: "2 Electronics Equipment",
    description: "2 Electronics Equipment Description",
    labName: "Electronics",
  },
  {
    name: "3 Electronics Equipment",
    description: "3 Electronics Equipment Description",
    labName: "Electronics",
  },

  // Fabrics Equipment
  {
    name: "1 Fabrics Equipment",
    description: "1 Fabrics Equipment Description",
    labName: "Fabrics",
  },
  {
    name: "2 Fabrics Equipment",
    description: "2 Fabrics Equipment Description",
    labName: "Fabrics",
  },
  {
    name: "3 Fabrics Equipment",
    description: "3 Fabrics Equipment Description",
    labName: "Fabrics",
  },

  // Hot Works Equipment
  {
    name: "1 Hot Works Equipment",
    description: "1 Hot Works Equipment Description",
    labName: "Hot Works",
  },
  {
    name: "2 Hot Works Equipment",
    description: "2 Hot Works Equipment Description",
    labName: "Hot Works",
  },
  {
    name: "3 Hot Works Equipment",
    description: "3 Hot Works Equipment Description",
    labName: "Hot Works",
  },

  // Metal Working Equipment
  {
    name: "1 Metal Working Equipment",
    description: "1 Metal Working Equipment Description",
    labName: "Metal Working",
  },
  {
    name: "2 Metal Working Equipment",
    description: "2 Metal Working Equipment Description",
    labName: "Metal Working",
  },
  {
    name: "3 Metal Working Equipment",
    description: "3 Metal Working Equipment Description",
    labName: "Metal Working",
  },

  // Printing and Prototyping Equipment
  {
    name: "1 Printing and Prototyping Equipment",
    description: "1 Printing and Prototyping Equipment Description",
    labName: "Printing and Prototyping",
  },
  {
    name: "2 Printing and Prototyping Equipment",
    description: "2 Printing and Prototyping Equipment Description",
    labName: "Printing and Prototyping",
  },
  {
    name: "3 Printing and Prototyping Equipment",
    description: "3 Printing and Prototyping Equipment Description",
    labName: "Printing and Prototyping",
  },

  // Woodworking Equipment
  {
    name: "1 Woodworking Equipment",
    description: "1 Woodworking Equipment Description",
    labName: "Woodworking",
  },
  {
    name: "2 Woodworking Equipment",
    description: "2 Woodworking Equipment Description",
    labName: "Woodworking",
  },
  {
    name: "3 Woodworking Equipment",
    description: "3 Woodworking Equipment Description",
    labName: "Woodworking",
  },
];

async function main() {
  console.log("Starting database seeding...");

  console.log("Clearing existing data...");
  await prisma.bookingEquipment.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.projectEquipment.deleteMany();
  await prisma.project.deleteMany();
  await prisma.consultation.deleteMany();
  await prisma.timeSlot.deleteMany();
  await prisma.labMentorAssignment.deleteMany();
  await prisma.equipment.deleteMany();
  await prisma.lab.deleteMany();
  await prisma.user.deleteMany();

  console.log("Creating labs...");
  const createdLabs = [];
  for (const labData of labsData) {
    const lab = await prisma.lab.create({
      data: labData,
    });
    createdLabs.push(lab);
    console.log(`   Created lab: ${lab.name}`);
  }

  console.log("Creating equipment...");
  for (const equipData of equipmentData) {
    const lab = createdLabs.find((l) => l.name === equipData.labName);
    if (lab) {
      const equipment = await prisma.equipment.create({
        data: {
          name: equipData.name,
          description: equipData.description,
          labId: lab.id,
          status: "AVAILABLE",
        },
      });
      console.log(`   Created equipment: ${equipment.name} in ${lab.name}`);
    }
  }

  console.log("Creating test users...");
  const hashedPassword = await bcrypt.hash("password123", 10);

  const adminUser = await prisma.user.create({
    data: {
      name: "System Administrator",
      email: "admin@purdue.edu",
      password: hashedPassword,
      role: "ADMIN",
      emailVerified: true,
      assignedLabIds: [],
    },
  });
  console.log(`   Created admin: ${adminUser.email}`);

  // Not signed agreement
  const testStudent = await prisma.user.create({
    data: {
      name: "Test Student",
      email: "student@purdue.edu",
      password: hashedPassword,
      role: "MEMBER",
      emailVerified: true,
      memberAgreementSigned: false,
      assignedLabIds: [],
    },
  });
  console.log(`   Created student (no agreement): ${testStudent.email}`);

  console.log("Creating consultation peer mentors...");
  const createdConsultationMentors = [];

  for (const mentorData of consultationPeerMentorSchedules) {
    // Create the mentor user
    const mentor = await prisma.user.create({
      data: {
        name: mentorData.name,
        email: mentorData.email,
        password: hashedPassword,
        role: mentorData.role,
        emailVerified: true,
        assignedLabIds: [],
        mentorType: null,
      },
    });

    // Create lab assignments using LabMentorAssignment table
    for (const labName of mentorData.assignedLabs) {
      const lab = createdLabs.find((l) => l.name === labName);
      if (lab) {
        await prisma.labMentorAssignment.create({
          data: {
            userId: mentor.id,
            labId: lab.id,
            mentorType: "CONSULTATION",
          },
        });
      }
    }

    createdConsultationMentors.push({
      ...mentor,
      schedule: mentorData.schedule,
      assignedLabs: mentorData.assignedLabs,
    });

    console.log(
      `   Created consultation peer mentor: ${
        mentor.name
      } for labs: ${mentorData.assignedLabs.join(", ")}`
    );
  }

  console.log("Creating lab peer mentors...");
  const createdLabMentors = [];

  for (const mentorData of labPeerMentorSchedules) {
    // Create the mentor user
    const mentor = await prisma.user.create({
      data: {
        name: mentorData.name,
        email: mentorData.email,
        password: hashedPassword,
        role: mentorData.role,
        emailVerified: true,
        assignedLabIds: [],
        mentorType: null,
      },
    });

    // Create lab assignments using LabMentorAssignment table
    for (const labName of mentorData.assignedLabs) {
      const lab = createdLabs.find((l) => l.name === labName);
      if (lab) {
        await prisma.labMentorAssignment.create({
          data: {
            userId: mentor.id,
            labId: lab.id,
            mentorType: "LAB",
          },
        });
      }
    }

    createdLabMentors.push({
      ...mentor,
      schedule: mentorData.schedule,
      assignedLabs: mentorData.assignedLabs,
    });

    console.log(
      `   Created lab peer mentor: ${
        mentor.name
      } for labs: ${mentorData.assignedLabs.join(", ")}`
    );
  }

  console.log("Generating consultation time slots...");
  const consultationTimeSlots = [];

  for (const mentor of createdConsultationMentors) {
    for (const labName of mentor.assignedLabs) {
      const lab = createdLabs.find((l) => l.name === labName);
      if (lab) {
        const timeSlots = generateTimeSlots(
          mentor.id,
          lab.id,
          mentor.schedule,
          "CONSULTATION"
        );
        consultationTimeSlots.push(...timeSlots);
      }
    }
  }

  // Create consultation time slots in database
  for (const timeSlot of consultationTimeSlots) {
    await prisma.timeSlot.create({
      data: timeSlot,
    });
  }

  console.log(
    `   Created ${consultationTimeSlots.length} consultation time slots`
  );

  console.log("Generating lab mentor time slots...");
  const labTimeSlots = [];

  for (const mentor of createdLabMentors) {
    for (const labName of mentor.assignedLabs) {
      const lab = createdLabs.find((l) => l.name === labName);
      if (lab) {
        const timeSlots = generateTimeSlots(
          mentor.id,
          lab.id,
          mentor.schedule,
          "LAB"
        );
        labTimeSlots.push(...timeSlots);
      }
    }
  }

  // Create lab time slots in database
  for (const timeSlot of labTimeSlots) {
    await prisma.timeSlot.create({
      data: timeSlot,
    });
  }

  console.log(`   Created ${labTimeSlots.length} lab mentor time slots`);

  console.log("\nDatabase seeding completed successfully!");
  console.log("\nSummary:");
  console.log(`   - ${createdLabs.length} labs created`);
  console.log(`   - ${equipmentData.length} pieces of equipment created`);
  console.log(
    `   - ${
      createdConsultationMentors.length + createdLabMentors.length + 2
    } users created`
  );
  console.log(
    `   - ${consultationTimeSlots.length} consultation time slots generated`
  );
  console.log(`   - ${labTimeSlots.length} lab mentor time slots generated`);

  console.log("\nTest Account Credentials:");
  console.log("   Admin: admin@purdue.edu / password123");
  console.log("   Student (no agreement): student@purdue.edu / password123");

  console.log(
    "\nConsultation Peer Mentor Credentials (password: password123):"
  );
  for (const mentor of consultationPeerMentorSchedules) {
    console.log(
      `   - ${mentor.name}: ${mentor.email} (Labs: ${mentor.assignedLabs.join(
        ", "
      )})`
    );
  }

  console.log("\nLab Peer Mentor Credentials (password: password123):");
  for (const mentor of labPeerMentorSchedules) {
    console.log(
      `   - ${mentor.name}: ${mentor.email} (Labs: ${mentor.assignedLabs.join(
        ", "
      )})`
    );
  }
}

main()
  .catch((e) => {
    console.error("Error during seeding:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
