const express = require("express");
const cors = require("cors");
const path = require("path");
const morgan = require("morgan");
require("dotenv").config();

const logger = require("./utils/logger");
const {
  scheduleLabAvailabilityMonitor,
} = require("./services/labAvailabilityService");
const {
  scheduleEquipmentAvailabilityMonitor,
} = require("./services/equipmentAvailabilityService");

const app = express();
const PORT = process.env.PORT || 3001;
const allowedOrigins = (process.env.FRONTEND_URL || "http://localhost:3000")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
const allowedOriginSet = new Set(allowedOrigins);

// Middleware
app.use(
  cors({
    origin: (origin, callback) => {
      // Allow same-origin/non-browser requests
      if (!origin) {
        return callback(null, true);
      }
      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error("CORS origin not allowed"));
    },
    credentials: true,
  }),
);
app.use(express.json());

// CSRF defense for cookie-based auth: require trusted Origin/Referer on mutating requests
app.use((req, res, next) => {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    return next();
  }

  const origin = req.headers.origin;
  const referer = req.headers.referer;

  // Allow non-browser clients that do not send origin metadata
  if (!origin && !referer) {
    return next();
  }

  let requestOrigin = origin;
  if (!requestOrigin && referer) {
    try {
      requestOrigin = new URL(referer).origin;
    } catch (_error) {
      return res.status(403).json({ message: "Invalid request origin" });
    }
  }

  if (requestOrigin && allowedOriginSet.has(requestOrigin)) {
    return next();
  }

  return res.status(403).json({ message: "Invalid request origin" });
});

// Request logging middleware
// Skip logging for health check endpoint
app.use(
  morgan("combined", {
    stream: logger.stream,
    skip: (req, res) => req.url === "/health",
  }),
);

// Serve static files (for PDF)
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.use("/auth", require("./routes/auth"));
app.use("/admin", require("./routes/admin"));
app.use("/bookings", require("./routes/bookings"));
app.use("/lab-management", require("./routes/labManagement"));
app.use("/member", require("./routes/member"));
app.use("/lab-agreements", require("./routes/labAgreements"));
app.use("/archive", require("./routes/archive"));

// Health check endpoint (not logged)
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Basic test route
app.get("/", (req, res) => {
  res.json({ message: "Schedule Optimizer API is running!" });
});

// Global error handling middleware
app.use((err, req, res, next) => {
  logger.error("Unhandled error:", {
    error: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    userId: req.user?.userId || "unauthenticated",
  });

  res.status(err.status || 500).json({
    message:
      process.env.NODE_ENV === "production"
        ? "Internal server error"
        : err.message,
  });
});

// Start server
app.listen(PORT, () => {
  logger.info(`Server started on port ${PORT}`);
  console.log(`Server is running on port ${PORT}`);
  scheduleLabAvailabilityMonitor();
  scheduleEquipmentAvailabilityMonitor();
});

// Handle uncaught exceptions
process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception:", {
    error: error.message,
    stack: error.stack,
  });
  process.exit(1);
});

// Handle unhandled promise rejections
process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Rejection:", {
    reason: reason,
    promise: promise,
  });
});
