const buckets = new Map();
const MAX_BUCKETS = 10000;

const pruneExpiredBuckets = (now) => {
  for (const [key, value] of buckets.entries()) {
    if (value.resetAt <= now) {
      buckets.delete(key);
    }
  }
};

const createRateLimiter = ({
  windowMs = 15 * 60 * 1000,
  max = 30,
  keyResolver,
  message = "Too many requests, please try again later.",
} = {}) => {
  return (req, res, next) => {
    const now = Date.now();
    const key = keyResolver ? keyResolver(req) : req.ip;

    if (!key) {
      return next();
    }

    const existing = buckets.get(key);
    if (!existing || existing.resetAt <= now) {
      if (buckets.size >= MAX_BUCKETS) {
        pruneExpiredBuckets(now);
      }
      buckets.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }

    if (existing.count >= max) {
      const retryAfterSeconds = Math.ceil((existing.resetAt - now) / 1000);
      res.setHeader("Retry-After", retryAfterSeconds);
      return res.status(429).json({ message });
    }

    existing.count += 1;
    return next();
  };
};

module.exports = {
  createRateLimiter,
};
