const prisma = require("../db/prisma");

module.exports = async function loadUserDetails(req, res, next) {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        emailVerified: true,
        isActive: true,

        // Peer mentor fields
        assignedLabIds: true,
        mentorType: true,

        labAssignments: {
          select: {
            labId: true,
            mentorType: true,
          },
        },
      },
    });

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    if (!user.isActive) {
      return res.status(403).json({ message: "Account is inactive" });
    }

    req.userDetails = user;
    next();
  } catch (err) {
    console.error("loadUserDetails error:", err);
    return res.status(500).json({ message: "Server error" });
  }
};
