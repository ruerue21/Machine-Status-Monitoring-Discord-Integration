const { authenticateToken } = require("./auth");
const loadUserDetails = require("./loadUserDetails");
const { hasLabBookingPrivileges } = require("../utils/bookingAccess");

const authenticateUser = [authenticateToken, loadUserDetails];

const requireConsultationMentor = (req, res, next) => {
  if (
    !req.userDetails ||
    req.userDetails.role !== "PEER_MENTOR" ||
    req.userDetails.mentorType !== "CONSULTATION"
  ) {
    return res.status(403).json({
      message: "Consultation peer mentor privileges required",
    });
  }
  next();
};

const requireLabMentor = (req, res, next) => {
  if (
    !req.userDetails ||
    req.userDetails.role !== "PEER_MENTOR" ||
    req.userDetails.mentorType !== "LAB"
  ) {
    return res.status(403).json({
      message: "Lab peer mentor privileges required",
    });
  }
  next();
};

const requireBookingManager = (req, res, next) => {
  if (!hasLabBookingPrivileges(req.userDetails)) {
    return res.status(403).json({
      message: "Booking management privileges required",
    });
  }

  next();
};

module.exports = {
  authenticateUser,
  requireConsultationMentor,
  requireLabMentor,
  requireBookingManager,
};
