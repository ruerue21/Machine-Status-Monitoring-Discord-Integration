const jwt = require("jsonwebtoken");

const getCookieToken = (cookieHeader) => {
  if (!cookieHeader || typeof cookieHeader !== "string") {
    return null;
  }

  const cookies = cookieHeader.split(";").map((part) => part.trim());
  const authCookie = cookies.find((cookie) => cookie.startsWith("auth_token="));
  if (!authCookie) {
    return null;
  }

  return decodeURIComponent(authCookie.slice("auth_token=".length));
};

const getJwtSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET is not set in the environment (.env).");
  }
  return secret;
};

const authenticateToken = (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"];
    const bearerToken = authHeader && authHeader.split(" ")[1];
    const cookieToken = getCookieToken(req.headers.cookie);
    const token = bearerToken || cookieToken;

    if (!token) {
      return res.status(401).json({ message: "Access token required" });
    }

    const secret = getJwtSecret();

    jwt.verify(token, secret, (err, decoded) => {
      if (err) {
        return res.status(401).json({ message: "Invalid or expired token" });
      }
      req.user = decoded;
      next();
    });
  } catch (error) {
    console.error("Auth middleware error:", error);
    return res.status(500).json({ message: "Server configuration error" });
  }
};

module.exports = { authenticateToken };
