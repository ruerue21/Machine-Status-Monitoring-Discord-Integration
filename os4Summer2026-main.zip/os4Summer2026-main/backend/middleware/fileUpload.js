const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { sanitizeFilename } = require("../utils/validation");

const makeStorage = (relativePath) =>
  multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, `../uploads/${relativePath}`);
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      const safeOriginal = sanitizeFilename(path.basename(file.originalname));
      cb(null, `${uniqueSuffix}-${safeOriginal || "uploaded-file"}`);
    },
  });

const createAgreementUpload = (relativePath) =>
  multer({
    storage: makeStorage(relativePath),
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
      const allowedTypes = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "image/jpeg",
        "image/png",
        "image/jpg",
      ];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Invalid file type. Only PDF, DOCX, and images allowed."));
      }
    },
  });

const uploadLabAgreement = createAgreementUpload("lab-agreements");
const uploadMemberAgreement = createAgreementUpload("member-agreements");

module.exports = {
  uploadLabAgreement,
  uploadMemberAgreement,
};
