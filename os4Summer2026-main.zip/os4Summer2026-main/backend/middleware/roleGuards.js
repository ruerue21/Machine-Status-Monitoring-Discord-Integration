const requireRoles = (...roles) => {
  return (req, res, next) => {
    const role = req.userDetails?.role || req.user?.role;
    const isActive = req.userDetails?.isActive;

    if (!role) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (isActive === false) {
      return res.status(403).json({ message: "Account is inactive" });
    }

    if (!roles.includes(role)) {
      return res.status(403).json({
        message: `Access denied. Required role(s): ${roles.join(", ")}`,
      });
    }

    next();
  };
};

const requireAdmin = requireRoles("ADMIN");
const requireSupervisor = requireRoles("SUPERVISOR");
const requireAdminOrSupervisor = requireRoles("ADMIN", "SUPERVISOR");
const requireEmployee = requireRoles("ADMIN", "SUPERVISOR", "PEER_MENTOR");

module.exports = {
  requireRoles,
  requireAdmin,
  requireSupervisor,
  requireAdminOrSupervisor,
  requireEmployee,
};
