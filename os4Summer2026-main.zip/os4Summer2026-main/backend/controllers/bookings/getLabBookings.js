module.exports = async (req, res, prisma) => {
  try {
    const { labId } = req.params;
    const userRole = req.userDetails.role;
    const mentorType = req.userDetails.mentorType;
    const userId = req.userDetails.id;

    // Permissions: lab mentors can view their lab bookings; admins/supervisors can view all
    const canView =
      ["ADMIN", "SUPERVISOR"].includes(userRole) ||
      (userRole === "PEER_MENTOR" && mentorType === "LAB");

    if (!canView) {
      return res.status(403).json({ message: "Access denied" });
    }

    const whereClause = {
      labId: parseInt(labId),
      isArchived: false,
    };

    // If lab mentor, only see bookings assigned to them
    if (userRole === "PEER_MENTOR" && mentorType === "LAB") {
      whereClause.labMentorId = userId;
    }

    const bookings = await prisma.booking.findMany({
      where: whereClause,
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, name: true } },
        equipment: {
          include: {
            equipment: { select: { id: true, name: true, description: true } },
          },
        },
        labMentor: { select: { id: true, name: true, email: true } },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
      orderBy: { startDate: "asc" },
    });

    const formattedBookings = bookings.map((booking) => ({
      id: booking.id,
      student: booking.user ? booking.user.name : "[Deleted Account]",
      studentEmail: booking.user ? booking.user.email : "[Deleted]",
      studentId: booking.user ? booking.user.id : null,
      project: booking.project.name,
      projectId: booking.project.id,
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
        description: be.equipment.description,
      })),
      labMentor: booking.labMentor
        ? {
            id: booking.labMentor.id,
            name: booking.labMentor.name,
            email: booking.labMentor.email,
          }
        : null,
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      bookingOwnerId: booking.userId,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get lab bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
