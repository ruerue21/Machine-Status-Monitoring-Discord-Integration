module.exports = async (req, res, prisma) => {
  try {
    const userId = req.user.userId;
    const { status, upcoming, sortOrder } = req.query;

    if (!userId) {
      return res
        .status(401)
        .json({ message: "Invalid token: user ID missing" });
    }

    const whereClause = {
      userId,
      isArchived: false,
    };

    if (status && status !== "ALL") {
      whereClause.status = status;
    }

    if (upcoming === "true") {
      whereClause.startDate = { gte: new Date() };
    }

    const bookings = await prisma.booking.findMany({
      where: whereClause,
      include: {
        project: {
          select: {
            id: true,
            name: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        labMentor: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
      orderBy: { startDate: sortOrder === "asc" ? "asc" : "desc" },
    });

    const formattedBookings = bookings.map((booking) => ({
      id: booking.id,
      project: {
        id: booking.project.id,
        name: booking.project.name,
      },
      lab: {
        id: booking.lab.id,
        name: booking.lab.name,
        location: booking.lab.location,
      },
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
      })),
      labMentor: booking.labMentor
        ? {
            id: booking.labMentor.id,
            name: booking.labMentor.name,
            email: booking.labMentor.email,
          }
        : null,
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      cancelledBy: booking.cancelledBy,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get my bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
