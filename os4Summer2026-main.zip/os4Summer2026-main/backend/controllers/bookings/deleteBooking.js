const { formatUserName } = require("../../utils/roleHelpers");
const { canManageBooking } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const { bookingId } = req.params;
    const parsedBookingId = parseInt(bookingId);
    if (!Number.isInteger(parsedBookingId)) {
      return res.status(400).json({ message: "Invalid booking ID" });
    }

    const booking = await prisma.booking.findUnique({
      where: { id: parsedBookingId },
      include: {
        user: { select: { name: true, email: true } },
        project: { select: { name: true } },
        timeSlot: { select: { id: true } },
      },
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }
    const hasPermission = await canManageBooking(
      prisma,
      req.userDetails,
      booking,
    );
    if (!hasPermission) {
      return res.status(403).json({ message: "Permission denied" });
    }

    // Delete booking and free time slot in transaction
    await prisma.$transaction(async (tx) => {
      // Free time slot if exists
      if (booking.timeSlotId) {
        await tx.timeSlot.update({
          where: { id: booking.timeSlotId },
          data: { isBooked: false },
        });
      }

      // Delete booking (cascade will delete BookingEquipment)
      await tx.booking.delete({
        where: { id: parsedBookingId },
      });
    });

    res.json({
      message: "Booking deleted successfully",
      deletedBooking: {
        id: booking.id,
        student: formatUserName(booking.user),
        project: booking.project.name,
      },
    });
  } catch (error) {
    console.error("Delete booking error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
