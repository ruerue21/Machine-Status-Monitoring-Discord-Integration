const { getAccessibleBookingLabIds } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const userRole = req.userDetails.role;
    const accessibleLabIds = await getAccessibleBookingLabIds(
      prisma,
      req.userDetails,
    );

    let whereScope = { isArchived: false };
    if (userRole !== "ADMIN") {
      whereScope =
        accessibleLabIds && accessibleLabIds.length > 0
          ? { isArchived: false, labId: { in: accessibleLabIds } }
          : { isArchived: false, id: -1 };
    }

    const [stats, upcoming] = await Promise.all([
      prisma.booking.groupBy({
        by: ["status"],
        where: whereScope,
        _count: { id: true },
      }),
      prisma.booking.count({
        where: {
          ...whereScope,
          status: "CONFIRMED",
          startDate: { gte: new Date() },
        },
      }),
    ]);

    const formattedStats = {
      total: 0,
      confirmed: 0,
      completed: 0,
      cancelled: 0,
      absent: 0,
      upcoming,
    };

    stats.forEach((stat) => {
      const count = stat._count.id;
      formattedStats.total += count;

      switch (stat.status) {
        case "CONFIRMED":
          formattedStats.confirmed = count;
          break;
        case "COMPLETED":
          formattedStats.completed = count;
          break;
        case "CANCELLED":
          formattedStats.cancelled = count;
          break;
        case "ABSENT":
          formattedStats.absent = count;
          break;
        default:
          break;
      }
    });

    res.json({ stats: formattedStats });
  } catch (error) {
    console.error("Get booking stats error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
