module.exports = async (req, res, prisma) => {
  try {
    const userId = req.userDetails.id;
    const role = req.userDetails.role;
    const mentorType = req.userDetails.mentorType;

    // Validate that user is a lab mentor
    if (role !== "PEER_MENTOR" || mentorType !== "LAB") {
      return res.status(403).json({ message: "Access denied" });
    }

    const bookings = await prisma.booking.findMany({
      where: {
        labMentorId: userId,
        isArchived: false,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        project: {
          select: {
            id: true,
            name: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
                description: true,
              },
            },
          },
        },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
      orderBy: { startDate: "asc" },
    });

    const formattedBookings = bookings.map((booking) => ({
      id: booking.id,
      student: booking.user
        ? {
            id: booking.user.id,
            name: booking.user.name,
            email: booking.user.email,
          }
        : {
            id: null,
            name: "[Deleted Account]",
            email: "[Deleted]",
          },
      project: {
        id: booking.project.id,
        name: booking.project.name,
      },
      lab: {
        id: booking.lab.id,
        name: booking.lab.name,
        location: booking.lab.location,
      },
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
        description: be.equipment.description,
      })),
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get my lab bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
