const {
  notifyLabSessionUpdated,
  notifyLabSessionStatusChanged,
} = require("../../services/notificationService");
const { canManageBooking } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const { bookingId } = req.params;
    const { status, timeSlotId, notes } = req.body;
    const parsedBookingId = parseInt(bookingId);
    const userRole = req.userDetails.role;
    const requesterId = req.userDetails.id;
    const allowedStatuses = ["CONFIRMED", "COMPLETED", "CANCELLED", "ABSENT"];
    if (!Number.isInteger(parsedBookingId)) {
      return res.status(400).json({ message: "Invalid booking ID" });
    }

    const booking = await prisma.booking.findUnique({
      where: { id: parsedBookingId },
      include: {
        user: { select: { name: true, email: true } },
        project: { select: { name: true } },
        timeSlot: { select: { id: true } },
      },
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }
    const hasPermission = await canManageBooking(
      prisma,
      req.userDetails,
      booking,
    );
    if (!hasPermission) {
      return res.status(403).json({ message: "Permission denied" });
    }
    if (booking.isArchived) {
      return res
        .status(400)
        .json({ message: "Archived bookings cannot be edited" });
    }

    const updateData = {};
    let shouldReleaseTimeSlot = false;
    const warnings = [];

    if (status) {
      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({ message: "Invalid booking status" });
      }
      if (status === "CONFIRMED" && booking.status !== "CONFIRMED") {
        return res.status(400).json({
          message:
            "This booking can no longer be set back to confirmed. Please use completed, cancelled, or absent.",
        });
      }
      updateData.status = status;

      // If changing status to CANCELLED, track who cancelled it
      if (status === "CANCELLED" && booking.status !== "CANCELLED") {
        updateData.cancelledBy = req.userDetails.id;
      }

      // Check if we should release the time slot
      const statusChangingFromActive =
        booking.status === "CONFIRMED" && status !== "CONFIRMED";

      const bookingNotStartedYet = new Date(booking.startDate) > new Date();

      if (
        statusChangingFromActive &&
        bookingNotStartedYet &&
        booking.timeSlotId
      ) {
        shouldReleaseTimeSlot = true;
        warnings.push(
          `Time slot released early - booking was ${status.toLowerCase()} before scheduled time`,
        );
      }
    }

    if (notes !== undefined) {
      if (typeof notes !== "string") {
        return res.status(400).json({ message: "Invalid notes value" });
      }
      if (notes.length > 1000) {
        return res
          .status(400)
          .json({ message: "Notes must be 1000 characters or less" });
      }
      updateData.notes = notes.trim();
    }

    // Handle time slot change
    if (
      timeSlotId !== undefined &&
      parseInt(timeSlotId) !== booking.timeSlot?.id
    ) {
      const parsedTimeSlotId = parseInt(timeSlotId);
      if (!Number.isInteger(parsedTimeSlotId)) {
        return res.status(400).json({ message: "Invalid time slot" });
      }

      // Verify new time slot
      const newTimeSlot = await prisma.timeSlot.findUnique({
        where: { id: parsedTimeSlotId },
        include: {
          mentor: { select: { id: true, name: true } },
        },
      });

      if (!newTimeSlot) {
        return res.status(400).json({ message: "Invalid time slot" });
      }

      if (newTimeSlot.isBooked && newTimeSlot.id !== booking.timeSlotId) {
        return res.status(400).json({ message: "Time slot is already booked" });
      }
      if (newTimeSlot.labId !== booking.labId) {
        return res.status(400).json({
          message: "Time slot does not belong to this booking's lab",
        });
      }
      if (userRole === "PEER_MENTOR" && newTimeSlot.mentorId !== requesterId) {
        return res.status(403).json({
          message:
            "Peer mentors can only assign sessions to time slots assigned to them",
        });
      }
      if (newTimeSlot.slotType !== "LAB") {
        return res.status(400).json({
          message: "Only lab session time slots can be assigned to bookings",
        });
      }
      const dateString = newTimeSlot.date.toISOString().split("T")[0];
      const nextStartDate = new Date(`${dateString}T${newTimeSlot.startTime}`);
      const nextEndDate = new Date(`${dateString}T${newTimeSlot.endTime}`);

      // Update booking and time slots in transaction
      await prisma.$transaction(async (tx) => {
        // Reserve new time slot atomically to prevent concurrent double-booking
        const reservation = await tx.timeSlot.updateMany({
          where: {
            id: newTimeSlot.id,
            isBooked: false,
          },
          data: { isBooked: true },
        });
        if (reservation.count === 0) {
          throw new Error("Time slot is already booked");
        }

        // Free old time slot only after new reservation succeeds
        if (booking.timeSlotId) {
          await tx.timeSlot.update({
            where: { id: booking.timeSlotId },
            data: { isBooked: false },
          });
        }

        // Update booking with new time slot and lab mentor
        await tx.booking.update({
          where: { id: parsedBookingId },
          data: {
            ...updateData,
            timeSlotId: newTimeSlot.id,
            labMentorId: newTimeSlot.mentorId,
            startDate: nextStartDate,
            endDate: nextEndDate,
          },
        });
      });
    } else if (shouldReleaseTimeSlot) {
      // Release time slot if status changed from confirmed to something else
      await prisma.$transaction(async (tx) => {
        // Free time slot
        if (booking.timeSlotId) {
          await tx.timeSlot.update({
            where: { id: booking.timeSlotId },
            data: { isBooked: false },
          });
        }

        // Update booking (remove time slot association)
        await tx.booking.update({
          where: { id: parsedBookingId },
          data: {
            ...updateData,
            timeSlotId: null,
            labMentorId: null,
          },
        });
      });
    } else {
      // Simple update without time slot changes
      await prisma.booking.update({
        where: { id: parsedBookingId },
        data: updateData,
      });
    }

    // Get updated booking
    const updatedBooking = await prisma.booking.findUnique({
      where: { id: parsedBookingId },
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, name: true } },
        lab: { select: { id: true, name: true, location: true } },
        equipment: {
          include: {
            equipment: { select: { id: true, name: true } },
          },
        },
        labMentor: { select: { id: true, name: true, email: true } },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
    });

    // Determine if we should send update or status change notification
    const previousMentorId = timeSlotId ? booking.labMentorId : null;

    if (status && status !== booking.status) {
      // Status changed - send status change notification
      notifyLabSessionStatusChanged(
        parsedBookingId,
        status,
        booking.status,
      ).catch((err) => {
        console.error(
          "Failed to send booking status change notifications:",
          err,
        );
      });
    } else if (timeSlotId || notes !== undefined) {
      // Time slot or notes updated - send update notification
      notifyLabSessionUpdated(parsedBookingId, previousMentorId).catch(
        (err) => {
          console.error("Failed to send booking update notifications:", err);
        },
      );
    }

    res.json({
      message: "Booking updated successfully",
      warnings: warnings.length > 0 ? warnings : undefined,
      booking: {
        id: updatedBooking.id,
        student: updatedBooking.user
          ? updatedBooking.user.name
          : "[Deleted Account]",
        project: updatedBooking.project.name,
        lab: updatedBooking.lab.name,
        startDate: updatedBooking.startDate,
        endDate: updatedBooking.endDate,
        status: updatedBooking.status,
        equipment: updatedBooking.equipment.map((be) => ({
          id: be.equipment.id,
          name: be.equipment.name,
        })),
        labMentor: updatedBooking.labMentor,
        timeSlot: updatedBooking.timeSlot,
        notes: updatedBooking.notes,
        updatedAt: updatedBooking.updatedAt,
      },
    });
  } catch (error) {
    console.error("Update booking error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
