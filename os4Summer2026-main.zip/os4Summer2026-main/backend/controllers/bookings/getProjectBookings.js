module.exports = async (req, res, prisma) => {
  try {
    const { projectId } = req.params;
    const parsedProjectId = parseInt(projectId, 10);
    const userRole = req.userDetails?.role;
    const userId = req.userDetails?.id;
    const assignedLabIds = (req.userDetails?.labAssignments || []).map(
      (assignment) => assignment.labId,
    );

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const project = await prisma.project.findUnique({
      where: { id: parsedProjectId },
      select: { id: true, userId: true, labId: true },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const isAdminOrSupervisor = ["ADMIN", "SUPERVISOR"].includes(userRole);
    const isProjectOwner = project.userId === userId;
    const isAssignedPeerMentor =
      userRole === "PEER_MENTOR" && assignedLabIds.includes(project.labId);

    if (!isAdminOrSupervisor && !isProjectOwner && !isAssignedPeerMentor) {
      return res.status(403).json({ message: "Access denied" });
    }

    const bookings = await prisma.booking.findMany({
      where: {
        projectId: parsedProjectId,
        isArchived: false,
      },
      include: {
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
                description: true,
              },
            },
          },
        },
        labMentor: {
          select: { id: true, name: true, email: true },
        },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
      orderBy: { startDate: "asc" },
    });

    const formattedBookings = bookings.map((booking) => ({
      id: booking.id,
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      lab: {
        id: booking.lab.id,
        name: booking.lab.name,
        location: booking.lab.location,
      },
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
        description: be.equipment.description,
      })),
      labMentor: booking.labMentor
        ? {
            id: booking.labMentor.id,
            name: booking.labMentor.name,
            email: booking.labMentor.email,
          }
        : null,
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get project bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
