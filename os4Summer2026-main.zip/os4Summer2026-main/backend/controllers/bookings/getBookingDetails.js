const { getAccessibleBookingLabIds } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const { bookingId } = req.params;
    const userRole = req.userDetails.role;
    const userId = req.userDetails.id;

    const booking = await prisma.booking.findUnique({
      where: { id: parseInt(bookingId) },
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, name: true, description: true } },
        lab: {
          select: { id: true, name: true, location: true, description: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { id: true, name: true, description: true, status: true },
            },
          },
        },
        labMentor: { select: { id: true, name: true, email: true } },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Permission checks:
    const isOwner = booking.userId === userId;
    const accessibleLabIds = await getAccessibleBookingLabIds(
      prisma,
      req.userDetails,
    );
    const isEmployeeWithLabAccess =
      userRole === "ADMIN" ||
      (Array.isArray(accessibleLabIds) &&
        accessibleLabIds.includes(booking.labId));

    if (!isOwner && !isEmployeeWithLabAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    let cancellerInfo = null;
    if (booking.cancelledBy) {
      const canceller = await prisma.user.findUnique({
        where: { id: booking.cancelledBy },
        select: { id: true, name: true, email: true, role: true },
      });
      if (canceller) {
        cancellerInfo = {
          id: canceller.id,
          name: canceller.name,
          email: canceller.email,
          role: canceller.role,
        };
      }
    }

    const formattedBooking = {
      id: booking.id,
      student: booking.user
        ? {
            id: booking.user.id,
            name: booking.user.name,
            email: booking.user.email,
          }
        : {
            id: null,
            name: "[Deleted Account]",
            email: "[Deleted]",
          },
      project: {
        id: booking.project.id,
        name: booking.project.name,
        description: booking.project.description,
      },
      lab: {
        id: booking.lab.id,
        name: booking.lab.name,
        location: booking.lab.location,
        description: booking.lab.description,
      },
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
        description: be.equipment.description,
        status: be.equipment.status,
      })),
      labMentor: booking.labMentor
        ? {
            id: booking.labMentor.id,
            name: booking.labMentor.name,
            email: booking.labMentor.email,
          }
        : null,
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      cancelledBy: cancellerInfo,
      bookingOwnerId: booking.userId,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    };

    res.json({ booking: formattedBooking });
  } catch (error) {
    console.error("Get booking details error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
