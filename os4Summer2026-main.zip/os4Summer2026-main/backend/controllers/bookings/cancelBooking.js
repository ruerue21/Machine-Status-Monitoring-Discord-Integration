const {
  notifyLabSessionStatusChanged,
} = require("../../services/notificationService");

module.exports = async (req, res, prisma) => {
  try {
    const { bookingId } = req.params;
    const parsedBookingId = parseInt(bookingId, 10);
    const { cancellationReason } = req.body;
    const userId = req.user.userId;

    if (!Number.isInteger(parsedBookingId)) {
      return res.status(400).json({ message: "Invalid booking ID" });
    }

    // Find the booking
    const booking = await prisma.booking.findUnique({
      where: { id: parsedBookingId },
      include: {
        timeSlot: {
          select: { id: true },
        },
      },
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    // Verify ownership
    if (booking.userId !== userId) {
      return res.status(403).json({ message: "Not authorized" });
    }

    // Verify booking can be cancelled
    if (booking.status !== "CONFIRMED") {
      return res
        .status(400)
        .json({ message: "Only confirmed bookings can be cancelled" });
    }

    // Update booking and free time slot in transaction
    await prisma.$transaction(async (tx) => {
      // Free time slot if exists
      if (booking.timeSlotId) {
        await tx.timeSlot.update({
          where: { id: booking.timeSlotId },
          data: { isBooked: false },
        });
      }

      // Cancel booking
      await tx.booking.update({
        where: { id: parsedBookingId },
        data: {
          status: "CANCELLED",
          cancellationReason: cancellationReason || "Cancelled by student",
        },
      });
    });

    // Send notification asynchronously
    notifyLabSessionStatusChanged(
      parsedBookingId,
      "CANCELLED",
      "CONFIRMED",
    ).catch((err) => {
      console.error("Failed to send booking cancellation notifications:", err);
    });

    res.json({ message: "Booking cancelled successfully" });
  } catch (error) {
    console.error("Cancel booking error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
