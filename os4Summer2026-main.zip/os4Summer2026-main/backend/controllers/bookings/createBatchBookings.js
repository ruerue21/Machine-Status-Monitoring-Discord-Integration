const {
  notifyBatchLabSessionsCreated,
} = require("../../services/notificationService");
const { sanitizeText, validateMaxLength } = require("../../utils/sanitization");
const { runSerializableTransaction } = require("../../utils/transaction");
const { getAccessibleBookingLabIds } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const { projectId, bookings, bookingSlots, notes: defaultNotes } = req.body;
    const requesterId = req.userDetails?.id ?? null;
    const userRole = req.userDetails?.role || "ADMIN";
    const isAdmin = userRole === "ADMIN";
    const parsedProjectId = parseInt(projectId);
    const hasBookingsArray = Array.isArray(bookings) && bookings.length > 0;
    const hasBookingSlotsArray =
      Array.isArray(bookingSlots) && bookingSlots.length > 0;

    // Validate required fields
    if (!projectId || (!hasBookingsArray && !hasBookingSlotsArray)) {
      return res.status(400).json({ message: "Invalid request data" });
    }
    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    // Validate project exists and is approved
    const project = await prisma.project.findUnique({
      where: { id: parsedProjectId },
      include: {
        user: { select: { id: true, name: true, email: true } },
        lab: { select: { id: true, name: true, location: true } },
        equipment: {
          include: {
            equipment: { select: { id: true, name: true, status: true } },
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (project.status !== "APPROVED") {
      return res
        .status(400)
        .json({ message: "Project must be approved to create bookings" });
    }

    const accessibleLabIds = isAdmin
      ? null
      : await getAccessibleBookingLabIds(prisma, req.userDetails || {});

    if (
      Array.isArray(accessibleLabIds) &&
      !accessibleLabIds.includes(project.lab.id)
    ) {
      return res.status(403).json({
        message:
          "You do not have permission to create sessions for this project",
      });
    }

    const createdBookingIds = [];

    // Create bookings in a transaction
    const createdBookings = await runSerializableTransaction(
      prisma,
      async (tx) => {
        const results = [];
        let normalizedBookings = bookings;

        // Backward compatibility: accept legacy `bookingSlots` payload from frontend
        if (!hasBookingsArray && hasBookingSlotsArray) {
          const slotIds = bookingSlots.map((slot) => parseInt(slot.timeSlotId));
          const timeSlots = await tx.timeSlot.findMany({
            where: {
              id: { in: slotIds },
              slotType: "LAB",
            },
            select: {
              id: true,
              labId: true,
              date: true,
              startTime: true,
              endTime: true,
            },
          });

          const timeSlotMap = new Map(timeSlots.map((slot) => [slot.id, slot]));

          normalizedBookings = bookingSlots.map((slot) => {
            const parsedTimeSlotId = parseInt(slot.timeSlotId);
            const matchedTimeSlot = timeSlotMap.get(parsedTimeSlotId);

            if (!matchedTimeSlot) {
              throw new Error(`Invalid time slot: ${slot.timeSlotId}`);
            }

            const dateString = matchedTimeSlot.date.toISOString().split("T")[0];

            return {
              timeSlotId: parsedTimeSlotId,
              labId: matchedTimeSlot.labId,
              startDate: new Date(
                `${dateString}T${matchedTimeSlot.startTime}`,
              ).toISOString(),
              endDate: new Date(
                `${dateString}T${matchedTimeSlot.endTime}`,
              ).toISOString(),
              equipmentIds: Array.isArray(slot.equipmentIds)
                ? slot.equipmentIds
                : [],
              notes: slot.notes ?? defaultNotes ?? null,
            };
          });
        }

        const requestedLabIds = Array.from(
          new Set(normalizedBookings.map((booking) => parseInt(booking.labId))),
        ).filter((id) => Number.isInteger(id));

        if (
          Array.isArray(accessibleLabIds) &&
          requestedLabIds.some((labId) => !accessibleLabIds.includes(labId))
        ) {
          throw new Error(
            "You do not have permission to create sessions for one or more labs",
          );
        }

        const labMap = new Map();
        if (
          requestedLabIds.length > 0 &&
          typeof tx.lab.findMany === "function"
        ) {
          const labs = await tx.lab.findMany({
            where: { id: { in: requestedLabIds } },
            select: {
              id: true,
              name: true,
              location: true,
              isActive: true,
              unavailableUntil: true,
              deactivationNever: true,
            },
          });
          labs.forEach((lab) => labMap.set(lab.id, lab));
        }

        const requestedTimeSlotIds = Array.from(
          new Set(
            normalizedBookings
              .map((booking) =>
                booking.timeSlotId !== undefined && booking.timeSlotId !== null
                  ? parseInt(booking.timeSlotId)
                  : null,
              )
              .filter((id) => Number.isInteger(id)),
          ),
        );
        const timeSlotMap = new Map();
        if (
          requestedTimeSlotIds.length > 0 &&
          typeof tx.timeSlot.findMany === "function"
        ) {
          const timeSlots = await tx.timeSlot.findMany({
            where: { id: { in: requestedTimeSlotIds } },
            include: {
              mentor: { select: { id: true, name: true, email: true } },
            },
          });
          timeSlots.forEach((slot) => timeSlotMap.set(slot.id, slot));
        }

        for (const bookingData of normalizedBookings) {
          const { startDate, endDate, labId, equipmentIds, timeSlotId, notes } =
            bookingData;
          const parsedLabId = parseInt(labId);

          // Validate required fields for each booking
          if (!startDate || !endDate || !labId) {
            throw new Error("Missing required booking fields");
          }
          if (!Number.isInteger(parsedLabId)) {
            throw new Error("Invalid lab ID");
          }

          const startDateTime = new Date(startDate);
          const endDateTime = new Date(endDate);
          if (
            Number.isNaN(startDateTime.getTime()) ||
            Number.isNaN(endDateTime.getTime()) ||
            endDateTime <= startDateTime
          ) {
            throw new Error("Invalid booking date range");
          }

          // Validate lab exists
          const lab =
            labMap.get(parsedLabId) ||
            (await tx.lab.findUnique({
              where: { id: parsedLabId },
              select: { id: true, name: true, location: true },
            }));

          if (!lab) {
            throw new Error(`Lab not found: ${labId}`);
          }
          if (!lab.isActive) {
            if (lab.deactivationNever) {
              throw new Error(
                `Lab is unavailable indefinitely and cannot accept new sessions: ${lab.name}`,
              );
            }
            if (
              lab.unavailableUntil &&
              startDateTime < new Date(lab.unavailableUntil)
            ) {
              throw new Error(
                `Lab "${lab.name}" is unavailable until ${new Date(
                  lab.unavailableUntil,
                ).toLocaleString()}.`,
              );
            }
          }

          // Check for duplicate/overlapping bookings
          const overlappingBooking = await tx.booking.findFirst({
            where: {
              projectId: parsedProjectId,
              labId: parsedLabId,
              status: "CONFIRMED", // Only check CONFIRMED bookings
              isArchived: false,
              AND: [
                { startDate: { lt: endDateTime } },
                { endDate: { gt: startDateTime } },
              ],
            },
          });

          if (overlappingBooking) {
            const overlapStart = overlappingBooking.startDate
              .toISOString()
              .split("T")[0];
            const overlapEnd = overlappingBooking.endDate
              .toISOString()
              .split("T")[0];
            throw new Error(
              `Overlapping booking exists from ${overlapStart} to ${overlapEnd}`,
            );
          }

          // Validate time slot if provided
          let timeSlot = null;
          if (timeSlotId) {
            const parsedTimeSlotId = parseInt(timeSlotId);
            if (!Number.isInteger(parsedTimeSlotId)) {
              throw new Error(`Invalid time slot: ${timeSlotId}`);
            }
            timeSlot =
              timeSlotMap.get(parsedTimeSlotId) ||
              (await tx.timeSlot.findUnique({
                where: { id: parsedTimeSlotId },
                include: {
                  mentor: { select: { id: true, name: true, email: true } },
                },
              }));

            if (
              timeSlot &&
              (timeSlot.slotType === undefined ||
                timeSlot.isBooked === undefined ||
                timeSlot.mentorId === undefined)
            ) {
              timeSlot = await tx.timeSlot.findUnique({
                where: { id: parsedTimeSlotId },
                include: {
                  mentor: { select: { id: true, name: true, email: true } },
                },
              });
            }

            if (!timeSlot) {
              throw new Error(`Invalid time slot: ${timeSlotId}`);
            }

            if (
              userRole === "PEER_MENTOR" &&
              req.userDetails?.mentorType === "LAB" &&
              timeSlot.mentorId !== requesterId
            ) {
              throw new Error(
                `Peer mentors can only create sessions for their own assigned time slots`,
              );
            }

            if (timeSlot.isBooked) {
              throw new Error(`Time slot already booked: ${timeSlotId}`);
            }

            if (timeSlot.labId !== parsedLabId || timeSlot.slotType !== "LAB") {
              throw new Error(`Time slot does not belong to lab: ${labId}`);
            }

            // Mark time slot as booked
            if (typeof tx.timeSlot.updateMany === "function") {
              const reservation = await tx.timeSlot.updateMany({
                where: {
                  id: timeSlot.id,
                  isBooked: false,
                },
                data: { isBooked: true },
              });
              if (reservation.count === 0) {
                throw new Error(`Time slot already booked: ${timeSlotId}`);
              }
            } else {
              await tx.timeSlot.update({
                where: { id: timeSlot.id },
                data: { isBooked: true },
              });
            }
          }

          // Validate equipment if provided
          let validEquipmentIds = [];
          if (
            equipmentIds &&
            Array.isArray(equipmentIds) &&
            equipmentIds.length > 0
          ) {
            const requestedEquipmentIds = equipmentIds.map((id) =>
              parseInt(id),
            );

            // Check if equipment exists and is AVAILABLE
            const equipments = await tx.equipment.findMany({
              where: {
                id: { in: requestedEquipmentIds },
                labId: parsedLabId,
                isActive: true,
                status: "AVAILABLE",
              },
              select: { id: true, name: true },
            });

            if (equipments.length !== requestedEquipmentIds.length) {
              throw new Error(
                "Some equipment items are invalid, unavailable, or not in this lab",
              );
            }

            // Check if any equipment is already booked during this time period
            const conflictingBookings = await tx.booking.findMany({
              where: {
                labId: parsedLabId,
                status: "CONFIRMED",
                isArchived: false,
                AND: [
                  { startDate: { lt: endDateTime } },
                  { endDate: { gt: startDateTime } },
                ],
                equipment: {
                  some: {
                    equipmentId: { in: requestedEquipmentIds },
                  },
                },
              },
              include: {
                equipment: {
                  where: {
                    equipmentId: { in: requestedEquipmentIds },
                  },
                  include: {
                    equipment: {
                      select: { id: true, name: true },
                    },
                  },
                },
              },
            });

            if (conflictingBookings.length > 0) {
              const conflictingEquipment =
                conflictingBookings[0].equipment[0].equipment;
              const conflictStart = conflictingBookings[0].startDate
                .toISOString()
                .split("T")[0];
              const conflictEnd = conflictingBookings[0].endDate
                .toISOString()
                .split("T")[0];

              throw new Error(
                `Equipment "${conflictingEquipment.name}" is already booked from ${conflictStart} to ${conflictEnd}`,
              );
            }

            validEquipmentIds = equipments.map((eq) => eq.id);
          }

          if (notes && !validateMaxLength(notes, 1000)) {
            throw new Error("Notes must be 1000 characters or less");
          }

          // Create booking
          const created = await tx.booking.create({
            data: {
              userId: project.userId,
              projectId: parsedProjectId,
              labId: parsedLabId,
              startDate: new Date(startDate),
              endDate: new Date(endDate),
              status: "CONFIRMED",
              notes: typeof notes === "string" ? sanitizeText(notes) : null,
              timeSlotId: timeSlot ? timeSlot.id : null,
              labMentorId: timeSlot ? timeSlot.mentorId : null,
              equipment: validEquipmentIds.length
                ? {
                    create: validEquipmentIds.map((equipmentId) => ({
                      equipmentId,
                    })),
                  }
                : undefined,
            },
            include: {
              user: { select: { id: true, name: true, email: true } },
              project: { select: { id: true, name: true } },
              lab: { select: { id: true, name: true, location: true } },
              equipment: {
                include: {
                  equipment: { select: { id: true, name: true } },
                },
              },
              labMentor: { select: { id: true, name: true, email: true } },
              timeSlot: {
                select: {
                  id: true,
                  date: true,
                  startTime: true,
                  endTime: true,
                },
              },
            },
          });

          createdBookingIds.push(created.id);
          results.push(created);
        }

        return results;
      },
    );

    // Send batch notifications asynchronously
    notifyBatchLabSessionsCreated(createdBookingIds).catch((err) => {
      console.error("Failed to send batch lab session notifications:", err);
    });

    res.status(201).json({
      message: "Bookings created successfully",
      bookingCount: createdBookings.length,
      bookingIds: createdBookingIds,
      bookings: createdBookings.map((booking) => ({
        id: booking.id,
        student: booking.user ? booking.user.name : "[Deleted Account]",
        project: booking.project.name,
        lab: booking.lab.name,
        startDate: booking.startDate,
        endDate: booking.endDate,
        status: booking.status,
        equipment: booking.equipment.map((be) => ({
          id: be.equipment.id,
          name: be.equipment.name,
        })),
        labMentor: booking.labMentor,
        timeSlot: booking.timeSlot,
        notes: booking.notes,
      })),
    });
  } catch (error) {
    console.error("Create batch bookings error:", error);
    const safeClientErrorPrefixes = [
      "Invalid time slot",
      "Time slot already booked",
      "Time slot does not belong to lab",
      "You do not have permission",
      "Peer mentors can only create sessions",
      "Lab not found",
      "Lab is unavailable indefinitely and cannot accept new sessions",
      'Lab "',
      "Overlapping booking exists",
      "Some equipment items are invalid",
      'Equipment "',
      "Missing required booking fields",
      "Invalid lab ID",
      "Notes must be 1000 characters or less",
      "Invalid booking date range",
    ];

    const isClientError = safeClientErrorPrefixes.some((prefix) =>
      error.message?.startsWith(prefix),
    );

    if (isClientError) {
      const statusCode =
        error.message?.startsWith("You do not have permission") ||
        error.message?.startsWith("Peer mentors can only create sessions")
          ? 403
          : 400;
      return res.status(statusCode).json({ message: error.message });
    }
    if (
      error.code === "P2034" ||
      (typeof error.message === "string" &&
        error.message.toLowerCase().includes("could not serialize"))
    ) {
      return res.status(409).json({
        message:
          "Booking conflicts detected from concurrent requests. Please retry.",
      });
    }

    res.status(500).json({ message: "Server error" });
  }
};
