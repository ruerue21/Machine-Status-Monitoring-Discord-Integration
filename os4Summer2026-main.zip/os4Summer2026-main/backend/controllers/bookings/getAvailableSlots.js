const { getAccessibleBookingLabIds } = require("../../utils/bookingAccess");

module.exports = async (req, res, prisma) => {
  try {
    const { labId } = req.params;
    const { startDate, endDate } = req.query;
    const parsedLabId = parseInt(labId, 10);

    if (!Number.isInteger(parsedLabId)) {
      return res.status(400).json({ message: "Invalid lab ID" });
    }

    const parsedStartDate = startDate ? new Date(startDate) : new Date();
    const parsedEndDate = endDate ? new Date(endDate) : null;

    if (Number.isNaN(parsedStartDate.getTime())) {
      return res.status(400).json({ message: "Invalid startDate" });
    }
    if (parsedEndDate && Number.isNaN(parsedEndDate.getTime())) {
      return res.status(400).json({ message: "Invalid endDate" });
    }
    if (parsedEndDate && parsedEndDate < parsedStartDate) {
      return res.status(400).json({
        message: "endDate must be greater than or equal to startDate",
      });
    }

    const accessibleLabIds = await getAccessibleBookingLabIds(
      prisma,
      req.userDetails,
    );
    if (
      Array.isArray(accessibleLabIds) &&
      !accessibleLabIds.includes(parsedLabId)
    ) {
      return res.status(403).json({ message: "Access denied for this lab" });
    }

    const lab = await prisma.lab.findUnique({
      where: { id: parsedLabId },
      select: {
        id: true,
        isActive: true,
        unavailableUntil: true,
        deactivationNever: true,
      },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }
    let minimumSlotDateTime = null;
    if (!lab.isActive) {
      if (lab.deactivationNever) {
        return res.status(400).json({
          message:
            "This lab is unavailable indefinitely. No lab session slots can be created.",
        });
      }
      if (lab.unavailableUntil) {
        minimumSlotDateTime = new Date(lab.unavailableUntil);
      }
    }

    const whereClause = {
      labId: parsedLabId,
      slotType: "LAB",
      isBooked: false,
      date: {
        gte: parsedStartDate,
      },
    };

    if (parsedEndDate) {
      whereClause.date.lte = parsedEndDate;
    }
    if (
      req.userDetails.role === "PEER_MENTOR" &&
      req.userDetails.mentorType === "LAB"
    ) {
      whereClause.mentorId = req.userDetails.id;
    }

    // Get available time slots with mentor info
    const availableSlots = await prisma.timeSlot.findMany({
      where: whereClause,
      include: {
        mentor: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    const filteredByAvailability = minimumSlotDateTime
      ? availableSlots.filter((slot) => {
          const slotDate = slot.date.toISOString().split("T")[0];
          const slotDateTime = new Date(`${slotDate}T${slot.startTime}`);
          return slotDateTime >= minimumSlotDateTime;
        })
      : availableSlots;

    const formattedSlots = filteredByAvailability.map((slot) => ({
      id: slot.id,
      date: slot.date.toISOString().split("T")[0],
      startTime: slot.startTime,
      endTime: slot.endTime,
      mentor: {
        id: slot.mentor.id,
        name: slot.mentor.name,
        email: slot.mentor.email,
      },
      lab: {
        id: slot.lab.id,
        name: slot.lab.name,
        location: slot.lab.location,
      },
    }));

    res.json({ availableSlots: formattedSlots });
  } catch (error) {
    console.error("Get available slots error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
