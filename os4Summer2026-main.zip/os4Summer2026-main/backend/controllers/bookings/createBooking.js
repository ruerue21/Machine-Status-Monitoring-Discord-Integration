const {
  notifyLabSessionCreated,
} = require("../../services/notificationService");
const { sanitizeText, validateMaxLength } = require("../../utils/sanitization");
const { runSerializableTransaction } = require("../../utils/transaction");

module.exports = async (req, res, prisma) => {
  try {
    const {
      projectId,
      startDate,
      endDate,
      labId,
      equipmentIds,
      timeSlotId,
      notes,
    } = req.body;

    const parsedProjectId = parseInt(projectId);
    const parsedLabId = parseInt(labId);
    const parsedTimeSlotId =
      timeSlotId !== undefined && timeSlotId !== null
        ? parseInt(timeSlotId)
        : null;

    if (!projectId || !startDate || !endDate || !labId) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    if (!Number.isInteger(parsedProjectId) || !Number.isInteger(parsedLabId)) {
      return res.status(400).json({ message: "Invalid project or lab ID" });
    }
    if (
      parsedTimeSlotId !== null &&
      (!Number.isInteger(parsedTimeSlotId) || parsedTimeSlotId <= 0)
    ) {
      return res.status(400).json({ message: "Invalid time slot ID" });
    }

    const startDateTime = new Date(startDate);
    const endDateTime = new Date(endDate);
    if (
      Number.isNaN(startDateTime.getTime()) ||
      Number.isNaN(endDateTime.getTime())
    ) {
      return res.status(400).json({ message: "Invalid booking date range" });
    }
    if (endDateTime <= startDateTime) {
      return res
        .status(400)
        .json({ message: "End date must be after start date" });
    }

    let sanitizedNotes = null;
    if (notes) {
      if (!validateMaxLength(notes, 1000)) {
        return res.status(400).json({
          message: "Notes must be 1000 characters or less",
        });
      }
      sanitizedNotes = sanitizeText(notes);
    }

    const project = await prisma.project.findUnique({
      where: { id: parsedProjectId },
      include: {
        user: { select: { id: true, name: true, email: true } },
        equipment: {
          include: {
            equipment: { select: { id: true, name: true } },
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    if (project.status !== "APPROVED") {
      return res
        .status(400)
        .json({ message: "Project must be approved to create bookings" });
    }

    const lab = await prisma.lab.findUnique({
      where: { id: parsedLabId },
      select: {
        id: true,
        name: true,
        location: true,
        isActive: true,
        unavailableUntil: true,
        deactivationNever: true,
      },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }
    if (!lab.isActive) {
      if (lab.deactivationNever) {
        return res.status(400).json({
          message:
            "This lab is unavailable indefinitely. New lab sessions cannot be created.",
        });
      }
      if (
        lab.unavailableUntil &&
        startDateTime < new Date(lab.unavailableUntil)
      ) {
        return res.status(400).json({
          message: `This lab is unavailable until ${new Date(
            lab.unavailableUntil,
          ).toLocaleString()}. Please choose a session time after that.`,
        });
      }
    }

    const requestedEquipmentIds =
      equipmentIds && Array.isArray(equipmentIds) && equipmentIds.length > 0
        ? equipmentIds.map((id) => parseInt(id))
        : [];
    if (requestedEquipmentIds.some((id) => !Number.isInteger(id))) {
      return res.status(400).json({ message: "Invalid equipment IDs" });
    }

    const booking = await runSerializableTransaction(prisma, async (tx) => {
      const bookingReadModel =
        typeof tx.booking?.findFirst === "function" &&
        typeof tx.booking?.findMany === "function"
          ? tx.booking
          : prisma.booking;
      const equipmentReadModel =
        typeof tx.equipment?.findMany === "function"
          ? tx.equipment
          : prisma.equipment;

      const overlappingBooking = await bookingReadModel.findFirst({
        where: {
          projectId: parsedProjectId,
          labId: parsedLabId,
          status: "CONFIRMED",
          isArchived: false,
          AND: [
            { startDate: { lt: endDateTime } },
            { endDate: { gt: startDateTime } },
          ],
        },
      });

      if (overlappingBooking) {
        const overlapStart = overlappingBooking.startDate
          .toISOString()
          .split("T")[0];
        const overlapEnd = overlappingBooking.endDate
          .toISOString()
          .split("T")[0];
        const err = new Error("Overlapping booking exists");
        err.code = "OVERLAPPING_BOOKING";
        err.existingBookingId = overlappingBooking.id;
        err.overlapStart = overlapStart;
        err.overlapEnd = overlapEnd;
        throw err;
      }

      let validEquipmentIds = [];
      if (requestedEquipmentIds.length > 0) {
        const equipments = await equipmentReadModel.findMany({
          where: {
            id: { in: requestedEquipmentIds },
            labId: parsedLabId,
            isActive: true,
            status: "AVAILABLE",
          },
          select: { id: true, name: true },
        });

        if (equipments.length !== requestedEquipmentIds.length) {
          throw new Error(
            "Some equipment items are invalid, unavailable, or not in this lab",
          );
        }

        const conflictingBookings = await bookingReadModel.findMany({
          where: {
            labId: parsedLabId,
            status: "CONFIRMED",
            isArchived: false,
            AND: [
              { startDate: { lt: endDateTime } },
              { endDate: { gt: startDateTime } },
            ],
            equipment: {
              some: {
                equipmentId: { in: requestedEquipmentIds },
              },
            },
          },
          include: {
            equipment: {
              where: {
                equipmentId: { in: requestedEquipmentIds },
              },
              include: {
                equipment: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        });

        if (conflictingBookings.length > 0) {
          const conflictingEquipment =
            conflictingBookings[0].equipment[0].equipment;
          const conflictStart = conflictingBookings[0].startDate
            .toISOString()
            .split("T")[0];
          const conflictEnd = conflictingBookings[0].endDate
            .toISOString()
            .split("T")[0];
          const err = new Error(
            `Equipment "${conflictingEquipment.name}" is already booked from ${conflictStart} to ${conflictEnd}. Please select different equipment or a different time period.`,
          );
          err.code = "EQUIPMENT_CONFLICT";
          err.conflictingEquipment = conflictingEquipment.name;
          err.conflictingDates = { start: conflictStart, end: conflictEnd };
          throw err;
        }

        validEquipmentIds = equipments.map((eq) => eq.id);
      }

      let timeSlot = null;

      if (parsedTimeSlotId) {
        timeSlot = await tx.timeSlot.findUnique({
          where: { id: parsedTimeSlotId },
          include: {
            mentor: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        });

        if (!timeSlot) {
          throw new Error("Invalid time slot");
        }
        if (timeSlot.isBooked) {
          throw new Error("Time slot is already booked");
        }
        if (timeSlot.labId !== parsedLabId || timeSlot.slotType !== "LAB") {
          throw new Error("Time slot does not belong to selected lab");
        }

        const reservation = await tx.timeSlot.updateMany({
          where: {
            id: timeSlot.id,
            isBooked: false,
          },
          data: { isBooked: true },
        });

        if (reservation.count === 0) {
          throw new Error("Time slot is already booked");
        }
      }

      return tx.booking.create({
        data: {
          userId: project.userId,
          projectId: parsedProjectId,
          labId: parsedLabId,
          startDate: startDateTime,
          endDate: endDateTime,
          status: "CONFIRMED",
          notes: sanitizedNotes,
          timeSlotId: timeSlot ? timeSlot.id : null,
          labMentorId: timeSlot ? timeSlot.mentorId : null,
          equipment: validEquipmentIds.length
            ? {
                create: validEquipmentIds.map((equipmentId) => ({
                  equipmentId,
                })),
              }
            : undefined,
        },
        include: {
          user: { select: { id: true, name: true, email: true } },
          project: { select: { id: true, name: true } },
          lab: { select: { id: true, name: true, location: true } },
          equipment: {
            include: {
              equipment: { select: { id: true, name: true } },
            },
          },
          labMentor: { select: { id: true, name: true, email: true } },
          timeSlot: {
            select: {
              id: true,
              date: true,
              startTime: true,
              endTime: true,
            },
          },
        },
      });
    });

    notifyLabSessionCreated(booking.id).catch((err) => {
      console.error("Failed to send lab session notifications:", err);
    });

    res.status(201).json({
      message: "Booking created successfully",
      booking: {
        id: booking.id,
        student: booking.user ? booking.user.name : "[Deleted Account]",
        project: booking.project.name,
        lab: booking.lab.name,
        startDate: booking.startDate,
        endDate: booking.endDate,
        status: booking.status,
        equipment: booking.equipment.map((be) => ({
          id: be.equipment.id,
          name: be.equipment.name,
        })),
        labMentor: booking.labMentor,
        timeSlot: booking.timeSlot,
        notes: booking.notes,
      },
    });
  } catch (error) {
    console.error("Create booking error:", error);

    if (error.message === "Time slot is already booked") {
      return res.status(400).json({
        message:
          "This time slot was just booked by another user. Please select a different time slot.",
      });
    }
    if (error.message === "Invalid time slot") {
      return res.status(400).json({ message: "Invalid time slot" });
    }
    if (error.message === "Time slot does not belong to selected lab") {
      return res
        .status(400)
        .json({ message: "Time slot does not belong to selected lab" });
    }
    if (error.code === "OVERLAPPING_BOOKING") {
      return res.status(400).json({
        message: `You already have a booking for this project and lab from ${error.overlapStart} to ${error.overlapEnd}. Please cancel or modify the existing booking first.`,
        existingBookingId: error.existingBookingId,
      });
    }
    if (error.code === "EQUIPMENT_CONFLICT") {
      return res.status(400).json({
        message: error.message,
        conflictingEquipment: error.conflictingEquipment,
        conflictingDates: error.conflictingDates,
      });
    }
    if (error.code === "P2034") {
      return res.status(409).json({
        message:
          "Booking conflict detected from concurrent requests. Please retry.",
      });
    }
    if (
      typeof error.message === "string" &&
      error.message.toLowerCase().includes("could not serialize")
    ) {
      return res.status(409).json({
        message:
          "Booking conflict detected from concurrent requests. Please retry.",
      });
    }

    res.status(500).json({ message: "Server error" });
  }
};
