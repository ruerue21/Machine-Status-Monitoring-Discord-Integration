const { formatUserDisplay } = require("../../utils/roleHelpers");
const { getAccessibleBookingLabIds } = require("../../utils/bookingAccess");
const {
  parsePaginationParams,
  createPaginatedResponse,
} = require("../../utils/pagination");

module.exports = async (req, res, prisma) => {
  try {
    const userRole = req.userDetails.role;
    const accessibleLabIds = await getAccessibleBookingLabIds(
      prisma,
      req.userDetails,
    );

    const whereClause = { isArchived: false };
    let orderBy = { startDate: "desc" };
    const validStatuses = new Set([
      "CONFIRMED",
      "COMPLETED",
      "CANCELLED",
      "ABSENT",
    ]);
    const validSortFields = new Set([
      "startDate",
      "endDate",
      "status",
      "createdAt",
      "updatedAt",
    ]);

    const {
      status,
      labId,
      lab,
      projectId,
      studentId,
      student,
      mentorId,
      sort,
      order,
      sortBy,
    } = req.query;

    if (status && status !== "ALL") {
      if (!validStatuses.has(status)) {
        return res.status(400).json({ message: "Invalid status filter" });
      }
      whereClause.status = status;
    }
    if (labId) {
      const parsedLabId = parseInt(labId);
      if (!Number.isInteger(parsedLabId)) {
        return res.status(400).json({ message: "Invalid lab ID filter" });
      }
      whereClause.labId = parsedLabId;
    }
    if (lab && lab !== "ALL") {
      whereClause.lab = {
        name: lab,
      };
    }
    if (projectId) {
      const parsedProjectId = parseInt(projectId);
      if (!Number.isInteger(parsedProjectId)) {
        return res.status(400).json({ message: "Invalid project ID filter" });
      }
      whereClause.projectId = parsedProjectId;
    }
    if (studentId) {
      const parsedStudentId = parseInt(studentId);
      if (!Number.isInteger(parsedStudentId)) {
        return res.status(400).json({ message: "Invalid student ID filter" });
      }
      whereClause.userId = parsedStudentId;
    }
    if (student) {
      whereClause.user = {
        OR: [
          { name: { contains: student, mode: "insensitive" } },
          { email: { contains: student, mode: "insensitive" } },
        ],
      };
    }
    if (mentorId) {
      const parsedMentorId = parseInt(mentorId);
      if (!Number.isInteger(parsedMentorId)) {
        return res.status(400).json({ message: "Invalid mentor ID filter" });
      }
      whereClause.labMentorId = parsedMentorId;
    }

    if (sort) {
      if (!validSortFields.has(sort)) {
        return res.status(400).json({ message: "Invalid sort field" });
      }
      orderBy = { [sort]: order === "asc" ? "asc" : "desc" };
    } else if (sortBy) {
      switch (sortBy) {
        case "oldest":
          orderBy = { startDate: "asc" };
          break;
        case "status":
          orderBy = { status: "asc" };
          break;
        case "student":
          orderBy = { user: { name: "asc" } };
          break;
        case "newest":
        default:
          orderBy = { startDate: "desc" };
          break;
      }
    }

    if (Array.isArray(accessibleLabIds)) {
      if (accessibleLabIds.length === 0) {
        whereClause.id = -1;
      } else if (typeof whereClause.labId === "number") {
        if (!accessibleLabIds.includes(whereClause.labId)) {
          whereClause.id = -1;
        }
      } else {
        whereClause.labId = { in: accessibleLabIds };
      }
    }

    // Parse pagination parameters
    const { page, limit, skip } = parsePaginationParams(req.query);

    // Get total count for pagination
    const total = await prisma.booking.count({
      where: whereClause,
    });

    // Get paginated bookings
    const bookings = await prisma.booking.findMany({
      where: whereClause,
      orderBy,
      skip,
      take: limit,
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, name: true } },
        lab: { select: { id: true, name: true, location: true } },
        equipment: {
          include: {
            equipment: { select: { id: true, name: true, description: true } },
          },
        },
        labMentor: { select: { id: true, name: true, email: true } },
        timeSlot: {
          select: { id: true, date: true, startTime: true, endTime: true },
        },
      },
    });

    const cancelledByIds = bookings
      .filter((b) => b.cancelledBy)
      .map((b) => b.cancelledBy);

    const cancellers =
      cancelledByIds.length > 0
        ? await prisma.user.findMany({
            where: { id: { in: cancelledByIds } },
            select: { id: true, name: true, email: true, role: true },
          })
        : [];

    const cancellerMap = new Map(cancellers.map((c) => [c.id, c]));

    const formattedBookings = bookings.map((booking) => {
      const canceller = booking.cancelledBy
        ? cancellerMap.get(booking.cancelledBy)
        : null;

      const studentDisplay = formatUserDisplay(booking.user);
      const mentorDisplay = formatUserDisplay(booking.labMentor);
      const cancellerDisplay = formatUserDisplay(canceller);

      return {
        id: booking.id,
        student: studentDisplay.name,
        studentEmail: studentDisplay.email,
        studentId: studentDisplay.id,
        project: booking.project.name,
        projectId: booking.project.id,
        lab: booking.lab.name,
        labId: booking.lab.id,
        labLocation: booking.lab.location,
        startDate: booking.startDate,
        endDate: booking.endDate,
        status: booking.status,
        equipment: booking.equipment.map((be) => ({
          id: be.equipment.id,
          name: be.equipment.name,
          description: be.equipment.description,
        })),
        labMentor: booking.labMentor
          ? {
              id: mentorDisplay.id,
              name: mentorDisplay.name,
              email: mentorDisplay.email,
            }
          : null,
        timeSlot: booking.timeSlot,
        notes: booking.notes,
        cancellationReason: booking.cancellationReason,
        cancelledBy: canceller
          ? {
              id: cancellerDisplay.id,
              name: cancellerDisplay.name,
              email: cancellerDisplay.email,
              role: canceller.role,
            }
          : null,
        bookingOwnerId: booking.userId,
        createdAt: booking.createdAt,
        updatedAt: booking.updatedAt,
      };
    });

    res.json(createPaginatedResponse(formattedBookings, total, page, limit));
  } catch (error) {
    console.error("Get all bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
