module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const { status } = req.query;

    const whereClause = { labId: parseInt(labId) };

    if (status && status !== "ALL") {
      whereClause.status = status;
    }

    const equipment = await prisma.equipment.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        description: true,
        status: true,
        isActive: true,
        outOfOrderUntil: true,
        outOfOrderNever: true,
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { name: "asc" },
    });

    res.json({ equipment });
  } catch (error) {
    console.error("Get lab equipment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
