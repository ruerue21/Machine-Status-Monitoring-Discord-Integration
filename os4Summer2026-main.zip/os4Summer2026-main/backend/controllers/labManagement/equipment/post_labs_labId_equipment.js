module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const { name, description, status, outOfOrderUntil, outOfOrderNever } =
      req.body;

    if (typeof name !== "string" || !name.trim()) {
      return res.status(400).json({
        message: "Equipment name is required",
      });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    // Check if equipment with same name already exists in this lab
    const existingEquipment = await prisma.equipment.findFirst({
      where: {
        labId: parseInt(labId),
        name: { equals: name.trim(), mode: "insensitive" },
      },
    });

    if (existingEquipment) {
      return res.status(400).json({
        message: "Equipment with this name already exists in this lab",
      });
    }

    // Validate status
    const validStatuses = ["AVAILABLE", "OUT_OF_ORDER"];
    const equipmentStatus = status || "AVAILABLE";

    if (!validStatuses.includes(equipmentStatus)) {
      return res.status(400).json({
        message: "Invalid equipment status. Must be AVAILABLE or OUT_OF_ORDER",
      });
    }

    if (outOfOrderNever !== undefined && typeof outOfOrderNever !== "boolean") {
      return res.status(400).json({
        message: "outOfOrderNever must be true or false",
      });
    }

    let parsedOutOfOrderUntil = null;
    let resolvedOutOfOrderNever = Boolean(outOfOrderNever);

    if (equipmentStatus === "OUT_OF_ORDER") {
      if (resolvedOutOfOrderNever) {
        parsedOutOfOrderUntil = null;
      } else {
        if (!outOfOrderUntil) {
          return res.status(400).json({
            message:
              'Provide "outOfOrderUntil" or set "outOfOrderNever" to true when status is OUT_OF_ORDER',
          });
        }
        parsedOutOfOrderUntil = new Date(outOfOrderUntil);
        if (Number.isNaN(parsedOutOfOrderUntil.getTime())) {
          return res.status(400).json({
            message: "Invalid outOfOrderUntil date/time",
          });
        }
        if (parsedOutOfOrderUntil <= new Date()) {
          return res.status(400).json({
            message: "Out-of-order end date/time must be in the future",
          });
        }
      }
    } else {
      resolvedOutOfOrderNever = false;
      parsedOutOfOrderUntil = null;
    }

    const createData = {
      labId: parseInt(labId),
      name: name.trim(),
      description: description?.trim() || "",
      status: equipmentStatus,
      isActive: true,
      outOfOrderNever: resolvedOutOfOrderNever,
      outOfOrderUntil: parsedOutOfOrderUntil,
    };

    const newEquipment = await prisma.equipment.create({
      data: createData,
    });

    res.status(201).json({
      message: "Equipment added successfully",
      equipment: newEquipment,
    });
  } catch (error) {
    console.error("Add equipment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
