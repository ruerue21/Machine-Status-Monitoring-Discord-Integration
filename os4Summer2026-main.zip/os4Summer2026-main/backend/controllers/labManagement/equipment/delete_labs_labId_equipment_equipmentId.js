module.exports = async function (req, res, prisma) {
  try {
    const { labId, equipmentId } = req.params;

    const equipment = await prisma.equipment.findUnique({
      where: { id: parseInt(equipmentId) },
    });

    if (!equipment) {
      return res.status(404).json({ message: "Equipment not found" });
    }

    if (equipment.labId !== parseInt(labId)) {
      return res.status(400).json({
        message: "Equipment does not belong to this lab",
      });
    }

    // Check for active usage only
    const [activeProjects, upcomingBookings] = await Promise.all([
      // Active projects using this equipment
      prisma.projectEquipment.count({
        where: {
          equipmentId: parseInt(equipmentId),
          project: {
            status: { in: ["APPROVED", "IN_PROCESS"] },
            isArchived: false,
          },
        },
      }),

      // Upcoming bookings using this equipment
      prisma.bookingEquipment.count({
        where: {
          equipmentId: parseInt(equipmentId),
          booking: {
            status: "CONFIRMED",
            startDate: { gte: new Date() },
            isArchived: false,
          },
        },
      }),
    ]);

    // Build warnings for active usage
    const warnings = [];
    if (activeProjects > 0) {
      warnings.push(
        `${activeProjects} active project(s) (approved or in-process) are using this equipment`
      );
    }
    if (upcomingBookings > 0) {
      warnings.push(
        `${upcomingBookings} upcoming booking(s) include this equipment`
      );
    }

    if (warnings.length > 0) {
      return res.status(400).json({
        message: "Cannot delete equipment that is currently in active use",
        warnings,
        suggestion:
          "Consider marking the equipment as OUT_OF_ORDER instead, or wait until bookings are completed",
      });
    }

    // Safe to delete - no active usage
    await prisma.equipment.delete({
      where: { id: parseInt(equipmentId) },
    });

    res.json({
      message: "Equipment deleted successfully",
      deletedEquipment: {
        id: equipment.id,
        name: equipment.name,
      },
    });
  } catch (error) {
    console.error("Delete equipment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
