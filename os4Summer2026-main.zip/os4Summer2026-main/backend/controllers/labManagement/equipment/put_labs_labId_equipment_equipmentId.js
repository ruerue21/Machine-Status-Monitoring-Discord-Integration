const {
  applyEquipmentOutOfOrderImpact,
} = require("../../../utils/equipmentAvailability");

module.exports = async function (req, res, prisma) {
  try {
    const { labId, equipmentId } = req.params;
    const {
      name,
      description,
      status,
      isActive,
      outOfOrderUntil,
      outOfOrderNever,
    } = req.body;

    const equipment = await prisma.equipment.findUnique({
      where: { id: parseInt(equipmentId) },
      include: {
        lab: {
          select: {
            name: true,
          },
        },
      },
    });

    if (!equipment) {
      return res.status(404).json({ message: "Equipment not found" });
    }

    if (equipment.labId !== parseInt(labId)) {
      return res.status(400).json({
        message: "Equipment does not belong to this lab",
      });
    }

    const parsedName = typeof name === "string" ? name.trim() : null;

    if (name !== undefined && !parsedName) {
      return res.status(400).json({
        message: "Equipment name is required",
      });
    }

    // Check if new name conflicts with another equipment in same lab
    if (parsedName && parsedName !== equipment.name) {
      const existingEquipment = await prisma.equipment.findFirst({
        where: {
          labId: parseInt(labId),
          name: { equals: parsedName, mode: "insensitive" },
          id: { not: parseInt(equipmentId) },
        },
      });

      if (existingEquipment) {
        return res.status(400).json({
          message: "Equipment with this name already exists in this lab",
        });
      }
    }

    const updateData = {};
    const statusAfterUpdate = status !== undefined ? status : equipment.status;

    if (name !== undefined) {
      updateData.name = parsedName;
    }

    if (description !== undefined) {
      updateData.description = description?.trim() || "";
    }

    if (status !== undefined) {
      const validStatuses = ["AVAILABLE", "OUT_OF_ORDER"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          message:
            "Invalid equipment status. Must be AVAILABLE or OUT_OF_ORDER",
        });
      }
      updateData.status = status;
    }

    if (isActive !== undefined) {
      if (typeof isActive !== "boolean") {
        return res
          .status(400)
          .json({ message: "isActive must be true or false" });
      }
      updateData.isActive = isActive;
    }

    if (outOfOrderNever !== undefined && typeof outOfOrderNever !== "boolean") {
      return res.status(400).json({
        message: "outOfOrderNever must be true or false",
      });
    }

    const shouldApplyOutOfOrderWindow =
      statusAfterUpdate === "OUT_OF_ORDER" &&
      (status !== undefined ||
        outOfOrderUntil !== undefined ||
        outOfOrderNever !== undefined);

    let parsedOutOfOrderUntil =
      equipment.outOfOrderUntil instanceof Date
        ? equipment.outOfOrderUntil
        : null;
    let resolvedOutOfOrderNever = Boolean(equipment.outOfOrderNever);

    if (shouldApplyOutOfOrderWindow) {
      resolvedOutOfOrderNever =
        outOfOrderNever !== undefined
          ? outOfOrderNever
          : resolvedOutOfOrderNever;

      if (resolvedOutOfOrderNever) {
        parsedOutOfOrderUntil = null;
      } else {
        const effectiveOutOfOrderUntilRaw =
          outOfOrderUntil !== undefined
            ? outOfOrderUntil
            : parsedOutOfOrderUntil;
        if (!effectiveOutOfOrderUntilRaw) {
          return res.status(400).json({
            message:
              'Provide "outOfOrderUntil" or set "outOfOrderNever" to true when status is OUT_OF_ORDER',
          });
        }
        parsedOutOfOrderUntil = new Date(effectiveOutOfOrderUntilRaw);
        if (Number.isNaN(parsedOutOfOrderUntil.getTime())) {
          return res.status(400).json({
            message: "Invalid outOfOrderUntil date/time",
          });
        }
        if (parsedOutOfOrderUntil <= new Date()) {
          return res.status(400).json({
            message: "Out-of-order end date/time must be in the future",
          });
        }
      }

      updateData.outOfOrderNever = resolvedOutOfOrderNever;
      updateData.outOfOrderUntil = resolvedOutOfOrderNever
        ? null
        : parsedOutOfOrderUntil;
    }

    if (statusAfterUpdate === "AVAILABLE") {
      updateData.outOfOrderNever = false;
      updateData.outOfOrderUntil = null;
    }

    const updatedEquipment = await prisma.equipment.update({
      where: { id: parseInt(equipmentId) },
      data: updateData,
    });

    const equipmentNameAfterUpdate =
      updatedEquipment.name || equipment.name || "Equipment";

    const oldOutOfOrderUntilMs = equipment.outOfOrderUntil
      ? new Date(equipment.outOfOrderUntil).getTime()
      : null;
    const newOutOfOrderUntilMs = updatedEquipment.outOfOrderUntil
      ? new Date(updatedEquipment.outOfOrderUntil).getTime()
      : null;

    const becameOutOfOrder =
      equipment.status !== "OUT_OF_ORDER" &&
      updatedEquipment.status === "OUT_OF_ORDER";
    const outOfOrderWindowChanged =
      updatedEquipment.status === "OUT_OF_ORDER" &&
      (Boolean(equipment.outOfOrderNever) !==
        Boolean(updatedEquipment.outOfOrderNever) ||
        oldOutOfOrderUntilMs !== newOutOfOrderUntilMs);

    let impactedResult = {
      impactedCount: 0,
      adjustedCount: 0,
      cancelledCount: 0,
      adjustedBookingIds: [],
      cancelledBookingIds: [],
    };

    if (becameOutOfOrder || outOfOrderWindowChanged) {
      impactedResult = await applyEquipmentOutOfOrderImpact({
        prisma,
        equipmentId: updatedEquipment.id,
        equipmentName: equipmentNameAfterUpdate,
        labName: equipment.lab?.name || "Lab",
        cancelledByUserId: req.userDetails?.id || null,
        outOfOrderUntil: updatedEquipment.outOfOrderNever
          ? null
          : updatedEquipment.outOfOrderUntil,
      });
    }

    res.json({
      message: "Equipment updated successfully",
      equipment: updatedEquipment,
      impactedBookings: impactedResult.impactedCount,
      adjustedBookings: impactedResult.adjustedCount,
      cancelledBookings: impactedResult.cancelledCount,
      adjustedBookingIds: impactedResult.adjustedBookingIds,
      cancelledBookingIds: impactedResult.cancelledBookingIds,
    });
  } catch (error) {
    console.error("Update equipment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
