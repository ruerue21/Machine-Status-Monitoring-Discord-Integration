module.exports = async function (req, res, prisma) {
  try {
    const { search, status, agreementRequired } = req.query;

    const whereClause = {};

    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { location: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ];
    }

    if (status && status !== "ALL") {
      whereClause.isActive = status === "ACTIVE";
    }

    if (agreementRequired && agreementRequired !== "ALL") {
      whereClause.agreementRequired = agreementRequired === "REQUIRED";
    }

    const labs = await prisma.lab.findMany({
      where: whereClause,
      include: {
        equipment: {
          orderBy: { name: "asc" },
        },
        _count: {
          select: {
            projects: true,
            bookings: true,
            timeSlots: true,
          },
        },
      },
      orderBy: { name: "asc" },
    });

    // Get signature and file counts for labs with agreements
    const labIds = labs.map((lab) => lab.id);
    const [signatureCounts, fileCounts] = await Promise.all([
      prisma.labAgreement.groupBy({
        by: ["labId"],
        where: {
          labId: { in: labIds },
          signed: true,
        },
        _count: true,
      }),
      prisma.labAgreementFile.groupBy({
        by: ["labId"],
        where: {
          labId: { in: labIds },
        },
        _count: true,
      }),
    ]);

    // Create lookup maps
    const signatureMap = Object.fromEntries(
      signatureCounts.map((s) => [s.labId, s._count]),
    );
    const fileMap = Object.fromEntries(
      fileCounts.map((f) => [f.labId, f._count]),
    );

    const formattedLabs = labs.map((lab) => ({
      id: lab.id,
      name: lab.name,
      location: lab.location,
      description: lab.description,
      isActive: lab.isActive,
      unavailableUntil: lab.unavailableUntil,
      deactivationNever: lab.deactivationNever,
      agreementRequired: lab.agreementRequired,
      equipment: lab.equipment.map((equip) => ({
        id: equip.id,
        name: equip.name,
        description: equip.description,
        status: equip.status,
        isActive: equip.isActive,
        outOfOrderUntil: equip.outOfOrderUntil,
        outOfOrderNever: equip.outOfOrderNever,
        createdAt: equip.createdAt,
      })),
      stats: {
        totalProjects: lab._count.projects,
        totalBookings: lab._count.bookings,
        totalTimeSlots: lab._count.timeSlots,
        totalEquipment: lab.equipment.length,
        activeEquipment: lab.equipment.filter((e) => e.isActive).length,
      },
      agreement: {
        required: lab.agreementRequired,
        fileCount: fileMap[lab.id] || 0,
        signatureCount: signatureMap[lab.id] || 0,
      },
      createdAt: lab.createdAt,
      updatedAt: lab.updatedAt,
    }));

    res.json({ labs: formattedLabs });
  } catch (error) {
    console.error("Get labs error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
