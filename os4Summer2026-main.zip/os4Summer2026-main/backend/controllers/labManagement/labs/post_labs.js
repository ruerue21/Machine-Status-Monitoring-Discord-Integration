module.exports = async function (req, res, prisma) {
  try {
    const { name, location, description } = req.body;

    // Only name is required
    if (!name || !name.trim()) {
      return res.status(400).json({
        message: "Lab name is required",
      });
    }

    // Check if lab name already exists
    const existingLab = await prisma.lab.findFirst({
      where: {
        name: { equals: name.trim(), mode: "insensitive" },
      },
    });

    if (existingLab) {
      return res.status(400).json({
        message: "A lab with this name already exists",
      });
    }

    // Build create data with required description field
    const createData = {
      name: name.trim(),
      location: location?.trim() || "",
      description: description?.trim() || "",
      isActive: true,
    };

    const newLab = await prisma.lab.create({
      data: createData,
    });

    res.status(201).json({
      message: "Lab created successfully",
      lab: newLab,
    });
  } catch (error) {
    console.error("Create lab error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
