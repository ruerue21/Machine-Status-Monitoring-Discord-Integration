const { cancelImpactedLabBookings } = require("../../../utils/labAvailability");

module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const {
      name,
      location,
      description,
      isActive,
      unavailableUntil,
      deactivationNever,
    } = req.body;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    // Check if new name conflicts with another lab
    if (name && name.trim() !== lab.name) {
      const existingLab = await prisma.lab.findFirst({
        where: {
          name: { equals: name.trim(), mode: "insensitive" },
          id: { not: parseInt(labId) },
        },
      });

      if (existingLab) {
        return res.status(400).json({
          message: "A lab with this name already exists",
        });
      }
    }

    const updateData = {};

    if (isActive !== undefined && typeof isActive !== "boolean") {
      return res
        .status(400)
        .json({ message: "isActive must be true or false" });
    }
    if (
      deactivationNever !== undefined &&
      typeof deactivationNever !== "boolean"
    ) {
      return res.status(400).json({
        message: "deactivationNever must be true or false",
      });
    }

    if (name !== undefined && name.trim()) {
      updateData.name = name.trim();
    }

    if (location !== undefined) {
      updateData.location = location?.trim() || "";
    }

    if (description !== undefined) {
      updateData.description = description?.trim() || "";
    }

    if (isActive !== undefined) {
      updateData.isActive = isActive;
    }

    const hasDeactivationPayload =
      unavailableUntil !== undefined || deactivationNever !== undefined;
    const shouldDeactivate =
      isActive === false || (lab.isActive === false && hasDeactivationPayload);
    const shouldReactivate = isActive === true;

    if (shouldReactivate) {
      updateData.isActive = true;
      updateData.unavailableUntil = null;
      updateData.deactivationNever = false;

      const updatedLab = await prisma.lab.update({
        where: { id: parseInt(labId) },
        data: updateData,
      });

      return res.json({
        message: "Lab reactivated successfully",
        lab: updatedLab,
        cancelledBookings: 0,
      });
    }

    if (shouldDeactivate) {
      const now = new Date();
      const isNever = Boolean(deactivationNever);
      let parsedUnavailableUntil = null;

      if (!isNever) {
        if (!unavailableUntil) {
          return res.status(400).json({
            message:
              'Provide "unavailableUntil" or set "deactivationNever" to true when deactivating a lab.',
          });
        }
        parsedUnavailableUntil = new Date(unavailableUntil);
        if (Number.isNaN(parsedUnavailableUntil.getTime())) {
          return res.status(400).json({
            message: "Invalid unavailableUntil date/time",
          });
        }
        if (parsedUnavailableUntil <= now) {
          return res.status(400).json({
            message: "Reactivation date/time must be in the future",
          });
        }
      }

      updateData.isActive = false;
      updateData.deactivationNever = isNever;
      updateData.unavailableUntil = isNever ? null : parsedUnavailableUntil;

      const updatedLab = await prisma.lab.update({
        where: { id: parseInt(labId) },
        data: updateData,
      });

      const cancelledResult = await cancelImpactedLabBookings({
        prisma,
        labId: updatedLab.id,
        labName: updatedLab.name,
        cancelledByUserId: req.userDetails?.id || null,
        unavailableUntil: isNever ? null : parsedUnavailableUntil,
      });

      return res.json({
        message: isNever
          ? "Lab deactivated indefinitely"
          : "Lab deactivated until scheduled reactivation time",
        lab: updatedLab,
        cancelledBookings: cancelledResult.cancelledCount,
        cancelledBookingIds: cancelledResult.cancelledBookingIds,
      });
    }

    const updatedLab = await prisma.lab.update({
      where: { id: parseInt(labId) },
      data: updateData,
    });

    res.json({
      message: "Lab updated successfully",
      lab: updatedLab,
      cancelledBookings: 0,
    });
  } catch (error) {
    console.error("Update lab error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
