module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      include: {
        equipment: {
          orderBy: { name: "asc" },
        },
        _count: {
          select: {
            projects: true,
            bookings: true,
            timeSlots: true,
          },
        },
      },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    const formattedLab = {
      id: lab.id,
      name: lab.name,
      location: lab.location,
      description: lab.description,
      isActive: lab.isActive,
      unavailableUntil: lab.unavailableUntil,
      deactivationNever: lab.deactivationNever,
      equipment: lab.equipment.map((equip) => ({
        id: equip.id,
        name: equip.name,
        description: equip.description,
        status: equip.status,
        isActive: equip.isActive,
        outOfOrderUntil: equip.outOfOrderUntil,
        outOfOrderNever: equip.outOfOrderNever,
        createdAt: equip.createdAt,
      })),
      stats: {
        totalProjects: lab._count.projects,
        totalBookings: lab._count.bookings,
        totalTimeSlots: lab._count.timeSlots,
        totalEquipment: lab.equipment.length,
      },
      createdAt: lab.createdAt,
      updatedAt: lab.updatedAt,
    };

    res.json({ lab: formattedLab });
  } catch (error) {
    console.error("Get lab details error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
