module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    // Check for active dependencies only
    const [activeProjects, upcomingBookings, futureTimeSlots, activeEquipment] =
      await Promise.all([
        // Active projects (APPROVED or IN_PROCESS)
        prisma.project.count({
          where: {
            labId: parseInt(labId),
            status: { in: ["APPROVED", "IN_PROCESS"] },
            isArchived: false,
          },
        }),

        // Upcoming bookings (CONFIRMED, not past)
        prisma.booking.count({
          where: {
            labId: parseInt(labId),
            status: "CONFIRMED",
            startDate: { gte: new Date() },
            isArchived: false,
          },
        }),

        // Future time slots (not past)
        prisma.timeSlot.count({
          where: {
            labId: parseInt(labId),
            date: { gte: new Date() },
          },
        }),

        // Active equipment count
        prisma.equipment.count({
          where: {
            labId: parseInt(labId),
            isActive: true,
          },
        }),
      ]);

    // Build warnings for active dependencies
    const warnings = [];
    if (activeProjects > 0) {
      warnings.push(
        `${activeProjects} active project(s) (approved or in-process)`
      );
    }
    if (upcomingBookings > 0) {
      warnings.push(`${upcomingBookings} upcoming booking(s)`);
    }
    if (futureTimeSlots > 0) {
      warnings.push(`${futureTimeSlots} future time slot(s)`);
    }
    if (activeEquipment > 0) {
      warnings.push(
        `${activeEquipment} active equipment item(s) will be deleted`
      );
    }

    if (warnings.length > 0) {
      return res.status(400).json({
        message: "Cannot delete lab with active dependencies",
        warnings,
        suggestion:
          "Consider marking the lab as inactive instead, or wait until projects/bookings are completed",
      });
    }

    // Safe to delete - no active dependencies
    await prisma.lab.delete({
      where: { id: parseInt(labId) },
    });

    res.json({
      message: "Lab deleted successfully",
      deletedLab: {
        id: lab.id,
        name: lab.name,
      },
    });
  } catch (error) {
    console.error("Delete lab error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
