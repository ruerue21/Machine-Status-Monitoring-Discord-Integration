module.exports = async function (req, res, prisma) {
  try {
    const { labId, userId, cancellationId } = req.params;
    const { reason } = req.body;

    // Verify the cancellation record exists and belongs to this user/lab
    const cancellation = await prisma.labAgreementCancellation.findUnique({
      where: { id: parseInt(cancellationId) },
      include: {
        cancelledByUser: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    if (!cancellation) {
      return res.status(404).json({ message: "Cancellation record not found" });
    }

    if (
      cancellation.userId !== parseInt(userId) ||
      cancellation.labId !== parseInt(labId)
    ) {
      return res.status(400).json({
        message: "Cancellation record does not match user/lab combination",
      });
    }

    // Update the reason
    const updatedCancellation = await prisma.labAgreementCancellation.update({
      where: { id: parseInt(cancellationId) },
      data: {
        reason: reason || null,
      },
      include: {
        cancelledByUser: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
    });

    res.json({
      message: "Cancellation reason updated successfully",
      cancellation: updatedCancellation,
    });
  } catch (error) {
    console.error("Update lab agreement cancellation reason error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
