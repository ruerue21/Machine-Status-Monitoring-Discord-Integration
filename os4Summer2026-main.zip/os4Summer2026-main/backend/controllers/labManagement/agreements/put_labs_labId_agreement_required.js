module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const { agreementRequired } = req.body;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    const updatedLab = await prisma.lab.update({
      where: { id: parseInt(labId) },
      data: { agreementRequired: agreementRequired },
    });

    res.json({
      message: `Agreement requirement ${agreementRequired ? "enabled" : "disabled"} for ${lab.name}`,
      lab: {
        id: updatedLab.id,
        name: updatedLab.name,
        agreementRequired: updatedLab.agreementRequired,
      },
    });
  } catch (error) {
    console.error("Toggle agreement requirement error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
