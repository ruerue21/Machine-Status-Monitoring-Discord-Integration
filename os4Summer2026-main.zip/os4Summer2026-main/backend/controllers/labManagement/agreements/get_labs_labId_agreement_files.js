module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;

    const files = await prisma.labAgreementFile.findMany({
      where: { labId: parseInt(labId) },
      orderBy: { uploadedAt: "desc" },
    });

    // Get signature count
    const signatureCount = await prisma.labAgreement.count({
      where: {
        labId: parseInt(labId),
        signed: true,
      },
    });

    res.json({
      files,
      signatureCount,
    });
  } catch (error) {
    console.error("Get agreement files error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
