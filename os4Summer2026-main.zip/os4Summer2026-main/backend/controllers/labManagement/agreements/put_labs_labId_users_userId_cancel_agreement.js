module.exports = async function (req, res, prisma) {
  try {
    const { labId, userId } = req.params;
    const { reason } = req.body;

    const cancelledBy = req.userDetails.id;
    const cancellerRole = req.userDetails.role;

    if (!cancelledBy) {
      return res.status(401).json({ message: "User not authenticated" });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      select: { id: true, name: true },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    // Verify target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if lab agreement is signed
    const labAgreement = await prisma.labAgreement.findUnique({
      where: {
        userId_labId: {
          userId: parseInt(userId),
          labId: parseInt(labId),
        },
      },
    });

    if (!labAgreement || !labAgreement.signed) {
      return res.status(400).json({
        message: `User has not signed the lab agreement for ${lab.name}`,
      });
    }

    // Permission checks based on canceller role
    if (cancellerRole === "ADMIN") {
      // Admins can cancel for everyone (no restrictions)
    } else if (cancellerRole === "SUPERVISOR") {
      // Supervisors can cancel for MEMBER and PEER_MENTOR only
      if (targetUser.role === "ADMIN") {
        return res.status(403).json({
          message: "Supervisors cannot cancel agreements for administrators",
        });
      }
      if (targetUser.role === "SUPERVISOR") {
        return res.status(403).json({
          message: "Supervisors cannot cancel agreements for other supervisors",
        });
      }
      // Can cancel for MEMBER and PEER_MENTOR
    } else if (cancellerRole === "PEER_MENTOR") {
      // Peer mentors cannot cancel any agreements
      return res.status(403).json({
        message: "Peer mentors do not have permission to cancel lab agreements",
      });
    } else {
      // MEMBER or any other role
      return res.status(403).json({
        message: "You do not have permission to cancel lab agreements",
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      // Create cancellation history record
      await tx.labAgreementCancellation.create({
        data: {
          userId: parseInt(userId),
          labId: parseInt(labId),
          labAgreementId: labAgreement.id,
          cancelledBy: parseInt(cancelledBy),
          reason: reason || null,
        },
      });

      // Cancel agreement and increment counter
      const updatedAgreement = await tx.labAgreement.update({
        where: { id: labAgreement.id },
        data: {
          signed: false,
          signedAt: null,
          cancellations: {
            increment: 1,
          },
          lastCancelledAt: new Date(),
          lastCancelledBy: parseInt(cancelledBy),
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              role: true,
            },
          },
          lab: {
            select: {
              id: true,
              name: true,
            },
          },
          cancelledBy: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      return updatedAgreement;
    });

    res.json({
      message: `Lab agreement cancelled successfully for ${lab.name}`,
      agreement: result,
      reason: reason || "No reason provided",
    });
  } catch (error) {
    console.error("Cancel lab agreement error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
