module.exports = async function (req, res, prisma) {
  try {
    const { labId, userId } = req.params;
    const { limit = 10, offset = 0 } = req.query;

    // Convert to integers and validate
    const limitNum = Math.min(parseInt(limit) || 10, 50); // Max 50 per page
    const offsetNum = parseInt(offset) || 0;

    // Get total count
    const totalCount = await prisma.labAgreementCancellation.count({
      where: {
        userId: parseInt(userId),
        labId: parseInt(labId),
      },
    });

    // Get paginated history
    const history = await prisma.labAgreementCancellation.findMany({
      where: {
        userId: parseInt(userId),
        labId: parseInt(labId),
      },
      include: {
        cancelledByUser: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: limitNum,
      skip: offsetNum,
    });

    res.json({
      history,
      pagination: {
        total: totalCount,
        limit: limitNum,
        offset: offsetNum,
        hasMore: offsetNum + limitNum < totalCount,
      },
    });
  } catch (error) {
    console.error("Get lab agreement history error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
