const fs = require("fs");
const {
  validateAgreementFile,
  sanitizeFilename,
} = require("../../../utils/validation");

const safeDeleteFile = async (filePath) => {
  if (!filePath) return;
  try {
    await fs.promises.unlink(filePath);
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Failed to clean up uploaded file:", error);
    }
  }
};

module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;

    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const validation = validateAgreementFile(req.file);
    if (!validation.valid) {
      // Delete uploaded file
      await safeDeleteFile(req.file.path);
      return res.status(400).json({ message: validation.error });
    }

    const maxFileSize = 10 * 1024 * 1024; // 10MB in bytes
    if (req.file.size > maxFileSize) {
      await safeDeleteFile(req.file.path);
      return res.status(400).json({
        message: `File size exceeds 10MB limit. File size: ${(
          req.file.size /
          1024 /
          1024
        ).toFixed(2)}MB`,
      });
    }

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      // Delete uploaded file if lab doesn't exist
      await safeDeleteFile(req.file.path);
      return res.status(404).json({ message: "Lab not found" });
    }

    // Use validated file type instead of determining it again
    const fileType = validation.fileType;

    const result = await prisma.$transaction(async (tx) => {
      // Create the new agreement file
      const agreementFile = await tx.labAgreementFile.create({
        data: {
          labId: parseInt(labId),
          fileName: sanitizeFilename(req.file.originalname),
          fileUrl: req.file.filename,
          fileType: fileType,
        },
      });

      // Invalidate all existing signatures for this lab
      const invalidatedCount = await tx.labAgreement.updateMany({
        where: {
          labId: parseInt(labId),
          signed: true,
        },
        data: {
          signed: false,
          signedAt: null,
        },
      });

      // Enable agreement requirement if not already enabled
      if (!lab.agreementRequired) {
        await tx.lab.update({
          where: { id: parseInt(labId) },
          data: { agreementRequired: true },
        });
      }

      return { agreementFile, invalidatedCount: invalidatedCount.count };
    });

    res.json({
      message: "Agreement file uploaded successfully",
      file: {
        id: result.agreementFile.id,
        fileName: result.agreementFile.fileName,
        fileType: result.agreementFile.fileType,
        uploadedAt: result.agreementFile.uploadedAt,
      },
      invalidatedSignatures: result.invalidatedCount,
      warning:
        result.invalidatedCount > 0
          ? `${result.invalidatedCount} user(s) will need to re-sign this agreement`
          : null,
    });
  } catch (error) {
    console.error("Upload agreement file error:", error);
    // Clean up file on error
    if (req.file) {
      await safeDeleteFile(req.file.path);
    }
    res.status(500).json({ message: "Server error" });
  }
};
