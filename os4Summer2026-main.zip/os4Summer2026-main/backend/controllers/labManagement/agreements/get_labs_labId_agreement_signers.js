module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const { search } = req.query;

    const whereClause = {
      labId: parseInt(labId),
    };

    // Build user filter if search term provided
    const userFilter = search
      ? {
          OR: [
            { name: { contains: search, mode: "insensitive" } },
            { email: { contains: search, mode: "insensitive" } },
          ],
        }
      : {};

    const signers = await prisma.labAgreement.findMany({
      where: {
        ...whereClause,
        user: userFilter,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
        cancelledBy: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: [
        { signed: "desc" }, // Signed users first
        { signedAt: "desc" }, // Then by date
      ],
    });

    res.json({ signers });
  } catch (error) {
    console.error("Get lab agreement signers error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
