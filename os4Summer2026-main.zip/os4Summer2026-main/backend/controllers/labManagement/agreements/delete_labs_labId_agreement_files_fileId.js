const fs = require("fs");
const path = require("path");

module.exports = async function (req, res, prisma) {
  try {
    const { labId, fileId } = req.params;

    const file = await prisma.labAgreementFile.findFirst({
      where: {
        id: parseInt(fileId),
        labId: parseInt(labId),
      },
    });

    if (!file) {
      return res.status(404).json({ message: "Agreement file not found" });
    }

    // Delete file from filesystem
    const filePath = path.join(
      __dirname,
      "../../../uploads/lab-agreements",
      file.fileUrl,
    );
    try {
      await fs.promises.unlink(filePath);
    } catch (unlinkError) {
      if (unlinkError.code !== "ENOENT") {
        throw unlinkError;
      }
    }

    // Delete from database
    await prisma.labAgreementFile.delete({
      where: { id: parseInt(fileId) },
    });

    // Check if this was the last file - if so, disable agreement requirement
    const remainingFiles = await prisma.labAgreementFile.count({
      where: { labId: parseInt(labId) },
    });

    if (remainingFiles === 0) {
      await prisma.lab.update({
        where: { id: parseInt(labId) },
        data: { agreementRequired: false },
      });
    }

    res.json({
      message: "Agreement file deleted successfully",
      remainingFiles,
    });
  } catch (error) {
    console.error("Delete agreement file error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
