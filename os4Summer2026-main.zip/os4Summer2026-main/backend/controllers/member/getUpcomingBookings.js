module.exports = async function (req, res, prisma) {
  try {
    const userId = req.user.userId;

    if (!userId) {
      return res
        .status(401)
        .json({ message: "Invalid token: user ID missing" });
    }

    const bookings = await prisma.booking.findMany({
      where: {
        userId,
        status: "CONFIRMED",
        startDate: { gte: new Date() },
      },
      include: {
        project: {
          select: { name: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { name: true },
            },
          },
        },
      },
      orderBy: { startDate: "asc" },
      take: 5,
    });

    const formattedBookings = bookings.map((b) => ({
      id: b.id,
      projectName: b.project.name,
      labName: b.lab.name,
      labLocation: b.lab.location,
      startDate: b.startDate,
      endDate: b.endDate,
      status: b.status,
      equipment: b.equipment.map((e) => e.equipment.name),
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get upcoming bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
