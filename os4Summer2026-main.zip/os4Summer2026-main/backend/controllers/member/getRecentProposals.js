module.exports = async function (req, res, prisma) {
  try {
    const userId = req.user.userId;

    if (!userId) {
      return res
        .status(401)
        .json({ message: "Invalid token: user ID missing" });
    }

    // Use consultations array instead of singular consultation
    const proposals = await prisma.project.findMany({
      where: {
        userId: userId, // Only get THIS user's projects
        isArchived: false, // Don't show archived projects
      },
      include: {
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
          orderBy: {
            createdAt: "asc",
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 5,
    });

    const formattedProposals = proposals.map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description,
      status: p.status,
      labName: p.lab.name,
      labLocation: p.lab.location,
      // Include consultations array for Dashboard to use
      consultations: p.consultations.map((consultation) => ({
        id: consultation.id,
        status: consultation.status,
        date: consultation.timeSlot?.date || null,
        startTime: consultation.timeSlot?.startTime || null,
        endTime: consultation.timeSlot?.endTime || null,
        mentor: consultation.timeSlot?.mentor?.name || null,
        mentorEmail: consultation.timeSlot?.mentor?.email || null,
      })),
      createdAt: p.createdAt,
      updatedAt: p.updatedAt,
    }));

    res.json({ proposals: formattedProposals });
  } catch (error) {
    console.error("Get recent proposals error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
