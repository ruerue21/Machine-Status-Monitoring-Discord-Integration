const {
  getMemberAgreementStatusForUser,
} = require("../../utils/memberAgreement");

module.exports = async function (req, res, prisma) {
  try {
    const userId = req.user.userId;
    const agreementStatus = await getMemberAgreementStatusForUser(
      prisma,
      userId,
    );

    if (!userId) {
      return res
        .status(401)
        .json({ message: "Invalid token: user ID missing" });
    }

    // Get proposal counts
    const [
      totalProposals,
      inProcessProposals,
      approvedProposals,
      declinedProposals,
    ] = await Promise.all([
      prisma.project.count({ where: { userId } }),
      prisma.project.count({ where: { userId, status: "IN_PROCESS" } }),
      prisma.project.count({ where: { userId, status: "APPROVED" } }),
      prisma.project.count({ where: { userId, status: "DECLINED" } }),
    ]);

    // Get booking counts
    const [totalBookings, upcomingBookings, completedBookings] =
      await Promise.all([
        prisma.booking.count({ where: { userId } }),
        prisma.booking.count({
          where: {
            userId,
            status: "CONFIRMED",
            startDate: { gte: new Date() },
          },
        }),
        prisma.booking.count({
          where: { userId, status: "COMPLETED" },
        }),
      ]);

    // Get user info
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        memberAgreementSigned: true,
        memberAgreementDate: true,
        agreementCancellations: true,
        lastAgreementCancelledAt: true,
      },
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({
      stats: {
        proposals: {
          total: totalProposals,
          inProcess: inProcessProposals,
          approved: approvedProposals,
          declined: declinedProposals,
        },
        bookings: {
          total: totalBookings,
          upcoming: upcomingBookings,
          completed: completedBookings,
        },
        agreement: {
          signed: Boolean(agreementStatus?.memberAgreementSigned),
          cancellations: user.agreementCancellations,
          lastCancelledAt: user.lastAgreementCancelledAt,
        },
      },
    });
  } catch (error) {
    console.error("Get member stats error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
