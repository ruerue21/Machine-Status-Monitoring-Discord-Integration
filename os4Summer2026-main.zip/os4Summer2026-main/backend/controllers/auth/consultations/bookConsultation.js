const { bookTimeSlot } = require("../../../services/timeSlotService");

module.exports = async function bookConsultation(req, res, prisma) {
  try {
    const { timeSlotId, labId } = req.body;
    const userId = req.user.userId;
    const parsedTimeSlotId = parseInt(timeSlotId);
    const parsedLabId = parseInt(labId);

    if (!Number.isInteger(parsedTimeSlotId) || !Number.isInteger(parsedLabId)) {
      return res.status(400).json({ message: "Invalid consultation request" });
    }

    const consultation = await bookTimeSlot(
      parsedTimeSlotId,
      userId,
      parsedLabId,
    );

    res.json({
      consultation: {
        id: consultation.id,
        status: consultation.status,
        timeSlot: {
          date: consultation.timeSlot.date,
          startTime: consultation.timeSlot.startTime,
          endTime: consultation.timeSlot.endTime,
          mentor: consultation.timeSlot.mentor,
        },
        lab: consultation.lab,
        createdAt: consultation.createdAt,
      },
    });
  } catch (error) {
    console.error("Book consultation error:", error);
    const safeClientErrors = [
      "No available mentors for selected time slot",
      "Time slot not found",
      "Time slot is no longer available",
    ];
    if (safeClientErrors.includes(error.message)) {
      return res.status(400).json({ message: error.message });
    }
    res.status(500).json({ message: "Server error" });
  }
};
