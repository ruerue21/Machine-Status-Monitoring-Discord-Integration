const {
  notifyConsultationCancelled,
} = require("../../../services/notificationService");

module.exports = async function cancelConsultation(req, res, prisma) {
  try {
    const { consultationId } = req.params;
    const parsedConsultationId = parseInt(consultationId, 10);
    const { cancelReason } = req.body;
    const userId = req.user.userId;

    if (!Number.isInteger(parsedConsultationId)) {
      return res.status(400).json({ message: "Invalid consultation ID" });
    }

    // Get the consultation
    const consultation = await prisma.consultation.findUnique({
      where: { id: parsedConsultationId },
      include: {
        project: {
          include: {
            user: true,
            consultations: true,
          },
        },
      },
    });

    if (!consultation) {
      return res.status(404).json({ message: "Consultation not found" });
    }

    // Verify user owns this project
    if (consultation.project.userId !== userId) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    if (consultation.status === "CANCELLED") {
      return res
        .status(400)
        .json({ message: "Consultation already cancelled" });
    }
    if (consultation.status === "COMPLETED") {
      return res
        .status(400)
        .json({ message: "Cannot cancel a completed consultation" });
    }
    if (consultation.status === "ABSENT") {
      return res
        .status(400)
        .json({ message: "Cannot cancel a consultation marked absent" });
    }

    // Update consultation
    await prisma.consultation.update({
      where: { id: parsedConsultationId },
      data: {
        status: "CANCELLED",
        cancelledBy: userId,
        cancelledAt: new Date(),
        cancelReason: cancelReason || null,
      },
    });

    // Free time slot
    if (consultation.timeSlotId) {
      await prisma.timeSlot.update({
        where: { id: consultation.timeSlotId },
        data: { isBooked: false },
      });

      await prisma.consultation.update({
        where: { id: parsedConsultationId },
        data: { timeSlotId: null },
      });
    }

    // Check if all consultations are cancelled
    const allConsultations = await prisma.consultation.findMany({
      where: { projectId: consultation.projectId },
    });

    const allDone = allConsultations.every((c) =>
      ["CANCELLED", "ABSENT"].includes(c.status),
    );

    if (allDone) {
      await prisma.project.update({
        where: { id: consultation.projectId },
        data: { status: "CONSULTATION_CANCELLED" },
      });
    }

    await notifyConsultationCancelled(
      consultation.projectId,
      parsedConsultationId,
    );

    res.json({ message: "Consultation cancelled successfully" });
  } catch (error) {
    console.error("Cancel consultation error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
