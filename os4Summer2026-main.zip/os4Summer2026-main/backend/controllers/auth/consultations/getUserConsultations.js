module.exports = async function getUserConsultations(req, res, prisma) {
  try {
    const userId = req.user.userId;

    const consultations = await prisma.consultation.findMany({
      where: { userId: userId },
      orderBy: { createdAt: "desc" },
      include: {
        timeSlot: {
          include: {
            mentor: {
              select: { name: true, email: true },
            },
          },
        },
        lab: true,
        project: {
          select: { id: true, name: true, status: true },
        },
      },
    });

    res.json({ consultations });
  } catch (error) {
    console.error("Get consultations error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
