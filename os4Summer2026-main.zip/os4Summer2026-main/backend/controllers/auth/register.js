const bcrypt = require("bcrypt");
const { sendVerificationEmail } = require("../../services/emailService");
const { sanitizeEmail, sanitizeText } = require("../../utils/sanitization");
const {
  validatePurdueEmail,
  generateVerificationToken,
  hashToken,
  validatePassword,
} = require("../../utils/validation");

module.exports = async function register(req, res, prisma) {
  try {
    const { name, email, password } = req.body;
    const normalizedEmail = sanitizeEmail(email);
    const normalizedName = sanitizeText(name);

    if (!normalizedName || normalizedName.length > 100) {
      return res.status(400).json({
        message: "Name is required and must be 100 characters or less",
      });
    }

    if (!validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return res.status(400).json({
        message: passwordValidation.message,
      });
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const verificationToken = generateVerificationToken();
    const verificationTokenHash = hashToken(verificationToken);

    // Set token to expire in 24 hours
    const verificationTokenExpires = new Date();
    verificationTokenExpires.setHours(verificationTokenExpires.getHours() + 24);

    const user = await prisma.user.create({
      data: {
        name: normalizedName,
        email: normalizedEmail,
        password: hashedPassword,
        role: "MEMBER",
        emailVerified: false,
        verificationToken: verificationTokenHash,
        verificationTokenExpires,
        assignedLabIds: [],
        memberAgreementSigned: false,
      },
    });

    await sendVerificationEmail(normalizedEmail, verificationToken);

    res.json({
      message:
        "Registration successful! Please check your email to verify your account.",
      email: user.email,
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
