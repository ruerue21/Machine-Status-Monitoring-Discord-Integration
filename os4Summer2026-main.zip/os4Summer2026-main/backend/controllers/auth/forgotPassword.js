const { sendPasswordResetEmail } = require("../../services/emailService");
const { sanitizeEmail } = require("../../utils/sanitization");
const {
  validatePurdueEmail,
  generateVerificationToken,
  hashToken,
} = require("../../utils/validation");

module.exports = async function forgotPassword(req, res, prisma) {
  try {
    const { email } = req.body;
    const normalizedEmail = sanitizeEmail(email);

    if (!validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (!user) {
      return res.json({
        message:
          "If your email is registered, you will receive a password reset link.",
      });
    }

    const resetToken = generateVerificationToken();
    const resetTokenHash = hashToken(resetToken);

    // Use UTC for consistency - expires in 1 hour
    const resetExpires = new Date(Date.now() + 60 * 60 * 1000);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        passwordResetToken: resetTokenHash,
        passwordResetExpires: resetExpires,
      },
    });

    await sendPasswordResetEmail(normalizedEmail, resetToken);

    res.json({
      message:
        "If your email is registered, you will receive a password reset link.",
    });
  } catch (error) {
    console.error("Password reset request error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
