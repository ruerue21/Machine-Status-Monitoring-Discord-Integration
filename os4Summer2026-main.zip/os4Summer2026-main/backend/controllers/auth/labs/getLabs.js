module.exports = async function getLabs(req, res, prisma) {
  try {
    const labs = await prisma.lab.findMany({
      where: { isActive: true },
      orderBy: { name: "asc" },
      include: {
        equipment: {
          where: { isActive: true },
          orderBy: { name: "asc" },
        },
      },
    });

    // Keep the same behavior as your current file (mentors are fetched but not returned)
    const labsWithMentors = await Promise.all(
      labs.map(async (lab) => {
        await prisma.user.findMany({
          where: {
            role: "PEER_MENTOR",
            assignedLabIds: {
              has: lab.id,
            },
          },
          select: {
            id: true,
            name: true,
            email: true,
          },
        });

        return {
          ...lab,
        };
      })
    );

    res.json({ labs: labsWithMentors });
  } catch (error) {
    console.error("Get labs error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
