const { getAvailableTimeSlots } = require("../../../services/timeSlotService");

module.exports = async function getLabTimeSlots(req, res) {
  try {
    const { labId } = req.params;
    const { date } = req.query;

    const timeSlots = await getAvailableTimeSlots(labId, date);
    res.json({ timeSlots });
  } catch (error) {
    console.error("Get time slots error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
