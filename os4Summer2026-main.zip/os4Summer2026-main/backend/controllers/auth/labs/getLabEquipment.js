module.exports = async function getLabEquipment(req, res, prisma) {
  try {
    const { labId } = req.params;

    const equipment = await prisma.equipment.findMany({
      where: {
        labId: parseInt(labId),
        isActive: true,
        status: "AVAILABLE",
      },
      orderBy: { name: "asc" },
    });

    res.json({ equipment });
  } catch (error) {
    console.error("Get equipment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
