const { sendVerificationEmail } = require("../../services/emailService");
const {
  validatePurdueEmail,
  generateVerificationToken,
  hashToken,
} = require("../../utils/validation");
const { sanitizeEmail } = require("../../utils/sanitization");

module.exports = async function resendVerification(req, res, prisma) {
  try {
    const { email } = req.body;
    const normalizedEmail = sanitizeEmail(email);

    if (!validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (!user) {
      return res.json({
        message:
          "If your email is registered and unverified, a new verification link has been sent.",
      });
    }

    if (user.emailVerified) {
      return res.status(400).json({
        message: "Email is already verified. You can log in.",
      });
    }

    const verificationToken = generateVerificationToken();
    const verificationTokenHash = hashToken(verificationToken);

    // Set new token to expire in 24 hours
    const verificationTokenExpires = new Date();
    verificationTokenExpires.setHours(verificationTokenExpires.getHours() + 24);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        verificationToken: verificationTokenHash,
        verificationTokenExpires,
      },
    });

    await sendVerificationEmail(normalizedEmail, verificationToken);

    res.json({
      message:
        "If your email is registered and unverified, a new verification link has been sent.",
    });
  } catch (error) {
    console.error("Resend verification error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
