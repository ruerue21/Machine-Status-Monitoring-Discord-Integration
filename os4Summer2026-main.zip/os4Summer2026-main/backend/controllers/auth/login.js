const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { validatePurdueEmail } = require("../../utils/validation");
const { sanitizeEmail } = require("../../utils/sanitization");
const logger = require("../../utils/logger");
const { setAuthCookie } = require("../../utils/authCookie");

module.exports = async function login(req, res, prisma) {
  try {
    const { email, password } = req.body;
    const normalizedEmail = sanitizeEmail(email);

    if (typeof password !== "string" || password.length === 0) {
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    }

    if (!validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    if (!user.emailVerified) {
      return res.status(400).json({
        message: "Please verify your email address before logging in",
      });
    }

    if (!user.isActive) {
      return res.status(403).json({
        message:
          "Your account is inactive. Please contact an administrator for support.",
      });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    await prisma.user.update({
      where: { id: user.id },
      data: {
        lastLoginAt: new Date(),
      },
    });

    if (!process.env.JWT_SECRET) {
      return res.status(500).json({ message: "Server configuration error" });
    }

    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        mentorType: user.mentorType,
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" },
    );

    setAuthCookie(res, token);

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        mentorType: user.mentorType,
      },
    });
  } catch (error) {
    logger.error("Login error:", {
      error: error.message,
      stack: error.stack,
      email: req.body.email,
    });
    res.status(500).json({ message: "Server error" });
  }
};
