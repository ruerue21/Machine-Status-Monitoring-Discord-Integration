const {
  getMemberAgreementStatusForUser,
} = require("../../../utils/memberAgreement");

module.exports = async function getStatus(req, res, prisma) {
  try {
    const userId = req.user.userId;
    const status = await getMemberAgreementStatusForUser(prisma, userId);
    if (!status) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(status);
  } catch (error) {
    console.error("Get agreement status error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
