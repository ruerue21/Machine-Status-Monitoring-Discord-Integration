const fs = require("fs");
const path = require("path");

module.exports = async function downloadFile(req, res, prisma) {
  try {
    const { fileId } = req.params;

    const file = await prisma.memberAgreementFile.findUnique({
      where: { id: parseInt(fileId, 10) },
    });

    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }

    const filePath = path.join(
      __dirname,
      "../../../uploads/member-agreements",
      path.basename(file.fileUrl),
    );

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server" });
    }

    return res.download(filePath, file.fileName);
  } catch (error) {
    console.error("Download member agreement file error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};
