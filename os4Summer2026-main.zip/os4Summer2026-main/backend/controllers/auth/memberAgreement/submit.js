const {
  getOrCreateMemberAgreementConfig,
  getMemberAgreementStatusForUser,
} = require("../../../utils/memberAgreement");

module.exports = async function submit(req, res, prisma) {
  try {
    const userId = req.user.userId;
    const config = await getOrCreateMemberAgreementConfig(prisma);
    const status = await getMemberAgreementStatusForUser(prisma, userId);

    if (!status) {
      return res.status(404).json({ message: "User not found" });
    }

    if (status.memberAgreementSigned) {
      return res.status(400).json({
        message: "Member agreement is already signed for the current cycle",
      });
    }

    const now = new Date();
    const signedFiles = await prisma.$transaction(async (tx) => {
      const files = await tx.memberAgreementFile.findMany({
        where: { configId: config.id },
        select: { id: true },
      });

      await Promise.all(
        files.map((file) =>
          tx.memberAgreementFileSignature.upsert({
            where: {
              userId_fileId: {
                userId,
                fileId: file.id,
              },
            },
            create: {
              userId,
              fileId: file.id,
              signedAt: now,
            },
            update: {
              signedAt: now,
            },
          }),
        ),
      );

      await tx.user.update({
        where: { id: userId },
        data: {
          memberAgreementSigned: true,
          memberAgreementDate: now,
          memberAgreementVersionSigned: config.currentVersion,
        },
      });

      return files.length;
    });

    res.json({
      message: "Member agreement submitted successfully",
      memberAgreementSigned: true,
      memberAgreementDate: now,
      signedFiles,
    });
  } catch (error) {
    console.error("Submit agreement error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
