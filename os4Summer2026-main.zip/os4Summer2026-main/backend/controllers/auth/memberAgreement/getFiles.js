const {
  getOrCreateMemberAgreementConfig,
} = require("../../../utils/memberAgreement");

module.exports = async function getFiles(req, res, prisma) {
  try {
    const config = await getOrCreateMemberAgreementConfig(prisma);

    const files = await prisma.memberAgreementFile.findMany({
      where: { configId: config.id },
      orderBy: [{ displayOrder: "asc" }, { uploadedAt: "asc" }],
      select: {
        id: true,
        fileName: true,
        fileType: true,
        resignType: true,
        anchorDate: true,
        specificDate: true,
        displayOrder: true,
        uploadedAt: true,
        updatedAt: true,
      },
    });

    res.json({ files });
  } catch (error) {
    console.error("Get member agreement files error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
