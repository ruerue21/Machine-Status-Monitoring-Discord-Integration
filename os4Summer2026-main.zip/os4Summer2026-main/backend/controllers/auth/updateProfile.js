const jwt = require("jsonwebtoken");
const {
  validatePurdueEmail,
  generateVerificationToken,
  hashToken,
} = require("../../utils/validation");
const { sendEmailChangeConfirmation } = require("../../services/emailService");
const { sanitizeEmail, sanitizeText } = require("../../utils/sanitization");
const { setAuthCookie } = require("../../utils/authCookie");

module.exports = async function updateProfile(req, res, prisma) {
  try {
    const { name, email } = req.body;
    const userId = req.user.userId;
    const normalizedName =
      typeof name === "string" ? sanitizeText(name) : undefined;
    const normalizedEmail =
      typeof email === "string" ? sanitizeEmail(email) : undefined;

    const currentUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!currentUser) {
      return res.status(404).json({ message: "User not found" });
    }

    const emailChanged =
      typeof normalizedEmail === "string" &&
      normalizedEmail !== currentUser.email;

    if (emailChanged && !validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    if (emailChanged) {
      const existingUser = await prisma.user.findUnique({
        where: { email: normalizedEmail },
      });

      if (existingUser) {
        return res.status(400).json({ message: "Email is already in use" });
      }
    }

    const updateData = {};
    const nameChanged =
      normalizedName !== undefined && normalizedName !== currentUser.name;

    if (normalizedName !== undefined) {
      if (!normalizedName || normalizedName.length > 100) {
        return res.status(400).json({
          message: "Name is required and must be 100 characters or less",
        });
      }
      updateData.name = normalizedName;
    }

    let verificationToken = null;
    if (emailChanged) {
      verificationToken = generateVerificationToken();
      updateData.pendingEmail = normalizedEmail;
      updateData.verificationToken = hashToken(verificationToken);
      const verificationTokenExpires = new Date();
      verificationTokenExpires.setHours(
        verificationTokenExpires.getHours() + 24,
      );
      updateData.verificationTokenExpires = verificationTokenExpires;
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData,
    });

    if (emailChanged) {
      await sendEmailChangeConfirmation(
        currentUser.email,
        normalizedEmail,
        verificationToken,
      );
    }

    const token = jwt.sign(
      {
        userId: updatedUser.id,
        email: updatedUser.email,
        role: updatedUser.role,
        name: updatedUser.name,
        mentorType: updatedUser.mentorType,
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" },
    );

    setAuthCookie(res, token);

    res.json({
      message: emailChanged
        ? nameChanged
          ? "Profile updated. Please confirm the email change from your current email address."
          : "Email change requested. Please confirm from your current email address before it is applied."
        : "Profile updated successfully.",
      token,
      user: {
        id: updatedUser.id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        mentorType: updatedUser.mentorType,
      },
      pendingEmail: updatedUser.pendingEmail || null,
    });
  } catch (error) {
    console.error("Profile update error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
