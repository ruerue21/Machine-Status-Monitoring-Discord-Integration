const bcrypt = require("bcrypt");
const { validatePassword } = require("../../utils/validation");

module.exports = async function changePassword(req, res, prisma) {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.userId;

    if (
      typeof currentPassword !== "string" ||
      currentPassword.length === 0 ||
      typeof newPassword !== "string" ||
      newPassword.length === 0
    ) {
      return res.status(400).json({
        message: "Current password and new password are required",
      });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, password: true, isActive: true },
    });

    if (!user || !user.isActive) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const matchesCurrent = await bcrypt.compare(currentPassword, user.password);
    if (!matchesCurrent) {
      return res.status(400).json({ message: "Current password is incorrect" });
    }

    const passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.valid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    const isSamePassword = await bcrypt.compare(newPassword, user.password);
    if (isSamePassword) {
      return res.status(400).json({
        message: "New password must be different from current password",
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    return res.json({ message: "Password changed successfully." });
  } catch (error) {
    console.error("Change password error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};
