const { sendWelcomeEmail } = require("../../services/emailService");

const { hashToken } = require("../../utils/validation");

module.exports = async function verifyEmail(req, res, prisma) {
  try {
    const { token } = req.query;

    if (!token) {
      return res
        .status(400)
        .json({ message: "Verification token is required" });
    }

    const tokenHash = hashToken(token);

    // First, try to find user by token
    const userWithToken = await prisma.user.findFirst({
      where: {
        OR: [{ verificationToken: token }, { verificationToken: tokenHash }],
      },
    });

    if (userWithToken) {
      // Check if token is expired
      if (
        userWithToken.verificationTokenExpires &&
        new Date() > userWithToken.verificationTokenExpires
      ) {
        return res.status(400).json({
          message:
            "Verification token has expired. Please request a new verification email.",
          expired: true,
        });
      }

      const isPendingEmailChange = Boolean(userWithToken.pendingEmail);

      if (isPendingEmailChange) {
        const pendingEmail = userWithToken.pendingEmail;
        const conflictingUser = await prisma.user.findUnique({
          where: { email: pendingEmail },
          select: { id: true },
        });

        if (conflictingUser && conflictingUser.id !== userWithToken.id) {
          return res.status(400).json({
            message:
              "Unable to apply email change because the requested email is now in use. Please update your profile and try again.",
          });
        }

        await prisma.user.update({
          where: { id: userWithToken.id },
          data: {
            email: pendingEmail,
            emailVerified: true,
            pendingEmail: null,
            verificationToken: null,
            verificationTokenExpires: null,
          },
        });

        return res.json({
          message:
            "Email change confirmed successfully. Your account email has been updated.",
        });
      }

      // Token is valid and not expired, verify the user
      const updatedUser = await prisma.user.update({
        where: { id: userWithToken.id },
        data: {
          emailVerified: true,
          verificationToken: null,
          verificationTokenExpires: null,
        },
        select: {
          name: true,
          email: true,
        },
      });

      // Send welcome email
      sendWelcomeEmail(updatedUser.email, {
        name: updatedUser.name,
      }).catch((err) => {
        console.error("Failed to send welcome email:", err);
      });

      return res.json({
        message: "Email verified successfully! You can now log in.",
      });
    }

    // Token is invalid (or already consumed) when no matching user is found
    return res
      .status(400)
      .json({ message: "Invalid or expired verification token" });
  } catch (error) {
    console.error("Email verification error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
