const {
  notifyMemberConsultationCancelled,
} = require("../../../services/notificationService");

module.exports = async function cancelConsultation(req, res, prisma) {
  try {
    const { projectId } = req.params;
    const parsedProjectId = parseInt(projectId, 10);
    const { reason } = req.body;
    const userId = req.user.userId;

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const project = await prisma.project.findFirst({
      where: {
        id: parsedProjectId,
        userId: userId,
      },
      include: {
        consultations: {
          include: {
            timeSlot: true,
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({
        message:
          "Project not found or you don't have permission to cancel this consultation",
      });
    }

    if (!project.consultations || project.consultations.length === 0) {
      return res.status(404).json({ message: "Consultation not found" });
    }
    const targetConsultation =
      project.consultations.find((c) => c.status === "SCHEDULED") ||
      project.consultations.find(
        (c) => !["COMPLETED", "CANCELLED", "ABSENT"].includes(c.status),
      ) ||
      project.consultations[0];

    if (targetConsultation.status === "CANCELLED") {
      return res.status(400).json({
        message: "Consultation is already cancelled",
      });
    }

    if (targetConsultation.status === "COMPLETED") {
      return res.status(400).json({
        message: "Cannot cancel a completed consultation",
      });
    }

    if (targetConsultation.status === "ABSENT") {
      return res.status(400).json({
        message: "Cannot cancel a consultation marked as absent",
      });
    }

    notifyMemberConsultationCancelled(parsedProjectId, reason).catch((err) => {
      console.error("Failed to send member cancellation notification:", err);
    });

    let finalProjectStatus = "IN_PROCESS";
    await prisma.$transaction(async (tx) => {
      await tx.consultation.update({
        where: { id: targetConsultation.id },
        data: {
          status: "CANCELLED",
          cancelledBy: userId,
          cancelledAt: new Date(),
          cancelReason: reason?.trim() ? reason.trim() : null,
        },
      });

      if (targetConsultation.timeSlotId) {
        await tx.timeSlot.update({
          where: { id: targetConsultation.timeSlotId },
          data: { isBooked: false },
        });

        await tx.consultation.update({
          where: { id: targetConsultation.id },
          data: { timeSlotId: null },
        });
      }

      const consultations = await tx.consultation.findMany({
        where: { projectId: parsedProjectId },
        select: { status: true },
      });
      const allCancelled = consultations.every((c) => c.status === "CANCELLED");
      const allDone = consultations.every((c) =>
        ["CANCELLED", "ABSENT"].includes(c.status),
      );
      finalProjectStatus =
        allCancelled || allDone ? "CONSULTATION_CANCELLED" : "IN_PROCESS";

      await tx.project.update({
        where: { id: parsedProjectId },
        data: { status: finalProjectStatus },
      });
    });

    res.json({
      message:
        "Consultation cancelled successfully. You can reschedule by creating a new project proposal.",
      project: {
        id: project.id,
        name: project.name,
        status: finalProjectStatus,
      },
      consultation: {
        status: "CANCELLED",
        cancelledAt: new Date(),
      },
    });
  } catch (error) {
    console.error("Cancel consultation error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
