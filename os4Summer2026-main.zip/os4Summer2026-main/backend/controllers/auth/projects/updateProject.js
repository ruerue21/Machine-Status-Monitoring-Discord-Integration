const {
  notifyProjectDetailsUpdated,
  notifyProjectLabOrTimeChanged,
} = require("../../../services/notificationService");
const { sanitizeText, validateMaxLength } = require("../../../utils/sanitization");

module.exports = async function updateProject(req, res, prisma) {
  try {
    const { projectId } = req.params;
    const { name, description, labId, equipmentIds, timeSlotId, timeSlotIds } =
      req.body;
    const userId = req.user.userId;
    const parsedProjectId = parseInt(projectId);

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const existingProject = await prisma.project.findFirst({
      where: {
        id: parsedProjectId,
        userId,
      },
      include: {
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
          },
          orderBy: { createdAt: "asc" },
        },
        equipment: {
          include: {
            equipment: true,
          },
        },
        lab: {
          select: { id: true, name: true, location: true, description: true },
        },
      },
    });

    if (!existingProject) {
      return res.status(404).json({ message: "Project not found" });
    }
    if (existingProject.status !== "IN_PROCESS") {
      return res.status(400).json({
        message: "Cannot edit project that has been approved or declined",
      });
    }
    if (!existingProject.consultations?.length) {
      return res.status(400).json({
        message: "Project has no consultations available for updates",
      });
    }

    const primaryConsultation = existingProject.consultations[0];
    const existingTimeSlotIds = existingProject.consultations
      .map((c) => c.timeSlotId)
      .filter((id) => Number.isInteger(id));

    const normalizedName =
      typeof name === "string" ? sanitizeText(name).trim() : existingProject.name;
    const normalizedDescription =
      typeof description === "string"
        ? sanitizeText(description).trim()
        : existingProject.description;

    if (!normalizedName || !validateMaxLength(normalizedName, 200)) {
      return res.status(400).json({
        message: "Project name is required and must be 200 characters or less",
      });
    }
    if (!normalizedDescription || !validateMaxLength(normalizedDescription, 2000)) {
      return res.status(400).json({
        message: "Project description is required and must be 2000 characters or less",
      });
    }

    const parsedLabId =
      labId !== undefined ? parseInt(labId) : existingProject.labId;

    if (!Number.isInteger(parsedLabId)) {
      return res.status(400).json({ message: "Invalid lab selection" });
    }

    const labChanged = parsedLabId !== existingProject.labId;

    let requestedTimeSlotIds = [...existingTimeSlotIds];
    const hasTimeSlotIdsArray = Array.isArray(timeSlotIds);
    const hasSingleTimeSlotUpdate =
      timeSlotId !== undefined && timeSlotId !== null && !hasTimeSlotIdsArray;

    if (hasTimeSlotIdsArray) {
      if (timeSlotIds.length === 0) {
        return res.status(400).json({
          message: "At least one consultation session is required",
        });
      }
      if (timeSlotIds.length > 5) {
        return res.status(400).json({
          message: "Maximum 5 consultation sessions allowed per project",
        });
      }
      requestedTimeSlotIds = timeSlotIds.map((id) => parseInt(id));
    } else if (hasSingleTimeSlotUpdate) {
      const parsedTimeSlotId = parseInt(timeSlotId);
      if (!Number.isInteger(parsedTimeSlotId)) {
        return res
          .status(400)
          .json({ message: "Invalid or unavailable time slot" });
      }

      const primaryIndex = requestedTimeSlotIds.findIndex(
        (id) => id === primaryConsultation.timeSlotId,
      );
      if (primaryIndex >= 0) {
        requestedTimeSlotIds[primaryIndex] = parsedTimeSlotId;
      } else if (requestedTimeSlotIds.length > 0) {
        requestedTimeSlotIds[0] = parsedTimeSlotId;
      } else {
        requestedTimeSlotIds = [parsedTimeSlotId];
      }
    }

    if (requestedTimeSlotIds.some((id) => !Number.isInteger(id))) {
      return res.status(400).json({
        message: "Invalid consultation time slot selection",
      });
    }

    requestedTimeSlotIds = [...new Set(requestedTimeSlotIds)];
    if (requestedTimeSlotIds.length === 0) {
      return res.status(400).json({
        message: "At least one consultation session is required",
      });
    }
    if (requestedTimeSlotIds.length > 5) {
      return res.status(400).json({
        message: "Maximum 5 consultation sessions allowed per project",
      });
    }

    if (labChanged && !hasTimeSlotIdsArray && !hasSingleTimeSlotUpdate) {
      return res.status(400).json({
        message:
          "Please select consultation time slots for the newly selected lab",
      });
    }

    const sortedExistingTimeSlotIds = [...existingTimeSlotIds].sort((a, b) => a - b);
    const sortedRequestedTimeSlotIds = [...requestedTimeSlotIds].sort(
      (a, b) => a - b,
    );
    const consultationChanged =
      JSON.stringify(sortedExistingTimeSlotIds) !==
      JSON.stringify(sortedRequestedTimeSlotIds);

    const currentEquipmentIds = existingProject.equipment
      .map((pe) => pe.equipment.id)
      .sort((a, b) => a - b);

    let finalEquipmentIds = currentEquipmentIds;
    if (equipmentIds !== undefined) {
      if (!Array.isArray(equipmentIds) || equipmentIds.length === 0) {
        return res.status(400).json({
          message: "Please select at least one piece of equipment",
        });
      }

      finalEquipmentIds = equipmentIds.map((id) => parseInt(id));
      if (finalEquipmentIds.some((id) => !Number.isInteger(id))) {
        return res.status(400).json({
          message: "One or more equipment IDs are invalid",
        });
      }
    }

    const sortedNewEquipment = [...finalEquipmentIds].sort((a, b) => a - b);
    const equipmentChanged =
      JSON.stringify(currentEquipmentIds) !== JSON.stringify(sortedNewEquipment);

    const nameChanged = normalizedName !== existingProject.name;
    const descriptionChanged = normalizedDescription !== existingProject.description;

    if (
      !nameChanged &&
      !descriptionChanged &&
      !labChanged &&
      !equipmentChanged &&
      !consultationChanged
    ) {
      return res.status(400).json({ message: "No changes detected." });
    }

    const selectedLab = await prisma.lab.findFirst({
      where: { id: parsedLabId, isActive: true },
      select: { id: true },
    });
    if (!selectedLab) {
      return res.status(400).json({ message: "Invalid lab selection" });
    }

    if (equipmentChanged || labChanged) {
      const equipmentList = await prisma.equipment.findMany({
        where: {
          id: { in: finalEquipmentIds },
          labId: parsedLabId,
          isActive: true,
          status: "AVAILABLE",
        },
      });

      if (equipmentList.length !== finalEquipmentIds.length) {
        return res.status(400).json({
          message:
            "One or more selected equipment items are invalid or not available",
        });
      }
    }

    if (consultationChanged || labChanged) {
      const nextTimeSlots = await findTimeSlotsForProjectUpdate(
        prisma,
        requestedTimeSlotIds,
        parsedLabId,
        existingTimeSlotIds,
      );

      if (nextTimeSlots.length !== requestedTimeSlotIds.length) {
        return res
          .status(400)
          .json({ message: "Invalid or unavailable time slot" });
      }
    }

    const oldMentorId = primaryConsultation.timeSlot?.mentor?.id || null;
    const oldLabId = existingProject.labId;
    const oldTimeSlot = {
      date: primaryConsultation.timeSlot?.date || null,
      startTime: primaryConsultation.timeSlot?.startTime || null,
      endTime: primaryConsultation.timeSlot?.endTime || null,
    };

    const updatedProject = await prisma.$transaction(async (tx) => {
      if (consultationChanged || labChanged) {
        const addedTimeSlotIds = requestedTimeSlotIds.filter(
          (slotId) => !existingTimeSlotIds.includes(slotId),
        );
        const removedTimeSlotIds = existingTimeSlotIds.filter(
          (slotId) => !requestedTimeSlotIds.includes(slotId),
        );

        const canSwapPrimaryConsultation =
          !labChanged &&
          hasSingleTimeSlotUpdate &&
          addedTimeSlotIds.length === 1 &&
          removedTimeSlotIds.length === 1;

        if (canSwapPrimaryConsultation) {
          const oldTimeSlotId = removedTimeSlotIds[0];
          const newTimeSlotId = addedTimeSlotIds[0];

          await tx.consultation.update({
            where: { id: primaryConsultation.id },
            data: { timeSlotId: newTimeSlotId },
          });

          await tx.timeSlot.update({
            where: { id: oldTimeSlotId },
            data: { isBooked: false },
          });

          await tx.timeSlot.update({
            where: { id: newTimeSlotId },
            data: { isBooked: true },
          });
        } else {
        const consultationsByTimeSlot = new Map(
          existingProject.consultations.map((consultation) => [
            consultation.timeSlotId,
            consultation,
          ]),
        );
        const requestedSet = new Set(requestedTimeSlotIds);

        const consultationsToDelete = existingProject.consultations.filter(
          (consultation) => !requestedSet.has(consultation.timeSlotId),
        );

        const consultationsToRetain = existingProject.consultations.filter(
          (consultation) => requestedSet.has(consultation.timeSlotId),
        );

        const newTimeSlotIds = requestedTimeSlotIds.filter(
          (slotId) => !consultationsByTimeSlot.has(slotId),
        );

        if (consultationsToDelete.length > 0) {
          await tx.consultation.deleteMany({
            where: {
              id: { in: consultationsToDelete.map((consultation) => consultation.id) },
            },
          });

          await tx.timeSlot.updateMany({
            where: {
              id: { in: consultationsToDelete.map((consultation) => consultation.timeSlotId) },
            },
            data: { isBooked: false },
          });
        }

        if (consultationsToRetain.length > 0 && labChanged) {
          await tx.consultation.updateMany({
            where: {
              id: { in: consultationsToRetain.map((consultation) => consultation.id) },
            },
            data: {
              labId: parsedLabId,
            },
          });
        }

        for (const newTimeSlotId of newTimeSlotIds) {
          await tx.consultation.create({
            data: {
              userId,
              labId: parsedLabId,
              projectId: parsedProjectId,
              timeSlotId: newTimeSlotId,
              status: "SCHEDULED",
            },
          });

          await tx.timeSlot.update({
            where: { id: newTimeSlotId },
            data: { isBooked: true },
          });
        }
        }
      }

      if (equipmentChanged) {
        await tx.projectEquipment.deleteMany({
          where: { projectId: parsedProjectId },
        });

        await tx.projectEquipment.createMany({
          data: finalEquipmentIds.map((equipmentId) => ({
            projectId: parsedProjectId,
            equipmentId,
          })),
        });
      }

      return tx.project.update({
        where: { id: parsedProjectId },
        data: {
          name: normalizedName,
          description: normalizedDescription,
          labId: parsedLabId,
        },
        include: {
          lab: true,
          equipment: {
            include: {
              equipment: true,
            },
          },
          consultations: {
            include: {
              timeSlot: {
                include: {
                  mentor: {
                    select: { id: true, name: true, email: true },
                  },
                },
              },
            },
            orderBy: { createdAt: "asc" },
          },
        },
      });
    });

    if (labChanged || consultationChanged) {
      const newPrimaryConsultation = updatedProject.consultations[0];
      const newMentorId = newPrimaryConsultation.timeSlot?.mentor?.id || null;
      const newTimeSlot = {
        date: newPrimaryConsultation.timeSlot?.date || null,
        startTime: newPrimaryConsultation.timeSlot?.startTime || null,
        endTime: newPrimaryConsultation.timeSlot?.endTime || null,
      };

      notifyProjectLabOrTimeChanged(
        parsedProjectId,
        primaryConsultation.id,
        oldMentorId,
        newMentorId,
        oldLabId,
        parsedLabId,
        oldTimeSlot,
        newTimeSlot,
      ).catch((err) => {
        console.error("Failed to send lab/time change notifications:", err);
      });
    }

    if (nameChanged || descriptionChanged || equipmentChanged) {
      const changes = [];
      if (nameChanged) {
        changes.push({ field: "Project Name", newValue: normalizedName });
      }
      if (descriptionChanged) {
        changes.push({
          field: "Project Description",
          newValue: normalizedDescription,
        });
      }
      if (equipmentChanged) {
        const newEquipmentNames = updatedProject.equipment
          .map((pe) => pe.equipment.name)
          .join(", ");
        changes.push({ field: "Equipment", newValue: newEquipmentNames });
      }

      if (changes.length > 0) {
        notifyProjectDetailsUpdated(parsedProjectId, changes).catch((err) => {
          console.error("Failed to send project update notification:", err);
        });
      }
    }

    return res.json({
      message: "Project updated successfully!",
      project: formatProjectResponse(updatedProject),
    });
  } catch (error) {
    console.error("Update project error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

function formatProjectResponse(project) {
  const firstConsultation = project.consultations?.[0];

  return {
    id: project.id,
    name: project.name,
    description: project.description,
    status: project.status,
    lab: {
      id: project.lab.id,
      name: project.lab.name,
      location: project.lab.location,
      description: project.lab.description,
    },
    equipment: project.equipment.map((pe) => ({
      id: pe.equipment.id,
      name: pe.equipment.name,
      description: pe.equipment.description,
      status: pe.equipment.status,
    })),
    consultations: project.consultations.map((consultation) => ({
      id: consultation.id,
      status: consultation.status,
      date: consultation.timeSlot?.date,
      startTime: consultation.timeSlot?.startTime,
      endTime: consultation.timeSlot?.endTime,
      mentor: consultation.timeSlot?.mentor?.name,
      mentorEmail: consultation.timeSlot?.mentor?.email,
      notes: consultation.notes,
      mentorFeedback: consultation.mentorFeedback,
    })),
    consultation: firstConsultation
      ? {
          id: firstConsultation.id,
          status: firstConsultation.status,
          date: firstConsultation.timeSlot?.date,
          startTime: firstConsultation.timeSlot?.startTime,
          endTime: firstConsultation.timeSlot?.endTime,
          mentor: firstConsultation.timeSlot?.mentor?.name,
          mentorEmail: firstConsultation.timeSlot?.mentor?.email,
          notes: firstConsultation.notes,
          mentorFeedback: firstConsultation.mentorFeedback,
          timeSlot: firstConsultation.timeSlot
            ? { id: firstConsultation.timeSlot.id }
            : null,
        }
      : null,
    createdAt: project.createdAt,
    updatedAt: project.updatedAt,
  };
}

async function findTimeSlotsForProjectUpdate(
  prisma,
  requestedTimeSlotIds,
  labId,
  existingTimeSlotIds,
) {
  if (typeof prisma.timeSlot?.findMany === "function") {
    return prisma.timeSlot.findMany({
      where: {
        id: { in: requestedTimeSlotIds },
        labId,
        slotType: "CONSULTATION",
        OR: [{ isBooked: false }, { id: { in: existingTimeSlotIds } }],
      },
      include: {
        mentor: {
          select: { id: true, name: true, email: true },
        },
      },
    });
  }

  if (typeof prisma.timeSlot?.findFirst !== "function") {
    throw new Error("Time slot query methods are unavailable");
  }

  const slots = await Promise.all(
    requestedTimeSlotIds.map((timeSlotId) =>
      prisma.timeSlot.findFirst({
        where: {
          id: timeSlotId,
          labId,
          slotType: "CONSULTATION",
          OR: [{ isBooked: false }, { id: { in: existingTimeSlotIds } }],
        },
        include: {
          mentor: {
            select: { id: true, name: true, email: true },
          },
        },
      }),
    ),
  );

  return slots.filter(Boolean);
}
