module.exports = async function getProjectDetails(req, res, prisma) {
  try {
    const { projectId } = req.params;
    const userId = req.user.userId;

    const project = await prisma.project.findFirst({
      where: {
        id: parseInt(projectId),
        userId: userId,
      },
      include: {
        lab: true,
        equipment: {
          include: {
            equipment: true,
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
        user: {
          select: { name: true, email: true },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const consultations = project.consultations || [];
    const primaryConsultation =
      consultations.find((c) => c.status === "SCHEDULED" && c.timeSlot) ||
      consultations.find((c) => c.timeSlot) ||
      consultations[0] ||
      null;

    const formattedProject = {
      id: project.id,
      name: project.name,
      description: project.description,
      status: project.status,
      lab: {
        id: project.lab.id,
        name: project.lab.name,
        location: project.lab.location,
        description: project.lab.description,
      },
      equipment: project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
        description: pe.equipment.description,
        status: pe.equipment.status,
      })),
      consultations: consultations.map((consultation) => ({
        id: consultation.id,
        status: consultation.status,
        date: consultation.timeSlot?.date || null,
        startTime: consultation.timeSlot?.startTime || null,
        endTime: consultation.timeSlot?.endTime || null,
        mentor: consultation.timeSlot?.mentor?.name || null,
        mentorEmail: consultation.timeSlot?.mentor?.email || null,
        notes: consultation.notes,
        mentorFeedback: consultation.mentorFeedback,
        timeSlot: consultation.timeSlot
          ? {
              id: consultation.timeSlot.id,
              startTime: consultation.timeSlot.startTime,
              endTime: consultation.timeSlot.endTime,
              date: consultation.timeSlot.date,
            }
          : null,
      })),
      consultation: primaryConsultation
        ? {
            id: primaryConsultation.id,
            status: primaryConsultation.status,
            date: primaryConsultation.timeSlot?.date || null,
            startTime: primaryConsultation.timeSlot?.startTime || null,
            endTime: primaryConsultation.timeSlot?.endTime || null,
            mentor: primaryConsultation.timeSlot?.mentor?.name || null,
            mentorEmail: primaryConsultation.timeSlot?.mentor?.email || null,
            notes: primaryConsultation.notes,
            mentorFeedback: primaryConsultation.mentorFeedback,
            timeSlot: primaryConsultation.timeSlot
              ? {
                  id: primaryConsultation.timeSlot.id,
                  startTime: primaryConsultation.timeSlot.startTime,
                  endTime: primaryConsultation.timeSlot.endTime,
                  date: primaryConsultation.timeSlot.date,
                }
              : null,
          }
        : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    };

    res.json({ project: formattedProject });
  } catch (error) {
    console.error("Get project details error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
