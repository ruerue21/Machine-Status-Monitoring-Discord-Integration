const {
  notifyProjectDeleted,
} = require("../../../services/notificationService");
const {
  sendProjectDeletionConfirmation,
} = require("../../../services/emailService");

module.exports = async function deleteProject(req, res, prisma) {
  try {
    const { projectId } = req.params;
    const userId = req.user.userId;
    const parsedProjectId = parseInt(projectId);
    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project id" });
    }

    const existingProject = await prisma.project.findFirst({
      where: {
        id: parsedProjectId,
        userId: userId,
      },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true },
        },
        consultations: {
          include: {
            timeSlot: true,
          },
        },
        bookings: {
          include: {
            timeSlot: true,
          },
        },
      },
    });

    if (!existingProject) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (existingProject.status !== "IN_PROCESS") {
      return res.status(400).json({
        message: "Cannot delete project that has been approved or declined",
      });
    }

    // Notify before deletion
    notifyProjectDeleted(parsedProjectId).catch((err) => {
      console.error("Failed to send project deletion notification:", err);
    });

    // Calculate freed time slots
    let freedTimeSlots = 0;
    if (existingProject.consultations?.length > 0) {
      freedTimeSlots += existingProject.consultations.filter(
        (c) => c.timeSlotId,
      ).length;
    }
    if (existingProject.bookings?.length > 0) {
      freedTimeSlots += existingProject.bookings.filter(
        (b) => b.timeSlotId,
      ).length;
    }

    // Send deletion confirmation to student
    sendProjectDeletionConfirmation(existingProject.user.email, {
      studentName: existingProject.user.name,
      projectName: existingProject.name,
      labName: existingProject.lab.name,
      deletedAt: new Date(),
      freedTimeSlots: freedTimeSlots,
    }).catch((err) => {
      console.error("Failed to send project deletion confirmation:", err);
    });

    await prisma.$transaction(async (tx) => {
      // Delete project equipment associations
      await tx.projectEquipment.deleteMany({
        where: { projectId: parsedProjectId },
      });

      // Free any booking time slots and delete bookings
      if (existingProject.bookings && existingProject.bookings.length > 0) {
        const bookingTimeSlotIds = existingProject.bookings
          .filter((b) => b.timeSlotId)
          .map((b) => b.timeSlotId);

        if (bookingTimeSlotIds.length > 0) {
          await tx.timeSlot.updateMany({
            where: { id: { in: bookingTimeSlotIds } },
            data: { isBooked: false },
          });
        }

        // Delete booking equipment associations
        await tx.bookingEquipment.deleteMany({
          where: {
            bookingId: {
              in: existingProject.bookings.map((b) => b.id),
            },
          },
        });

        // Delete bookings
        await tx.booking.deleteMany({
          where: { projectId: parsedProjectId },
        });
      }

      // Delete the project (this will cascade delete consultation due to onDelete: Cascade)
      await tx.project.delete({
        where: { id: parsedProjectId },
      });

      // Free the consultation time slot if it exists
      const consultationTimeSlotIds = existingProject.consultations
        .filter((c) => c.timeSlotId)
        .map((c) => c.timeSlotId);

      if (consultationTimeSlotIds.length > 0) {
        await tx.timeSlot.updateMany({
          where: { id: { in: consultationTimeSlotIds } },
          data: { isBooked: false },
        });
      }
    });

    res.json({
      message: "Project deleted successfully!",
      deletedBookings: existingProject.bookings?.length || 0,
    });
  } catch (error) {
    console.error("Delete project error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
