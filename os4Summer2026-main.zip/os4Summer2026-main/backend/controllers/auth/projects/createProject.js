const {
  notifyProjectProposalCreated,
} = require("../../../services/notificationService");
const {
  sanitizeText,
  validateMaxLength,
} = require("../../../utils/sanitization");
const {
  getMemberAgreementStatusForUser,
} = require("../../../utils/memberAgreement");

module.exports = async function createProject(req, res, prisma) {
  try {
    const {
      name,
      description,
      labId,
      equipmentIds,
      timeSlotIds, // Array of time slot IDs
      isReschedule,
      rescheduledFromId,
    } = req.body;

    const userId = req.user.userId;
    const agreementStatus = await getMemberAgreementStatusForUser(
      prisma,
      userId,
    );
    const hasCurrentAgreement = Boolean(agreementStatus?.memberAgreementSigned);

    if (!hasCurrentAgreement) {
      return res.status(403).json({
        message:
          "Member agreement must be signed for the current required cycle before creating a project",
      });
    }

    // Validate required fields
    if (!name || !description || !labId || !equipmentIds || !timeSlotIds) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    // Validate max lengths
    if (!validateMaxLength(name, 200)) {
      return res.status(400).json({
        message: "Project name must be 200 characters or less",
      });
    }

    if (!validateMaxLength(description, 2000)) {
      return res.status(400).json({
        message: "Project description must be 2000 characters or less",
      });
    }

    // Sanitize inputs
    const sanitizedName = sanitizeText(name);
    const sanitizedDescription = sanitizeText(description);

    if (!sanitizedName || sanitizedName.trim().length === 0) {
      return res.status(400).json({
        message: "Project name cannot be empty",
      });
    }

    if (!sanitizedDescription || sanitizedDescription.trim().length === 0) {
      return res.status(400).json({
        message: "Project description cannot be empty",
      });
    }

    if (!Array.isArray(equipmentIds) || equipmentIds.length === 0) {
      return res
        .status(400)
        .json({ message: "At least one equipment must be selected" });
    }

    const parsedLabId = parseInt(labId);
    if (!Number.isInteger(parsedLabId)) {
      return res.status(400).json({ message: "Invalid lab selection" });
    }

    const selectedLab = await prisma.lab.findFirst({
      where: { id: parsedLabId, isActive: true },
      select: { id: true },
    });
    if (!selectedLab) {
      return res.status(400).json({ message: "Invalid lab selection" });
    }

    const parsedEquipmentIds = equipmentIds.map((id) => parseInt(id));
    if (parsedEquipmentIds.some((id) => !Number.isInteger(id))) {
      return res.status(400).json({ message: "Invalid equipment selection" });
    }

    const validEquipment = await prisma.equipment.findMany({
      where: {
        id: { in: parsedEquipmentIds },
        labId: parsedLabId,
        isActive: true,
        status: "AVAILABLE",
      },
      select: { id: true },
    });

    if (validEquipment.length !== parsedEquipmentIds.length) {
      return res.status(400).json({
        message:
          "One or more selected equipment items are invalid or not available",
      });
    }

    // Validate time slots array
    if (!Array.isArray(timeSlotIds) || timeSlotIds.length === 0) {
      return res.status(400).json({
        message: "At least one consultation time slot must be selected",
      });
    }

    // Limit maximum consultations
    if (timeSlotIds.length > 5) {
      return res.status(400).json({
        message: "Maximum 5 consultation sessions allowed per project",
      });
    }

    const parsedTimeSlotIds = timeSlotIds.map((id) => parseInt(id));
    if (parsedTimeSlotIds.some((id) => !Number.isInteger(id))) {
      return res.status(400).json({
        message: "Invalid consultation time slot selection",
      });
    }

    // Verify all time slots exist and are available
    const timeSlots = await prisma.timeSlot.findMany({
      where: {
        id: { in: parsedTimeSlotIds },
        labId: parsedLabId,
        slotType: "CONSULTATION",
      },
      include: {
        mentor: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    if (timeSlots.length !== parsedTimeSlotIds.length) {
      return res.status(404).json({
        message:
          "One or more selected consultation time slots are invalid for this lab",
      });
    }

    // Check if any slots are already booked
    const bookedSlots = timeSlots.filter((slot) => slot.isBooked);
    if (bookedSlots.length > 0) {
      return res.status(400).json({
        message: `${bookedSlots.length} selected time slot(s) are no longer available`,
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      // Create project (without consultationId)
      const project = await tx.project.create({
        data: {
          name: sanitizedName,
          description: sanitizedDescription,
          userId: userId,
          labId: parsedLabId,
          status: "IN_PROCESS",
          isRescheduled: isReschedule || false,
          rescheduledFromId: rescheduledFromId
            ? parseInt(rescheduledFromId)
            : null,
        },
      });

      // Create multiple consultations and mark time slots as booked
      const consultations = [];
      for (const timeSlotId of parsedTimeSlotIds) {
        // Create consultation
        const consultation = await tx.consultation.create({
          data: {
            userId: userId,
            labId: parsedLabId,
            projectId: project.id, // Link to project
            timeSlotId,
            status: "SCHEDULED",
          },
        });

        // Mark time slot as booked
        await tx.timeSlot.update({
          where: { id: timeSlotId },
          data: { isBooked: true },
        });

        consultations.push(consultation);
      }

      // Create equipment associations
      const equipmentData = parsedEquipmentIds.map((equipmentId) => ({
        projectId: project.id,
        equipmentId: parseInt(equipmentId),
      }));

      await tx.projectEquipment.createMany({
        data: equipmentData,
      });

      // Fetch complete project with all relations
      const completeProject = await tx.project.findUnique({
        where: { id: project.id },
        include: {
          lab: true,
          equipment: {
            include: {
              equipment: true,
            },
          },
          consultations: {
            include: {
              timeSlot: {
                include: {
                  mentor: {
                    select: { id: true, name: true, email: true },
                  },
                },
              },
            },
            orderBy: {
              createdAt: "asc",
            },
          },
          rescheduledTo: true,
        },
      });

      return completeProject;
    });

    const formattedProject = {
      id: result.id,
      name: result.name,
      description: result.description,
      status: result.status,
      userId: result.userId,
      isRescheduled: result.isRescheduled,
      rescheduledFromId: result.rescheduledFromId,
      rescheduledTo: result.rescheduledTo || [],
      consultations: result.consultations,
    };

    // Send notifications
    notifyProjectProposalCreated(result.id).catch((err) => {
      console.error("Failed to send project proposal notifications:", err);
    });

    res.json({ project: formattedProject });
  } catch (error) {
    console.error("Create project error:", error);
    if (error.code === "P2002") {
      return res.status(400).json({
        message:
          "One or more selected consultation time slots are no longer available",
      });
    }
    res.status(500).json({ message: "Server error" });
  }
};
