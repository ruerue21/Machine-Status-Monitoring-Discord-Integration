module.exports = async function getUserProjects(req, res, prisma) {
  try {
    const userId = req.user.userId;

    const projects = await prisma.project.findMany({
      where: { userId: userId },
      orderBy: { createdAt: "desc" },
      include: {
        lab: true,
        equipment: {
          include: {
            equipment: true,
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
          orderBy: {
            createdAt: "asc", // Show consultations in chronological order
          },
        },
        rescheduledTo: {
          select: {
            id: true,
            name: true,
            status: true,
            createdAt: true,
            isRescheduled: true,
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });

    const formattedProjects = projects.map((project) => ({
      id: project.id,
      name: project.name,
      description: project.description,
      status: project.status,
      userId: project.userId,
      isRescheduled: project.isRescheduled,
      rescheduledFromId: project.rescheduledFromId,
      rescheduledTo: project.rescheduledTo || [],
      lab: {
        id: project.lab.id,
        name: project.lab.name,
        location: project.lab.location,
        description: project.lab.description,
      },
      equipment: project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
        description: pe.equipment.description,
        status: pe.equipment.status,
      })),
      // Return ALL consultations, not just first one
      consultations: project.consultations.map((consultation) => ({
        id: consultation.id,
        status: consultation.status,
        date: consultation.timeSlot?.date || null,
        startTime: consultation.timeSlot?.startTime || null,
        endTime: consultation.timeSlot?.endTime || null,
        mentor: consultation.timeSlot?.mentor?.name || null,
        mentorEmail: consultation.timeSlot?.mentor?.email || null,
        mentorFeedback: consultation.mentorFeedback,
        notes: consultation.notes,
        cancelledBy: consultation.cancelledBy,
        cancelledAt: consultation.cancelledAt,
        cancelReason: consultation.cancelReason,
        markedAbsentBy: consultation.markedAbsentBy,
        absentAt: consultation.absentAt,
        absentReason: consultation.absentReason,
        timeSlot: consultation.timeSlot
          ? {
              id: consultation.timeSlot.id,
              startTime: consultation.timeSlot.startTime,
              endTime: consultation.timeSlot.endTime,
              date: consultation.timeSlot.date,
            }
          : null,
      })),
      // Keep backward compatibility - include first consultation as "consultation"
      consultation: project.consultations[0]
        ? {
            id: project.consultations[0].id,
            status: project.consultations[0].status,
            date: project.consultations[0].timeSlot?.date || null,
            startTime: project.consultations[0].timeSlot?.startTime || null,
            endTime: project.consultations[0].timeSlot?.endTime || null,
            mentor: project.consultations[0].timeSlot?.mentor?.name || null,
            mentorEmail:
              project.consultations[0].timeSlot?.mentor?.email || null,
            mentorFeedback: project.consultations[0].mentorFeedback,
            notes: project.consultations[0].notes,
            cancelledBy: project.consultations[0].cancelledBy,
            cancelledAt: project.consultations[0].cancelledAt,
            cancelReason: project.consultations[0].cancelReason,
            markedAbsentBy: project.consultations[0].markedAbsentBy,
            absentAt: project.consultations[0].absentAt,
            absentReason: project.consultations[0].absentReason,
            timeSlot: project.consultations[0].timeSlot
              ? {
                  id: project.consultations[0].timeSlot.id,
                  startTime: project.consultations[0].timeSlot.startTime,
                  endTime: project.consultations[0].timeSlot.endTime,
                  date: project.consultations[0].timeSlot.date,
                }
              : null,
          }
        : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    }));

    res.json({ projects: formattedProjects });
  } catch (error) {
    console.error("Get projects error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
