module.exports = async function getMe(req, res, prisma) {
  try {
    const userId = req.user.userId;
    const rawUser = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        mentorType: true,
        isActive: true,
        assignedLabIds: true,
        labAssignments: {
          select: {
            id: true,
            mentorType: true,
            labId: true,
            lab: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
    });

    if (!rawUser || !rawUser.isActive) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const assignedLabIdSet = new Set(
      Array.isArray(rawUser.assignedLabIds) ? rawUser.assignedLabIds : [],
    );

    for (const assignment of rawUser.labAssignments || []) {
      if (Number.isInteger(assignment.labId)) {
        assignedLabIdSet.add(assignment.labId);
      }
    }

    // Supervisors can be assigned via schedule slots without explicit user.labAssignments
    if (rawUser.role === "SUPERVISOR") {
      const scheduledLabs = await prisma.timeSlot.findMany({
        where: {
          mentorId: rawUser.id,
          slotType: "CONSULTATION",
          date: { gte: new Date() },
        },
        select: {
          labId: true,
        },
        distinct: ["labId"],
      });

      for (const slot of scheduledLabs) {
        if (Number.isInteger(slot.labId)) {
          assignedLabIdSet.add(slot.labId);
        }
      }
    }

    let assignedLabs = [];
    if (assignedLabIdSet.size > 0) {
      assignedLabs = await prisma.lab.findMany({
        where: {
          id: { in: Array.from(assignedLabIdSet) },
        },
        select: {
          id: true,
          name: true,
        },
        orderBy: { name: "asc" },
      });
    }

    const user = {
      id: rawUser.id,
      name: rawUser.name,
      email: rawUser.email,
      role: rawUser.role,
      mentorType: rawUser.mentorType,
      isActive: rawUser.isActive,
      assignedLabIds: Array.from(assignedLabIdSet),
      assignedLabs,
      labAssignments: (rawUser.labAssignments || []).map((assignment) => ({
        id: assignment.id,
        labId: assignment.labId,
        mentorType: assignment.mentorType,
        labName: assignment.lab?.name || "Unknown Lab",
      })),
    };

    res.json({
      user,
      exp: req.user.exp || null,
    });
  } catch (error) {
    console.error("Get current user error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
