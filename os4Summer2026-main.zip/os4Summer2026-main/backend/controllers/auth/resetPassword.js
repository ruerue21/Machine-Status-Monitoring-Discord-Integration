const bcrypt = require("bcrypt");
const { validatePassword, hashToken } = require("../../utils/validation");

module.exports = async function resetPassword(req, res, prisma) {
  try {
    const { token, newPassword } = req.body;

    if (
      typeof token !== "string" ||
      token.trim().length === 0 ||
      typeof newPassword !== "string" ||
      newPassword.length === 0
    ) {
      return res
        .status(400)
        .json({ message: "Token and new password are required" });
    }

    // Validate password strength
    const passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.valid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    const tokenHash = hashToken(token);

    // Find user with valid token that hasn't expired
    const user = await prisma.user.findFirst({
      where: {
        OR: [{ passwordResetToken: token }, { passwordResetToken: tokenHash }],
        passwordResetExpires: {
          gt: new Date(), // Compare with current UTC time
        },
      },
    });

    if (!user) {
      // Check if token exists but is expired
      const expiredUser = await prisma.user.findFirst({
        where: {
          OR: [
            { passwordResetToken: token },
            { passwordResetToken: tokenHash },
          ],
        },
      });

      if (expiredUser) {
        return res.status(400).json({
          message:
            "Password reset token has expired. Please request a new one.",
          expired: true,
        });
      }

      return res
        .status(400)
        .json({ message: "Invalid or expired reset token" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        passwordResetToken: null,
        passwordResetExpires: null,
      },
    });

    res.json({
      message: "Password has been reset successfully. You can now log in.",
    });
  } catch (error) {
    console.error("Password reset error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
