const { clearAuthCookie } = require("../../utils/authCookie");

module.exports = async function logout(req, res) {
  clearAuthCookie(res);
  res.json({ message: "Logged out successfully" });
};
