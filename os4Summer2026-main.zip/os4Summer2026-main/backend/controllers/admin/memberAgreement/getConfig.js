const {
  getOrCreateMemberAgreementConfig,
} = require("../../../utils/memberAgreement");

module.exports = async function getConfig(req, res, prisma) {
  try {
    const config = await getOrCreateMemberAgreementConfig(prisma);

    const files = await prisma.memberAgreementFile.findMany({
      where: { configId: config.id },
      orderBy: [{ displayOrder: "asc" }, { uploadedAt: "asc" }],
      select: {
        id: true,
        fileName: true,
        fileType: true,
        resignType: true,
        anchorDate: true,
        specificDate: true,
        displayOrder: true,
        uploadedAt: true,
        updatedAt: true,
      },
    });

    res.json({
      config: {
        id: config.id,
        resignType: config.resignType,
        anchorDate: config.anchorDate,
        specificDate: config.specificDate,
        currentVersion: config.currentVersion,
        updatedAt: config.updatedAt,
      },
      files,
    });
  } catch (error) {
    console.error("Get member agreement config error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
