const VALID_TYPES = ["YEARLY", "MONTHLY", "WEEKLY", "SPECIFIC_DATE"];

const parseDate = (value) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

module.exports = async function updateFileSchedule(req, res, prisma) {
  try {
    const { fileId } = req.params;
    const { resignType, anchorDate, specificDate } = req.body;

    if (!VALID_TYPES.includes(resignType)) {
      return res.status(400).json({
        message:
          "Invalid re-sign schedule. Use YEARLY, MONTHLY, WEEKLY, or SPECIFIC_DATE.",
      });
    }

    const file = await prisma.memberAgreementFile.findUnique({
      where: { id: parseInt(fileId, 10) },
      include: { config: true },
    });

    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }

    const parsedAnchorDate =
      resignType === "SPECIFIC_DATE"
        ? file.anchorDate || file.config.anchorDate
        : parseDate(anchorDate) || file.anchorDate || file.config.anchorDate;

    const parsedSpecificDate =
      resignType === "SPECIFIC_DATE" ? parseDate(specificDate) : null;

    if (resignType === "SPECIFIC_DATE" && !parsedSpecificDate) {
      return res.status(400).json({
        message:
          "A valid specific date is required for SPECIFIC_DATE schedule.",
      });
    }

    const updated = await prisma.memberAgreementFile.update({
      where: { id: file.id },
      data: {
        resignType,
        anchorDate: parsedAnchorDate,
        specificDate: parsedSpecificDate,
      },
      select: {
        id: true,
        fileName: true,
        resignType: true,
        anchorDate: true,
        specificDate: true,
        updatedAt: true,
      },
    });

    res.json({
      message: `Schedule updated for ${updated.fileName}`,
      file: updated,
    });
  } catch (error) {
    console.error("Update member agreement file schedule error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
