const fs = require("fs");
const {
  validateAgreementFile,
  sanitizeFilename,
} = require("../../../utils/validation");
const {
  getOrCreateMemberAgreementConfig,
} = require("../../../utils/memberAgreement");

const safeDeleteFile = async (filePath) => {
  if (!filePath) return;
  try {
    await fs.promises.unlink(filePath);
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Failed to clean up uploaded file:", error);
    }
  }
};

module.exports = async function uploadFile(req, res, prisma) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const validation = validateAgreementFile(req.file);
    if (!validation.valid) {
      await safeDeleteFile(req.file.path);
      return res.status(400).json({ message: validation.error });
    }

    const config = await getOrCreateMemberAgreementConfig(prisma);

    const latestFile = await prisma.memberAgreementFile.findFirst({
      where: { configId: config.id },
      orderBy: { displayOrder: "desc" },
      select: { displayOrder: true },
    });

    const created = await prisma.memberAgreementFile.create({
      data: {
        configId: config.id,
        fileName: sanitizeFilename(req.file.originalname),
        fileUrl: req.file.filename,
        fileType: validation.fileType,
        resignType: config.resignType,
        anchorDate: config.anchorDate,
        specificDate: config.specificDate,
        displayOrder: (latestFile?.displayOrder || 0) + 1,
      },
    });

    res.json({
      message: "Member agreement document uploaded successfully",
      file: {
        id: created.id,
        fileName: created.fileName,
        fileType: created.fileType,
        uploadedAt: created.uploadedAt,
      },
      warning:
        "Users will need to sign this new document based on its schedule.",
    });
  } catch (error) {
    console.error("Upload member agreement file error:", error);
    if (req.file) {
      await safeDeleteFile(req.file.path);
    }
    res.status(500).json({ message: "Server error" });
  }
};
