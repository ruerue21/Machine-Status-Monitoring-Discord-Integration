const fs = require("fs");
const path = require("path");

const safeDeleteFile = async (filePath) => {
  if (!filePath) return;
  try {
    await fs.promises.unlink(filePath);
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Failed to delete file:", error);
    }
  }
};

module.exports = async function deleteFile(req, res, prisma) {
  try {
    const { fileId } = req.params;

    const existing = await prisma.memberAgreementFile.findUnique({
      where: { id: parseInt(fileId, 10) },
    });

    if (!existing) {
      return res.status(404).json({ message: "File not found" });
    }

    const existingFilePath = path.join(
      __dirname,
      "../../../uploads/member-agreements",
      path.basename(existing.fileUrl),
    );

    await prisma.memberAgreementFile.delete({ where: { id: existing.id } });

    await safeDeleteFile(existingFilePath);

    res.json({
      message: "Member agreement document deleted successfully",
      warning: "This document is no longer required for signing.",
    });
  } catch (error) {
    console.error("Delete member agreement file error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
