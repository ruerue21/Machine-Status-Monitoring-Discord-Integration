const fs = require("fs");
const path = require("path");
const {
  validateAgreementFile,
  sanitizeFilename,
} = require("../../../utils/validation");

const safeDeleteFile = async (filePath) => {
  if (!filePath) return;
  try {
    await fs.promises.unlink(filePath);
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Failed to delete file:", error);
    }
  }
};

module.exports = async function replaceFile(req, res, prisma) {
  try {
    const { fileId } = req.params;

    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const validation = validateAgreementFile(req.file);
    if (!validation.valid) {
      await safeDeleteFile(req.file.path);
      return res.status(400).json({ message: validation.error });
    }

    const existing = await prisma.memberAgreementFile.findUnique({
      where: { id: parseInt(fileId, 10) },
      include: { config: true },
    });

    if (!existing) {
      await safeDeleteFile(req.file.path);
      return res.status(404).json({ message: "File not found" });
    }

    const previousFilePath = path.join(
      __dirname,
      "../../../uploads/member-agreements",
      path.basename(existing.fileUrl),
    );

    const updated = await prisma.memberAgreementFile.update({
      where: { id: existing.id },
      data: {
        fileName: sanitizeFilename(req.file.originalname),
        fileUrl: req.file.filename,
        fileType: validation.fileType,
      },
    });

    await safeDeleteFile(previousFilePath);

    res.json({
      message: "Member agreement document replaced successfully",
      file: {
        id: updated.id,
        fileName: updated.fileName,
        fileType: updated.fileType,
        updatedAt: updated.updatedAt,
      },
      warning: "Users will need to re-sign this document.",
    });
  } catch (error) {
    console.error("Replace member agreement file error:", error);
    if (req.file) {
      await safeDeleteFile(req.file.path);
    }
    res.status(500).json({ message: "Server error" });
  }
};
