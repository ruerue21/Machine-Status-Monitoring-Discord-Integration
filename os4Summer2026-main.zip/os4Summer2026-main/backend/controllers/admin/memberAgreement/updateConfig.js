const {
  getOrCreateMemberAgreementConfig,
} = require("../../../utils/memberAgreement");

const VALID_TYPES = ["YEARLY", "MONTHLY", "WEEKLY", "SPECIFIC_DATE"];

const parseDate = (value) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

module.exports = async function updateConfig(req, res, prisma) {
  try {
    const { resignType, anchorDate, specificDate } = req.body;

    if (!VALID_TYPES.includes(resignType)) {
      return res.status(400).json({
        message:
          "Invalid re-sign schedule. Use YEARLY, MONTHLY, WEEKLY, or SPECIFIC_DATE.",
      });
    }

    const config = await getOrCreateMemberAgreementConfig(prisma);

    const parsedAnchorDate =
      resignType === "SPECIFIC_DATE"
        ? config.anchorDate
        : parseDate(anchorDate) || config.anchorDate;

    const parsedSpecificDate =
      resignType === "SPECIFIC_DATE" ? parseDate(specificDate) : null;

    if (resignType === "SPECIFIC_DATE" && !parsedSpecificDate) {
      return res.status(400).json({
        message:
          "A valid specific date is required for SPECIFIC_DATE schedule.",
      });
    }

    const updated = await prisma.memberAgreementConfig.update({
      where: { id: config.id },
      data: {
        resignType,
        anchorDate: parsedAnchorDate,
        specificDate: parsedSpecificDate,
      },
      select: {
        id: true,
        resignType: true,
        anchorDate: true,
        specificDate: true,
        currentVersion: true,
        updatedAt: true,
      },
    });

    res.json({
      message: "Default re-sign schedule saved for new files.",
      config: updated,
      invalidatedSignatures: false,
    });
  } catch (error) {
    console.error("Update member agreement config error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
