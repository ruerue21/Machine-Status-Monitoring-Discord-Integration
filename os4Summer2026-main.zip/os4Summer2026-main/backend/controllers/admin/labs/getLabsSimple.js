module.exports = async function (req, res, prisma) {
  try {
    const labs = await prisma.lab.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        location: true,
      },
      orderBy: { name: "asc" },
    });

    res.json({ labs });
  } catch (error) {
    console.error("Get labs error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
