const bcrypt = require("bcrypt");
const { sendVerificationEmail } = require("../../../services/emailService");
const { sanitizeEmail, sanitizeText } = require("../../../utils/sanitization");
const {
  validatePurdueEmail,
  validatePassword,
  generateVerificationToken,
  hashToken,
} = require("../../../utils/validation");

const VALID_ROLES = ["MEMBER", "PEER_MENTOR", "SUPERVISOR", "ADMIN"];

module.exports = async function (req, res, prisma) {
  try {
    const {
      name,
      email,
      password,
      role = "MEMBER",
      isActive = true,
      emailVerified = false,
      labAssignments = [],
    } = req.body;

    const currentUserRole = req.userDetails.role;
    const normalizedName = sanitizeText(name);
    const normalizedEmail = sanitizeEmail(email);
    const normalizedRole = typeof role === "string" ? role.toUpperCase() : role;

    if (!normalizedName || normalizedName.length > 100) {
      return res.status(400).json({
        message: "Name is required and must be 100 characters or less",
      });
    }

    if (!validatePurdueEmail(normalizedEmail)) {
      return res.status(400).json({
        message: "Please use a valid @purdue.edu email address",
      });
    }

    if (!VALID_ROLES.includes(normalizedRole)) {
      return res.status(400).json({
        message: "Invalid role provided",
      });
    }

    if (currentUserRole === "SUPERVISOR" && normalizedRole === "ADMIN") {
      return res.status(403).json({
        message: "Supervisors cannot create administrator accounts",
      });
    }

    const passwordValidation = validatePassword(password);
    if (!passwordValidation.valid) {
      return res.status(400).json({
        message: passwordValidation.message,
      });
    }

    if (typeof isActive !== "boolean" || typeof emailVerified !== "boolean") {
      return res.status(400).json({
        message: "isActive and emailVerified must be true or false",
      });
    }

    if (normalizedRole === "PEER_MENTOR" && Array.isArray(labAssignments)) {
      for (const assignment of labAssignments) {
        if (!assignment.labId || !assignment.mentorType) {
          return res.status(400).json({
            message: "Each lab assignment must have labId and mentorType",
          });
        }

        if (!["CONSULTATION", "LAB"].includes(assignment.mentorType)) {
          return res.status(400).json({
            message: "mentorType must be either CONSULTATION or LAB",
          });
        }
      }
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      select: { id: true },
    });

    if (existingUser) {
      return res.status(400).json({
        message: "A user with this email already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password.trim(), 10);

    const verificationToken = emailVerified
      ? null
      : generateVerificationToken();
    const verificationTokenHash = verificationToken
      ? hashToken(verificationToken)
      : null;
    const verificationTokenExpires = verificationToken
      ? new Date(Date.now() + 24 * 60 * 60 * 1000)
      : null;

    const createdUser = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          name: normalizedName,
          email: normalizedEmail,
          password: hashedPassword,
          role: normalizedRole,
          isActive,
          emailVerified,
          verificationToken: verificationTokenHash,
          verificationTokenExpires,
          assignedLabIds: [],
          mentorType: null,
        },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          isActive: true,
          emailVerified: true,
          createdAt: true,
        },
      });

      if (
        normalizedRole === "PEER_MENTOR" &&
        Array.isArray(labAssignments) &&
        labAssignments.length > 0
      ) {
        await tx.labMentorAssignment.createMany({
          data: labAssignments.map((a) => ({
            userId: user.id,
            labId: Number(a.labId),
            mentorType: a.mentorType,
          })),
          skipDuplicates: true,
        });
      }

      return user;
    });

    let verificationEmailSent = false;
    if (verificationToken) {
      try {
        await sendVerificationEmail(normalizedEmail, verificationToken);
        verificationEmailSent = true;
      } catch (emailError) {
        console.error(
          "Failed to send verification email for admin-created user:",
          emailError,
        );
      }
    }

    res.status(201).json({
      message: `Account created for ${createdUser.name}`,
      user: createdUser,
      verificationEmailSent,
    });
  } catch (error) {
    console.error("Create user account error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
