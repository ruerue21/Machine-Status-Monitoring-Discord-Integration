module.exports = async function (req, res, prisma) {
  try {
    const { userId, cancellationId } = req.params;
    const { reason } = req.body;

    // Verify the cancellation record exists and belongs to this user
    const cancellation = await prisma.agreementCancellation.findUnique({
      where: { id: parseInt(cancellationId) },
      include: {
        user: {
          select: { id: true, name: true },
        },
      },
    });

    if (!cancellation) {
      return res.status(404).json({ message: "Cancellation record not found" });
    }

    if (cancellation.userId !== parseInt(userId)) {
      return res.status(400).json({
        message: "Cancellation record does not belong to this user",
      });
    }

    // Update the reason
    const updatedCancellation = await prisma.agreementCancellation.update({
      where: { id: parseInt(cancellationId) },
      data: {
        reason: reason || null,
      },
      include: {
        cancelledByUser: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
    });

    res.json({
      message: "Cancellation reason updated successfully",
      cancellation: updatedCancellation,
    });
  } catch (error) {
    console.error("Update cancellation reason error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
