const {
  sendAgreementCancellationNotification,
} = require("../../../services/emailService");

module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const { reason } = req.body;

    const cancelledBy = req.userDetails.id;
    const cancellerRole = req.userDetails.role;

    if (!cancelledBy) {
      return res.status(401).json({ message: "User not authenticated" });
    }

    // Verify target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        memberAgreementSigned: true,
        agreementCancellations: true,
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if agreement is actually signed
    if (!targetUser.memberAgreementSigned) {
      return res.status(400).json({
        message: "User has not signed the member agreement",
      });
    }

    // Permission checks based on canceller role
    if (cancellerRole === "SUPERVISOR") {
      // Supervisors can cancel for everyone except ADMIN
      if (targetUser.role === "ADMIN") {
        return res.status(403).json({
          message: "Supervisors cannot cancel agreements for administrators",
        });
      }
    } else if (cancellerRole === "ADMIN") {
      // Admins can cancel for everyone (no restrictions)
    } else {
      return res.status(403).json({
        message: "You do not have permission to cancel member agreements",
      });
    }

    const result = await prisma.$transaction(async (tx) => {
      // Create cancellation history record
      await tx.agreementCancellation.create({
        data: {
          userId: parseInt(userId),
          cancelledBy: parseInt(cancelledBy),
          reason: reason || null,
        },
      });

      // Cancel agreement and increment counter
      const updatedUser = await tx.user.update({
        where: { id: parseInt(userId) },
        data: {
          memberAgreementSigned: false,
          memberAgreementDate: null,
          agreementCancellations: {
            increment: 1,
          },
          lastAgreementCancelledAt: new Date(),
          lastAgreementCancelledBy: parseInt(cancelledBy),
        },
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          memberAgreementSigned: true,
          agreementCancellations: true,
          lastAgreementCancelledAt: true,
          agreementCancelledBy: {
            select: {
              name: true,
              email: true,
            },
          },
        },
      });

      return updatedUser;
    });

    // Send cancellation notification to user
    sendAgreementCancellationNotification(targetUser.email, {
      userName: targetUser.name,
      cancelledAt: new Date(),
      cancelledByName: req.userDetails.name,
      reason: reason || null,
    }).catch((err) => {
      console.error("Failed to send agreement cancellation notification:", err);
    });

    res.json({
      message: "Member agreement cancelled successfully",
      user: result,
      reason: reason || "No reason provided",
    });
  } catch (error) {
    console.error("Cancel agreement error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
