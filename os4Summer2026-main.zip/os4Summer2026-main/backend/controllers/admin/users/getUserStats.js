module.exports = async function (req, res, prisma) {
  try {
    const [
      totalAdmins,
      totalSupervisors,
      totalMembers,
      totalInactive,
      totalActive,
      totalUsers,
      consultationMentorAssignments,
      labMentorAssignments,
    ] = await Promise.all([
      prisma.user.count({ where: { role: "ADMIN" } }),
      prisma.user.count({ where: { role: "SUPERVISOR" } }),
      prisma.user.count({ where: { role: "MEMBER" } }),
      prisma.user.count({ where: { isActive: false } }),
      prisma.user.count({ where: { isActive: true } }),
      prisma.user.count(),
      // Get unique consultation mentors
      prisma.labMentorAssignment.findMany({
        where: { mentorType: "CONSULTATION" },
        select: { userId: true },
        distinct: ["userId"],
      }),
      // Get unique lab mentors
      prisma.labMentorAssignment.findMany({
        where: { mentorType: "LAB" },
        select: { userId: true },
        distinct: ["userId"],
      }),
    ]);

    // Count unique users
    const totalConsultationMentors = consultationMentorAssignments.length;
    const totalLabMentors = labMentorAssignments.length;

    res.json({
      stats: {
        totalAdmins,
        totalSupervisors,
        totalConsultationMentors,
        totalLabMentors,
        totalMembers,
        totalInactive,
        totalActive,
        totalUsers,
      },
    });
  } catch (error) {
    console.error("Get user stats error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
