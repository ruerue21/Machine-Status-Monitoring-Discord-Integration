const {
  sendAccountDeletionNotification,
} = require("../../../services/emailService");

module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const currentUserRole = req.userDetails.role;
    const currentUserId = req.userDetails.id;

    // Prevent self-deletion
    if (parseInt(userId) === currentUserId) {
      return res.status(400).json({
        message: "You cannot delete your own account",
      });
    }

    // Verify target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        _count: {
          select: {
            projects: true,
            bookings: true,
            consultations: true,
          },
        },
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Permission checks
    if (currentUserRole === "SUPERVISOR") {
      if (targetUser.role === "ADMIN") {
        return res.status(403).json({
          message: "Supervisors cannot delete administrator accounts",
        });
      }
    }

    // Get detailed booking info before deletion
    const userBookings = await prisma.booking.findMany({
      where: {
        userId: parseInt(userId),
        status: { in: ["CONFIRMED"] }, // Only active bookings
      },
      include: {
        timeSlot: true,
      },
    });

    // Prepare warning info
    const warnings = [];
    if (targetUser._count.projects > 0) {
      warnings.push(
        `${targetUser._count.projects} project(s) will remain in the system without an owner`,
      );
    }
    if (userBookings.length > 0) {
      warnings.push(
        `${userBookings.length} active booking(s) will be cancelled and time slots released`,
      );
    }
    if (targetUser._count.consultations > 0) {
      warnings.push(
        `${targetUser._count.consultations} consultation(s) will remain in the system without an owner`,
      );
    }

    // Send deletion notification to user before deleting account
    sendAccountDeletionNotification(targetUser.email, {
      name: targetUser.name,
      email: targetUser.email,
      deletedAt: new Date(),
      cancelledBookings: userBookings.length,
    }).catch((err) => {
      console.error("Failed to send account deletion notification:", err);
      // Continue with deletion even if email fails
    });

    // Delete user in transaction
    await prisma.$transaction(async (tx) => {
      // Cancel all active bookings and free their time slots
      if (userBookings.length > 0) {
        // Update bookings to CANCELLED status with reason
        await tx.booking.updateMany({
          where: {
            userId: parseInt(userId),
            status: { in: ["CONFIRMED"] },
          },
          data: {
            status: "CANCELLED",
            cancellationReason: "Account deleted",
            cancelledBy: currentUserId,
          },
        });

        // Free all time slots associated with these bookings
        const timeSlotIds = userBookings
          .filter((b) => b.timeSlotId)
          .map((b) => b.timeSlotId);

        if (timeSlotIds.length > 0) {
          await tx.timeSlot.updateMany({
            where: { id: { in: timeSlotIds } },
            data: { isBooked: false },
          });
        }
      }

      // Handle consultations (free their time slots if they haven't happened yet)
      const userConsultations = await tx.consultation.findMany({
        where: {
          userId: parseInt(userId),
          status: "SCHEDULED",
          timeSlotId: { not: null },
        },
        include: {
          timeSlot: true,
        },
      });

      if (userConsultations.length > 0) {
        const consultationTimeSlotIds = userConsultations.map(
          (c) => c.timeSlotId,
        );

        // Free consultation time slots
        await tx.timeSlot.updateMany({
          where: { id: { in: consultationTimeSlotIds } },
          data: { isBooked: false },
        });

        // Update consultations to CANCELLED
        await tx.consultation.updateMany({
          where: {
            userId: parseInt(userId),
            status: "SCHEDULED",
          },
          data: {
            status: "CANCELLED",
            notes: "User account deleted",
          },
        });
      }

      // Delete lab mentor assignments
      await tx.labMentorAssignment.deleteMany({
        where: { userId: parseInt(userId) },
      });

      // Time slots where user is the mentor will CASCADE delete due to schema

      // Delete agreement cancellation history
      await tx.agreementCancellation.deleteMany({
        where: {
          OR: [{ userId: parseInt(userId) }, { cancelledBy: parseInt(userId) }],
        },
      });

      // Delete lab agreement cancellation history where this user is actor/subject
      await tx.labAgreementCancellation.deleteMany({
        where: {
          OR: [{ userId: parseInt(userId) }, { cancelledBy: parseInt(userId) }],
        },
      });

      // Update users who had their agreements cancelled by this user
      await tx.user.updateMany({
        where: { lastAgreementCancelledBy: parseInt(userId) },
        data: { lastAgreementCancelledBy: null },
      });

      // Finally, delete the user
      // Projects, bookings (now cancelled), and consultations will have userId set to null
      await tx.user.delete({
        where: { id: parseInt(userId) },
      });
    });

    res.json({
      message: `User account for ${targetUser.name} has been permanently deleted`,
      warnings: warnings.length > 0 ? warnings : undefined,
      deletedUser: {
        id: targetUser.id,
        name: targetUser.name,
        email: targetUser.email,
      },
      details: {
        cancelledBookings: userBookings.length,
        orphanedProjects: targetUser._count.projects,
      },
    });
  } catch (error) {
    console.error("Delete user account error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
