module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;

    const history = await prisma.agreementCancellation.findMany({
      where: { userId: parseInt(userId) },
      include: {
        cancelledByUser: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    res.json({ history });
  } catch (error) {
    console.error("Get agreement history error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
