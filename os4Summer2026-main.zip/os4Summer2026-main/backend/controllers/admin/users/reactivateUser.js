module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const currentUserRole = req.userDetails.role;

    // Verify target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if user is already active
    if (targetUser.isActive) {
      return res.status(400).json({
        message: "User is already active",
      });
    }

    // Permission checks
    if (currentUserRole === "SUPERVISOR") {
      if (targetUser.role === "ADMIN") {
        return res.status(403).json({
          message: "Supervisors cannot reactivate administrators",
        });
      }
    }

    // Update user to active
    const updatedUser = await prisma.user.update({
      where: { id: parseInt(userId) },
      data: {
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
      },
    });

    res.json({
      message: `User ${updatedUser.name} has been reactivated`,
      user: updatedUser,
    });
  } catch (error) {
    console.error("Reactivate user error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
