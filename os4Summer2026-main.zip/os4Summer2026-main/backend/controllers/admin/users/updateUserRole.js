const {
  canChangeUserRole,
  getRoleDisplayName,
  getRoleChangeAction,
} = require("../../../utils/roleHelpers");

module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const { newRole, labAssignments = [] } = req.body;
    const currentUserRole = req.userDetails.role;

    // Validate the target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        mentorType: true,
        assignedLabIds: true,
        labAssignments: {
          include: {
            lab: { select: { id: true, name: true } },
          },
        },
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Validate role change permissions
    if (!canChangeUserRole(currentUserRole, targetUser.role, newRole)) {
      return res.status(403).json({
        message: "You don't have permission to make this role change",
      });
    }

    // Validate peer mentor requirements
    if (newRole === "PEER_MENTOR") {
      if (!labAssignments || labAssignments.length === 0) {
        return res.status(400).json({
          message:
            "Peer mentors must be assigned to at least one lab with a mentor type",
        });
      }

      // Validate each assignment has required fields
      for (const assignment of labAssignments) {
        if (!assignment.labId || !assignment.mentorType) {
          return res.status(400).json({
            message: "Each lab assignment must have labId and mentorType",
          });
        }
        if (!["CONSULTATION", "LAB"].includes(assignment.mentorType)) {
          return res.status(400).json({
            message: "mentorType must be either CONSULTATION or LAB",
          });
        }
      }
    }

    // Perform role change with cleanup
    const warnings = [];
    const oldRole = targetUser.role;

    await prisma.$transaction(async (tx) => {
      // Handle leaving PEER_MENTOR role
      if (oldRole === "PEER_MENTOR" && newRole !== "PEER_MENTOR") {
        // Get all lab assignments
        const oldAssignments = await tx.labMentorAssignment.findMany({
          where: { userId: parseInt(userId) },
          select: { mentorType: true },
        });

        const hasConsultation = oldAssignments.some(
          (a) => a.mentorType === "CONSULTATION",
        );
        const hasLab = oldAssignments.some((a) => a.mentorType === "LAB");

        // Handle CONSULTATION peer mentor specific cleanup
        if (hasConsultation) {
          const mentorTimeSlots = await tx.timeSlot.findMany({
            where: {
              mentorId: parseInt(userId),
              slotType: "CONSULTATION",
            },
            select: { id: true },
          });

          const timeSlotIds = mentorTimeSlots.map((slot) => slot.id);

          const allConsultations = await tx.consultation.findMany({
            where: { timeSlotId: { in: timeSlotIds } },
            include: {
              project: {
                include: {
                  user: { select: { name: true, email: true } },
                  bookings: { select: { id: true } },
                },
              },
            },
          });

          const projectMap = new Map();
          allConsultations.forEach((consultation) => {
            if (!consultation.project?.id) {
              return;
            }
            if (!projectMap.has(consultation.project.id)) {
              projectMap.set(consultation.project.id, consultation.project);
            }
          });

          for (const project of projectMap.values()) {
            const projectId = project.id;

            // Delete all bookings for this project
            if (project.bookings.length > 0) {
              // Free the time slots associated with bookings
              const bookingsWithSlots = await tx.booking.findMany({
                where: { projectId: projectId },
                select: { timeSlotId: true },
              });

              const bookingTimeSlotIds = bookingsWithSlots
                .filter((b) => b.timeSlotId)
                .map((b) => b.timeSlotId);

              if (bookingTimeSlotIds.length > 0) {
                await tx.timeSlot.updateMany({
                  where: { id: { in: bookingTimeSlotIds } },
                  data: { isBooked: false },
                });
              }

              // Delete booking equipment associations
              await tx.bookingEquipment.deleteMany({
                where: {
                  booking: {
                    projectId: projectId,
                  },
                },
              });

              // Delete all bookings
              await tx.booking.deleteMany({
                where: { projectId: projectId },
              });

              warnings.push(
                `Deleted ${project.bookings.length} booking(s) for ${project.user.name}'s project`,
              );
            }

            // Delete project
            await tx.project.delete({
              where: { id: projectId },
            });

            warnings.push(
              `Deleted consultation project for ${project.user.name}`,
            );
          }

          // Delete consultation time slots
          const deletedConsultationSlots = await tx.timeSlot.deleteMany({
            where: {
              mentorId: parseInt(userId),
              slotType: "CONSULTATION",
            },
          });

          if (deletedConsultationSlots.count > 0) {
            warnings.push(
              `Removed ${deletedConsultationSlots.count} consultation time slots`,
            );
          }
        }

        // Handle LAB peer mentor specific cleanup
        if (hasLab) {
          const activeBookings = await tx.booking.count({
            where: {
              labMentorId: parseInt(userId),
              status: "CONFIRMED",
              startDate: { gte: new Date() },
            },
          });

          if (activeBookings > 0) {
            warnings.push(
              `User has ${activeBookings} active lab booking(s) that will need reassignment`,
            );
          }

          // Delete lab time slots
          const deletedLabSlots = await tx.timeSlot.deleteMany({
            where: {
              mentorId: parseInt(userId),
              slotType: "LAB",
            },
          });

          if (deletedLabSlots.count > 0) {
            warnings.push(`Removed ${deletedLabSlots.count} lab time slots`);
          }
        }

        // Delete all lab assignments
        await tx.labMentorAssignment.deleteMany({
          where: { userId: parseInt(userId) },
        });

        warnings.push("Removed from all lab assignments");
      }

      // Update user role
      await tx.user.update({
        where: { id: parseInt(userId) },
        data: {
          role: newRole,
          assignedLabIds: [],
          mentorType: null,
        },
      });

      // Create new lab assignments for peer mentors
      if (newRole === "PEER_MENTOR" && labAssignments.length > 0) {
        // Delete existing assignments first
        await tx.labMentorAssignment.deleteMany({
          where: { userId: parseInt(userId) },
        });

        // Create new assignments
        await tx.labMentorAssignment.createMany({
          data: labAssignments.map((a) => ({
            userId: parseInt(userId),
            labId: a.labId,
            mentorType: a.mentorType,
          })),
          skipDuplicates: true,
        });

        const consultationCount = labAssignments.filter(
          (a) => a.mentorType === "CONSULTATION",
        ).length;
        const labCount = labAssignments.filter(
          (a) => a.mentorType === "LAB",
        ).length;

        const parts = [];
        if (consultationCount > 0) {
          parts.push(`${consultationCount} Consultation`);
        }
        if (labCount > 0) {
          parts.push(`${labCount} Lab`);
        }

        warnings.push(
          `Assigned to ${parts.join(" and ")} position(s) - schedule generation needed`,
        );
      }
    });

    // Get updated user data with new assignments
    const updatedUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        labAssignments: {
          include: {
            lab: { select: { id: true, name: true, location: true } },
          },
        },
      },
    });

    res.json({
      message: `User ${targetUser.name} has been ${getRoleChangeAction(
        targetUser.role,
        newRole,
      )} to ${getRoleDisplayName(newRole)}`,
      user: updatedUser,
      warnings: warnings,
    });
  } catch (error) {
    console.error("Update user role error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
