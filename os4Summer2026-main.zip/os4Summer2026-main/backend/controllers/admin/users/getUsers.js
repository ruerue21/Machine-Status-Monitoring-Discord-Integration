const {
  canPromoteUser,
  canDemoteUser,
  getAvailablePromotions,
  getAvailableDemotions,
} = require("../../../utils/roleHelpers");
const {
  parsePaginationParams,
  createPaginationMeta,
} = require("../../../utils/pagination");
const {
  hasCurrentSignaturesForAllFiles,
  getOrCreateMemberAgreementConfig,
} = require("../../../utils/memberAgreement");

module.exports = async function (req, res, prisma) {
  try {
    const { search, role, mentorType } = req.query;
    const currentUserRole = req.userDetails.role;
    const config = await getOrCreateMemberAgreementConfig(prisma);

    // Build where clause for filtering
    const whereClause = {};

    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
      ];
    }

    if (role && role !== "ALL") {
      whereClause.role = role;
    }

    if (role === "PEER_MENTOR" && mentorType && mentorType !== "ALL") {
      whereClause.labAssignments = {
        some: {
          mentorType,
        },
      };
    }

    // Parse pagination parameters
    const { page, limit, skip } = parsePaginationParams(req.query);

    // Get total count for pagination
    const total = await prisma.user.count({
      where: whereClause,
    });

    // Get paginated users
    const users = await prisma.user.findMany({
      where: whereClause,
      skip,
      take: limit,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        mentorType: true,
        emailVerified: true,
        memberAgreementSigned: true,
        memberAgreementDate: true,
        memberAgreementVersionSigned: true,
        agreementCancellations: true,
        lastAgreementCancelledAt: true,
        isActive: true,
        lastLoginAt: true,
        createdAt: true,
        assignedLabIds: true,
        labAssignments: {
          include: {
            lab: { select: { id: true, name: true, location: true } },
          },
        },
      },
      orderBy: [{ role: "asc" }, { name: "asc" }],
    });

    const userIds = users.map((u) => u.id);

    const [agreementFiles, signatures] = await Promise.all([
      prisma.memberAgreementFile.findMany({
        where: { configId: config.id },
        select: {
          id: true,
          resignType: true,
          anchorDate: true,
          specificDate: true,
          updatedAt: true,
        },
      }),
      userIds.length
        ? prisma.memberAgreementFileSignature.findMany({
            where: {
              userId: { in: userIds },
            },
            select: {
              userId: true,
              fileId: true,
              signedAt: true,
            },
          })
        : [],
    ]);

    const signatureMapByUser = new Map();
    signatures.forEach((signature) => {
      const existing = signatureMapByUser.get(signature.userId) || new Map();
      existing.set(signature.fileId, signature.signedAt);
      signatureMapByUser.set(signature.userId, existing);
    });

    const supervisorIds = users
      .filter((user) => user.role === "SUPERVISOR")
      .map((user) => user.id);

    const supervisorTimeSlots =
      supervisorIds.length > 0
        ? await prisma.timeSlot.findMany({
            where: {
              mentorId: { in: supervisorIds },
              slotType: "CONSULTATION",
              date: { gte: new Date() },
            },
            distinct: ["mentorId", "labId"],
            select: {
              mentorId: true,
              lab: {
                select: { id: true, name: true, location: true },
              },
            },
          })
        : [];

    const supervisorLabMap = new Map();
    supervisorTimeSlots.forEach((slot) => {
      const existing = supervisorLabMap.get(slot.mentorId) || [];
      existing.push({
        labId: slot.lab.id,
        labName: slot.lab.name,
        labLocation: slot.lab.location,
        mentorType: null,
      });
      supervisorLabMap.set(slot.mentorId, existing);
    });

    // Process each user and fetch supervisor labs if needed
    const usersWithPermissions = await Promise.all(
      users.map(async (user) => {
        let finalLabAssignments = [];

        // For supervisors, get unique labs from their time slots
        if (user.role === "SUPERVISOR") {
          finalLabAssignments = supervisorLabMap.get(user.id) || [];
        } else if (user.role === "PEER_MENTOR") {
          // For peer mentors, use existing lab assignments
          finalLabAssignments = user.labAssignments.map((a) => ({
            labId: a.labId,
            labName: a.lab.name,
            labLocation: a.lab.location,
            mentorType: a.mentorType,
          }));
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          mentorType: user.mentorType,
          emailVerified: user.emailVerified,
          memberAgreementSigned: hasCurrentSignaturesForAllFiles(
            agreementFiles,
            signatureMapByUser.get(user.id) || new Map(),
            config,
          ),
          memberAgreementDate: user.memberAgreementDate,
          agreementCancellations: user.agreementCancellations,
          lastAgreementCancelledAt: user.lastAgreementCancelledAt,
          isActive: user.isActive,
          lastLoginAt: user.lastLoginAt,
          createdAt: user.createdAt,
          assignedLabIds: user.assignedLabIds,
          canPromote: canPromoteUser(currentUserRole, user.role),
          canDemote: canDemoteUser(currentUserRole, user.role),
          availablePromotions: getAvailablePromotions(
            currentUserRole,
            user.role,
          ),
          availableDemotions: getAvailableDemotions(currentUserRole, user.role),
          labAssignments: finalLabAssignments,
        };
      }),
    );

    const paginationMeta = createPaginationMeta(total, page, limit);
    const hasMemberAgreementFiles = agreementFiles.length > 0;

    res.json({
      users: usersWithPermissions,
      currentUserRole,
      pagination: paginationMeta,
      hasMemberAgreementFiles,
    });
  } catch (error) {
    console.error("Get users error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
