const bcrypt = require("bcrypt");
const { sendVerificationEmail } = require("../../../services/emailService");
const { sanitizeEmail, sanitizeText } = require("../../../utils/sanitization");
const {
  validatePurdueEmail,
  validatePassword,
  generateVerificationToken,
  hashToken,
} = require("../../../utils/validation");

module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const currentUserRole = req.userDetails.role;
    const targetUserId = parseInt(userId);

    if (Number.isNaN(targetUserId)) {
      return res.status(400).json({ message: "Invalid user id" });
    }

    const targetUser = await prisma.user.findUnique({
      where: { id: targetUserId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        emailVerified: true,
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    if (currentUserRole === "SUPERVISOR" && targetUser.role === "ADMIN") {
      return res.status(403).json({
        message: "Supervisors cannot edit administrator accounts",
      });
    }

    const hasName = Object.prototype.hasOwnProperty.call(req.body, "name");
    const hasEmail = Object.prototype.hasOwnProperty.call(req.body, "email");
    const hasIsActive = Object.prototype.hasOwnProperty.call(
      req.body,
      "isActive",
    );
    const hasEmailVerified = Object.prototype.hasOwnProperty.call(
      req.body,
      "emailVerified",
    );
    const hasPassword = Object.prototype.hasOwnProperty.call(
      req.body,
      "password",
    );

    if (
      !hasName &&
      !hasEmail &&
      !hasIsActive &&
      !hasEmailVerified &&
      !hasPassword
    ) {
      return res.status(400).json({
        message:
          "Provide at least one field to update: name, email, isActive, emailVerified, or password",
      });
    }

    const updateData = {};

    if (hasName) {
      const normalizedName = sanitizeText(req.body.name);
      if (!normalizedName || normalizedName.length > 100) {
        return res.status(400).json({
          message: "Name is required and must be 100 characters or less",
        });
      }
      updateData.name = normalizedName;
    }

    if (hasEmail) {
      const normalizedEmail = sanitizeEmail(req.body.email);
      if (!validatePurdueEmail(normalizedEmail)) {
        return res.status(400).json({
          message: "Please use a valid @purdue.edu email address",
        });
      }

      if (normalizedEmail !== targetUser.email) {
        const existing = await prisma.user.findUnique({
          where: { email: normalizedEmail },
          select: { id: true },
        });

        if (existing && existing.id !== targetUser.id) {
          return res.status(400).json({
            message: "A user with this email already exists",
          });
        }
      }

      updateData.email = normalizedEmail;
    }

    if (hasIsActive) {
      if (typeof req.body.isActive !== "boolean") {
        return res.status(400).json({
          message: "isActive must be true or false",
        });
      }
      updateData.isActive = req.body.isActive;
    }

    let shouldSendVerificationEmail = false;
    let rawVerificationToken = null;

    if (hasEmailVerified) {
      if (typeof req.body.emailVerified !== "boolean") {
        return res.status(400).json({
          message: "emailVerified must be true or false",
        });
      }

      updateData.emailVerified = req.body.emailVerified;

      if (req.body.emailVerified) {
        updateData.verificationToken = null;
        updateData.verificationTokenExpires = null;
      } else {
        rawVerificationToken = generateVerificationToken();
        updateData.verificationToken = hashToken(rawVerificationToken);
        updateData.verificationTokenExpires = new Date(
          Date.now() + 24 * 60 * 60 * 1000,
        );
        shouldSendVerificationEmail = true;
      }
    }

    if (hasPassword) {
      const passwordValidation = validatePassword(req.body.password);
      if (!passwordValidation.valid) {
        return res.status(400).json({
          message: passwordValidation.message,
        });
      }
      updateData.password = await bcrypt.hash(req.body.password.trim(), 10);
    }

    const updatedUser = await prisma.user.update({
      where: { id: targetUserId },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        emailVerified: true,
        lastLoginAt: true,
        updatedAt: true,
      },
    });

    let verificationEmailSent = false;
    if (shouldSendVerificationEmail && rawVerificationToken) {
      try {
        await sendVerificationEmail(updatedUser.email, rawVerificationToken);
        verificationEmailSent = true;
      } catch (emailError) {
        console.error(
          "Failed to send verification email after admin update:",
          emailError,
        );
      }
    }

    res.json({
      message: `Account updated for ${updatedUser.name}`,
      user: updatedUser,
      verificationEmailSent,
    });
  } catch (error) {
    console.error("Update user account error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
