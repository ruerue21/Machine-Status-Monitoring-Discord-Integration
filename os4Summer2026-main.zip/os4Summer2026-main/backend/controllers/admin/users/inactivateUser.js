module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const currentUserRole = req.userDetails.role;

    // Verify target user exists
    const targetUser = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
      },
    });

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if user is already inactive
    if (!targetUser.isActive) {
      return res.status(400).json({
        message: "User is already inactive",
      });
    }

    // Permission checks
    if (currentUserRole === "SUPERVISOR") {
      if (targetUser.role === "ADMIN") {
        return res.status(403).json({
          message: "Supervisors cannot inactivate administrators",
        });
      }
    }

    // Update user to inactive
    const updatedUser = await prisma.user.update({
      where: { id: parseInt(userId) },
      data: {
        isActive: false,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
      },
    });

    res.json({
      message: `User ${updatedUser.name} has been marked as inactive`,
      user: updatedUser,
    });
  } catch (error) {
    console.error("Inactivate user error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
