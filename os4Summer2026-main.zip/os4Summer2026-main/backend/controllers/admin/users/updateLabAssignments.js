module.exports = async function (req, res, prisma) {
  try {
    const { userId } = req.params;
    const { labAssignments = [] } = req.body;

    const user = await prisma.user.findUnique({
      where: { id: parseInt(userId) },
      select: {
        id: true,
        name: true,
        role: true,
        labAssignments: {
          include: {
            lab: { select: { id: true, name: true } },
          },
        },
      },
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.role !== "PEER_MENTOR") {
      return res.status(400).json({
        message: "User must be a peer mentor to update lab assignments",
      });
    }

    if (labAssignments.length === 0) {
      return res.status(400).json({
        message: "At least one lab assignment is required",
      });
    }

    // Validate assignments
    for (const assignment of labAssignments) {
      if (!assignment.labId || !assignment.mentorType) {
        return res.status(400).json({
          message: "Each lab assignment must have labId and mentorType",
        });
      }
      if (!["CONSULTATION", "LAB"].includes(assignment.mentorType)) {
        return res.status(400).json({
          message: "mentorType must be either CONSULTATION or LAB",
        });
      }
    }

    const warnings = [];

    await prisma.$transaction(async (tx) => {
      // Get old assignments to identify removed labs
      const oldAssignments = await tx.labMentorAssignment.findMany({
        where: { userId: parseInt(userId) },
        select: { id: true, labId: true, mentorType: true },
      });

      // Find removed assignments (lab+type combinations that are being removed)
      const newAssignmentKeys = labAssignments.map(
        (a) => `${a.labId}-${a.mentorType}`,
      );
      const removedAssignments = oldAssignments.filter(
        (old) => !newAssignmentKeys.includes(`${old.labId}-${old.mentorType}`),
      );

      // Clean up time slots for removed lab assignments
      for (const removed of removedAssignments) {
        // Check for booked slots before deleting
        const bookedSlotsCount = await tx.timeSlot.count({
          where: {
            mentorId: parseInt(userId),
            labId: removed.labId,
            slotType: removed.mentorType,
            isBooked: true,
          },
        });

        if (bookedSlotsCount > 0) {
          const lab = await tx.lab.findUnique({
            where: { id: removed.labId },
            select: { name: true },
          });
          warnings.push(
            `${bookedSlotsCount} booked ${removed.mentorType.toLowerCase()} slot(s) remain for ${lab.name} - will need reassignment`,
          );
        }

        // Delete all time slots for this removed assignment
        const deletedSlots = await tx.timeSlot.deleteMany({
          where: {
            mentorId: parseInt(userId),
            labId: removed.labId,
            slotType: removed.mentorType,
          },
        });

        if (deletedSlots.count > 0) {
          const lab = await tx.lab.findUnique({
            where: { id: removed.labId },
            select: { name: true },
          });
          warnings.push(
            `Removed ${deletedSlots.count} time slot(s) from ${lab.name} (${removed.mentorType})`,
          );
        }
      }

      // Delete all existing assignments
      await tx.labMentorAssignment.deleteMany({
        where: { userId: parseInt(userId) },
      });

      // Create new assignments
      await tx.labMentorAssignment.createMany({
        data: labAssignments.map((a) => ({
          userId: parseInt(userId),
          labId: a.labId,
          mentorType: a.mentorType,
        })),
        skipDuplicates: true,
      });
    });

    // Get updated assignments
    const updatedAssignments = await prisma.labMentorAssignment.findMany({
      where: { userId: parseInt(userId) },
      include: {
        lab: { select: { id: true, name: true, location: true } },
      },
    });

    const consultationCount = updatedAssignments.filter(
      (a) => a.mentorType === "CONSULTATION",
    ).length;
    const labCount = updatedAssignments.filter(
      (a) => a.mentorType === "LAB",
    ).length;

    const summary = [];
    if (consultationCount > 0) {
      summary.push(`${consultationCount} Consultation assignment(s)`);
    }
    if (labCount > 0) {
      summary.push(`${labCount} Lab assignment(s)`);
    }

    res.json({
      message: `Lab assignments updated successfully: ${summary.join(" and ")}`,
      assignments: updatedAssignments,
      warnings: warnings.length > 0 ? warnings : undefined,
    });
  } catch (error) {
    console.error("Update lab assignments error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
