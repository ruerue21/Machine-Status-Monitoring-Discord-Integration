const DAY_NAMES = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

const createEmptyWeeklySchedule = () => ({
  monday: [],
  tuesday: [],
  wednesday: [],
  thursday: [],
  friday: [],
  saturday: [],
  sunday: [],
});

module.exports = async function getMySchedule(req, res, prisma) {
  try {
    const userId = req.user?.userId;
    const role = req.userDetails?.role || req.user?.role;

    if (!Number.isInteger(userId)) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (!["PEER_MENTOR", "SUPERVISOR", "ADMIN"].includes(role)) {
      return res.status(403).json({ message: "Access denied" });
    }

    const slots = await prisma.timeSlot.findMany({
      where: {
        mentorId: userId,
        date: { gte: new Date() },
      },
      select: {
        id: true,
        date: true,
        startTime: true,
        endTime: true,
        isBooked: true,
        slotType: true,
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        consultation: {
          select: {
            id: true,
            status: true,
            project: {
              select: {
                id: true,
                name: true,
              },
            },
            user: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        bookings: {
          select: {
            id: true,
            status: true,
            project: {
              select: {
                id: true,
                name: true,
              },
            },
            user: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    const assignmentMap = new Map();

    for (const slot of slots) {
      const assignmentKey = `${slot.slotType}:${slot.lab.id}`;
      if (!assignmentMap.has(assignmentKey)) {
        assignmentMap.set(assignmentKey, {
          assignmentKey,
          slotType: slot.slotType,
          lab: {
            id: slot.lab.id,
            name: slot.lab.name,
            location: slot.lab.location,
          },
          weeklySchedule: createEmptyWeeklySchedule(),
          upcomingSlots: [],
          totalSlots: 0,
          bookedSlots: 0,
        });
      }

      const assignment = assignmentMap.get(assignmentKey);
      assignment.totalSlots += 1;
      if (slot.isBooked) {
        assignment.bookedSlots += 1;
      }

      const dayName = DAY_NAMES[slot.date.getDay()];
      const existingPattern = assignment.weeklySchedule[dayName] || [];
      const alreadyHasTime = existingPattern.some(
        (patternSlot) =>
          patternSlot.startTime === slot.startTime &&
          patternSlot.endTime === slot.endTime,
      );

      if (!alreadyHasTime) {
        assignment.weeklySchedule[dayName] = [
          ...existingPattern,
          {
            startTime: slot.startTime,
            endTime: slot.endTime,
          },
        ].sort((a, b) => a.startTime.localeCompare(b.startTime));
      }

      const workItems = [];
      if (slot.consultation) {
        workItems.push({
          type: "CONSULTATION",
          id: slot.consultation.id,
          status: slot.consultation.status,
          projectName: slot.consultation.project?.name || "Unknown Project",
          studentName: slot.consultation.user?.name || "Unknown Student",
        });
      }

      for (const booking of slot.bookings || []) {
        workItems.push({
          type: "LAB_BOOKING",
          id: booking.id,
          status: booking.status,
          projectName: booking.project?.name || "Unknown Project",
          studentName: booking.user?.name || "Unknown Student",
        });
      }

      assignment.upcomingSlots.push({
        id: slot.id,
        date: slot.date,
        startTime: slot.startTime,
        endTime: slot.endTime,
        isBooked: slot.isBooked,
        workItems,
      });
    }

    const assignments = Array.from(assignmentMap.values())
      .map((assignment) => ({
        ...assignment,
        upcomingSlots: assignment.upcomingSlots.slice(0, 30),
      }))
      .sort((a, b) => {
        if (a.slotType !== b.slotType) {
          return a.slotType.localeCompare(b.slotType);
        }
        return a.lab.name.localeCompare(b.lab.name);
      });

    return res.json({
      summary: {
        role,
        totalAssignments: assignments.length,
        totalUpcomingSlots: slots.length,
        totalBookedSlots: slots.filter((slot) => slot.isBooked).length,
      },
      assignments,
    });
  } catch (error) {
    console.error("Get my schedule error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};
