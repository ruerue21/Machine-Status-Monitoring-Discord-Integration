const {
  sanitizeText,
  validateMaxLength,
} = require("../../../utils/sanitization");
const {
  getSupervisorAssignedLabIds,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function updateComment(req, res, prisma) {
  try {
    const { consultationId } = req.params;
    const { comment } = req.body;
    const parsedConsultationId = parseInt(consultationId);

    if (!Number.isInteger(parsedConsultationId)) {
      return res.status(400).json({ message: "Invalid consultation id" });
    }

    const consultation = await prisma.consultation.findUnique({
      where: { id: parsedConsultationId },
      include: {
        project: {
          select: { labId: true, userId: true },
        },
        timeSlot: {
          select: { mentorId: true },
        },
      },
    });

    if (!consultation) {
      return res.status(404).json({ message: "Consultation not found" });
    }

    const role = req.userDetails.role;
    if (role === "SUPERVISOR") {
      const assignedLabIds = await getSupervisorAssignedLabIds(
        prisma,
        req.userDetails.id,
      );
      if (!assignedLabIds.includes(consultation.project.labId)) {
        return res.status(403).json({ message: "Access denied" });
      }
    }
    if (
      role === "PEER_MENTOR" &&
      !canPeerMentorManageProjectActions(
        req.userDetails,
        consultation.project,
        [consultation],
      )
    ) {
      return res.status(403).json({
        message:
          "You do not have permission to update this consultation feedback",
      });
    }

    if (comment !== undefined && typeof comment !== "string") {
      return res.status(400).json({ message: "Invalid comment value" });
    }
    if (comment && !validateMaxLength(comment, 2000)) {
      return res
        .status(400)
        .json({ message: "Comment must be 2000 characters or less" });
    }
    const sanitizedComment =
      typeof comment === "string" ? sanitizeText(comment).trim() : null;

    await prisma.consultation.update({
      where: { id: parsedConsultationId },
      data: { mentorFeedback: sanitizedComment || null },
    });

    res.json({
      message: "Comment updated successfully",
      consultationId: parsedConsultationId,
      comment: sanitizedComment || null,
    });
  } catch (error) {
    console.error("Update consultation comment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
