const {
  notifyMentorChanged,
} = require("../../../services/notificationService");

module.exports = async function changeConsultationMentor(req, res, prisma) {
  try {
    const { consultationId } = req.params;
    const parsedConsultationId = parseInt(consultationId, 10);
    const { newMentorId } = req.body;
    const parsedNewMentorId = parseInt(newMentorId, 10);

    if (!Number.isInteger(parsedConsultationId)) {
      return res.status(400).json({ message: "Invalid consultation ID" });
    }

    if (!Number.isInteger(parsedNewMentorId)) {
      return res.status(400).json({ message: "New mentor ID is required" });
    }

    // Get the consultation
    const consultation = await prisma.consultation.findUnique({
      where: { id: parsedConsultationId },
      include: {
        timeSlot: {
          include: {
            mentor: true,
          },
        },
        project: {
          include: {
            user: true,
            lab: true,
          },
        },
      },
    });

    if (!consultation) {
      return res.status(404).json({ message: "Consultation not found" });
    }
    if (consultation.status !== "SCHEDULED") {
      return res.status(400).json({
        message: "Only scheduled consultations can have mentor reassignments",
      });
    }
    if (!consultation.timeSlot) {
      return res.status(400).json({
        message: "Consultation has no active time slot to reassign",
      });
    }

    const oldTimeSlot = consultation.timeSlot;
    if (oldTimeSlot.mentorId === parsedNewMentorId) {
      return res.status(400).json({
        message: "This mentor is already assigned to this consultation",
      });
    }

    const mentor = await prisma.user.findFirst({
      where: {
        id: parsedNewMentorId,
        role: "PEER_MENTOR",
        labAssignments: {
          some: {
            labId: consultation.labId,
            mentorType: "CONSULTATION",
          },
        },
      },
      select: { id: true },
    });

    if (!mentor) {
      return res.status(400).json({
        message:
          "Selected mentor is not assigned as a consultation mentor for this lab",
      });
    }

    // New mentor must have an available slot at the exact same date/time
    const newTimeSlot = await prisma.timeSlot.findFirst({
      where: {
        mentorId: parsedNewMentorId,
        labId: consultation.labId,
        slotType: "CONSULTATION",
        isBooked: false,
        date: oldTimeSlot.date,
        startTime: oldTimeSlot.startTime,
        endTime: oldTimeSlot.endTime,
      },
    });

    if (!newTimeSlot) {
      return res.status(404).json({
        message:
          "Selected mentor does not have availability at the same consultation time",
      });
    }

    // Transaction: Update consultation and time slots
    await prisma.$transaction(async (tx) => {
      // Free up old time slot
      if (oldTimeSlot) {
        await tx.timeSlot.update({
          where: { id: oldTimeSlot.id },
          data: { isBooked: false },
        });
      }

      // Book new time slot
      await tx.timeSlot.update({
        where: { id: newTimeSlot.id },
        data: { isBooked: true },
      });

      // Update consultation
      await tx.consultation.update({
        where: { id: parsedConsultationId },
        data: {
          timeSlotId: newTimeSlot.id,
        },
      });
    });

    // Send notifications
    await notifyMentorChanged(consultation.projectId, parsedConsultationId, {
      oldMentorId: oldTimeSlot?.mentorId,
      newMentorId: parsedNewMentorId,
    });

    res.json({ message: "Mentor changed successfully" });
  } catch (error) {
    console.error("Change mentor error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
