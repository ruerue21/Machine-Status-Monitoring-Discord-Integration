const {
  notifyConsultationCancelled,
} = require("../../../services/notificationService");
const {
  getSupervisorAssignedLabIds,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function cancelConsultation(req, res, prisma) {
  try {
    const { consultationId } = req.params;
    const parsedConsultationId = parseInt(consultationId, 10);
    const { cancelReason } = req.body;
    const userId = req.userDetails.id;

    if (!Number.isInteger(parsedConsultationId)) {
      return res.status(400).json({ message: "Invalid consultation ID" });
    }

    // Get the consultation with related data
    const consultation = await prisma.consultation.findUnique({
      where: { id: parsedConsultationId },
      include: {
        project: {
          include: {
            user: true,
            lab: true,
            consultations: true,
          },
        },
        timeSlot: {
          include: {
            mentor: true,
          },
        },
      },
    });

    if (!consultation) {
      return res.status(404).json({ message: "Consultation not found" });
    }

    const role = req.userDetails.role;
    if (role === "SUPERVISOR") {
      const assignedLabIds = await getSupervisorAssignedLabIds(
        prisma,
        req.userDetails.id,
      );
      if (!assignedLabIds.includes(consultation.project.labId)) {
        return res.status(403).json({ message: "Access denied" });
      }
    }
    if (
      role === "PEER_MENTOR" &&
      !canPeerMentorManageProjectActions(
        req.userDetails,
        consultation.project,
        [consultation],
      )
    ) {
      return res.status(403).json({
        message: "You do not have permission to cancel this consultation",
      });
    }

    if (consultation.status === "CANCELLED") {
      return res
        .status(400)
        .json({ message: "Consultation already cancelled" });
    }
    if (consultation.status === "COMPLETED") {
      return res
        .status(400)
        .json({ message: "Cannot cancel a completed consultation" });
    }

    // Update consultation status
    const updatedConsultation = await prisma.consultation.update({
      where: { id: parsedConsultationId },
      data: {
        status: "CANCELLED",
        cancelledBy: userId,
        cancelledAt: new Date(),
        cancelReason: cancelReason || null,
      },
    });

    // Free up the time slot only if consultation hasn't happened yet
    if (consultation.timeSlotId && consultation.timeSlot) {
      const now = new Date();

      // Extract date parts from DateTime
      const dateObj = new Date(consultation.timeSlot.date);
      const year = dateObj.getFullYear();
      const month = String(dateObj.getMonth() + 1).padStart(2, "0");
      const day = String(dateObj.getDate()).padStart(2, "0");
      const dateString = `${year}-${month}-${day}`;

      // Combine with time
      const consultationDateTime = new Date(
        `${dateString}T${consultation.timeSlot.startTime}`,
      );

      // Only release slot if consultation is in the future
      if (consultationDateTime > now) {
        await prisma.timeSlot.update({
          where: { id: consultation.timeSlotId },
          data: { isBooked: false },
        });

        await prisma.consultation.update({
          where: { id: parsedConsultationId },
          data: { timeSlotId: null },
        });
      }
    }

    // Update project status based on ALL consultations
    const allConsultations = await prisma.consultation.findMany({
      where: { projectId: consultation.projectId },
    });

    // Check if ALL consultations are cancelled
    const allCancelled = allConsultations.every(
      (c) => c.status === "CANCELLED",
    );

    // Check if ALL consultations are either cancelled or absent
    const allDone = allConsultations.every(
      (c) => c.status === "CANCELLED" || c.status === "ABSENT",
    );

    // Only update project status if ALL sessions are done
    if (allCancelled) {
      await prisma.project.update({
        where: { id: consultation.projectId },
        data: { status: "CONSULTATION_CANCELLED" },
      });
    } else if (allDone) {
      // Mix of cancelled and absent - use a general status
      await prisma.project.update({
        where: { id: consultation.projectId },
        data: { status: "CONSULTATION_CANCELLED" },
      });
    }
    // Otherwise, keep project status as IN_PROCESS

    // Send notifications
    await notifyConsultationCancelled(
      consultation.projectId,
      parsedConsultationId,
    );

    res.json({
      message: "Consultation cancelled successfully",
      consultation: updatedConsultation,
    });
  } catch (error) {
    console.error("Cancel consultation error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
