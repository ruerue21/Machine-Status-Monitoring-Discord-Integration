const { getProjectAccessWhere } = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Get total count of projects by status
    const projectStats = await prisma.project.groupBy({
      by: ["status"],
      where: accessWhere,
      _count: {
        id: true,
      },
    });

    // Transform the data for frontend
    const stats = {
      total: 0,
      inProcess: 0,
      consultationCancelled: 0,
      consultationAbsent: 0,
      approved: 0,
      declined: 0,
      approvalRate: 0,
    };

    let totalReviewed = 0;

    projectStats.forEach((stat) => {
      const count = stat._count.id;
      stats.total += count;

      switch (stat.status) {
        case "IN_PROCESS":
          stats.inProcess = count;
          break;
        case "CONSULTATION_CANCELLED":
          stats.consultationCancelled = count;
          break;
        case "CONSULTATION_ABSENT":
          stats.consultationAbsent = count;
          break;
        case "APPROVED":
          stats.approved = count;
          totalReviewed += count;
          break;
        case "DECLINED":
          stats.declined = count;
          totalReviewed += count;
          break;
      }
    });

    // Calculate approval rate (only for reviewed projects)
    if (totalReviewed > 0) {
      stats.approvalRate =
        Math.round((stats.approved / totalReviewed) * 100 * 10) / 10;
    }

    res.json({ stats });
  } catch (error) {
    console.error("Get admin stats error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
