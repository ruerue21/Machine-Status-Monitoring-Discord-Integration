const { getProjectAccessWhere } = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    const recentProjects = await prisma.project.findMany({
      where: {
        AND: [
          { status: "IN_PROCESS" }, // Only show projects awaiting review
          accessWhere,
        ],
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 5, // Limit to 5 most recent
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
      },
    });

    const formattedProjects = recentProjects.map((project) => ({
      id: project.id,
      name: project.name,
      user: project.user ? project.user.name : "[Deleted Account]",
      lab: project.lab.name,
      status: project.status,
      createdAt: project.createdAt,
    }));

    res.json({ projects: formattedProjects });
  } catch (error) {
    console.error("Get recent projects error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
