const {
  getActualScheduleFromDatabase,
} = require("../../../utils/scheduleHelpers");

module.exports = async function (req, res, prisma) {
  try {
    const { search } = req.query;

    const whereClause = {
      role: "SUPERVISOR",
    };

    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
      ];
    }

    const supervisors = await prisma.user.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true,
      },
      orderBy: { name: "asc" },
    });

    // Get schedule info for each supervisor
    const supervisorsWithSchedules = await Promise.all(
      supervisors.map(async (supervisor) => {
        // Get all labs they have schedules for
        const timeSlots = await prisma.timeSlot.findMany({
          where: {
            mentorId: supervisor.id,
            slotType: "CONSULTATION",
            date: { gte: new Date() },
          },
          include: {
            lab: {
              select: { id: true, name: true, location: true },
            },
          },
        });

        // Get unique labs
        const labsMap = new Map();
        timeSlots.forEach((slot) => {
          if (!labsMap.has(slot.labId)) {
            labsMap.set(slot.labId, {
              labId: slot.lab.id,
              labName: slot.lab.name,
              labLocation: slot.lab.location,
              activeTimeSlotsCount: 0,
            });
          }
          labsMap.get(slot.labId).activeTimeSlotsCount++;
        });

        // For each lab, get the actual schedule
        const labs = await Promise.all(
          Array.from(labsMap.values()).map(async (labInfo) => {
            const actualSchedule = await getActualScheduleFromDatabase(
              supervisor.id,
              "CONSULTATION",
              labInfo.labId
            );

            return {
              labId: labInfo.labId,
              labName: labInfo.labName,
              labLocation: labInfo.labLocation,
              schedule: actualSchedule,
              hasConfiguredSchedule: Object.keys(actualSchedule).length > 0,
              activeTimeSlotsCount: labInfo.activeTimeSlotsCount,
            };
          })
        );

        return {
          id: supervisor.id,
          name: supervisor.name,
          email: supervisor.email,
          createdAt: supervisor.createdAt,
          labs: labs,
        };
      })
    );

    res.json({ supervisors: supervisorsWithSchedules });
  } catch (error) {
    console.error("Get supervisors error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
