const {
  getActualScheduleFromDatabase,
} = require("../../../utils/scheduleHelpers");

module.exports = async function (req, res, prisma) {
  try {
    const { supervisorId, labId } = req.params;

    // Verify supervisor exists
    const supervisor = await prisma.user.findUnique({
      where: { id: parseInt(supervisorId) },
      select: { id: true, name: true, email: true, role: true },
    });

    if (!supervisor) {
      return res.status(404).json({ message: "Supervisor not found" });
    }

    if (supervisor.role !== "SUPERVISOR") {
      return res.status(400).json({ message: "User is not a supervisor" });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      select: { id: true, name: true, location: true },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    // Get schedule from database time slots for this lab
    const actualSchedule = await getActualScheduleFromDatabase(
      parseInt(supervisorId),
      "CONSULTATION",
      parseInt(labId)
    );

    // Get future time slots for this lab
    const timeSlots = await prisma.timeSlot.findMany({
      where: {
        mentorId: parseInt(supervisorId),
        labId: parseInt(labId),
        slotType: "CONSULTATION",
        date: { gte: new Date() },
      },
      include: {
        consultation: {
          select: {
            id: true,
            status: true,
            project: {
              select: {
                id: true,
                name: true,
                user: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
          },
        },
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    res.json({
      supervisor: {
        id: supervisor.id,
        name: supervisor.name,
        email: supervisor.email,
      },
      lab: {
        id: lab.id,
        name: lab.name,
        location: lab.location,
      },
      currentSchedule: actualSchedule,
      hasConfiguredSchedule: Object.keys(actualSchedule).length > 0,
      totalActiveSlots: timeSlots.length,
      timeSlots: timeSlots.map((slot) => ({
        id: slot.id,
        date: slot.date,
        startTime: slot.startTime,
        endTime: slot.endTime,
        isBooked: slot.isBooked,
        consultation: slot.consultation,
      })),
    });
  } catch (error) {
    console.error("Get supervisor schedule error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
