module.exports = async function (req, res, prisma) {
  try {
    const { supervisorId, labId } = req.params;
    const { schedule } = req.body;

    // Verify supervisor exists
    const supervisor = await prisma.user.findUnique({
      where: { id: parseInt(supervisorId) },
      select: { id: true, name: true, role: true },
    });

    if (!supervisor) {
      return res.status(404).json({ message: "Supervisor not found" });
    }

    if (supervisor.role !== "SUPERVISOR") {
      return res.status(400).json({ message: "User is not a supervisor" });
    }

    // Verify lab exists
    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      select: { id: true, name: true },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    const warnings = [];
    let oldSlotCount = 0;
    let newSlotCount = 0;

    await prisma.$transaction(async (tx) => {
      // Get current slot count for this lab
      oldSlotCount = await tx.timeSlot.count({
        where: {
          mentorId: parseInt(supervisorId),
          labId: parseInt(labId),
          slotType: "CONSULTATION",
          date: { gte: new Date() },
        },
      });

      // Check for booked slots
      const bookedSlots = await tx.timeSlot.findMany({
        where: {
          mentorId: parseInt(supervisorId),
          labId: parseInt(labId),
          slotType: "CONSULTATION",
          date: { gte: new Date() },
          isBooked: true,
        },
        include: {
          consultation: {
            include: {
              project: {
                include: {
                  user: { select: { name: true, email: true } },
                },
              },
            },
          },
        },
      });

      if (bookedSlots.length > 0) {
        warnings.push(
          `IMPORTANT: ${bookedSlots.length} booked consultations will remain unchanged for ${lab.name}.`,
        );
      }

      // Delete unbooked slots for this lab
      const deletedSlots = await tx.timeSlot.deleteMany({
        where: {
          mentorId: parseInt(supervisorId),
          labId: parseInt(labId),
          slotType: "CONSULTATION",
          date: { gte: new Date() },
          isBooked: false,
        },
      });

      if (deletedSlots.count > 0) {
        warnings.push(
          `Removed ${deletedSlots.count} unbooked slots for ${lab.name}`,
        );
      }

      // Generate new time slots
      const {
        generateTimeSlots,
      } = require("../../../config/peerMentorSchedules");
      const timeSlots = generateTimeSlots(
        parseInt(supervisorId),
        parseInt(labId),
        schedule,
        "CONSULTATION",
      );

      for (const timeSlot of timeSlots) {
        await tx.timeSlot.create({ data: timeSlot });
      }

      // Get new slot count
      newSlotCount = await tx.timeSlot.count({
        where: {
          mentorId: parseInt(supervisorId),
          labId: parseInt(labId),
          slotType: "CONSULTATION",
          date: { gte: new Date() },
        },
      });
    });

    const netChange = newSlotCount - oldSlotCount;
    if (netChange > 0) {
      warnings.push(
        `Generated ${netChange} new slots for ${lab.name} (${newSlotCount} total)`,
      );
    } else if (netChange < 0) {
      warnings.push(
        `Reduced by ${Math.abs(netChange)} slots for ${lab.name} (${newSlotCount} total)`,
      );
    } else {
      warnings.push(
        `Slot count unchanged for ${lab.name} (${newSlotCount} total)`,
      );
    }

    res.json({
      message: `Schedule updated successfully for ${lab.name}`,
      warnings,
      oldSlotCount,
      newSlotCount,
      netChange,
    });
  } catch (error) {
    console.error("Update supervisor schedule error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
