module.exports = async function (req, res, prisma) {
  try {
    const { mentorId, assignmentId } = req.params;
    const { schedule } = req.body;
    const parsedMentorId = parseInt(mentorId);
    const parsedAssignmentId = parseInt(assignmentId);

    if (
      !Number.isInteger(parsedMentorId) ||
      !Number.isInteger(parsedAssignmentId)
    ) {
      return res
        .status(400)
        .json({ message: "Invalid mentor or assignment id" });
    }

    // Verify the assignment exists
    const assignment = await prisma.labMentorAssignment.findUnique({
      where: { id: parsedAssignmentId },
      include: {
        user: { select: { id: true, name: true, role: true } },
        lab: { select: { id: true, name: true } },
      },
    });

    if (!assignment) {
      return res.status(404).json({ message: "Lab assignment not found" });
    }
    if (assignment.userId !== parsedMentorId) {
      return res.status(404).json({ message: "Lab assignment not found" });
    }

    if (assignment.user.role !== "PEER_MENTOR") {
      return res.status(400).json({ message: "User is not a peer mentor" });
    }

    const warnings = [];
    let oldSlotCount = 0;
    let newSlotCount = 0;

    await prisma.$transaction(async (tx) => {
      // Get current slot count for this lab only
      oldSlotCount = await tx.timeSlot.count({
        where: {
          mentorId: parsedMentorId,
          labId: assignment.labId,
          slotType: assignment.mentorType,
          date: { gte: new Date() },
        },
      });

      // Check for booked slots for this lab
      const bookedSlots = await tx.timeSlot.findMany({
        where: {
          mentorId: parsedMentorId,
          labId: assignment.labId,
          slotType: assignment.mentorType,
          date: { gte: new Date() },
          isBooked: true,
        },
        include:
          assignment.mentorType === "CONSULTATION"
            ? {
                consultation: {
                  include: {
                    project: {
                      include: {
                        user: { select: { name: true, email: true } },
                      },
                    },
                  },
                },
              }
            : {
                bookings: {
                  include: {
                    user: { select: { name: true, email: true } },
                    project: { select: { name: true } },
                  },
                },
              },
      });

      if (bookedSlots.length > 0) {
        const bookingType =
          assignment.mentorType === "CONSULTATION"
            ? "consultations"
            : "lab sessions";
        warnings.push(
          `IMPORTANT: ${bookedSlots.length} booked ${bookingType} will remain unchanged for ${assignment.lab.name}.`,
        );
      }

      // Delete unbooked slots for this lab only
      const deletedSlots = await tx.timeSlot.deleteMany({
        where: {
          mentorId: parsedMentorId,
          labId: assignment.labId,
          slotType: assignment.mentorType,
          date: { gte: new Date() },
          isBooked: false,
        },
      });

      if (deletedSlots.count > 0) {
        warnings.push(
          `Removed ${deletedSlots.count} unbooked slots for ${assignment.lab.name}`,
        );
      }

      // Update the schedule in the assignment
      await tx.labMentorAssignment.update({
        where: { id: parsedAssignmentId },
        data: { schedule: schedule },
      });

      // Generate new time slots for this lab
      const {
        generateTimeSlots,
      } = require("../../../config/peerMentorSchedules");
      const timeSlots = generateTimeSlots(
        parsedMentorId,
        assignment.labId,
        schedule,
        assignment.mentorType,
      );

      if (timeSlots.length > 0) {
        // Check for existing slots to avoid duplicates
        const existingSlots = await tx.timeSlot.findMany({
          where: {
            mentorId: parsedMentorId,
            labId: assignment.labId,
            slotType: assignment.mentorType,
            date: { gte: new Date() },
          },
          select: {
            date: true,
            startTime: true,
            endTime: true,
          },
        });

        // Create a set of existing slot keys for fast lookup
        const existingSlotKeys = new Set(
          existingSlots.map(
            (slot) =>
              `${slot.date.toISOString().split("T")[0]}-${slot.startTime}-${slot.endTime}`,
          ),
        );

        // Filter out time slots that already exist
        const newTimeSlots = timeSlots.filter((slot) => {
          const slotKey = `${slot.date.toISOString().split("T")[0]}-${slot.startTime}-${slot.endTime}`;
          return !existingSlotKeys.has(slotKey);
        });

        // Only create slots that don't exist
        if (newTimeSlots.length > 0) {
          await tx.timeSlot.createMany({
            data: newTimeSlots,
            skipDuplicates: true,
          });
        }
      }

      // Get new slot count
      newSlotCount = await tx.timeSlot.count({
        where: {
          mentorId: parsedMentorId,
          labId: assignment.labId,
          slotType: assignment.mentorType,
          date: { gte: new Date() },
        },
      });
    });

    const netChange = newSlotCount - oldSlotCount;
    if (netChange > 0) {
      warnings.push(
        `Generated ${netChange} new slots for ${assignment.lab.name} (${newSlotCount} total)`,
      );
    } else if (netChange < 0) {
      warnings.push(
        `Reduced by ${Math.abs(netChange)} slots for ${assignment.lab.name} (${newSlotCount} total)`,
      );
    } else {
      warnings.push(
        `Slot count unchanged for ${assignment.lab.name} (${newSlotCount} total)`,
      );
    }

    res.json({
      message: `Schedule updated successfully for ${assignment.lab.name}`,
      warnings,
      oldSlotCount,
      newSlotCount,
      netChange,
    });
  } catch (error) {
    console.error("Update mentor schedule error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
