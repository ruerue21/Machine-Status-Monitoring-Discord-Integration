const {
  getActualScheduleFromDatabase,
} = require("../../../utils/scheduleHelpers");

module.exports = async function (req, res, prisma) {
  try {
    const { mentorId, assignmentId } = req.params;

    const parsedAssignmentId = parseInt(assignmentId);
    const parsedMentorId = parseInt(mentorId);
    if (
      !Number.isInteger(parsedAssignmentId) ||
      !Number.isInteger(parsedMentorId)
    ) {
      return res
        .status(400)
        .json({ message: "Invalid mentor or assignment id" });
    }

    // Verify the peer mentor and get the specific lab assignment
    const assignment = await prisma.labMentorAssignment.findUnique({
      where: { id: parsedAssignmentId },
      include: {
        user: {
          select: { id: true, name: true, email: true, role: true },
        },
        lab: {
          select: { id: true, name: true, location: true, isActive: true },
        },
      },
    });

    if (!assignment) {
      return res.status(404).json({ message: "Lab assignment not found" });
    }
    if (assignment.userId !== parsedMentorId) {
      return res.status(404).json({ message: "Lab assignment not found" });
    }

    if (assignment.user.role !== "PEER_MENTOR") {
      return res.status(400).json({ message: "User is not a peer mentor" });
    }

    // Get schedule from database time slots for this specific lab
    const actualSchedule = await getActualScheduleFromDatabase(
      parsedMentorId,
      assignment.mentorType,
      assignment.labId,
    );

    // Get future time slots for this lab
    const timeSlots = await prisma.timeSlot.findMany({
      where: {
        mentorId: parsedMentorId,
        labId: assignment.labId,
        slotType: assignment.mentorType,
        date: { gte: new Date() },
      },
      include: {
        consultation: {
          select: { id: true, status: true },
        },
        bookings: {
          select: { id: true, status: true },
        },
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    res.json({
      assignment: {
        id: assignment.id,
        mentorId: assignment.user.id,
        mentorName: assignment.user.name,
        mentorEmail: assignment.user.email,
        labId: assignment.lab.id,
        labName: assignment.lab.name,
        labLocation: assignment.lab.location,
        mentorType: assignment.mentorType,
      },
      currentSchedule: actualSchedule,
      hasConfiguredSchedule: Object.keys(actualSchedule).length > 0,
      totalActiveSlots: timeSlots.length,
    });
  } catch (error) {
    console.error("Get mentor schedule error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
