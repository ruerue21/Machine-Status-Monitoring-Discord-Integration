const {
  getActualScheduleFromDatabase,
} = require("../../../utils/scheduleHelpers");

module.exports = async function (req, res, prisma) {
  try {
    const { search, lab, mentorType = "CONSULTATION" } = req.query;

    // Validate mentorType
    if (!["CONSULTATION", "LAB"].includes(mentorType)) {
      return res.status(400).json({
        message: "Invalid mentorType. Must be CONSULTATION or LAB",
      });
    }

    // Build where clause for filtering
    const whereClause = {
      role: "PEER_MENTOR",
    };

    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
      ];
    }

    const peerMentors = await prisma.user.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        email: true,
        createdAt: true,
        labAssignments: {
          where: {
            mentorType: mentorType,
          },
          include: {
            lab: {
              select: { id: true, name: true, location: true, isActive: true },
            },
          },
        },
      },
      orderBy: { name: "asc" },
    });

    // Filter by lab if specified
    let filteredMentors = peerMentors.filter(
      (m) => m.labAssignments.length > 0
    );

    if (lab && lab !== "ALL") {
      filteredMentors = filteredMentors.filter((mentor) =>
        mentor.labAssignments.some((a) => a.labId === parseInt(lab))
      );
    }

    // Format mentor data with schedules per lab
    const mentorsWithLabDetails = await Promise.all(
      filteredMentors.map(async (mentor) => {
        // Get schedules and active slots for each lab assignment
        const labsWithSchedules = await Promise.all(
          mentor.labAssignments.map(async (assignment) => {
            // Get actual schedule from time slots for this specific lab
            const actualSchedule = await getActualScheduleFromDatabase(
              mentor.id,
              assignment.mentorType,
              assignment.labId
            );

            // Get active time slots count for this lab
            const activeTimeSlots = await prisma.timeSlot.count({
              where: {
                mentorId: mentor.id,
                labId: assignment.labId,
                slotType: assignment.mentorType,
                date: { gte: new Date() },
              },
            });

            return {
              assignmentId: assignment.id,
              labId: assignment.lab.id,
              labName: assignment.lab.name,
              labLocation: assignment.lab.location,
              mentorType: assignment.mentorType,
              schedule: actualSchedule,
              hasConfiguredSchedule: Object.keys(actualSchedule).length > 0,
              activeTimeSlotsCount: activeTimeSlots,
            };
          })
        );

        return {
          id: mentor.id,
          name: mentor.name,
          email: mentor.email,
          createdAt: mentor.createdAt,
          labs: labsWithSchedules,
        };
      })
    );

    res.json({ peerMentors: mentorsWithLabDetails });
  } catch (error) {
    console.error("Get peer mentors error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
