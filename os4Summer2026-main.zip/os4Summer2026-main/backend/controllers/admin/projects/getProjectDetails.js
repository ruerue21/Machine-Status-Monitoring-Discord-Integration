const { getProjectAccessWhere } = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const parsedProjectId = parseInt(projectId);
    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    const project = await prisma.project.findFirst({
      where: {
        AND: [{ id: parsedProjectId }, accessWhere],
      },
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
        lab: {
          select: { id: true, name: true, location: true, description: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { id: true, name: true, description: true, status: true },
            },
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const consultations = project.consultations || [];
    const primaryConsultation =
      consultations.find((c) => c.status === "SCHEDULED" && c.timeSlot) ||
      consultations.find((c) => c.timeSlot) ||
      consultations[0] ||
      null;

    const formattedProject = {
      id: project.id,
      name: project.name,
      description: project.description,
      status: project.status,
      user: project.user
        ? {
            id: project.user.id,
            name: project.user.name,
            email: project.user.email,
          }
        : {
            id: null,
            name: "[Deleted Account]",
            email: "[Deleted]",
          },
      lab: {
        id: project.lab.id,
        name: project.lab.name,
        location: project.lab.location,
        description: project.lab.description,
      },
      equipment: project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
        description: pe.equipment.description,
        status: pe.equipment.status,
      })),
      consultations: consultations.map((consultation) => ({
        id: consultation.id,
        status: consultation.status,
        date: consultation.timeSlot?.date || null,
        startTime: consultation.timeSlot?.startTime || null,
        endTime: consultation.timeSlot?.endTime || null,
        mentor: consultation.timeSlot?.mentor?.name || null,
        mentorEmail: consultation.timeSlot?.mentor?.email || null,
        notes: consultation.notes,
        mentorFeedback: consultation.mentorFeedback,
      })),
      consultation: primaryConsultation
        ? {
            id: primaryConsultation.id,
            status: primaryConsultation.status,
            date: primaryConsultation.timeSlot?.date || null,
            startTime: primaryConsultation.timeSlot?.startTime || null,
            endTime: primaryConsultation.timeSlot?.endTime || null,
            mentor: primaryConsultation.timeSlot?.mentor?.name || null,
            mentorEmail: primaryConsultation.timeSlot?.mentor?.email || null,
            notes: primaryConsultation.notes,
            mentorFeedback: primaryConsultation.mentorFeedback,
          }
        : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    };

    res.json({ project: formattedProject });
  } catch (error) {
    console.error("Get admin project details error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
