const {
  parsePaginationParams,
  createPaginatedResponse,
} = require("../../../utils/pagination");
const {
  getProjectAccessWhere,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { status, lab, search, sortBy = "newest" } = req.query;
    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);

    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Build where clause for filtering
    const whereClause = {
      AND: [{ isArchived: false }, accessWhere],
    };

    if (status && status !== "ALL") {
      // Convert lowercase to uppercase enum values
      const statusMap = {
        approved: "APPROVED",
        declined: "DECLINED",
        in_process: "IN_PROCESS",
        APPROVED: "APPROVED",
        DECLINED: "DECLINED",
        IN_PROCESS: "IN_PROCESS",
      };

      const mappedStatus = statusMap[status];
      if (mappedStatus) {
        whereClause.AND.push({ status: mappedStatus });
      }
    }

    if (lab && lab !== "ALL") {
      whereClause.AND.push({
        lab: {
          name: lab,
        },
      });
    }

    if (search) {
      whereClause.AND.push({
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
          { user: { name: { contains: search, mode: "insensitive" } } },
          { user: { email: { contains: search, mode: "insensitive" } } },
          { lab: { name: { contains: search, mode: "insensitive" } } },
        ],
      });
    }

    // Build orderBy clause
    let orderBy = {};
    switch (sortBy) {
      case "oldest":
        orderBy = { createdAt: "asc" };
        break;
      case "name":
        orderBy = { name: "asc" };
        break;
      case "status":
        orderBy = { status: "asc" };
        break;
      case "newest":
      default:
        orderBy = { createdAt: "desc" };
        break;
    }

    // Parse pagination parameters
    const { page, limit, skip } = parsePaginationParams(req.query);

    // Get total count for pagination
    const total = await prisma.project.count({
      where: whereClause,
    });

    // Get paginated projects
    const projects = await prisma.project.findMany({
      where: whereClause,
      orderBy: orderBy,
      skip,
      take: limit,
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
            description: true,
            isActive: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: { id: true, name: true, description: true },
            },
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    const adminUserIds = new Set();
    projects.forEach((project) => {
      // Safety check: ensure consultations array exists and has at least one element
      if (project.consultations && project.consultations.length > 0) {
        if (project.consultations[0].cancelledBy) {
          adminUserIds.add(project.consultations[0].cancelledBy);
        }
        if (project.consultations[0].markedAbsentBy) {
          adminUserIds.add(project.consultations[0].markedAbsentBy);
        }
      }
    });

    const adminUsers = await prisma.user.findMany({
      where: {
        id: { in: Array.from(adminUserIds) },
      },
      select: {
        id: true,
        name: true,
        role: true,
      },
    });

    const adminUserMap = {};
    adminUsers.forEach((user) => {
      adminUserMap[user.id] = user;
    });

    const role = req.userDetails?.role;
    const isAdmin = role === "ADMIN";
    const isSupervisor = role === "SUPERVISOR";
    const isPeerMentor = role === "PEER_MENTOR";

    const formattedProjects = projects.map((project) => {
      const canManageProjectActions =
        isAdmin ||
        isSupervisor ||
        (isPeerMentor &&
          canPeerMentorManageProjectActions(
            req.userDetails,
            project,
            project.consultations || [],
          ));

      const mappedConsultations =
        project.consultations && project.consultations.length > 0
          ? project.consultations.map((consultation) => ({
              id: consultation.id,
              status: consultation.status,
              date: consultation.timeSlot?.date || null,
              startTime: consultation.timeSlot?.startTime || null,
              endTime: consultation.timeSlot?.endTime || null,
              mentorId: consultation.timeSlot?.mentor?.id || null,
              mentor: consultation.timeSlot?.mentor?.name || null,
              mentorEmail: consultation.timeSlot?.mentor?.email || null,
              notes: consultation.notes,
              mentorFeedback: consultation.mentorFeedback,
              cancelledBy: consultation.cancelledBy,
              cancelledAt: consultation.cancelledAt,
              cancelReason: consultation.cancelReason,
              cancelledByUser: consultation.cancelledBy
                ? adminUserMap[consultation.cancelledBy] || null
                : null,
              markedAbsentBy: consultation.markedAbsentBy,
              absentAt: consultation.absentAt,
              absentReason: consultation.absentReason,
              markedAbsentByUser: consultation.markedAbsentBy
                ? adminUserMap[consultation.markedAbsentBy] || null
                : null,
              permissions: {
                canModify:
                  isAdmin ||
                  isSupervisor ||
                  (isPeerMentor &&
                    canPeerMentorManageProjectActions(
                      req.userDetails,
                      project,
                      [consultation],
                    )),
              },
            }))
          : [];

      const primaryConsultation = mappedConsultations[0] || null;

      return {
        id: project.id,
        name: project.name,
        description: project.description,
        status: project.status,
        user: project.user
          ? {
              id: project.user.id,
              name: project.user.name,
              email: project.user.email,
            }
          : {
              id: null,
              name: "[Deleted Account]",
              email: "[Deleted]",
            },
        lab: {
          id: project.lab.id,
          name: project.lab.name,
          location: project.lab.location,
          description: project.lab.description,
          isActive: project.lab.isActive,
        },
        equipment: project.equipment.map((pe) => ({
          id: pe.equipment.id,
          name: pe.equipment.name,
          description: pe.equipment.description,
        })),
        consultations: mappedConsultations,
        consultation: primaryConsultation
          ? {
              id: primaryConsultation.id,
              status: primaryConsultation.status,
              date: primaryConsultation.date,
              startTime: primaryConsultation.startTime,
              endTime: primaryConsultation.endTime,
              mentorId: primaryConsultation.mentorId,
              mentor:
                primaryConsultation.mentor ||
                (primaryConsultation.date && primaryConsultation.startTime
                  ? "[Not Assigned]"
                  : "[Consultation Completed]"),
              mentorEmail: primaryConsultation.mentorEmail,
              notes: primaryConsultation.notes,
              mentorFeedback: primaryConsultation.mentorFeedback,
              cancelledBy: primaryConsultation.cancelledBy,
              cancelledAt: primaryConsultation.cancelledAt,
              cancelReason: primaryConsultation.cancelReason,
              cancelledByUser: primaryConsultation.cancelledByUser,
              markedAbsentBy: primaryConsultation.markedAbsentBy,
              absentAt: primaryConsultation.absentAt,
              absentReason: primaryConsultation.absentReason,
              markedAbsentByUser: primaryConsultation.markedAbsentByUser,
              permissions: primaryConsultation.permissions,
            }
          : null,
        permissions: {
          canReview: canManageProjectActions,
          canApprove:
            canManageProjectActions && project.status === "IN_PROCESS",
          canDecline:
            canManageProjectActions && project.status === "IN_PROCESS",
          canCancel: canManageProjectActions,
          canMarkAbsent: canManageProjectActions,
          canGiveFeedback: canManageProjectActions,
          canArchive: isAdmin || isSupervisor,
        },
        createdAt: project.createdAt,
        updatedAt: project.updatedAt,
      };
    });

    res.json(createPaginatedResponse(formattedProjects, total, page, limit));
  } catch (error) {
    console.error("Get admin projects error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
