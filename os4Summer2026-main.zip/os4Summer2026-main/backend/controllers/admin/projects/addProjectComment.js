const {
  getProjectAccessWhere,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const { comment } = req.body;

    const parsedProjectId = parseInt(projectId);
    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project id" });
    }

    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    const project = await prisma.project.findFirst({
      where: {
        AND: [{ id: parsedProjectId }, accessWhere],
      },
      include: {
        consultations: {
          include: {
            timeSlot: {
              select: { mentorId: true },
            },
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const consultation = project.consultations[0];
    if (!consultation) {
      return res
        .status(404)
        .json({ message: "No consultations found for this project" });
    }

    if (req.userDetails.role === "PEER_MENTOR") {
      const canManageProject = canPeerMentorManageProjectActions(
        req.userDetails,
        project,
        [consultation],
      );
      if (!canManageProject) {
        return res.status(403).json({
          message:
            "You do not have permission to update feedback for this consultation",
        });
      }
    }

    await prisma.consultation.update({
      where: { id: consultation.id },
      data: { mentorFeedback: comment || null },
    });

    res.json({
      message: "Project comment updated successfully",
      projectId: parsedProjectId,
      consultationId: consultation.id,
      comment: comment || null,
    });
  } catch (error) {
    console.error("Update comment error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
