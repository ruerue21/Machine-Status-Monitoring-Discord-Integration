const {
  notifyAdminConsultationCancelled,
} = require("../../../services/notificationService");
const {
  getProjectAccessWhere,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const parsedProjectId = parseInt(projectId, 10);
    const { reason } = req.body;
    const cancelledBy = req.userDetails.id;

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Find the project with consultation
    const project = await prisma.project.findFirst({
      where: {
        AND: [{ id: parsedProjectId }, accessWhere],
      },
      include: {
        consultations: {
          include: {
            timeSlot: {
              select: {
                id: true,
                mentorId: true,
              },
            },
          },
        },
        user: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (!project.consultations || project.consultations.length === 0) {
      return res.status(404).json({ message: "Consultation not found" });
    }
    const targetConsultation =
      project.consultations.find((c) => c.status === "SCHEDULED") ||
      project.consultations.find(
        (c) => !["COMPLETED", "CANCELLED", "ABSENT"].includes(c.status),
      ) ||
      project.consultations[0];

    if (req.userDetails.role === "PEER_MENTOR") {
      const canManageProject = canPeerMentorManageProjectActions(
        req.userDetails,
        project,
        [targetConsultation],
      );

      if (!canManageProject) {
        return res.status(403).json({
          message: "You do not have permission to cancel this consultation",
        });
      }
    }

    // Check if consultation is already cancelled or completed
    if (targetConsultation.status === "CANCELLED") {
      return res.status(400).json({
        message: "Consultation is already cancelled",
      });
    }

    if (targetConsultation.status === "COMPLETED") {
      return res.status(400).json({
        message: "Cannot cancel a completed consultation",
      });
    }

    // Send notification to member before cancelling
    notifyAdminConsultationCancelled(parsedProjectId, reason).catch((err) => {
      console.error("Failed to send admin cancellation notification:", err);
    });

    // Update consultation and project in transaction
    let finalProjectStatus = "IN_PROCESS";
    await prisma.$transaction(async (tx) => {
      // Update consultation status
      await tx.consultation.update({
        where: { id: targetConsultation.id },
        data: {
          status: "CANCELLED",
          cancelledBy: cancelledBy,
          cancelledAt: new Date(),
          cancelReason: reason || null,
        },
      });

      // Free the time slot if it exists
      if (targetConsultation.timeSlotId) {
        await tx.timeSlot.update({
          where: { id: targetConsultation.timeSlotId },
          data: { isBooked: false },
        });

        // Clear the consultation's timeSlotId
        await tx.consultation.update({
          where: { id: targetConsultation.id },
          data: { timeSlotId: null },
        });
      }

      const consultations = await tx.consultation.findMany({
        where: { projectId: parsedProjectId },
        select: { status: true },
      });
      const allCancelled = consultations.every((c) => c.status === "CANCELLED");
      const allDone = consultations.every((c) =>
        ["CANCELLED", "ABSENT"].includes(c.status),
      );
      finalProjectStatus =
        allCancelled || allDone ? "CONSULTATION_CANCELLED" : "IN_PROCESS";

      await tx.project.update({
        where: { id: parsedProjectId },
        data: { status: finalProjectStatus },
      });
    });

    res.json({
      message: "Consultation cancelled successfully",
      project: {
        id: project.id,
        name: project.name,
        status: finalProjectStatus,
      },
      consultation: {
        status: "CANCELLED",
        cancelledBy: req.userDetails.name,
        cancelledAt: new Date(),
        reason: reason,
      },
    });
  } catch (error) {
    console.error("Cancel consultation error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
