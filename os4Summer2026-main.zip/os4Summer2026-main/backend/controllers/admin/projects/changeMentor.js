const {
  notifyConsultationMentorChanged,
} = require("../../../services/notificationService");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const { newMentorId } = req.body;

    if (!newMentorId) {
      return res.status(400).json({ message: "New mentor ID is required" });
    }

    // Get project with current consultation
    const project = await prisma.project.findUnique({
      where: { id: parseInt(projectId) },
      include: {
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: { select: { id: true, name: true } },
              },
            },
          },
        },
        lab: { select: { id: true, name: true } },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    const targetConsultation =
      project.consultations.find(
        (c) => c.status === "SCHEDULED" && c.timeSlot,
      ) ||
      project.consultations.find((c) => c.timeSlot) ||
      project.consultations[0];
    if (!targetConsultation || !targetConsultation.timeSlot) {
      return res.status(400).json({
        message: "Project has no consultation with an assigned time slot",
      });
    }

    // Verify new mentor exists and is assigned to this lab as consultation mentor
    const newMentor = await prisma.user.findFirst({
      where: {
        id: parseInt(newMentorId),
        role: "PEER_MENTOR",
        labAssignments: {
          some: {
            labId: project.labId,
            mentorType: "CONSULTATION",
          },
        },
      },
      select: { id: true, name: true, email: true },
    });

    if (!newMentor) {
      return res.status(404).json({
        message:
          "Mentor not found or not assigned as consultation mentor to this lab",
      });
    }

    // Check if mentor is being changed to the same person
    if (targetConsultation.timeSlot.mentorId === parseInt(newMentorId)) {
      return res.status(400).json({
        message: "This mentor is already assigned to this consultation",
      });
    }

    // Get the original consultation date and time
    const originalDate = targetConsultation.timeSlot.date;
    const originalStartTime = targetConsultation.timeSlot.startTime;
    const originalEndTime = targetConsultation.timeSlot.endTime;

    // Try to find a time slot from the new mentor at the same date and time
    const newTimeSlot = await prisma.timeSlot.findFirst({
      where: {
        mentorId: parseInt(newMentorId),
        labId: project.labId,
        slotType: "CONSULTATION",
        isBooked: false,
        date: originalDate,
        startTime: originalStartTime,
        endTime: originalEndTime,
      },
    });

    if (!newTimeSlot) {
      // If no exact match, try to find any available slot from new mentor
      const anyAvailableSlot = await prisma.timeSlot.findFirst({
        where: {
          mentorId: parseInt(newMentorId),
          labId: project.labId,
          slotType: "CONSULTATION",
          isBooked: false,
          date: { gte: new Date() },
        },
        orderBy: { date: "asc" },
      });

      if (!anyAvailableSlot) {
        return res.status(400).json({
          message: `No available time slots found for ${newMentor.name}. Please ensure they have a schedule configured.`,
        });
      }

      // Found a different time slot - warn the user
      return res.status(400).json({
        message: `${newMentor.name} is not available at the original consultation time (${originalStartTime}-${originalEndTime} on ${originalDate.toLocaleDateString()}). The earliest available slot is ${anyAvailableSlot.startTime}-${anyAvailableSlot.endTime} on ${anyAvailableSlot.date.toLocaleDateString()}. Please contact the student to reschedule.`,
        suggestedSlot: {
          date: anyAvailableSlot.date,
          startTime: anyAvailableSlot.startTime,
          endTime: anyAvailableSlot.endTime,
        },
      });
    }

    // Update consultation in transaction
    await prisma.$transaction(async (tx) => {
      // Free old time slot
      await tx.timeSlot.update({
        where: { id: targetConsultation.timeSlotId },
        data: { isBooked: false },
      });

      // Book new time slot
      await tx.timeSlot.update({
        where: { id: newTimeSlot.id },
        data: { isBooked: true },
      });

      // Update consultation with new time slot
      await tx.consultation.update({
        where: { id: targetConsultation.id },
        data: { timeSlotId: newTimeSlot.id },
      });
    });

    // Send mentor change notifications
    notifyConsultationMentorChanged(
      targetConsultation.id,
      targetConsultation.timeSlot.mentorId,
      parseInt(newMentorId),
      req.userDetails.id,
    ).catch((err) => {
      console.error("Failed to send mentor change notifications:", err);
    });

    res.json({
      message: `Consultation mentor changed from ${targetConsultation.timeSlot.mentor.name} to ${newMentor.name}. Consultation remains scheduled at the same time.`,
      consultation: {
        oldMentor: targetConsultation.timeSlot.mentor.name,
        newMentor: newMentor.name,
        timeSlot: {
          date: newTimeSlot.date,
          startTime: newTimeSlot.startTime,
          endTime: newTimeSlot.endTime,
        },
      },
    });
  } catch (error) {
    console.error("Change consultation mentor error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
