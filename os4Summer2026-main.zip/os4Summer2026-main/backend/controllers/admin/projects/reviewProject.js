const {
  notifyConsultationStatusChanged,
  notifyProjectApproved,
  notifyProjectDeclined,
} = require("../../../services/notificationService");
const {
  sanitizeText,
  validateMaxLength,
} = require("../../../utils/sanitization");
const {
  getProjectAccessWhere,
  canBypassProjectAgreementCheck,
  canPeerMentorManageProjectActions,
} = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const { action, comment } = req.body; // action: "approve" or "decline"

    if (!action || !["approve", "decline"].includes(action)) {
      return res.status(400).json({
        message: 'Invalid action. Must be "approve" or "decline"',
      });
    }

    // Sanitize comment if provided
    let sanitizedComment = null;
    if (comment) {
      if (!validateMaxLength(comment, 2000)) {
        return res.status(400).json({
          message: "Comment must be 2000 characters or less",
        });
      }
      sanitizedComment = sanitizeText(comment);
    }

    // For decline action, comment is required
    if (
      action === "decline" &&
      (!sanitizedComment || !sanitizedComment.trim())
    ) {
      return res.status(400).json({
        message: "Comment is required when declining a project",
      });
    }

    // Find the project
    const parsedProjectId = parseInt(projectId);
    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    const project = await prisma.project.findFirst({
      where: {
        AND: [{ id: parsedProjectId }, accessWhere],
      },
      include: {
        consultations: {
          include: {
            timeSlot: true,
          },
        },
        user: {
          select: { id: true, name: true, email: true },
        },
        lab: {
          select: { id: true, name: true, agreementRequired: true },
        },
        bookings: {
          include: {
            timeSlot: true,
            labMentor: {
              select: { name: true },
            },
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    const consultations = project.consultations || [];
    if (consultations.length === 0) {
      return res.status(400).json({
        message: "Project has no consultation available for review",
      });
    }

    if (req.userDetails.role === "PEER_MENTOR") {
      const canManageProject = canPeerMentorManageProjectActions(
        req.userDetails,
        project,
        consultations,
      );

      if (!canManageProject) {
        return res.status(403).json({
          message: "You do not have permission to review this project",
        });
      }
    }

    // Check if lab requires agreement and user has signed it
    if (action === "approve" && project.lab.agreementRequired) {
      const canBypassAgreement = canBypassProjectAgreementCheck(
        req.userDetails,
      );

      if (!canBypassAgreement) {
        const labAgreement = await prisma.labAgreement.findUnique({
          where: {
            userId_labId: {
              userId: project.user.id,
              labId: project.lab.id,
            },
          },
        });

        if (!labAgreement || !labAgreement.signed) {
          return res.status(400).json({
            message: `Cannot approve project - student must sign the lab agreement for ${project.lab.name} first.`,
            labId: project.lab.id,
            labName: project.lab.name,
            requiresAgreement: true,
            studentName: project.user.name,
            studentEmail: project.user.email,
          });
        }
      }
    }

    // Determine new status before using it
    const newStatus =
      action === "approve"
        ? "APPROVED"
        : action === "decline"
          ? "DECLINED"
          : "IN_PROCESS"; // for reset action

    // Check if project exists and can be reviewed
    if (project.status === newStatus) {
      return res.status(400).json({
        message: `Project is already ${newStatus
          .toLowerCase()
          .replace("_", " ")}`,
      });
    }

    // Build response message
    let message = `Project ${action}d successfully!`;
    const warnings = [];

    // Update project and consultation in transaction
    const result = await prisma.$transaction(async (tx) => {
      let releasedSlotsCount = 0;

      // If declining or resetting an approved project, delete all bookings and free time slots
      if (action === "decline" && project.status === "APPROVED") {
        // Get all bookings for this project
        const projectBookings = await tx.booking.findMany({
          where: { projectId: parsedProjectId },
          include: { timeSlot: true },
        });

        // Free all time slots
        const timeSlotIds = projectBookings
          .filter((b) => b.timeSlotId)
          .map((b) => b.timeSlotId);

        if (timeSlotIds.length > 0) {
          await tx.timeSlot.updateMany({
            where: { id: { in: timeSlotIds } },
            data: { isBooked: false },
          });
        }

        // Delete all bookings
        await tx.booking.deleteMany({
          where: { projectId: parsedProjectId },
        });
      }

      // Release future slots only for still-scheduled consultations
      if (action === "approve" || action === "decline") {
        const now = new Date();

        for (const consultation of consultations) {
          if (consultation.status !== "SCHEDULED") continue;
          if (!consultation.timeSlotId || !consultation.timeSlot) continue;

          const scheduledDateTime = new Date(consultation.timeSlot.date);
          const [hour, minute] = consultation.timeSlot.startTime.split(":");
          scheduledDateTime.setHours(parseInt(hour), parseInt(minute), 0, 0);

          if (now < scheduledDateTime) {
            await tx.timeSlot.update({
              where: { id: consultation.timeSlotId },
              data: { isBooked: false },
            });

            await tx.consultation.update({
              where: { id: consultation.id },
              data: { timeSlotId: null },
            });

            releasedSlotsCount += 1;
          }
        }
      }

      // Update project status
      const updatedProject = await tx.project.update({
        where: { id: parsedProjectId },
        data: { status: newStatus },
      });

      const reviewedConsultationStatus =
        action === "approve" ? "COMPLETED" : "CANCELLED";

      // Mark only scheduled sessions as completed/cancelled; keep cancelled/absent/completed unchanged
      await tx.consultation.updateMany({
        where: {
          projectId: parsedProjectId,
          status: "SCHEDULED",
        },
        data: {
          status: reviewedConsultationStatus,
          ...(sanitizedComment ? { mentorFeedback: sanitizedComment } : {}),
        },
      });

      return { updatedProject, releasedSlotsCount };
    });

    if (
      action === "decline" &&
      project.status === "APPROVED" &&
      project.bookings.length > 0
    ) {
      warnings.push(
        `Deleted ${project.bookings.length} associated booking(s) and freed time slots`,
      );
    }

    // Add message about consultation slot being freed
    if (result.releasedSlotsCount > 0) {
      warnings.push(
        `${result.releasedSlotsCount} consultation time slot(s) released for other students`,
      );
    }

    // Send email notifications based on action
    if (action === "approve") {
      notifyProjectApproved(parsedProjectId, comment, project.bookings).catch(
        (err) => {
          console.error("Failed to send project approval notification:", err);
        },
      );

      // Also update consultation status
      consultations
        .filter((consultation) => consultation.status === "SCHEDULED")
        .forEach((consultation) => {
          notifyConsultationStatusChanged(
            consultation.id,
            "COMPLETED",
            consultation.status,
          ).catch((err) => {
            console.error(
              "Failed to send consultation status change notification:",
              err,
            );
          });
        });
    } else if (action === "decline") {
      notifyProjectDeclined(parsedProjectId, comment).catch((err) => {
        console.error("Failed to send project decline notification:", err);
      });

      // Also update consultation status
      consultations
        .filter((consultation) => consultation.status === "SCHEDULED")
        .forEach((consultation) => {
          notifyConsultationStatusChanged(
            consultation.id,
            "CANCELLED",
            consultation.status,
          ).catch((err) => {
            console.error(
              "Failed to send consultation status change notification:",
              err,
            );
          });
        });
    }

    res.json({
      message,
      warnings,
      project: {
        id: result.updatedProject.id,
        status: result.updatedProject.status,
        action: action,
        comment: sanitizedComment,
        reviewedBy: req.userDetails.name,
        reviewedAt: new Date(),
      },
    });
  } catch (error) {
    console.error("Review project error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
