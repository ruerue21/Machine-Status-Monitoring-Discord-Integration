const { getProjectAccessWhere } = require("../../../utils/projectAccess");

module.exports = async (req, res, prisma) => {
  try {
    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    // Query only approved projects that do not have future confirmed bookings
    const approvedProjects = await prisma.project.findMany({
      where: {
        AND: [
          { isArchived: false },
          accessWhere,
          {
            status: "APPROVED",
            lab: {
              isActive: true,
            },
            bookings: {
              none: {
                status: "CONFIRMED",
                startDate: { gte: new Date() },
              },
            },
          },
        ],
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
                description: true,
              },
            },
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: {
                    name: true,
                    email: true,
                  },
                },
              },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return res.json({
      data: approvedProjects,
      projects: approvedProjects,
    });
  } catch (error) {
    console.error("Get approved projects without bookings error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};
