module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const { consultationId } = req.query;

    // Get project with consultation details
    const project = await prisma.project.findUnique({
      where: { id: parseInt(projectId) },
      include: {
        lab: { select: { id: true, name: true } },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const parsedConsultationId = consultationId
      ? parseInt(consultationId)
      : null;
    const targetConsultation =
      (Number.isInteger(parsedConsultationId)
        ? project.consultations.find((c) => c.id === parsedConsultationId)
        : null) ||
      project.consultations.find(
        (c) => c.status === "SCHEDULED" && c.timeSlot,
      ) ||
      project.consultations.find((c) => c.timeSlot) ||
      project.consultations[0];
    if (!targetConsultation || !targetConsultation.timeSlot) {
      return res.status(400).json({
        message: "Project has no consultation with an assigned time slot",
      });
    }

    // Get the current consultation's date and time
    const originalDate = targetConsultation.timeSlot.date;
    const originalStartTime = targetConsultation.timeSlot.startTime;
    const originalEndTime = targetConsultation.timeSlot.endTime;

    // Find all consultation peer mentors assigned to this lab
    const allMentors = await prisma.user.findMany({
      where: {
        role: "PEER_MENTOR",
        labAssignments: {
          some: {
            labId: project.labId,
            mentorType: "CONSULTATION",
          },
        },
      },
      select: {
        id: true,
        name: true,
        email: true,
      },
      orderBy: { name: "asc" },
    });

    const currentMentorId = targetConsultation.timeSlot.mentor.id;
    const mentorIds = allMentors.map((mentor) => mentor.id);
    const availableSlots = mentorIds.length
      ? await prisma.timeSlot.findMany({
          where: {
            mentorId: { in: mentorIds },
            labId: project.labId,
            slotType: "CONSULTATION",
            isBooked: false,
            date: originalDate,
            startTime: originalStartTime,
            endTime: originalEndTime,
          },
          select: { mentorId: true },
        })
      : [];
    const availableMentorIds = new Set(
      availableSlots.map((slot) => slot.mentorId),
    );
    const availableMentors = allMentors.filter(
      (mentor) =>
        mentor.id !== currentMentorId && availableMentorIds.has(mentor.id),
    );

    res.json({
      currentMentor: {
        id: targetConsultation.timeSlot.mentor.id,
        name: targetConsultation.timeSlot.mentor.name,
        email: targetConsultation.timeSlot.mentor.email,
      },
      availableMentors,
      consultationTime: {
        date: originalDate,
        startTime: originalStartTime,
        endTime: originalEndTime,
      },
      labId: project.labId,
      labName: project.lab.name,
    });
  } catch (error) {
    console.error("Get available mentors error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
