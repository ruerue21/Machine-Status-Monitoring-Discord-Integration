module.exports = async function (req, res, prisma) {
  try {
    const { search, status, lab, sortBy = "newest" } = req.query;

    const where = {
      isArchived: true,
    };

    if (search) {
      where.OR = [
        { user: { name: { contains: search, mode: "insensitive" } } },
        { user: { email: { contains: search, mode: "insensitive" } } },
        { project: { name: { contains: search, mode: "insensitive" } } },
      ];
    }

    if (status && status !== "ALL") {
      where.status = status;
    }

    if (lab && lab !== "ALL") {
      where.lab = { name: lab };
    }

    let orderBy = {};
    switch (sortBy) {
      case "oldest":
        orderBy = { createdAt: "asc" };
        break;
      case "status":
        orderBy = { status: "asc" };
        break;
      case "student":
        orderBy = { user: { name: "asc" } };
        break;
      case "newest":
      default:
        orderBy = { createdAt: "desc" };
        break;
    }

    const bookings = await prisma.booking.findMany({
      where,
      orderBy,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        project: {
          select: {
            id: true,
            name: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        labMentor: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        timeSlot: {
          select: {
            id: true,
            date: true,
            startTime: true,
            endTime: true,
          },
        },
      },
    });

    const formattedBookings = bookings.map((booking) => ({
      id: booking.id,
      bookingGroupId: booking.bookingGroupId,
      student: booking.user ? booking.user.name : "[Deleted Account]",
      studentEmail: booking.user ? booking.user.email : "[Deleted]",
      project: booking.project.name,
      projectId: booking.project.id,
      lab: booking.lab.name,
      labId: booking.lab.id,
      labLocation: booking.lab.location,
      startDate: booking.startDate,
      endDate: booking.endDate,
      status: booking.status,
      equipment: booking.equipment.map((be) => ({
        id: be.equipment.id,
        name: be.equipment.name,
      })),
      labMentor: booking.labMentor
        ? {
            id: booking.labMentor.id,
            name: booking.labMentor.name,
            email: booking.labMentor.email,
          }
        : null,
      timeSlot: booking.timeSlot,
      notes: booking.notes,
      cancellationReason: booking.cancellationReason,
      cancelledById: booking.cancelledById,
      createdAt: booking.createdAt,
      updatedAt: booking.updatedAt,
    }));

    res.json({ bookings: formattedBookings });
  } catch (error) {
    console.error("Get archived bookings error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
