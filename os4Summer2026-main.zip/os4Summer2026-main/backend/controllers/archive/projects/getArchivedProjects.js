module.exports = async function (req, res, prisma) {
  try {
    const { search, status, sortBy = "newest" } = req.query;

    const where = {
      isArchived: true,
    };

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { user: { name: { contains: search, mode: "insensitive" } } },
        { user: { email: { contains: search, mode: "insensitive" } } },
      ];
    }

    if (status && status !== "ALL") {
      where.status = status;
    }

    let orderBy = {};
    switch (sortBy) {
      case "oldest":
        orderBy = { createdAt: "asc" };
        break;
      case "status":
        orderBy = { status: "asc" };
        break;
      case "student":
        orderBy = { user: { name: "asc" } };
        break;
      case "newest":
      default:
        orderBy = { createdAt: "desc" };
        break;
    }

    const projects = await prisma.project.findMany({
      where,
      orderBy,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        lab: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
        equipment: {
          include: {
            equipment: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        consultations: {
          include: {
            timeSlot: {
              select: {
                id: true,
                date: true,
                startTime: true,
                endTime: true,
              },
            },
          },
        },
      },
    });

    const formattedProjects = projects.map((project) => ({
      id: project.id,
      name: project.name,
      description: project.description,
      status: project.status,
      student: project.user ? project.user.name : "[Deleted Account]",
      studentEmail: project.user ? project.user.email : "[Deleted]",
      lab: project.lab.name,
      labLocation: project.lab.location,
      equipment: project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
      })),
      consultation:
        project.consultations && project.consultations.length > 0
          ? {
              id: project.consultations[0].id,
              date: project.consultations[0].timeSlot?.date,
              startTime: project.consultations[0].timeSlot?.startTime,
              endTime: project.consultations[0].timeSlot?.endTime,
              status: project.consultations[0].status,
              mentorFeedback: project.consultations[0].mentorFeedback,
            }
          : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    }));

    res.json({ projects: formattedProjects });
  } catch (error) {
    console.error("Get archived projects error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
