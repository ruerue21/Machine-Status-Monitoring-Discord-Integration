module.exports = async function (req, res, prisma) {
  try {
    const [archivedProjects, archivedBookings] = await Promise.all([
      prisma.project.count({ where: { isArchived: true } }),
      prisma.booking.count({ where: { isArchived: true } }),
    ]);

    res.json({
      stats: {
        archivedProjects,
        archivedBookings,
      },
    });
  } catch (error) {
    console.error("Get archive stats error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
