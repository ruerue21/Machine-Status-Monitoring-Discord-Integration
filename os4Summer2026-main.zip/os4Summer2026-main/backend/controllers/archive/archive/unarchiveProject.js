module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const parsedProjectId = Number.parseInt(projectId, 10);

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const project = await prisma.project.findUnique({
      where: { id: parsedProjectId },
      select: { id: true, name: true, isArchived: true },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (!project.isArchived) {
      return res.status(400).json({ message: "Project is not archived" });
    }

    await prisma.project.update({
      where: { id: parsedProjectId },
      data: { isArchived: false },
    });

    res.json({
      message: `Project "${project.name}" has been unarchived`,
    });
  } catch (error) {
    console.error("Unarchive project error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
