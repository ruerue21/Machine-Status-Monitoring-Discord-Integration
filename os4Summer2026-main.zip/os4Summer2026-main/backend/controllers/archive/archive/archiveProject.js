const { getProjectAccessWhere } = require("../../../utils/projectAccess");

module.exports = async function (req, res, prisma) {
  try {
    const { projectId } = req.params;
    const parsedProjectId = Number.parseInt(projectId, 10);

    if (!Number.isInteger(parsedProjectId)) {
      return res.status(400).json({ message: "Invalid project ID" });
    }

    const accessWhere = await getProjectAccessWhere(prisma, req.userDetails);
    if (accessWhere === null) {
      return res.status(403).json({ message: "Access denied" });
    }

    const project = await prisma.project.findFirst({
      where: {
        AND: [{ id: parsedProjectId }, accessWhere],
      },
      select: { id: true, name: true, isArchived: true },
    });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (project.isArchived) {
      return res.status(400).json({ message: "Project is already archived" });
    }

    await prisma.project.update({
      where: { id: parsedProjectId },
      data: { isArchived: true },
    });

    res.json({
      message: `Project "${project.name}" has been archived`,
    });
  } catch (error) {
    console.error("Archive project error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
