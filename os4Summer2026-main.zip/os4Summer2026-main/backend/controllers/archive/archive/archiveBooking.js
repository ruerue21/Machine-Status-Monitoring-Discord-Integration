module.exports = async function (req, res, prisma) {
  try {
    const { bookingId } = req.params;
    const parsedBookingId = Number.parseInt(bookingId, 10);

    if (!Number.isInteger(parsedBookingId)) {
      return res.status(400).json({ message: "Invalid booking ID" });
    }

    const booking = await prisma.booking.findUnique({
      where: { id: parsedBookingId },
      include: {
        project: { select: { name: true } },
        user: { select: { name: true } },
      },
    });

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }

    if (booking.isArchived) {
      return res.status(400).json({ message: "Booking is already archived" });
    }

    await prisma.booking.update({
      where: { id: parsedBookingId },
      data: { isArchived: true },
    });

    res.json({
      message: `Booking for "${booking.project.name}" by ${booking.user?.name || "[Deleted Account]"} has been archived`,
    });
  } catch (error) {
    console.error("Archive booking error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
