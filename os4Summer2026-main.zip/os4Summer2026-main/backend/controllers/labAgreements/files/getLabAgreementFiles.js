module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;

    const files = await prisma.labAgreementFile.findMany({
      where: { labId: parseInt(labId) },
      orderBy: { uploadedAt: "desc" },
    });

    res.json({ files });
  } catch (error) {
    console.error("Get agreement files error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
