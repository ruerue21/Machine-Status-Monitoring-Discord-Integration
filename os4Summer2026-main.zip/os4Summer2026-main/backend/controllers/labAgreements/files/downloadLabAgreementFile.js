const fs = require("fs");
const path = require("path");

module.exports = async function (req, res, prisma) {
  try {
    const { labId, fileId } = req.params;

    const file = await prisma.labAgreementFile.findFirst({
      where: {
        id: parseInt(fileId),
        labId: parseInt(labId),
      },
    });

    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }

    const filePath = path.join(
      __dirname,
      "../../../uploads/lab-agreements",
      path.basename(file.fileUrl),
    );

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server" });
    }

    res.download(filePath, file.fileName);
  } catch (error) {
    console.error("Download agreement file error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
