module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const userId = req.user.userId;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
      select: {
        id: true,
        name: true,
        agreementRequired: true,
      },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    if (!lab.agreementRequired) {
      return res.json({
        required: false,
        signed: true, // No agreement required means effectively "signed"
        lab: { id: lab.id, name: lab.name },
      });
    }

    const agreement = await prisma.labAgreement.findUnique({
      where: {
        userId_labId: {
          userId: userId,
          labId: parseInt(labId),
        },
      },
    });

    const files = await prisma.labAgreementFile.findMany({
      where: { labId: parseInt(labId) },
      orderBy: { uploadedAt: "desc" },
    });

    res.json({
      required: true,
      signed: agreement?.signed || false,
      signedAt: agreement?.signedAt,
      lab: { id: lab.id, name: lab.name },
      files: files.map((f) => ({
        id: f.id,
        fileName: f.fileName,
        fileType: f.fileType,
        uploadedAt: f.uploadedAt,
      })),
    });
  } catch (error) {
    console.error("Get lab agreement status error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
