module.exports = async function (req, res, prisma) {
  try {
    const userId = req.user.userId;

    // Get all labs that require agreements
    const labsWithAgreements = await prisma.lab.findMany({
      where: {
        agreementRequired: true,
        isActive: true,
      },
      include: {
        labAgreements: {
          where: { userId: userId },
        },
        labAgreementFiles: {
          orderBy: { uploadedAt: "desc" },
        },
        // Get user's approved projects and upcoming bookings for this lab
        projects: {
          where: {
            userId: userId,
            status: "APPROVED",
          },
          select: { id: true, name: true },
        },
        bookings: {
          where: {
            userId: userId,
            status: "CONFIRMED",
            startDate: { gte: new Date() },
          },
          select: { id: true, startDate: true },
        },
      },
    });

    const unsignedAgreements = labsWithAgreements
      .filter((lab) => {
        const agreement = lab.labAgreements[0];
        return !agreement || !agreement.signed;
      })
      .map((lab) => ({
        labId: lab.id,
        labName: lab.name,
        labLocation: lab.location,
        hasProjects: lab.projects.length > 0,
        hasBookings: lab.bookings.length > 0,
        nextBooking: lab.bookings.length > 0 ? lab.bookings[0].startDate : null,
        fileCount: lab.labAgreementFiles.length,
      }));

    res.json({ unsignedAgreements });
  } catch (error) {
    console.error("Get unsigned agreements error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
