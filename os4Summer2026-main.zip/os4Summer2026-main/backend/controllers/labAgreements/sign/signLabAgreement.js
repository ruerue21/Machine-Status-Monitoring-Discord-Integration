module.exports = async function (req, res, prisma) {
  try {
    const { labId } = req.params;
    const userId = req.user.userId;

    const lab = await prisma.lab.findUnique({
      where: { id: parseInt(labId) },
    });

    if (!lab) {
      return res.status(404).json({ message: "Lab not found" });
    }

    if (!lab.agreementRequired) {
      return res
        .status(400)
        .json({ message: "This lab does not require an agreement" });
    }

    // Check if agreement files exist
    const fileCount = await prisma.labAgreementFile.count({
      where: { labId: parseInt(labId) },
    });

    if (fileCount === 0) {
      return res
        .status(400)
        .json({ message: "No agreement files available for this lab" });
    }

    // Create or update agreement
    const agreement = await prisma.labAgreement.upsert({
      where: {
        userId_labId: {
          userId: userId,
          labId: parseInt(labId),
        },
      },
      update: {
        signed: true,
        signedAt: new Date(),
      },
      create: {
        userId: userId,
        labId: parseInt(labId),
        signed: true,
        signedAt: new Date(),
      },
    });

    res.json({
      message: "Lab agreement signed successfully",
      agreement: {
        labId: agreement.labId,
        signed: agreement.signed,
        signedAt: agreement.signedAt,
      },
    });
  } catch (error) {
    console.error("Sign lab agreement error:", error);
    res.status(500).json({ message: "Server error" });
  }
};
