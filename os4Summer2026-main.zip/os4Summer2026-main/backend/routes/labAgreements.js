const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");

const router = express.Router();

// Controllers
const getLabAgreementStatus = require("../controllers/labAgreements/status/getLabAgreementStatus");
const getUnsignedAgreements = require("../controllers/labAgreements/unsigned/getUnsignedAgreements");

const getLabAgreementFiles = require("../controllers/labAgreements/files/getLabAgreementFiles");
const downloadLabAgreementFile = require("../controllers/labAgreements/files/downloadLabAgreementFile");

const signLabAgreement = require("../controllers/labAgreements/sign/signLabAgreement");

// Routes
router.get("/:labId/status", authenticateToken, (req, res) =>
  getLabAgreementStatus(req, res, prisma)
);

router.get("/unsigned", authenticateToken, (req, res) =>
  getUnsignedAgreements(req, res, prisma)
);

router.get("/:labId/files", authenticateToken, (req, res) =>
  getLabAgreementFiles(req, res, prisma)
);

router.get("/:labId/files/:fileId/download", authenticateToken, (req, res) =>
  downloadLabAgreementFile(req, res, prisma)
);

router.post("/:labId/sign", authenticateToken, (req, res) =>
  signLabAgreement(req, res, prisma)
);

module.exports = router;
