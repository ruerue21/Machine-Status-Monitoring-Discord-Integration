const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");
const loadUserDetails = require("../middleware/loadUserDetails");
const {
  requireRoles,
  requireAdminOrSupervisor,
  requireAdmin,
  requireEmployee,
} = require("../middleware/roleGuards");
const { uploadMemberAgreement } = require("../middleware/fileUpload");
const cancelConsultation2 = require("../controllers/admin/consultations/cancelConsultation");
const markConsultationAbsent = require("../controllers/admin/consultations/markAbsent");
const changeConsultationMentor = require("../controllers/admin/consultations/changeMentor");
const updateConsultationComment = require("../controllers/admin/consultations/updateComment");
const router = express.Router();

// Admin area access
router.use(
  authenticateToken,
  loadUserDetails,
  requireRoles("ADMIN", "SUPERVISOR", "PEER_MENTOR"),
);

// Dashboard
const getStats = require("../controllers/admin/dashboard/getStats");
const getRecentProjects = require("../controllers/admin/dashboard/getRecentProjects");

// Projects
const getProjects = require("../controllers/admin/projects/getProjects");
const reviewProject = require("../controllers/admin/projects/reviewProject");
const getProjectDetails = require("../controllers/admin/projects/getProjectDetails");
const addProjectComment = require("../controllers/admin/projects/addProjectComment");
const cancelConsultation = require("../controllers/admin/projects/cancelConsultation");
const markAbsent = require("../controllers/admin/projects/markAbsent");
const getAvailableMentors = require("../controllers/admin/projects/getAvailableMentors");
const changeMentor = require("../controllers/admin/projects/changeMentor");
const getApprovedWithoutBookings = require("../controllers/admin/projects/getApprovedWithoutBookings");
const getMySchedule = require("../controllers/admin/schedules/getMySchedule");

// Labs
const getLabs = require("../controllers/admin/labs/getLabs");
const getLabsSimple = require("../controllers/admin/labs/getLabsSimple");

// Users
const getUsers = require("../controllers/admin/users/getUsers");
const updateUserRole = require("../controllers/admin/users/updateUserRole");
const createUser = require("../controllers/admin/users/createUser");
const updateUserAccount = require("../controllers/admin/users/updateUserAccount");
const updateLabAssignments = require("../controllers/admin/users/updateLabAssignments");
const cancelAgreement = require("../controllers/admin/users/cancelAgreement");
const getAgreementHistory = require("../controllers/admin/users/getAgreementHistory");
const updateAgreementCancellation = require("../controllers/admin/users/updateAgreementCancellation");
const getUserStats = require("../controllers/admin/users/getUserStats");
const inactivateUser = require("../controllers/admin/users/inactivateUser");
const reactivateUser = require("../controllers/admin/users/reactivateUser");
const deleteUserAccount = require("../controllers/admin/users/deleteUserAccount");
const getMemberAgreementConfig = require("../controllers/admin/memberAgreement/getConfig");
const updateMemberAgreementConfig = require("../controllers/admin/memberAgreement/updateConfig");
const uploadMemberAgreementFile = require("../controllers/admin/memberAgreement/uploadFile");
const replaceMemberAgreementFile = require("../controllers/admin/memberAgreement/replaceFile");
const deleteMemberAgreementFile = require("../controllers/admin/memberAgreement/deleteFile");
const updateMemberAgreementFileSchedule = require("../controllers/admin/memberAgreement/updateFileSchedule");

// Mentors & schedules
const getPeerMentors = require("../controllers/admin/mentors/getPeerMentors");
const getMentorAssignmentSchedule = require("../controllers/admin/mentors/getMentorAssignmentSchedule");
const updateMentorAssignmentSchedule = require("../controllers/admin/mentors/updateMentorAssignmentSchedule");

// Supervisors & schedules
const getSupervisors = require("../controllers/admin/supervisors/getSupervisors");
const getSupervisorSchedule = require("../controllers/admin/supervisors/getSupervisorSchedule");
const updateSupervisorSchedule = require("../controllers/admin/supervisors/updateSupervisorSchedule");

// Dashboard
router.get("/stats", (req, res) => getStats(req, res, prisma));
router.get("/recent-projects", (req, res) =>
  getRecentProjects(req, res, prisma),
);

// Projects
router.get("/projects", (req, res) => getProjects(req, res, prisma));
router.put("/projects/:projectId/review", requireEmployee, (req, res) =>
  reviewProject(req, res, prisma),
);
router.get("/projects/:projectId", (req, res) =>
  getProjectDetails(req, res, prisma),
);
router.put("/projects/:projectId/comment", requireEmployee, (req, res) =>
  addProjectComment(req, res, prisma),
);
router.put(
  "/projects/:projectId/cancel-consultation",
  requireEmployee,
  (req, res) => cancelConsultation(req, res, prisma),
);
router.put("/projects/:projectId/mark-absent", requireEmployee, (req, res) =>
  markAbsent(req, res, prisma),
);
router.get("/projects/:projectId/available-mentors", (req, res) =>
  getAvailableMentors(req, res, prisma),
);
router.put(
  "/projects/:projectId/change-mentor",
  requireAdminOrSupervisor,
  (req, res) => changeMentor(req, res, prisma),
);
router.get("/approved-projects-without-bookings", (req, res) =>
  getApprovedWithoutBookings(req, res, prisma),
);
router.get("/my-schedule", requireEmployee, (req, res) =>
  getMySchedule(req, res, prisma),
);

// Labs
router.get("/labs", (req, res) => getLabs(req, res, prisma));
router.get("/labs-simple", requireAdmin, (req, res) =>
  getLabsSimple(req, res, prisma),
);

// Users
router.get("/users", requireAdmin, (req, res) => getUsers(req, res, prisma));
router.post("/users", requireAdmin, (req, res) => createUser(req, res, prisma));
router.put("/users/:userId/account", requireAdmin, (req, res) =>
  updateUserAccount(req, res, prisma),
);
router.put("/users/:userId/role", requireAdmin, (req, res) =>
  updateUserRole(req, res, prisma),
);
router.put("/users/:userId/lab-assignments", requireAdmin, (req, res) =>
  updateLabAssignments(req, res, prisma),
);
router.put("/users/:userId/cancel-agreement", requireAdmin, (req, res) =>
  cancelAgreement(req, res, prisma),
);
router.get("/users/:userId/agreement-history", requireAdmin, (req, res) =>
  getAgreementHistory(req, res, prisma),
);
router.put(
  "/users/:userId/agreement-history/:cancellationId",
  requireAdmin,
  (req, res) => updateAgreementCancellation(req, res, prisma),
);
router.get("/user-stats", requireAdmin, (req, res) =>
  getUserStats(req, res, prisma),
);
router.put("/users/:userId/inactivate", requireAdmin, (req, res) =>
  inactivateUser(req, res, prisma),
);
router.put("/users/:userId/reactivate", requireAdmin, (req, res) =>
  reactivateUser(req, res, prisma),
);
router.delete("/users/:userId/delete-account", requireAdmin, (req, res) =>
  deleteUserAccount(req, res, prisma),
);

// Member agreement configuration (admin only)
router.get("/member-agreement/config", requireAdmin, (req, res) =>
  getMemberAgreementConfig(req, res, prisma),
);
router.put("/member-agreement/config", requireAdmin, (req, res) =>
  updateMemberAgreementConfig(req, res, prisma),
);
router.post(
  "/member-agreement/files",
  requireAdmin,
  uploadMemberAgreement.single("agreementFile"),
  (req, res) => uploadMemberAgreementFile(req, res, prisma),
);
router.put(
  "/member-agreement/files/:fileId",
  requireAdmin,
  uploadMemberAgreement.single("agreementFile"),
  (req, res) => replaceMemberAgreementFile(req, res, prisma),
);
router.put(
  "/member-agreement/files/:fileId/schedule",
  requireAdmin,
  (req, res) => updateMemberAgreementFileSchedule(req, res, prisma),
);
router.delete("/member-agreement/files/:fileId", requireAdmin, (req, res) =>
  deleteMemberAgreementFile(req, res, prisma),
);

// Mentors & schedules
router.get("/peer-mentors", requireAdmin, (req, res) =>
  getPeerMentors(req, res, prisma),
);
router.get(
  "/peer-mentors/:mentorId/assignments/:assignmentId/schedule",
  requireAdmin,
  (req, res) => getMentorAssignmentSchedule(req, res, prisma),
);
router.put(
  "/peer-mentors/:mentorId/assignments/:assignmentId/schedule",
  requireAdmin,
  (req, res) => updateMentorAssignmentSchedule(req, res, prisma),
);

// Supervisors & schedules
router.get("/supervisors", requireAdmin, (req, res) =>
  getSupervisors(req, res, prisma),
);
router.get(
  "/supervisors/:supervisorId/schedule/:labId",
  requireAdmin,
  (req, res) => getSupervisorSchedule(req, res, prisma),
);
router.put(
  "/supervisors/:supervisorId/schedule/:labId",
  requireAdmin,
  (req, res) => updateSupervisorSchedule(req, res, prisma),
);

// Consultation-specific actions
router.put(
  "/consultations/:consultationId/cancel",
  requireEmployee,
  (req, res) => cancelConsultation2(req, res, prisma),
);
router.put(
  "/consultations/:consultationId/absent",
  requireEmployee,
  (req, res) => markConsultationAbsent(req, res, prisma),
);
router.put(
  "/consultations/:consultationId/change-mentor",
  requireAdminOrSupervisor,
  (req, res) => changeConsultationMentor(req, res, prisma),
);
router.put(
  "/consultations/:consultationId/comment",
  requireEmployee,
  (req, res) => updateConsultationComment(req, res, prisma),
);

module.exports = router;
