const express = require("express");
const prisma = require("../db/prisma");

const {
  authenticateUser,
  requireBookingManager,
} = require("../middleware/bookingAuth");

const getAvailableSlots = require("../controllers/bookings/getAvailableSlots");
const createBooking = require("../controllers/bookings/createBooking");
const createBatchBookings = require("../controllers/bookings/createBatchBookings");
const cancelBooking = require("../controllers/bookings/cancelBooking");
const getProjectBookings = require("../controllers/bookings/getProjectBookings");
const getMyBookings = require("../controllers/bookings/getMyBookings");
const getMyLabBookings = require("../controllers/bookings/getMyLabBookings");
const getLabBookings = require("../controllers/bookings/getLabBookings");
const getAllBookings = require("../controllers/bookings/getAllBookings");
const getBookingStats = require("../controllers/bookings/getBookingStats");
const getBookingDetails = require("../controllers/bookings/getBookingDetails");
const updateBooking = require("../controllers/bookings/updateBooking");
const deleteBooking = require("../controllers/bookings/deleteBooking");

const router = express.Router();

// Apply authentication to all routes
router.use(authenticateUser);

// Get available lab mentor time slots for a specific lab
router.get("/available-slots/:labId", (req, res) =>
  getAvailableSlots(req, res, prisma),
);

// Create a booking (consultation mentors only)
router.post("/", requireBookingManager, (req, res) =>
  createBooking(req, res, prisma),
);

// Create multiple bookings (batch)
router.post("/batch", requireBookingManager, (req, res) =>
  createBatchBookings(req, res, prisma),
);

// Cancel a booking (students only)
router.put("/:bookingId/cancel", (req, res) => cancelBooking(req, res, prisma));

// Get bookings for a specific project
router.get("/project/:projectId", (req, res) =>
  getProjectBookings(req, res, prisma),
);

// Get student's own bookings
router.get("/my-bookings", (req, res) => getMyBookings(req, res, prisma));

// Get lab mentor's assigned bookings
router.get("/my-lab-bookings", (req, res) =>
  getMyLabBookings(req, res, prisma),
);

// Get bookings for a specific lab (lab mentors can view)
router.get("/lab/:labId", (req, res) => getLabBookings(req, res, prisma));

// Get all bookings with filters
router.get("/", requireBookingManager, (req, res) =>
  getAllBookings(req, res, prisma),
);

// Get booking statistics
router.get("/stats", requireBookingManager, (req, res) =>
  getBookingStats(req, res, prisma),
);

// Get specific booking details
router.get("/:bookingId", (req, res) => getBookingDetails(req, res, prisma));

// Update booking (admin/supervisor/consultation mentors)
router.put("/:bookingId", requireBookingManager, (req, res) =>
  updateBooking(req, res, prisma),
);

// Delete/Cancel booking (employee with scoped access)
router.delete("/:bookingId", requireBookingManager, (req, res) =>
  deleteBooking(req, res, prisma),
);

module.exports = router;
