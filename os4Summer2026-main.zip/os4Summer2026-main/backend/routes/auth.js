const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");
const { createRateLimiter } = require("../middleware/rateLimit");

const register = require("../controllers/auth/register");
const verifyEmail = require("../controllers/auth/verifyEmail");
const login = require("../controllers/auth/login");
const forgotPassword = require("../controllers/auth/forgotPassword");
const resetPassword = require("../controllers/auth/resetPassword");
const resendVerification = require("../controllers/auth/resendVerification");
const getMe = require("../controllers/auth/getMe");
const logout = require("../controllers/auth/logout");

const updateProfile = require("../controllers/auth/updateProfile");
const changePassword = require("../controllers/auth/changePassword");

const getMemberAgreementStatus = require("../controllers/auth/memberAgreement/getStatus");
const submitMemberAgreement = require("../controllers/auth/memberAgreement/submit");
const getMemberAgreementFiles = require("../controllers/auth/memberAgreement/getFiles");
const downloadMemberAgreementFile = require("../controllers/auth/memberAgreement/downloadFile");
const viewMemberAgreementFile = require("../controllers/auth/memberAgreement/viewFile");

const getLabs = require("../controllers/auth/labs/getLabs");
const getLabEquipment = require("../controllers/auth/labs/getLabEquipment");
const getLabTimeSlots = require("../controllers/auth/labs/getLabTimeSlots");

const bookConsultation = require("../controllers/auth/consultations/bookConsultation");
const getUserConsultations = require("../controllers/auth/consultations/getUserConsultations");

const createProject = require("../controllers/auth/projects/createProject");
const getUserProjects = require("../controllers/auth/projects/getUserProjects");
const getProjectDetails = require("../controllers/auth/projects/getProjectDetails");
const updateProject = require("../controllers/auth/projects/updateProject");
const deleteProject = require("../controllers/auth/projects/deleteProject");
const cancelProjectConsultation = require("../controllers/auth/projects/cancelConsultation");
const cancelConsultation = require("../controllers/auth/consultations/cancelConsultation");

const router = express.Router();
const authLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 30,
  keyResolver: (req) => `${req.ip}:auth`,
  message: "Too many authentication attempts. Please try again later.",
});
const loginLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 8,
  keyResolver: (req) =>
    `${req.ip}:${(req.body?.email || "").toLowerCase()}:login`,
  message: "Too many login attempts. Please try again later.",
});

// Auth
router.post("/register", authLimiter, (req, res) => register(req, res, prisma));
router.get("/verify-email", authLimiter, (req, res) =>
  verifyEmail(req, res, prisma),
);
router.post("/login", loginLimiter, (req, res) => login(req, res, prisma));
router.post("/forgot-password", authLimiter, (req, res) =>
  forgotPassword(req, res, prisma),
);
router.post("/reset-password", authLimiter, (req, res) =>
  resetPassword(req, res, prisma),
);
router.post("/resend-verification", authLimiter, (req, res) =>
  resendVerification(req, res, prisma),
);
router.post("/logout", (req, res) => logout(req, res));
router.get("/me", authenticateToken, (req, res) => getMe(req, res, prisma));

// Profile
router.put("/profile", authenticateToken, (req, res) =>
  updateProfile(req, res, prisma),
);
router.put("/change-password", authenticateToken, (req, res) =>
  changePassword(req, res, prisma),
);

// Member agreement
router.get("/member-agreement/status", authenticateToken, (req, res) =>
  getMemberAgreementStatus(req, res, prisma),
);
router.get("/member-agreement/files", authenticateToken, (req, res) =>
  getMemberAgreementFiles(req, res, prisma),
);
router.get(
  "/member-agreement/files/:fileId/view",
  authenticateToken,
  (req, res) => viewMemberAgreementFile(req, res, prisma),
);
router.get(
  "/member-agreement/files/:fileId/download",
  authenticateToken,
  (req, res) => downloadMemberAgreementFile(req, res, prisma),
);
router.post("/member-agreement/submit", authenticateToken, (req, res) =>
  submitMemberAgreement(req, res, prisma),
);

// Labs
router.get("/labs", authenticateToken, (req, res) => getLabs(req, res, prisma));
router.get("/labs/:labId/equipment", authenticateToken, (req, res) =>
  getLabEquipment(req, res, prisma),
);
router.get("/labs/:labId/timeslots", authenticateToken, (req, res) =>
  getLabTimeSlots(req, res, prisma),
);

// Consultations
router.post("/consultations", authenticateToken, (req, res) =>
  bookConsultation(req, res, prisma),
);
router.get("/consultations", authenticateToken, (req, res) =>
  getUserConsultations(req, res, prisma),
);

// Projects
router.post("/projects", authenticateToken, (req, res) =>
  createProject(req, res, prisma),
);
router.get("/projects", authenticateToken, (req, res) =>
  getUserProjects(req, res, prisma),
);
router.get("/projects/:projectId", authenticateToken, (req, res) =>
  getProjectDetails(req, res, prisma),
);
router.put("/projects/:projectId", authenticateToken, (req, res) =>
  updateProject(req, res, prisma),
);
router.delete("/projects/:projectId", authenticateToken, (req, res) =>
  deleteProject(req, res, prisma),
);
router.put(
  "/projects/:projectId/cancel-consultation",
  authenticateToken,
  (req, res) => cancelProjectConsultation(req, res, prisma),
);
router.put(
  "/consultations/:consultationId/cancel",
  authenticateToken,
  (req, res) => cancelConsultation(req, res, prisma),
);

module.exports = router;
