const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");

const getStats = require("../controllers/member/getStats");
const getRecentProposals = require("../controllers/member/getRecentProposals");
const getUpcomingBookings = require("../controllers/member/getUpcomingBookings");

const router = express.Router();

router.use(authenticateToken);

// Routes
router.get("/stats", (req, res) => getStats(req, res, prisma));
router.get("/recent-proposals", (req, res) =>
  getRecentProposals(req, res, prisma)
);
router.get("/upcoming-bookings", (req, res) =>
  getUpcomingBookings(req, res, prisma)
);

module.exports = router;
