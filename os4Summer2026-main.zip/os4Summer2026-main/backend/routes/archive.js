const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");
const loadUserDetails = require("../middleware/loadUserDetails");
const {
  requireAdmin,
  requireAdminOrSupervisor,
} = require("../middleware/roleGuards");

const router = express.Router();

// Controllers
const getArchivedProjects = require("../controllers/archive/projects/getArchivedProjects");
const getArchivedBookings = require("../controllers/archive/bookings/getArchivedBookings");

const archiveProject = require("../controllers/archive/archive/archiveProject");
const unarchiveProject = require("../controllers/archive/archive/unarchiveProject");

const archiveBooking = require("../controllers/archive/archive/archiveBooking");
const unarchiveBooking = require("../controllers/archive/archive/unarchiveBooking");

const getArchiveStats = require("../controllers/archive/stats/getArchiveStats");

// Routes
router.get(
  "/projects",
  authenticateToken,
  loadUserDetails,
  requireAdmin,
  (req, res) => getArchivedProjects(req, res, prisma),
);

router.get(
  "/bookings",
  authenticateToken,
  loadUserDetails,
  requireAdmin,
  (req, res) => getArchivedBookings(req, res, prisma),
);

router.put(
  "/projects/:projectId/archive",
  authenticateToken,
  loadUserDetails,
  requireAdminOrSupervisor,
  (req, res) => archiveProject(req, res, prisma),
);

router.put(
  "/projects/:projectId/unarchive",
  authenticateToken,
  loadUserDetails,
  requireAdmin,
  (req, res) => unarchiveProject(req, res, prisma),
);

router.put(
  "/bookings/:bookingId/archive",
  authenticateToken,
  loadUserDetails,
  requireAdminOrSupervisor,
  (req, res) => archiveBooking(req, res, prisma),
);

router.put(
  "/bookings/:bookingId/unarchive",
  authenticateToken,
  loadUserDetails,
  requireAdmin,
  (req, res) => unarchiveBooking(req, res, prisma),
);

router.get(
  "/stats",
  authenticateToken,
  loadUserDetails,
  requireAdmin,
  (req, res) => getArchiveStats(req, res, prisma),
);

module.exports = router;
