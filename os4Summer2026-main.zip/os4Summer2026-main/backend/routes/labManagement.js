const express = require("express");
const prisma = require("../db/prisma");
const { authenticateToken } = require("../middleware/auth");
const loadUserDetails = require("../middleware/loadUserDetails");
const { requireAdminOrSupervisor } = require("../middleware/roleGuards");
const { uploadLabAgreement } = require("../middleware/fileUpload");

const router = express.Router();

router.use(authenticateToken, loadUserDetails, requireAdminOrSupervisor);

const labs = require("../controllers/labManagement/labs/get_labs.js");
const labsLabid = require("../controllers/labManagement/labs/get_labs_labId.js");
const labs2 = require("../controllers/labManagement/labs/post_labs.js");
const labsLabid2 = require("../controllers/labManagement/labs/put_labs_labId.js");
const labsLabid3 = require("../controllers/labManagement/labs/delete_labs_labId.js");
const labsLabidEquipment = require("../controllers/labManagement/equipment/get_labs_labId_equipment.js");
const labsLabidEquipment2 = require("../controllers/labManagement/equipment/post_labs_labId_equipment.js");
const labsLabidEquipmentEquipmentid = require("../controllers/labManagement/equipment/put_labs_labId_equipment_equipmentId.js");
const labsLabidEquipmentEquipmentid2 = require("../controllers/labManagement/equipment/delete_labs_labId_equipment_equipmentId.js");
const labsLabidAgreementRequired = require("../controllers/labManagement/agreements/put_labs_labId_agreement_required.js");
const labsLabidAgreementFiles = require("../controllers/labManagement/agreements/post_labs_labId_agreement_files.js");
const labsLabidAgreementFiles2 = require("../controllers/labManagement/agreements/get_labs_labId_agreement_files.js");
const labsLabidAgreementFilesFileid = require("../controllers/labManagement/agreements/delete_labs_labId_agreement_files_fileId.js");
const labsLabidAgreementSigners = require("../controllers/labManagement/agreements/get_labs_labId_agreement_signers.js");
const labsLabidUsersUseridCancelAgreement = require("../controllers/labManagement/agreements/put_labs_labId_users_userId_cancel_agreement.js");
const labsLabidUsersUseridAgreementHistory = require("../controllers/labManagement/agreements/get_labs_labId_users_userId_agreement_history.js");
const labsLabidUsersUseridAgreementHistoryCancellationid = require("../controllers/labManagement/agreements/put_labs_labId_users_userId_agreement_history_cancellationId.js");

router.get("/labs", (req, res) => labs(req, res, prisma));
router.get("/labs/:labId", (req, res) => labsLabid(req, res, prisma));
router.post("/labs", (req, res) => labs2(req, res, prisma));
router.put("/labs/:labId", (req, res) => labsLabid2(req, res, prisma));
router.delete("/labs/:labId", (req, res) => labsLabid3(req, res, prisma));
router.get("/labs/:labId/equipment", (req, res) =>
  labsLabidEquipment(req, res, prisma),
);
router.post("/labs/:labId/equipment", (req, res) =>
  labsLabidEquipment2(req, res, prisma),
);
router.put("/labs/:labId/equipment/:equipmentId", (req, res) =>
  labsLabidEquipmentEquipmentid(req, res, prisma),
);
router.delete("/labs/:labId/equipment/:equipmentId", (req, res) =>
  labsLabidEquipmentEquipmentid2(req, res, prisma),
);
router.put("/labs/:labId/agreement-required", (req, res) =>
  labsLabidAgreementRequired(req, res, prisma),
);
router.post(
  "/labs/:labId/agreement-files",
  uploadLabAgreement.single("file"),
  (req, res) => labsLabidAgreementFiles(req, res, prisma),
);
router.get("/labs/:labId/agreement-files", (req, res) =>
  labsLabidAgreementFiles2(req, res, prisma),
);
router.delete("/labs/:labId/agreement-files/:fileId", (req, res) =>
  labsLabidAgreementFilesFileid(req, res, prisma),
);
router.get("/labs/:labId/agreement-signers", (req, res) =>
  labsLabidAgreementSigners(req, res, prisma),
);
router.put("/labs/:labId/users/:userId/cancel-agreement", (req, res) =>
  labsLabidUsersUseridCancelAgreement(req, res, prisma),
);
router.get("/labs/:labId/users/:userId/agreement-history", (req, res) =>
  labsLabidUsersUseridAgreementHistory(req, res, prisma),
);
router.put(
  "/labs/:labId/users/:userId/agreement-history/:cancellationId",
  (req, res) =>
    labsLabidUsersUseridAgreementHistoryCancellationid(req, res, prisma),
);

module.exports = router;
