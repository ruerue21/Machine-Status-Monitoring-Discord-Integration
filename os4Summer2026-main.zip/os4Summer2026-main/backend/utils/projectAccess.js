async function getSupervisorAssignedLabIds(prisma, supervisorId) {
  const labs = await prisma.timeSlot.findMany({
    where: {
      mentorId: supervisorId,
      slotType: "CONSULTATION",
    },
    distinct: ["labId"],
    select: {
      labId: true,
    },
  });

  return labs.map((lab) => lab.labId);
}

function getPeerMentorAssignedLabIds(userDetails) {
  return getPeerMentorResponsibleLabIds(userDetails);
}

function canPeerMentorManageConsultation(userDetails, consultation) {
  if (userDetails?.role !== "PEER_MENTOR") {
    return false;
  }

  const consultationLabId = Number.isInteger(consultation?.labId)
    ? consultation.labId
    : Number.isInteger(consultation?.project?.labId)
      ? consultation.project.labId
      : null;

  if (!Number.isInteger(consultationLabId)) {
    return false;
  }

  const assignedLabIds = getPeerMentorResponsibleLabIds(userDetails);
  if (!assignedLabIds.includes(consultationLabId)) {
    return false;
  }

  const assignmentTypes = getPeerMentorLabAssignmentTypes(
    userDetails,
    consultationLabId,
  );

  // Consultation ownership checks apply only to consultation mentor assignments
  if (!assignmentTypes.has("CONSULTATION")) {
    return false;
  }

  return consultation?.timeSlot?.mentorId === userDetails?.id;
}

function getPeerMentorResponsibleLabIds(userDetails) {
  const assignmentLabIds = (userDetails?.labAssignments || [])
    .map((assignment) => assignment?.labId)
    .filter((labId) => Number.isInteger(labId));

  const legacyAssignedLabIds = Array.isArray(userDetails?.assignedLabIds)
    ? userDetails.assignedLabIds.filter((labId) => Number.isInteger(labId))
    : [];

  return Array.from(new Set([...assignmentLabIds, ...legacyAssignedLabIds]));
}

function getPeerMentorLabAssignmentTypes(userDetails, labId) {
  if (!Number.isInteger(labId)) {
    return new Set();
  }

  const types = new Set(
    (userDetails?.labAssignments || [])
      .filter((assignment) => assignment?.labId === labId)
      .map((assignment) => assignment?.mentorType)
      .filter(
        (mentorType) => mentorType === "CONSULTATION" || mentorType === "LAB",
      ),
  );

  // Legacy fallback: when only mentorType + assignedLabIds exist
  if (types.size === 0 && Array.isArray(userDetails?.assignedLabIds)) {
    if (userDetails.assignedLabIds.includes(labId)) {
      if (
        userDetails?.mentorType === "CONSULTATION" ||
        userDetails?.mentorType === "LAB"
      ) {
        types.add(userDetails.mentorType);
      }
    }
  }

  return types;
}

function canPeerMentorManageLabProject(userDetails, project) {
  if (userDetails?.role !== "PEER_MENTOR") {
    return false;
  }

  const projectLabId = Number.isInteger(project?.labId) ? project.labId : null;
  if (!projectLabId) {
    return false;
  }

  const assignedLabIds = getPeerMentorResponsibleLabIds(userDetails);
  if (!assignedLabIds.includes(projectLabId)) {
    return false;
  }

  const assignmentTypes = getPeerMentorLabAssignmentTypes(
    userDetails,
    projectLabId,
  );
  const isOwnProject = project?.userId === userDetails?.id;

  // Both mentor types can act on their own proposals in assigned labs
  if (isOwnProject && assignmentTypes.size > 0) {
    return true;
  }

  // Legacy fallback: allow own-project actions when assignment types are not
  // populated but lab ownership is still available from assignedLabIds
  if (isOwnProject && assignmentTypes.size === 0) {
    return true;
  }

  return false;
}

function canPeerMentorManageProjectActions(
  userDetails,
  project,
  consultations = [],
) {
  if (userDetails?.role !== "PEER_MENTOR") {
    return false;
  }

  const projectLabId = Number.isInteger(project?.labId) ? project.labId : null;
  if (!Number.isInteger(projectLabId)) {
    return false;
  }

  const assignedLabIds = getPeerMentorResponsibleLabIds(userDetails);
  if (!assignedLabIds.includes(projectLabId)) {
    return false;
  }

  const canManageAssignedConsultation = (consultations || []).some(
    (consultation) =>
      canPeerMentorManageConsultation(userDetails, consultation),
  );
  if (canManageAssignedConsultation) {
    return true;
  }

  return canPeerMentorManageLabProject(userDetails, project);
}

async function getProjectAccessWhere(prisma, userDetails) {
  const role = userDetails?.role;
  const userId = userDetails?.id;

  if (!role || !userId) return null;

  if (role === "ADMIN") {
    return {};
  }

  if (role === "SUPERVISOR") {
    const assignedLabIds = await getSupervisorAssignedLabIds(prisma, userId);
    return assignedLabIds.length > 0
      ? { labId: { in: assignedLabIds } }
      : { id: -1 };
  }

  if (role === "PEER_MENTOR") {
    const labIds = getPeerMentorResponsibleLabIds(userDetails);
    return labIds.length > 0 ? { labId: { in: labIds } } : { id: -1 };
  }

  return null;
}

function canBypassProjectAgreementCheck(userDetails) {
  return ["ADMIN", "SUPERVISOR"].includes(userDetails?.role);
}

module.exports = {
  getSupervisorAssignedLabIds,
  getPeerMentorAssignedLabIds,
  getPeerMentorResponsibleLabIds,
  getPeerMentorLabAssignmentTypes,
  canPeerMentorManageConsultation,
  canPeerMentorManageLabProject,
  canPeerMentorManageProjectActions,
  getProjectAccessWhere,
  canBypassProjectAgreementCheck,
};
