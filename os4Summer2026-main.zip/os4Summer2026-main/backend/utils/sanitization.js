const xss = require("xss");
const validator = require("validator");

const sanitizeText = (input, options = {}) => {
  if (!input || typeof input !== "string") {
    return input;
  }

  // Trim whitespace
  let sanitized = validator.trim(input);

  // Remove XSS
  sanitized = xss(sanitized, {
    whiteList: options.allowHTML
      ? {
          b: [],
          i: [],
          em: [],
          strong: [],
          u: [],
          br: [],
          p: [],
        }
      : {}, // No HTML allowed by default
    stripIgnoreTag: true,
    stripIgnoreTagBody: ["script", "style"],
  });

  return sanitized;
};

const sanitizeObject = (obj, fields, options = {}) => {
  const sanitized = { ...obj };

  fields.forEach((field) => {
    if (sanitized[field] !== undefined && sanitized[field] !== null) {
      sanitized[field] = sanitizeText(sanitized[field], options);
    }
  });

  return sanitized;
};

const sanitizeEmail = (email) => {
  if (!email || typeof email !== "string") {
    return null;
  }

  const trimmed = validator.trim(email);
  const normalized = validator.normalizeEmail(trimmed);

  return normalized;
};

const validateMaxLength = (input, maxLength) => {
  if (!input || typeof input !== "string") {
    return true;
  }

  return input.length <= maxLength;
};

module.exports = {
  sanitizeText,
  sanitizeObject,
  sanitizeEmail,
  validateMaxLength,
};
