const validatePurdueEmail = (email) => {
  if (typeof email !== "string") {
    return false;
  }
  const purdueEmailRegex = /^[a-zA-Z0-9._%+-]+@purdue\.edu$/;
  return purdueEmailRegex.test(email.trim());
};

const generateVerificationToken = () => {
  return require("crypto").randomBytes(32).toString("hex");
};

const hashToken = (token) => {
  if (typeof token !== "string" || token.length === 0) {
    return null;
  }
  return require("crypto").createHash("sha256").update(token).digest("hex");
};

const validatePassword = (password) => {
  if (typeof password !== "string") {
    return {
      valid: false,
      message: "Password is required",
    };
  }

  const normalizedPassword = password.trim();

  // Check minimum length
  if (normalizedPassword.length < 8) {
    return {
      valid: false,
      message: "Password must be at least 8 characters long",
    };
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(normalizedPassword)) {
    return {
      valid: false,
      message: "Password must contain at least one uppercase letter",
    };
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(normalizedPassword)) {
    return {
      valid: false,
      message: "Password must contain at least one lowercase letter",
    };
  }

  // Check for at least one number
  if (!/[0-9]/.test(normalizedPassword)) {
    return {
      valid: false,
      message: "Password must contain at least one number",
    };
  }

  // Password is valid
  return {
    valid: true,
    message: "Password is valid",
  };
};

const validateAgreementFile = (file) => {
  if (!file || !file.originalname || !file.mimetype) {
    return { valid: false, error: "Invalid file upload payload" };
  }

  const extension = file.originalname.toLowerCase().split(".").pop();
  const allowedByMime = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
      "docx",
    "image/jpeg": "image",
    "image/jpg": "image",
    "image/png": "image",
  };

  if (!allowedByMime[file.mimetype]) {
    return {
      valid: false,
      error: "Invalid file type. Only PDF, DOCX, and images are allowed.",
    };
  }

  // Basic mime/extension consistency check
  if (file.mimetype === "application/pdf" && extension !== "pdf") {
    return { valid: false, error: "File extension does not match PDF type" };
  }
  if (
    file.mimetype ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document" &&
    extension !== "docx"
  ) {
    return { valid: false, error: "File extension does not match DOCX type" };
  }
  if (
    ["image/jpeg", "image/jpg"].includes(file.mimetype) &&
    !["jpg", "jpeg"].includes(extension)
  ) {
    return { valid: false, error: "File extension does not match JPEG type" };
  }
  if (file.mimetype === "image/png" && extension !== "png") {
    return { valid: false, error: "File extension does not match PNG type" };
  }

  return { valid: true, fileType: allowedByMime[file.mimetype] };
};

const sanitizeFilename = (filename) => {
  if (!filename || typeof filename !== "string") {
    return "uploaded-file";
  }

  const cleaned = filename
    .replace(/[^\w.\- ]+/g, "")
    .replace(/\.\.+/g, ".")
    .replace(/\s+/g, " ")
    .trim();

  return cleaned.slice(0, 255);
};

module.exports = {
  validatePurdueEmail,
  generateVerificationToken,
  hashToken,
  validatePassword,
  validateAgreementFile,
  sanitizeFilename,
};
