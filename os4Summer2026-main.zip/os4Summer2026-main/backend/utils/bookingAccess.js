const { getSupervisorAssignedLabIds } = require("./projectAccess");

function hasLabBookingPrivileges(userDetails) {
  if (!userDetails) {
    return false;
  }

  if (userDetails.role === "ADMIN" || userDetails.role === "SUPERVISOR") {
    return true;
  }

  if (userDetails.role !== "PEER_MENTOR") {
    return false;
  }

  const assignments = userDetails.labAssignments || [];
  if (assignments.length > 0) {
    return true;
  }

  if (userDetails.mentorType === "LAB") {
    return true;
  }

  return Array.isArray(userDetails.assignedLabIds)
    ? userDetails.assignedLabIds.length > 0
    : false;
}

function getPeerMentorLabBookingIds(userDetails) {
  const assignments = userDetails?.labAssignments || [];
  const labIdsFromAssignments = assignments.map(
    (assignment) => assignment.labId,
  );

  if (labIdsFromAssignments.length > 0) {
    return Array.from(new Set(labIdsFromAssignments));
  }

  if (Array.isArray(userDetails?.assignedLabIds)) {
    return Array.from(new Set(userDetails.assignedLabIds));
  }

  return [];
}

async function getAccessibleBookingLabIds(prisma, userDetails) {
  const role = userDetails?.role;

  if (role === "ADMIN") {
    return null;
  }

  if (role === "SUPERVISOR") {
    return getSupervisorAssignedLabIds(prisma, userDetails.id);
  }

  if (role === "PEER_MENTOR") {
    return getPeerMentorLabBookingIds(userDetails);
  }

  return [];
}

async function canManageBooking(prisma, userDetails, booking) {
  const role = userDetails?.role;
  if (role === "ADMIN") {
    return true;
  }

  if (role === "SUPERVISOR") {
    const accessibleLabIds = await getAccessibleBookingLabIds(
      prisma,
      userDetails,
    );
    return accessibleLabIds.includes(booking.labId);
  }

  if (role === "PEER_MENTOR") {
    if (!hasLabBookingPrivileges(userDetails)) {
      return false;
    }
    return booking.labMentorId === userDetails.id;
  }

  return false;
}

module.exports = {
  getAccessibleBookingLabIds,
  canManageBooking,
  hasLabBookingPrivileges,
};
