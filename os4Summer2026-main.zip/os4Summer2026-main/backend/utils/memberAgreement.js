const DEFAULT_ANCHOR_DATE = new Date(Date.UTC(2025, 7, 1, 0, 0, 0, 0));

const toDate = (value, fallback = null) => {
  if (!value) return fallback;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? fallback : parsed;
};

const getDaysInMonthUtc = (year, month) => {
  return new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
};

const buildUtcDate = (year, month, day, hour = 0, minute = 0) => {
  const safeDay = Math.min(day, getDaysInMonthUtc(year, month));
  return new Date(Date.UTC(year, month, safeDay, hour, minute, 0, 0));
};

function getAgreementCycleStart(config, now = new Date()) {
  const resignType = config?.resignType || "YEARLY";
  const anchorDate = toDate(config?.anchorDate, DEFAULT_ANCHOR_DATE);
  const currentDate = toDate(now, new Date());

  const anchorHour = anchorDate.getUTCHours();
  const anchorMinute = anchorDate.getUTCMinutes();

  if (resignType === "SPECIFIC_DATE") {
    return toDate(config?.specificDate, new Date(0));
  }

  if (resignType === "MONTHLY") {
    const anchorDay = anchorDate.getUTCDate();
    const thisMonthCandidate = buildUtcDate(
      currentDate.getUTCFullYear(),
      currentDate.getUTCMonth(),
      anchorDay,
      anchorHour,
      anchorMinute,
    );

    if (currentDate >= thisMonthCandidate) {
      return thisMonthCandidate;
    }

    const previousMonth = new Date(
      Date.UTC(currentDate.getUTCFullYear(), currentDate.getUTCMonth() - 1, 1),
    );
    return buildUtcDate(
      previousMonth.getUTCFullYear(),
      previousMonth.getUTCMonth(),
      anchorDay,
      anchorHour,
      anchorMinute,
    );
  }

  if (resignType === "WEEKLY") {
    const anchorWeekday = anchorDate.getUTCDay();
    const currentWeekday = currentDate.getUTCDay();
    const offsetDays = (currentWeekday - anchorWeekday + 7) % 7;
    const candidate = new Date(
      Date.UTC(
        currentDate.getUTCFullYear(),
        currentDate.getUTCMonth(),
        currentDate.getUTCDate() - offsetDays,
        anchorHour,
        anchorMinute,
        0,
        0,
      ),
    );

    if (currentDate >= candidate) {
      return candidate;
    }

    return new Date(candidate.getTime() - 7 * 24 * 60 * 60 * 1000);
  }

  const anchorMonth = anchorDate.getUTCMonth();
  const anchorDay = anchorDate.getUTCDate();
  const thisYearCandidate = buildUtcDate(
    currentDate.getUTCFullYear(),
    anchorMonth,
    anchorDay,
    anchorHour,
    anchorMinute,
  );

  if (currentDate >= thisYearCandidate) {
    return thisYearCandidate;
  }

  return buildUtcDate(
    currentDate.getUTCFullYear() - 1,
    anchorMonth,
    anchorDay,
    anchorHour,
    anchorMinute,
  );
}

function getEffectiveSchedule(file, config) {
  return {
    resignType: file?.resignType || config?.resignType || "YEARLY",
    anchorDate: toDate(
      file?.anchorDate,
      toDate(config?.anchorDate, DEFAULT_ANCHOR_DATE),
    ),
    specificDate: toDate(
      file?.specificDate,
      toDate(config?.specificDate, null),
    ),
  };
}

function isFileSignatureCurrent(signedAt, file, config, now = new Date()) {
  const parsedSignedAt = toDate(signedAt);
  if (!parsedSignedAt) return false;

  const schedule = getEffectiveSchedule(file, config);
  const cycleStart = getAgreementCycleStart(schedule, now);
  const fileUpdatedAt = toDate(file?.updatedAt, new Date(0));

  return parsedSignedAt >= cycleStart && parsedSignedAt >= fileUpdatedAt;
}

function hasCurrentSignaturesForAllFiles(
  files,
  signaturesByFileId,
  config,
  now = new Date(),
) {
  if (!Array.isArray(files) || files.length === 0) {
    return true;
  }

  return files.every((file) =>
    isFileSignatureCurrent(signaturesByFileId.get(file.id), file, config, now),
  );
}

function isMemberAgreementCurrent(user, config, now = new Date()) {
  if (!user?.memberAgreementSigned) return false;
  if (!user?.memberAgreementDate) return false;

  const signedAt = toDate(user.memberAgreementDate);
  if (!signedAt) return false;

  const currentVersion = config?.currentVersion || 1;
  if ((user.memberAgreementVersionSigned || 0) !== currentVersion) {
    return false;
  }

  return signedAt >= getAgreementCycleStart(config, now);
}

function getComputedAgreementStatus(user, config, now = new Date()) {
  const signed = isMemberAgreementCurrent(user, config, now);

  return {
    memberAgreementSigned: signed,
    memberAgreementDate: user?.memberAgreementDate || null,
    memberAgreementVersionSigned: user?.memberAgreementVersionSigned || 0,
    requiredAgreementVersion: config?.currentVersion || 1,
    resignType: config?.resignType || "YEARLY",
    anchorDate: config?.anchorDate || DEFAULT_ANCHOR_DATE,
    specificDate: config?.specificDate || null,
    cycleStartDate: getAgreementCycleStart(config, now),
  };
}

async function getOrCreateMemberAgreementConfig(prisma) {
  const existing = await prisma.memberAgreementConfig.findFirst({
    orderBy: { id: "asc" },
  });

  if (existing) {
    return existing;
  }

  return prisma.memberAgreementConfig.create({
    data: {
      resignType: "YEARLY",
      anchorDate: DEFAULT_ANCHOR_DATE,
      currentVersion: 1,
    },
  });
}

async function getMemberAgreementStatusForUser(
  prisma,
  userId,
  now = new Date(),
) {
  const [config, user] = await Promise.all([
    getOrCreateMemberAgreementConfig(prisma),
    prisma.user.findUnique({
      where: { id: userId },
      select: {
        memberAgreementSigned: true,
        memberAgreementDate: true,
        memberAgreementVersionSigned: true,
      },
    }),
  ]);

  if (!user) {
    return null;
  }

  const files = await prisma.memberAgreementFile.findMany({
    where: { configId: config.id },
    orderBy: [{ displayOrder: "asc" }, { uploadedAt: "asc" }],
    select: {
      id: true,
      fileName: true,
      fileType: true,
      resignType: true,
      anchorDate: true,
      specificDate: true,
      displayOrder: true,
      uploadedAt: true,
      updatedAt: true,
    },
  });

  const signatures = await prisma.memberAgreementFileSignature.findMany({
    where: {
      userId,
      fileId: { in: files.map((file) => file.id) },
    },
    select: {
      fileId: true,
      signedAt: true,
    },
  });

  const signaturesByFileId = new Map(
    signatures.map((signature) => [signature.fileId, signature.signedAt]),
  );

  const filesWithStatus = files.map((file) => {
    const signedAt = signaturesByFileId.get(file.id) || null;
    return {
      ...file,
      signedAt,
      signed: isFileSignatureCurrent(signedAt, file, config, now),
    };
  });

  return {
    ...getComputedAgreementStatus(user, config, now),
    memberAgreementSigned: hasCurrentSignaturesForAllFiles(
      files,
      signaturesByFileId,
      config,
      now,
    ),
    files: filesWithStatus,
    requiredDocumentsCount: files.length,
  };
}

module.exports = {
  DEFAULT_ANCHOR_DATE,
  getAgreementCycleStart,
  getEffectiveSchedule,
  isFileSignatureCurrent,
  hasCurrentSignaturesForAllFiles,
  isMemberAgreementCurrent,
  getComputedAgreementStatus,
  getOrCreateMemberAgreementConfig,
  getMemberAgreementStatusForUser,
};
