const {
  notifyLabSessionStatusChanged,
} = require("../services/notificationService");

const buildLabUnavailableReason = (labName, unavailableUntil) => {
  if (unavailableUntil) {
    return `Lab "${labName}" is temporarily unavailable until ${unavailableUntil.toLocaleString()}. Session cancelled automatically.`;
  }
  return `Lab "${labName}" is unavailable until further notice. Session cancelled automatically.`;
};

async function cancelImpactedLabBookings({
  prisma,
  labId,
  labName,
  cancelledByUserId = null,
  unavailableUntil = null,
}) {
  const now = new Date();
  const whereClause = {
    labId,
    status: "CONFIRMED",
    isArchived: false,
    startDate: { gte: now },
  };

  if (unavailableUntil) {
    whereClause.startDate.lt = unavailableUntil;
  }

  const bookings = await prisma.booking.findMany({
    where: whereClause,
    select: {
      id: true,
      timeSlotId: true,
    },
  });

  if (bookings.length === 0) {
    return { cancelledBookingIds: [], cancelledCount: 0 };
  }

  const bookingIds = bookings.map((booking) => booking.id);
  const timeSlotIds = bookings
    .map((booking) => booking.timeSlotId)
    .filter((timeSlotId) => Number.isInteger(timeSlotId));

  const cancellationReason = buildLabUnavailableReason(
    labName,
    unavailableUntil,
  );

  await prisma.$transaction(async (tx) => {
    if (timeSlotIds.length > 0) {
      await tx.timeSlot.updateMany({
        where: { id: { in: timeSlotIds } },
        data: { isBooked: false },
      });
    }

    await tx.booking.updateMany({
      where: { id: { in: bookingIds } },
      data: {
        status: "CANCELLED",
        cancellationReason,
        ...(Number.isInteger(cancelledByUserId)
          ? { cancelledBy: cancelledByUserId }
          : {}),
      },
    });
  });

  await Promise.all(
    bookingIds.map((bookingId) =>
      notifyLabSessionStatusChanged(bookingId, "CANCELLED", "CONFIRMED"),
    ),
  );

  return {
    cancelledBookingIds: bookingIds,
    cancelledCount: bookingIds.length,
  };
}

module.exports = {
  cancelImpactedLabBookings,
};
