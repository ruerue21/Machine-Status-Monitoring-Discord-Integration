const {
  notifyLabSessionStatusChanged,
  notifyLabSessionEquipmentAdjusted,
} = require("../services/notificationService");

const buildEquipmentUnavailableReason = (
  equipmentName,
  labName,
  outOfOrderUntil,
) => {
  if (outOfOrderUntil) {
    return `Equipment "${equipmentName}" in lab "${labName}" is out of order until ${outOfOrderUntil.toLocaleString()}. Session cancelled automatically.`;
  }
  return `Equipment "${equipmentName}" in lab "${labName}" is out of order until further notice. Session cancelled automatically.`;
};

async function applyEquipmentOutOfOrderImpact({
  prisma,
  equipmentId,
  equipmentName,
  labName,
  cancelledByUserId = null,
  outOfOrderUntil = null,
}) {
  const now = new Date();
  const dateFilter = {
    gte: now,
  };

  if (outOfOrderUntil) {
    dateFilter.lt = outOfOrderUntil;
  }

  const impactedBookings = await prisma.booking.findMany({
    where: {
      status: "CONFIRMED",
      isArchived: false,
      startDate: dateFilter,
      equipment: {
        some: {
          equipmentId,
        },
      },
    },
    include: {
      equipment: {
        include: {
          equipment: {
            select: { id: true, name: true },
          },
        },
      },
      timeSlot: {
        select: { id: true },
      },
    },
    orderBy: { startDate: "asc" },
  });

  if (impactedBookings.length === 0) {
    return {
      impactedCount: 0,
      adjustedCount: 0,
      cancelledCount: 0,
      adjustedBookingIds: [],
      cancelledBookingIds: [],
    };
  }

  const adjustedBookings = impactedBookings.filter(
    (booking) => booking.equipment.length > 1,
  );
  const cancelledBookings = impactedBookings.filter(
    (booking) => booking.equipment.length <= 1,
  );

  const adjustedBookingIds = adjustedBookings.map((booking) => booking.id);
  const cancelledBookingIds = cancelledBookings.map((booking) => booking.id);
  const cancelledTimeSlotIds = cancelledBookings
    .map((booking) => booking.timeSlot?.id)
    .filter((timeSlotId) => Number.isInteger(timeSlotId));

  const cancellationReason = buildEquipmentUnavailableReason(
    equipmentName,
    labName,
    outOfOrderUntil,
  );

  await prisma.$transaction(async (tx) => {
    if (adjustedBookingIds.length > 0) {
      await tx.bookingEquipment.deleteMany({
        where: {
          bookingId: { in: adjustedBookingIds },
          equipmentId,
        },
      });
    }

    if (cancelledTimeSlotIds.length > 0) {
      await tx.timeSlot.updateMany({
        where: { id: { in: cancelledTimeSlotIds } },
        data: { isBooked: false },
      });
    }

    if (cancelledBookingIds.length > 0) {
      await tx.booking.updateMany({
        where: { id: { in: cancelledBookingIds } },
        data: {
          status: "CANCELLED",
          cancellationReason,
          ...(Number.isInteger(cancelledByUserId)
            ? { cancelledBy: cancelledByUserId }
            : {}),
        },
      });
    }
  });

  await Promise.all([
    ...adjustedBookingIds.map((bookingId) =>
      notifyLabSessionEquipmentAdjusted(
        bookingId,
        equipmentName,
        outOfOrderUntil,
      ),
    ),
    ...cancelledBookingIds.map((bookingId) =>
      notifyLabSessionStatusChanged(bookingId, "CANCELLED", "CONFIRMED"),
    ),
  ]);

  return {
    impactedCount: impactedBookings.length,
    adjustedCount: adjustedBookingIds.length,
    cancelledCount: cancelledBookingIds.length,
    adjustedBookingIds,
    cancelledBookingIds,
  };
}

module.exports = {
  applyEquipmentOutOfOrderImpact,
};
