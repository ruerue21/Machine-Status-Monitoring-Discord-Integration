const prisma = require("../db/prisma");

async function getActualScheduleFromDatabase(
  mentorId,
  slotType = "CONSULTATION",
  labId = null,
) {
  try {
    const whereClause = {
      mentorId: mentorId,
      slotType: slotType,
      date: {
        gte: new Date(),
        // Only look at next 14 days to get the pattern
        lte: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      },
    };

    // Filter by lab if specified
    if (labId) {
      whereClause.labId = labId;
    }

    const timeSlots = await prisma.timeSlot.findMany({
      where: whereClause,
      select: {
        date: true,
        startTime: true,
        endTime: true,
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    if (timeSlots.length === 0) {
      return {};
    }

    // Group by day of week and extract unique time patterns
    const scheduleByDay = {};

    timeSlots.forEach((slot) => {
      const dayOfWeek = slot.date.getDay();
      const dayNames = [
        "sunday",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
      ];
      const dayName = dayNames[dayOfWeek];

      if (!scheduleByDay[dayName]) {
        scheduleByDay[dayName] = new Set();
      }

      // Add unique time slot (startTime-endTime combination)
      scheduleByDay[dayName].add(`${slot.startTime}-${slot.endTime}`);
    });

    // Convert Sets to arrays of objects
    const actualSchedule = {};
    Object.keys(scheduleByDay).forEach((day) => {
      actualSchedule[day] = Array.from(scheduleByDay[day])
        .map((timeRange) => {
          const [startTime, endTime] = timeRange.split("-");
          return { startTime, endTime };
        })
        .sort((a, b) => a.startTime.localeCompare(b.startTime));
    });

    return actualSchedule;
  } catch (error) {
    console.error("Error getting actual schedule:", error);
    return {};
  }
}

module.exports = {
  getActualScheduleFromDatabase,
};
