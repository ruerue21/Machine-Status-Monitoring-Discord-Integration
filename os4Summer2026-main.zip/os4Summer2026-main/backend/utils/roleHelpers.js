const ROLE_HIERARCHY = {
  MEMBER: 1,
  PEER_MENTOR: 2,
  SUPERVISOR: 3,
  ADMIN: 4,
};

const getRoleHierarchy = () => ROLE_HIERARCHY;

function canPromoteUser(currentUserRole, targetUserRole) {
  const currentLevel = ROLE_HIERARCHY[currentUserRole];
  const targetLevel = ROLE_HIERARCHY[targetUserRole];

  if (currentUserRole === "ADMIN") return targetLevel < 4;
  if (currentUserRole === "SUPERVISOR")
    return targetLevel < 3 && currentLevel > targetLevel;
  return false;
}

function canDemoteUser(currentUserRole, targetUserRole) {
  const targetLevel = ROLE_HIERARCHY[targetUserRole];

  if (currentUserRole === "ADMIN") return targetLevel > 1;
  if (currentUserRole === "SUPERVISOR")
    return targetLevel <= 3 && targetLevel > 1;
  return false;
}

function canChangeUserRole(currentUserRole, fromRole, toRole) {
  const fromLevel = ROLE_HIERARCHY[fromRole];
  const toLevel = ROLE_HIERARCHY[toRole];

  if (currentUserRole === "ADMIN") return true;
  if (currentUserRole === "SUPERVISOR") return fromLevel <= 3 && toLevel <= 3;
  return false;
}

function getAvailablePromotions(currentUserRole, targetUserRole) {
  const targetLevel = ROLE_HIERARCHY[targetUserRole];
  const promotions = [];

  const roles = Object.keys(ROLE_HIERARCHY);

  if (currentUserRole === "ADMIN") {
    for (const role of roles) {
      if (ROLE_HIERARCHY[role] > targetLevel) promotions.push(role);
    }
  } else if (currentUserRole === "SUPERVISOR") {
    for (const role of roles) {
      const level = ROLE_HIERARCHY[role];
      if (level > targetLevel && level <= 3) promotions.push(role);
    }
  }

  return promotions;
}

function getAvailableDemotions(currentUserRole, targetUserRole) {
  const targetLevel = ROLE_HIERARCHY[targetUserRole];
  const demotions = [];

  const roles = Object.keys(ROLE_HIERARCHY);

  if (currentUserRole === "ADMIN") {
    for (const role of roles) {
      if (ROLE_HIERARCHY[role] < targetLevel) demotions.push(role);
    }
  } else if (currentUserRole === "SUPERVISOR") {
    if (targetLevel <= 3 && targetLevel > 1) {
      for (const role of roles) {
        if (ROLE_HIERARCHY[role] < targetLevel) demotions.push(role);
      }
    }
  }

  return demotions;
}

function getRoleDisplayName(role) {
  const displayNames = {
    MEMBER: "Member",
    PEER_MENTOR: "Peer Mentor",
    SUPERVISOR: "Supervisor",
    ADMIN: "Admin",
  };
  return displayNames[role] || role;
}

function getRoleChangeAction(fromRole, toRole) {
  return ROLE_HIERARCHY[toRole] > ROLE_HIERARCHY[fromRole]
    ? "promoted"
    : "demoted";
}

function formatUserDisplay(user, defaultName = "[Deleted Account]") {
  if (!user) {
    return {
      id: null,
      name: defaultName,
      email: null,
      isDeleted: true,
    };
  }

  return {
    id: user.id,
    name: user.name || defaultName,
    email: user.email || null,
    isDeleted: false,
  };
}

function formatUserName(user, defaultName = "[Deleted Account]") {
  return user?.name || defaultName;
}

function formatUserEmail(user, defaultEmail = "[No Email]") {
  return user?.email || defaultEmail;
}

module.exports = {
  getRoleHierarchy,
  canPromoteUser,
  canDemoteUser,
  canChangeUserRole,
  getAvailablePromotions,
  getAvailableDemotions,
  getRoleDisplayName,
  getRoleChangeAction,
  formatUserDisplay,
  formatUserName,
  formatUserEmail,
};
