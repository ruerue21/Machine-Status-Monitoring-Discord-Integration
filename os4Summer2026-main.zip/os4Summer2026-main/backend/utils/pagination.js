const parsePaginationParams = (query, defaultLimit = 20, maxLimit = 100) => {
  const page = Math.max(1, parseInt(query.page) || 1);
  const limit = Math.min(
    maxLimit,
    Math.max(1, parseInt(query.limit) || defaultLimit),
  );
  const skip = (page - 1) * limit;

  return {
    page,
    limit,
    skip,
  };
};

const createPaginationMeta = (total, page, limit) => {
  const totalPages = Math.ceil(total / limit);
  const hasNextPage = page < totalPages;
  const hasPrevPage = page > 1;

  return {
    total,
    page,
    limit,
    totalPages,
    hasNextPage,
    hasPrevPage,
  };
};

const createPaginatedResponse = (data, total, page, limit) => {
  return {
    data,
    pagination: createPaginationMeta(total, page, limit),
  };
};

module.exports = {
  parsePaginationParams,
  createPaginationMeta,
  createPaginatedResponse,
};
