const ONE_DAY_MS = 24 * 60 * 60 * 1000;

const resolveSameSite = () => {
  const configured = (process.env.AUTH_COOKIE_SAME_SITE || "lax")
    .toLowerCase()
    .trim();

  if (configured === "strict") return "strict";
  if (configured === "none") return "none";
  return "lax";
};

const resolveSecure = (sameSite) => {
  if (process.env.AUTH_COOKIE_SECURE === "true") return true;
  if (process.env.AUTH_COOKIE_SECURE === "false") return false;
  if (sameSite === "none") return true;
  return process.env.NODE_ENV === "production";
};

const getCookieOptions = () => {
  // Keep this configurable for both same-site and cross-site deployments
  const sameSite = resolveSameSite();
  const secure = resolveSecure(sameSite);
  return {
    httpOnly: true,
    secure,
    sameSite,
    maxAge: ONE_DAY_MS,
    path: "/",
  };
};

const getClearCookieOptions = () => {
  const sameSite = resolveSameSite();
  const secure = resolveSecure(sameSite);
  return {
    httpOnly: true,
    secure,
    sameSite,
    path: "/",
  };
};

const setAuthCookie = (res, token) => {
  res.cookie("auth_token", token, getCookieOptions());
};

const clearAuthCookie = (res) => {
  res.clearCookie("auth_token", getClearCookieOptions());
};

module.exports = {
  setAuthCookie,
  clearAuthCookie,
};
