const { Prisma } = require("@prisma/client");

const DEFAULT_RETRIES = 3;

const isRetryableSerializationError = (error) => {
  if (!error) return false;
  if (error.code === "P2034") return true;
  return (
    typeof error.message === "string" &&
    error.message.toLowerCase().includes("could not serialize")
  );
};

const runSerializableTransaction = async (prisma, callback, options = {}) => {
  const retries = Number.isInteger(options.retries)
    ? options.retries
    : DEFAULT_RETRIES;
  const maxWait = options.maxWait ?? 5000;
  const timeout = options.timeout ?? 10000;

  let attempt = 0;
  while (attempt <= retries) {
    try {
      return await prisma.$transaction(callback, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
        maxWait,
        timeout,
      });
    } catch (error) {
      if (!isRetryableSerializationError(error) || attempt === retries) {
        throw error;
      }
      attempt += 1;
    }
  }
};

module.exports = {
  runSerializableTransaction,
};
