const test = require("node:test");
const assert = require("node:assert/strict");

const { hashToken } = require("../utils/validation");
const getAvailableSlots = require("../controllers/bookings/getAvailableSlots");
const getProjectBookings = require("../controllers/bookings/getProjectBookings");

const createRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  },
});

test("hashToken returns deterministic SHA-256 hash", () => {
  const token = "abc123";
  const hashed = hashToken(token);
  assert.equal(
    hashed,
    "6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090",
  );
  assert.equal(hashToken(""), null);
  assert.equal(hashToken(null), null);
});

test("getAvailableSlots validates labId and date inputs", async () => {
  const prismaShouldNotBeCalled = {
    timeSlot: {
      findMany: async () => {
        throw new Error("timeSlot.findMany should not be called");
      },
    },
  };

  const reqBadLabId = {
    params: { labId: "oops" },
    query: {},
  };
  const resBadLabId = createRes();
  await getAvailableSlots(reqBadLabId, resBadLabId, prismaShouldNotBeCalled);
  assert.equal(resBadLabId.statusCode, 400);
  assert.equal(resBadLabId.body.message, "Invalid lab ID");

  const reqBadDate = {
    params: { labId: "1" },
    query: { startDate: "not-a-date" },
  };
  const resBadDate = createRes();
  await getAvailableSlots(reqBadDate, resBadDate, prismaShouldNotBeCalled);
  assert.equal(resBadDate.statusCode, 400);
  assert.equal(resBadDate.body.message, "Invalid startDate");
});

test("getProjectBookings rejects unauthorized users", async () => {
  let findManyCalled = false;
  const prisma = {
    project: {
      findUnique: async () => ({ id: 10, userId: 99, labId: 77 }),
    },
    booking: {
      findMany: async () => {
        findManyCalled = true;
        return [];
      },
    },
  };

  const req = {
    params: { projectId: "10" },
    userDetails: {
      id: 1,
      role: "MEMBER",
      labAssignments: [],
    },
  };
  const res = createRes();

  await getProjectBookings(req, res, prisma);
  assert.equal(res.statusCode, 403);
  assert.equal(res.body.message, "Access denied");
  assert.equal(findManyCalled, false);
});
