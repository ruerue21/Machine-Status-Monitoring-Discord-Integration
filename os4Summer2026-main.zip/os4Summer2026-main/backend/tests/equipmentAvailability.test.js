const test = require("node:test");
const assert = require("node:assert/strict");

let adjustedCalls = [];
let statusCalls = [];

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
const originalNotificationServiceCache = require.cache[notificationServicePath];
require.cache[notificationServicePath] = {
  exports: {
    notifyLabSessionStatusChanged: async (...args) => {
      statusCalls.push(args);
    },
    notifyLabSessionEquipmentAdjusted: async (...args) => {
      adjustedCalls.push(args);
    },
  },
};

const {
  applyEquipmentOutOfOrderImpact,
} = require("../utils/equipmentAvailability");

if (originalNotificationServiceCache) {
  require.cache[notificationServicePath] = originalNotificationServiceCache;
} else {
  delete require.cache[notificationServicePath];
}

const createPrismaMock = (bookings) => {
  const calls = {
    bookingEquipmentDeleteMany: 0,
    timeSlotUpdateMany: 0,
    bookingUpdateMany: 0,
  };

  const tx = {
    bookingEquipment: {
      deleteMany: async () => {
        calls.bookingEquipmentDeleteMany += 1;
      },
    },
    timeSlot: {
      updateMany: async () => {
        calls.timeSlotUpdateMany += 1;
      },
    },
    booking: {
      updateMany: async () => {
        calls.bookingUpdateMany += 1;
      },
    },
  };

  return {
    calls,
    prisma: {
      booking: {
        findMany: async () => bookings,
      },
      $transaction: async (fn) => fn(tx),
    },
  };
};

test("applyEquipmentOutOfOrderImpact removes equipment from multi-equipment bookings and cancels single-equipment bookings", async () => {
  adjustedCalls = [];
  statusCalls = [];

  const { prisma, calls } = createPrismaMock([
    {
      id: 101,
      timeSlot: { id: 501 },
      equipment: [
        { equipment: { id: 11, name: "Laser Cutter" } },
        { equipment: { id: 12, name: "Heat Press" } },
      ],
    },
    {
      id: 102,
      timeSlot: { id: 502 },
      equipment: [{ equipment: { id: 11, name: "Laser Cutter" } }],
    },
  ]);

  const result = await applyEquipmentOutOfOrderImpact({
    prisma,
    equipmentId: 11,
    equipmentName: "Laser Cutter",
    labName: "Prototyping Lab",
    cancelledByUserId: 7,
    outOfOrderUntil: new Date("2026-05-01T12:00:00.000Z"),
  });

  assert.equal(result.impactedCount, 2);
  assert.equal(result.adjustedCount, 1);
  assert.equal(result.cancelledCount, 1);
  assert.deepEqual(result.adjustedBookingIds, [101]);
  assert.deepEqual(result.cancelledBookingIds, [102]);

  assert.equal(calls.bookingEquipmentDeleteMany, 1);
  assert.equal(calls.timeSlotUpdateMany, 1);
  assert.equal(calls.bookingUpdateMany, 1);

  assert.equal(adjustedCalls.length, 1);
  assert.equal(adjustedCalls[0][0], 101);
  assert.equal(adjustedCalls[0][1], "Laser Cutter");

  assert.equal(statusCalls.length, 1);
  assert.deepEqual(statusCalls[0], [102, "CANCELLED", "CONFIRMED"]);
});

test("applyEquipmentOutOfOrderImpact is a no-op when no bookings are impacted", async () => {
  adjustedCalls = [];
  statusCalls = [];

  const { prisma, calls } = createPrismaMock([]);

  const result = await applyEquipmentOutOfOrderImpact({
    prisma,
    equipmentId: 11,
    equipmentName: "Laser Cutter",
    labName: "Prototyping Lab",
  });

  assert.equal(result.impactedCount, 0);
  assert.equal(result.adjustedCount, 0);
  assert.equal(result.cancelledCount, 0);
  assert.deepEqual(result.adjustedBookingIds, []);
  assert.deepEqual(result.cancelledBookingIds, []);

  assert.equal(calls.bookingEquipmentDeleteMany, 0);
  assert.equal(calls.timeSlotUpdateMany, 0);
  assert.equal(calls.bookingUpdateMany, 0);
  assert.equal(adjustedCalls.length, 0);
  assert.equal(statusCalls.length, 0);
});
