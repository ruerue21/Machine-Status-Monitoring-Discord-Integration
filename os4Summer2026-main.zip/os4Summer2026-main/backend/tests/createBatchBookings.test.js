const test = require("node:test");
const assert = require("node:assert/strict");

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
require.cache[notificationServicePath] = {
  exports: {
    notifyBatchLabSessionsCreated: () => Promise.resolve(),
  },
};

const createBatchBookings = require("../controllers/bookings/createBatchBookings");

const createMockRes = () => {
  const res = {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    },
  };
  return res;
};

test("createBatchBookings accepts legacy bookingSlots payload", async () => {
  let createdData = null;

  const tx = {
    timeSlot: {
      findMany: async () => [
        {
          id: 10,
          labId: 2,
          date: new Date("2026-03-10T00:00:00.000Z"),
          startTime: "09:00",
          endTime: "10:00",
        },
      ],
      findUnique: async () => ({
        id: 10,
        labId: 2,
        slotType: "LAB",
        isBooked: false,
        mentorId: 3,
        mentor: { id: 3, name: "Mentor A", email: "mentor@purdue.edu" },
      }),
      update: async () => null,
    },
    lab: {
      findUnique: async () => ({ id: 2, name: "Lab", location: "Loc" }),
    },
    booking: {
      findFirst: async () => null,
      findMany: async () => [],
      create: async ({ data }) => {
        createdData = data;
        return {
          id: 99,
          user: { id: 1, name: "Member", email: "m@purdue.edu" },
          project: { id: 1, name: "Project" },
          lab: { id: 2, name: "Lab", location: "Loc" },
          equipment: [],
          labMentor: { id: 3, name: "Mentor A", email: "mentor@purdue.edu" },
          timeSlot: {
            id: 10,
            date: "2026-03-10",
            startTime: "09:00",
            endTime: "10:00",
          },
          notes: data.notes,
          startDate: data.startDate,
          endDate: data.endDate,
          status: "CONFIRMED",
        };
      },
    },
    equipment: {
      findMany: async () => [],
    },
  };

  const prisma = {
    project: {
      findUnique: async () => ({
        id: 1,
        status: "APPROVED",
        userId: 1,
        user: { id: 1, name: "Member", email: "m@purdue.edu" },
        lab: { id: 2, name: "Lab", location: "Loc" },
        equipment: [],
      }),
    },
    $transaction: async (callback) => callback(tx),
  };

  const req = {
    body: {
      projectId: 1,
      bookingSlots: [{ timeSlotId: 10, equipmentIds: [] }],
      notes: "legacy format",
    },
  };
  const res = createMockRes();

  await createBatchBookings(req, res, prisma);

  assert.equal(res.statusCode, 201);
  assert.equal(res.body.bookingCount, 1);
  assert.equal(createdData.projectId, 1);
  assert.equal(createdData.labId, 2);
  assert.equal(createdData.timeSlotId, 10);
  assert.equal(createdData.notes, "legacy format");
  assert.ok(createdData.startDate instanceof Date);
  assert.ok(createdData.endDate instanceof Date);
});
