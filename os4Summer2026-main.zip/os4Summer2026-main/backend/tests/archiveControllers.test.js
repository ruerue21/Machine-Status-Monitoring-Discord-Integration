const test = require("node:test");
const assert = require("node:assert/strict");

const archiveProject = require("../controllers/archive/archive/archiveProject");
const unarchiveProject = require("../controllers/archive/archive/unarchiveProject");
const archiveBooking = require("../controllers/archive/archive/archiveBooking");
const unarchiveBooking = require("../controllers/archive/archive/unarchiveBooking");

function createRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.body = payload;
      return this;
    },
  };
}

test("archive project/booking controllers reject invalid ids with 400", async () => {
  const prisma = {
    project: {
      findUnique: async () => {
        throw new Error("project.findUnique should not run for invalid IDs");
      },
    },
    booking: {
      findUnique: async () => {
        throw new Error("booking.findUnique should not run for invalid IDs");
      },
    },
  };

  const projectReq = { params: { projectId: "abc" } };
  const projectRes = createRes();
  await archiveProject(projectReq, projectRes, prisma);
  assert.equal(projectRes.statusCode, 400);
  assert.equal(projectRes.body.message, "Invalid project ID");

  const bookingReq = { params: { bookingId: "abc" } };
  const bookingRes = createRes();
  await archiveBooking(bookingReq, bookingRes, prisma);
  assert.equal(bookingRes.statusCode, 400);
  assert.equal(bookingRes.body.message, "Invalid booking ID");
});

test("unarchive project/booking controllers reject invalid ids with 400", async () => {
  const prisma = {
    project: {
      findUnique: async () => {
        throw new Error("project.findUnique should not run for invalid IDs");
      },
    },
    booking: {
      findUnique: async () => {
        throw new Error("booking.findUnique should not run for invalid IDs");
      },
    },
  };

  const projectReq = { params: { projectId: "NaN" } };
  const projectRes = createRes();
  await unarchiveProject(projectReq, projectRes, prisma);
  assert.equal(projectRes.statusCode, 400);
  assert.equal(projectRes.body.message, "Invalid project ID");

  const bookingReq = { params: { bookingId: "NaN" } };
  const bookingRes = createRes();
  await unarchiveBooking(bookingReq, bookingRes, prisma);
  assert.equal(bookingRes.statusCode, 400);
  assert.equal(bookingRes.body.message, "Invalid booking ID");
});

test("archive project enforces supervisor lab-scoped access", async () => {
  const prisma = {
    timeSlot: {
      findMany: async () => [{ labId: 1 }],
    },
    project: {
      findFirst: async ({ where }) => {
        assert.deepEqual(where, {
          AND: [{ id: 42 }, { labId: { in: [1] } }],
        });
        return null;
      },
    },
  };

  const projectReq = {
    params: { projectId: "42" },
    userDetails: {
      id: 5,
      role: "SUPERVISOR",
    },
  };
  const projectRes = createRes();

  await archiveProject(projectReq, projectRes, prisma);

  assert.equal(projectRes.statusCode, 404);
  assert.equal(projectRes.body.message, "Project not found");
});
