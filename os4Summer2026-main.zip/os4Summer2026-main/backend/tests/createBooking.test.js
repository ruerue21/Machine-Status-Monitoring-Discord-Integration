const test = require("node:test");
const assert = require("node:assert/strict");

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
require.cache[notificationServicePath] = {
  exports: {
    notifyLabSessionCreated: () => Promise.resolve(),
  },
};

const createBooking = require("../controllers/bookings/createBooking");

const createMockRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  },
});

test("createBooking succeeds with equipmentIds and returns 201", async () => {
  const prisma = {
    project: {
      findUnique: async () => ({
        id: 1,
        status: "APPROVED",
        userId: 11,
        user: { id: 11, name: "Member", email: "m@purdue.edu" },
      }),
    },
    lab: {
      findUnique: async () => ({ id: 2, name: "Lab", location: "Loc" }),
    },
    booking: {
      findFirst: async () => null,
      findMany: async () => [],
    },
    equipment: {
      findMany: async () => [{ id: 101, name: "Printer" }],
    },
    $transaction: async (callback) =>
      callback({
        booking: {
          create: async ({ data }) => ({
            id: 99,
            user: { id: 11, name: "Member", email: "m@purdue.edu" },
            project: { id: 1, name: "Project" },
            lab: { id: 2, name: "Lab", location: "Loc" },
            equipment: [{ equipment: { id: 101, name: "Printer" } }],
            labMentor: null,
            timeSlot: null,
            notes: data.notes,
            startDate: data.startDate,
            endDate: data.endDate,
            status: "CONFIRMED",
          }),
        },
        timeSlot: {
          findUnique: async () => null,
          update: async () => null,
        },
      }),
  };

  const req = {
    body: {
      projectId: 1,
      startDate: "2026-03-10T10:00:00.000Z",
      endDate: "2026-03-10T11:00:00.000Z",
      labId: 2,
      equipmentIds: [101],
      notes: "Test note",
    },
  };
  const res = createMockRes();

  await createBooking(req, res, prisma);

  assert.equal(res.statusCode, 201);
  assert.equal(res.body.booking.id, 99);
  assert.equal(res.body.booking.equipment[0].name, "Printer");
});
