const test = require("node:test");
const assert = require("node:assert/strict");

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
require.cache[notificationServicePath] = {
  exports: {
    notifyConsultationStatusChanged: () => Promise.resolve(),
    notifyProjectApproved: () => Promise.resolve(),
    notifyProjectDeclined: () => Promise.resolve(),
  },
};

const reviewProject = require("../controllers/admin/projects/reviewProject");
const updateUserRole = require("../controllers/admin/users/updateUserRole");

const createRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  },
});

test("reviewProject decline marks scheduled consultations as CANCELLED", async () => {
  let updateManyData = null;

  const prisma = {
    project: {
      findFirst: async () => ({
        id: 42,
        status: "IN_PROCESS",
        consultations: [
          {
            id: 100,
            status: "SCHEDULED",
            timeSlotId: 901,
            timeSlot: {
              id: 901,
              date: new Date("2099-01-01T00:00:00.000Z"),
              startTime: "10:00",
            },
          },
        ],
        user: { id: 3, name: "Student", email: "student@example.com" },
        lab: { id: 1, name: "Lab 1", agreementRequired: false },
        bookings: [],
      }),
    },
    $transaction: async (callback) =>
      callback({
        timeSlot: {
          update: async () => null,
          updateMany: async () => null,
        },
        consultation: {
          update: async () => null,
          updateMany: async ({ data }) => {
            updateManyData = data;
            return { count: 1 };
          },
        },
        booking: {
          findMany: async () => [],
          deleteMany: async () => ({ count: 0 }),
        },
        project: {
          update: async () => ({ id: 42, status: "DECLINED" }),
        },
      }),
  };

  const req = {
    params: { projectId: "42" },
    body: { action: "decline", comment: "Needs revision" },
    userDetails: { id: 1, role: "ADMIN", name: "Admin Reviewer" },
  };
  const res = createRes();

  await reviewProject(req, res, prisma);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.project.status, "DECLINED");
  assert.equal(updateManyData.status, "CANCELLED");
});

test("updateUserRole consultation cleanup deletes each project once", async () => {
  let projectDeleteCalls = 0;
  let findUniqueCalls = 0;

  const prisma = {
    user: {
      findUnique: async () => {
        findUniqueCalls += 1;
        if (findUniqueCalls === 1) {
          return {
            id: 7,
            name: "Peer Mentor",
            email: "mentor@example.com",
            role: "PEER_MENTOR",
            mentorType: "CONSULTATION",
            assignedLabIds: [1],
            labAssignments: [],
          };
        }

        return {
          id: 7,
          name: "Peer Mentor",
          email: "mentor@example.com",
          role: "MEMBER",
          labAssignments: [],
        };
      },
    },
    $transaction: async (callback) =>
      callback({
        labMentorAssignment: {
          findMany: async () => [{ mentorType: "CONSULTATION" }],
          deleteMany: async () => ({ count: 1 }),
        },
        timeSlot: {
          findMany: async () => [{ id: 101 }, { id: 102 }],
          updateMany: async () => ({ count: 1 }),
          deleteMany: async () => ({ count: 2 }),
        },
        consultation: {
          findMany: async () => [
            {
              id: 1,
              project: {
                id: 999,
                user: { name: "Student A", email: "s@example.com" },
                bookings: [{ id: 201 }, { id: 202 }],
              },
            },
            {
              id: 2,
              project: {
                id: 999,
                user: { name: "Student A", email: "s@example.com" },
                bookings: [{ id: 201 }, { id: 202 }],
              },
            },
          ],
        },
        booking: {
          findMany: async () => [{ timeSlotId: 301 }],
          deleteMany: async () => ({ count: 2 }),
          count: async () => 0,
        },
        bookingEquipment: {
          deleteMany: async () => ({ count: 0 }),
        },
        project: {
          delete: async () => {
            projectDeleteCalls += 1;
            return { id: 999 };
          },
        },
        user: {
          update: async () => ({ id: 7 }),
        },
      }),
  };

  const req = {
    params: { userId: "7" },
    body: { newRole: "MEMBER" },
    userDetails: { role: "ADMIN" },
  };
  const res = createRes();

  await updateUserRole(req, res, prisma);

  assert.equal(res.statusCode, 200);
  assert.equal(projectDeleteCalls, 1);
});
