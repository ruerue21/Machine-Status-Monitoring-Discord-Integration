const test = require("node:test");
const assert = require("node:assert/strict");

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
require.cache[notificationServicePath] = {
  exports: {
    notifyLabSessionStatusChanged: () => Promise.resolve(),
    notifyConsultationCancelled: () => Promise.resolve(),
    notifyConsultationAbsent: () => Promise.resolve(),
    notifyMentorChanged: () => Promise.resolve(),
    notifyAdminConsultationCancelled: () => Promise.resolve(),
    notifyMemberConsultationCancelled: () => Promise.resolve(),
  },
};

const cancelBooking = require("../controllers/bookings/cancelBooking");
const cancelAuthConsultation = require("../controllers/auth/consultations/cancelConsultation");
const cancelAdminConsultation = require("../controllers/admin/consultations/cancelConsultation");
const markAdminConsultationAbsent = require("../controllers/admin/consultations/markAbsent");
const changeAdminConsultationMentor = require("../controllers/admin/consultations/changeMentor");
const cancelAuthProjectConsultation = require("../controllers/auth/projects/cancelConsultation");
const cancelAdminProjectConsultation = require("../controllers/admin/projects/cancelConsultation");

const createRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  },
});

const prismaShouldNotBeCalled = {
  booking: {
    findUnique: async () => {
      throw new Error("booking.findUnique should not run for invalid IDs");
    },
  },
  consultation: {
    findUnique: async () => {
      throw new Error("consultation.findUnique should not run for invalid IDs");
    },
  },
  project: {
    findFirst: async () => {
      throw new Error("project.findFirst should not run for invalid IDs");
    },
    findUnique: async () => {
      throw new Error("project.findUnique should not run for invalid IDs");
    },
  },
};

test("booking and consultation mutation controllers reject invalid consultation/booking IDs", async () => {
  const bookingReq = {
    params: { bookingId: "nope" },
    body: {},
    user: { userId: 1 },
  };
  const bookingRes = createRes();
  await cancelBooking(bookingReq, bookingRes, prismaShouldNotBeCalled);
  assert.equal(bookingRes.statusCode, 400);
  assert.equal(bookingRes.body.message, "Invalid booking ID");

  const authConsultationReq = {
    params: { consultationId: "bad-id" },
    body: {},
    user: { userId: 1 },
  };
  const authConsultationRes = createRes();
  await cancelAuthConsultation(
    authConsultationReq,
    authConsultationRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(authConsultationRes.statusCode, 400);
  assert.equal(authConsultationRes.body.message, "Invalid consultation ID");

  const adminConsultationReq = {
    params: { consultationId: "bad-id" },
    body: {},
    userDetails: { id: 2 },
  };
  const adminConsultationRes = createRes();
  await cancelAdminConsultation(
    adminConsultationReq,
    adminConsultationRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(adminConsultationRes.statusCode, 400);
  assert.equal(adminConsultationRes.body.message, "Invalid consultation ID");

  const markAbsentReq = {
    params: { consultationId: "bad-id" },
    body: {},
    userDetails: { id: 2 },
  };
  const markAbsentRes = createRes();
  await markAdminConsultationAbsent(
    markAbsentReq,
    markAbsentRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(markAbsentRes.statusCode, 400);
  assert.equal(markAbsentRes.body.message, "Invalid consultation ID");

  const changeMentorReq = {
    params: { consultationId: "bad-id" },
    body: { newMentorId: 5 },
  };
  const changeMentorRes = createRes();
  await changeAdminConsultationMentor(
    changeMentorReq,
    changeMentorRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(changeMentorRes.statusCode, 400);
  assert.equal(changeMentorRes.body.message, "Invalid consultation ID");
});

test("project consultation cancellation controllers reject invalid project IDs", async () => {
  const authProjectReq = {
    params: { projectId: "not-a-number" },
    body: {},
    user: { userId: 1 },
  };
  const authProjectRes = createRes();
  await cancelAuthProjectConsultation(
    authProjectReq,
    authProjectRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(authProjectRes.statusCode, 400);
  assert.equal(authProjectRes.body.message, "Invalid project ID");

  const adminProjectReq = {
    params: { projectId: "not-a-number" },
    body: {},
    userDetails: { id: 2 },
  };
  const adminProjectRes = createRes();
  await cancelAdminProjectConsultation(
    adminProjectReq,
    adminProjectRes,
    prismaShouldNotBeCalled,
  );
  assert.equal(adminProjectRes.statusCode, 400);
  assert.equal(adminProjectRes.body.message, "Invalid project ID");
});
