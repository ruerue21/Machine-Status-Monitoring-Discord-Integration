const test = require("node:test");
const assert = require("node:assert/strict");

const {
  canPeerMentorManageProjectActions,
  canPeerMentorManageConsultation,
  getProjectAccessWhere,
} = require("../utils/projectAccess");

test("consultation peer mentor can act only when assigned or owning project in assigned lab", () => {
  const user = {
    id: 10,
    role: "PEER_MENTOR",
    labAssignments: [{ labId: 1, mentorType: "CONSULTATION" }],
    assignedLabIds: [],
  };

  const otherUsersProject = { labId: 1, userId: 50 };
  const ownProject = { labId: 1, userId: 10 };
  const outsideLabProject = { labId: 2, userId: 10 };

  const assignedConsultation = { labId: 1, timeSlot: { mentorId: 10 } };
  const unassignedConsultation = { labId: 1, timeSlot: { mentorId: 77 } };

  assert.equal(
    canPeerMentorManageProjectActions(user, otherUsersProject, [
      assignedConsultation,
    ]),
    true,
  );

  assert.equal(
    canPeerMentorManageProjectActions(user, otherUsersProject, [
      unassignedConsultation,
    ]),
    false,
  );

  assert.equal(
    canPeerMentorManageProjectActions(user, ownProject, [
      unassignedConsultation,
    ]),
    true,
  );

  assert.equal(
    canPeerMentorManageProjectActions(user, outsideLabProject, [
      assignedConsultation,
    ]),
    false,
  );
});

test("lab peer mentor can act only on own projects inside assigned labs", () => {
  const user = {
    id: 21,
    role: "PEER_MENTOR",
    labAssignments: [{ labId: 4, mentorType: "LAB" }],
    assignedLabIds: [],
  };

  const ownProject = { labId: 4, userId: 21 };
  const otherUsersProject = { labId: 4, userId: 999 };
  const assignedConsultation = { labId: 4, timeSlot: { mentorId: 21 } };

  assert.equal(
    canPeerMentorManageProjectActions(user, ownProject, [assignedConsultation]),
    true,
  );

  assert.equal(
    canPeerMentorManageProjectActions(user, otherUsersProject, [
      assignedConsultation,
    ]),
    false,
  );
});

test("consultation assignment alone does not bypass lab assignment filter", () => {
  const user = {
    id: 33,
    role: "PEER_MENTOR",
    labAssignments: [{ labId: 9, mentorType: "CONSULTATION" }],
    assignedLabIds: [],
  };

  const consultationOutsideAssignedLab = {
    labId: 8,
    timeSlot: { mentorId: 33 },
  };

  assert.equal(
    canPeerMentorManageConsultation(user, consultationOutsideAssignedLab),
    false,
  );
});

test("peer mentor project visibility uses all assigned labs", async () => {
  const where = await getProjectAccessWhere(
    {},
    {
      id: 1,
      role: "PEER_MENTOR",
      labAssignments: [{ labId: 3, mentorType: "CONSULTATION" }],
      assignedLabIds: [7],
      mentorType: "CONSULTATION",
    },
  );

  assert.deepEqual(where, { labId: { in: [3, 7] } });
});
