const test = require("node:test");
const assert = require("node:assert/strict");

const notificationServicePath = require.resolve(
  "../services/notificationService",
);
require.cache[notificationServicePath] = {
  exports: {
    notifyProjectDetailsUpdated: () => Promise.resolve(),
    notifyProjectLabOrTimeChanged: () => Promise.resolve(),
  },
};

const updateProject = require("../controllers/auth/projects/updateProject");

const createMockRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  },
});

test("updateProject updates primary consultation using consultations[0].id", async () => {
  let updatedConsultationWhereId = null;

  const existingProject = {
    id: 5,
    userId: 1,
    name: "Old",
    description: "Old desc",
    status: "IN_PROCESS",
    labId: 2,
    lab: { id: 2, name: "Lab A", location: "L", description: "D" },
    equipment: [
      {
        equipment: { id: 11, name: "Eq", description: "", status: "AVAILABLE" },
      },
    ],
    consultations: [
      {
        id: 555,
        status: "SCHEDULED",
        timeSlotId: 101,
        timeSlot: {
          id: 101,
          labId: 2,
          date: new Date("2026-03-10T00:00:00.000Z"),
          startTime: "09:00",
          endTime: "10:00",
          mentor: { id: 7, name: "Mentor A", email: "a@purdue.edu" },
        },
      },
    ],
  };

  const updatedProject = {
    ...existingProject,
    name: "New Name",
    description: "New Desc",
    equipment: [
      {
        equipment: { id: 11, name: "Eq", description: "", status: "AVAILABLE" },
      },
    ],
    consultations: [
      {
        ...existingProject.consultations[0],
        timeSlotId: 202,
        timeSlot: {
          id: 202,
          labId: 2,
          date: new Date("2026-03-11T00:00:00.000Z"),
          startTime: "11:00",
          endTime: "12:00",
          mentor: { id: 8, name: "Mentor B", email: "b@purdue.edu" },
        },
      },
    ],
  };

  const prisma = {
    project: {
      findFirst: async () => existingProject,
      update: async () => updatedProject,
    },
    lab: {
      findFirst: async () => ({ id: 2 }),
    },
    equipment: {
      findMany: async () => [{ id: 11 }],
    },
    timeSlot: {
      findFirst: async () => ({
        id: 202,
        labId: 2,
        slotType: "CONSULTATION",
        isBooked: false,
        mentor: { id: 8, name: "Mentor B", email: "b@purdue.edu" },
      }),
    },
    $transaction: async (callback) =>
      callback({
        timeSlot: {
          update: async () => null,
        },
        consultation: {
          update: async ({ where }) => {
            updatedConsultationWhereId = where.id;
            return null;
          },
        },
        projectEquipment: {
          deleteMany: async () => null,
          createMany: async () => null,
        },
        project: {
          update: async () => updatedProject,
        },
      }),
  };

  const req = {
    params: { projectId: "5" },
    body: {
      name: "New Name",
      description: "New Desc",
      timeSlotId: 202,
    },
    user: { userId: 1 },
  };
  const res = createMockRes();

  await updateProject(req, res, prisma);

  assert.equal(res.statusCode, 200);
  assert.equal(updatedConsultationWhereId, 555);
  assert.equal(res.body.project.consultation.timeSlot.id, 202);
});
