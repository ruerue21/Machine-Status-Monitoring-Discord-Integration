const test = require("node:test");
const assert = require("node:assert/strict");

const {
  validateAgreementFile,
  sanitizeFilename,
} = require("../utils/validation");

test("validateAgreementFile accepts valid pdf payload", () => {
  const result = validateAgreementFile({
    originalname: "agreement.pdf",
    mimetype: "application/pdf",
  });

  assert.equal(result.valid, true);
  assert.equal(result.fileType, "pdf");
});

test("validateAgreementFile rejects mismatched extension/mime", () => {
  const result = validateAgreementFile({
    originalname: "agreement.docx",
    mimetype: "application/pdf",
  });

  assert.equal(result.valid, false);
});

test("sanitizeFilename removes unsafe chars and trims length", () => {
  const result = sanitizeFilename("../../my*unsafe?<name>.pdf");
  assert.equal(result.includes(".."), false);
  assert.equal(result.includes("*"), false);
  assert.equal(result.includes("?"), false);
  assert.equal(result.endsWith(".pdf"), true);
});
