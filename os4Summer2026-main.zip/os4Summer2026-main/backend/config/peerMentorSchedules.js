const consultationPeerMentorSchedules = [
  {
    name: "Mahmoud Leghlimi",
    email: "mleghlim@purdue.edu",
    role: "PEER_MENTOR",
    assignedLabs: ["Boilermakery"],
    schedule: {
      monday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
      wednesday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
      friday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
    },
  },
  {
    name: "David Olorunpoju-Essang",
    email: "dolorunp@purdue.edu",
    role: "PEER_MENTOR",
    assignedLabs: ["Electronics"],
    schedule: {
      tuesday: [
        { startTime: "10:00", endTime: "10:30" },
        { startTime: "11:00", endTime: "11:30" },
        { startTime: "13:00", endTime: "13:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "16:00", endTime: "16:30" },
      ],
      thursday: [
        { startTime: "10:00", endTime: "10:30" },
        { startTime: "11:00", endTime: "11:30" },
        { startTime: "13:00", endTime: "13:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "16:00", endTime: "16:30" },
      ],
    },
  },
  {
    name: "Nauryzbek Berdi",
    email: "nberdi@purdue.edu",
    role: "PEER_MENTOR",
    assignedLabs: ["Boilermakery", "Fabrics"],
    schedule: {
      monday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
      wednesday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
      friday: [
        { startTime: "09:30", endTime: "10:00" },
        { startTime: "10:30", endTime: "11:00" },
        { startTime: "12:00", endTime: "12:30" },
        { startTime: "14:00", endTime: "14:30" },
        { startTime: "15:00", endTime: "15:30" },
      ],
    },
  },
];

const labPeerMentorSchedules = [
  {
    name: "Lab Mentor 1",
    email: "labmentor1@purdue.edu",
    role: "PEER_MENTOR",
    mentorType: "LAB",
    assignedLabs: ["Boilermakery"],
    schedule: {
      monday: [
        { startTime: "10:00", endTime: "11:00" },
        { startTime: "13:00", endTime: "14:00" },
        { startTime: "15:00", endTime: "16:00" },
      ],
      wednesday: [
        { startTime: "10:00", endTime: "11:00" },
        { startTime: "13:00", endTime: "14:00" },
        { startTime: "15:00", endTime: "16:00" },
      ],
      friday: [
        { startTime: "10:00", endTime: "11:00" },
        { startTime: "13:00", endTime: "14:00" },
      ],
    },
  },
  {
    name: "Lab Mentor 2",
    email: "labmentor2@purdue.edu",
    role: "PEER_MENTOR",
    mentorType: "LAB",
    assignedLabs: ["Electronics"],
    schedule: {
      tuesday: [
        { startTime: "11:00", endTime: "12:00" },
        { startTime: "14:00", endTime: "15:00" },
        { startTime: "16:00", endTime: "17:00" },
      ],
      thursday: [
        { startTime: "11:00", endTime: "12:00" },
        { startTime: "14:00", endTime: "15:00" },
        { startTime: "16:00", endTime: "17:00" },
      ],
    },
  },
  {
    name: "Lab Mentor 3",
    email: "labmentor3@purdue.edu",
    role: "PEER_MENTOR",
    mentorType: "LAB",
    assignedLabs: ["Boilermakery", "Fabrics"],
    schedule: {
      monday: [
        { startTime: "11:00", endTime: "12:00" },
        { startTime: "14:00", endTime: "15:00" },
      ],
      wednesday: [
        { startTime: "11:00", endTime: "12:00" },
        { startTime: "14:00", endTime: "15:00" },
      ],
      friday: [
        { startTime: "11:00", endTime: "12:00" },
        { startTime: "14:00", endTime: "15:00" },
        { startTime: "16:00", endTime: "17:00" },
      ],
    },
  },
];

function generateTimeSlots(
  mentorId,
  labId,
  schedule,
  slotType = "CONSULTATION",
) {
  const slots = [];
  const now = new Date();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Get current time in minutes for filtering today's slots
  const currentTimeInMinutes = now.getHours() * 60 + now.getMinutes();

  const daysToGenerate = 90;

  for (let i = 0; i < daysToGenerate; i++) {
    const currentDate = new Date(today);
    currentDate.setDate(today.getDate() + i);

    const isToday = i === 0;

    const dayOfWeek = currentDate.getDay();
    const dayNames = [
      "sunday",
      "monday",
      "tuesday",
      "wednesday",
      "thursday",
      "friday",
      "saturday",
    ];
    const dayName = dayNames[dayOfWeek];

    // Check if this mentor has slots for this day
    if (schedule[dayName] && schedule[dayName].length > 0) {
      schedule[dayName].forEach((timeSlot) => {
        // If it's today, only add slots that haven't passed yet
        if (isToday) {
          const [hours, minutes] = timeSlot.startTime.split(":").map(Number);
          const slotStartTimeInMinutes = hours * 60 + minutes;

          // Skip if slot has already passed
          if (slotStartTimeInMinutes <= currentTimeInMinutes) {
            return;
          }
        }

        slots.push({
          mentorId: mentorId,
          labId: labId,
          date: currentDate,
          startTime: timeSlot.startTime,
          endTime: timeSlot.endTime,
          isBooked: false,
          slotType: slotType,
        });
      });
    }
  }

  return slots;
}

module.exports = {
  consultationPeerMentorSchedules,
  labPeerMentorSchedules,
  generateTimeSlots,
};
