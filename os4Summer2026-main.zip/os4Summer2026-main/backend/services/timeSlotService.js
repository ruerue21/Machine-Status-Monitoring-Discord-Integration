const {
  peerMentorSchedules,
  generateTimeSlots,
} = require("../config/peerMentorSchedules");
const prisma = require("../db/prisma");

// Generate time slots for next 2 weeks for all peer mentors
const generateTimeSlotsBatch = async () => {
  try {
    // Get all peer mentors with their assigned labs
    const mentors = await prisma.user.findMany({
      where: { role: "PEER_MENTOR" },
      select: {
        id: true,
        name: true,
        email: true,
        assignedLabIds: true,
      },
    });

    if (mentors.length === 0) {
      return 0;
    }

    // Clear existing future time slots (keep past ones for history)
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    await prisma.timeSlot.deleteMany({
      where: {
        date: { gte: today },
        isBooked: false,
      },
    });

    let totalCreated = 0;

    // Generate time slots for each mentor
    for (const mentor of mentors) {
      // Find mentor's schedule configuration
      const mentorConfig = peerMentorSchedules.find(
        (config) => config.email === mentor.email,
      );

      if (!mentorConfig) {
        continue;
      }

      // Generate time slots for each assigned lab
      for (const labId of mentor.assignedLabIds) {
        const timeSlots = generateTimeSlots(
          mentor.id,
          labId,
          mentorConfig.schedule,
        );

        if (timeSlots.length > 0) {
          const created = await prisma.timeSlot.createMany({
            data: timeSlots,
            skipDuplicates: true,
          });
          totalCreated += created.count;
        }
      }
    }

    return totalCreated;
  } catch (error) {
    console.error("Error generating time slots:", error);
    throw error;
  }
};

// Get available time slots with mentor availability tracking
const getAvailableTimeSlots = async (labId, date = null) => {
  try {
    const labIdInt = parseInt(labId);

    const dateFilter = {};
    if (date) {
      // Create date from the YYYY-MM-DD string sent by frontend
      const [year, month, day] = date.split("-");
      const targetDate = new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
      );

      // Create start and end of day in local timezone
      const startOfDay = new Date(targetDate);
      startOfDay.setHours(0, 0, 0, 0);

      const endOfDay = new Date(targetDate);
      endOfDay.setHours(23, 59, 59, 999);

      dateFilter.date = {
        gte: startOfDay,
        lte: endOfDay,
      };
    } else {
      // Default to showing slots from today onwards
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      dateFilter.date = {
        gte: today,
      };
    }

    // Get all time slots for this lab and date range
    const timeSlots = await prisma.timeSlot.findMany({
      where: {
        labId: labIdInt,
        slotType: "CONSULTATION",
        mentor: {
          is: {
            role: "PEER_MENTOR",
          },
        },
        ...dateFilter,
      },
      include: {
        mentor: {
          select: {
            id: true,
            name: true,
            role: true,
          },
        },
        consultation: {
          select: {
            id: true,
          },
        },
        lab: {
          select: { id: true, name: true },
        },
      },
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
    });

    // Group time slots by date and time to count available mentors
    const slotGroups = {};

    timeSlots.forEach((slot) => {
      const dateKey = slot.date.toISOString().split("T")[0];
      const timeKey = `${slot.startTime}-${slot.endTime}`;
      const groupKey = `${dateKey}_${timeKey}`;

      if (!slotGroups[groupKey]) {
        slotGroups[groupKey] = {
          date: slot.date,
          startTime: slot.startTime,
          endTime: slot.endTime,
          labId: slot.labId,
          availableSlots: [],
          bookedSlots: [],
          totalMentors: 0,
          availableMentors: 0,
          displayText: formatTimeSlotDisplayAnonymous(
            slot.date,
            slot.startTime,
            slot.endTime,
          ),
        };
      }

      slotGroups[groupKey].totalMentors++;

      if (slot.isBooked || slot.consultation) {
        slotGroups[groupKey].bookedSlots.push({
          id: slot.id,
          mentorId: slot.mentorId,
          mentorName: slot.mentor.name,
          isBooked: slot.isBooked,
        });
      } else {
        slotGroups[groupKey].availableSlots.push({
          id: slot.id,
          mentorId: slot.mentorId,
          mentorName: slot.mentor.name,
        });
        slotGroups[groupKey].availableMentors++;
      }
    });

    // Convert to array and filter out fully booked slots
    const availableTimeSlots = Object.values(slotGroups)
      .filter((group) => group.availableMentors > 0)
      .map((group) => ({
        id: group.availableSlots[0]?.id, // Use first available slot ID for booking
        date: group.date,
        startTime: group.startTime,
        endTime: group.endTime,
        labId: group.labId,
        availableMentors: group.availableMentors,
        totalMentors: group.totalMentors,
        availableSlotIds: group.availableSlots.map((s) => s.id),
        displayText: group.displayText,
        lab: { id: labIdInt, name: timeSlots[0]?.lab?.name || "" },
      }));

    return availableTimeSlots;
  } catch (error) {
    console.error("Error fetching available time slots:", error);
    throw error;
  }
};

// Format time slot for user friendly display without mentor name
const formatTimeSlotDisplayAnonymous = (date, startTime, endTime) => {
  const dateObj = new Date(date);
  const dayName = dateObj.toLocaleDateString("en-US", { weekday: "long" });
  const monthDay = dateObj.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
  });

  // Convert 24-hour time to 12-hour format
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formattedStartTime = formatTime(startTime);
  const formattedEndTime = formatTime(endTime);

  return `${dayName}, ${monthDay} - ${formattedStartTime} to ${formattedEndTime}`;
};

// Format time slot for user friendly display with mentor name (for admin/mentor views)
const formatTimeSlotDisplay = (date, startTime, endTime, mentorName) => {
  const dateObj = new Date(date);
  const dayName = dateObj.toLocaleDateString("en-US", { weekday: "long" });
  const monthDay = dateObj.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
  });

  // Convert 24-hour time to 12-hour format
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(":");
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? "PM" : "AM";
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const formattedStartTime = formatTime(startTime);
  const formattedEndTime = formatTime(endTime);

  return `${dayName}, ${monthDay} - ${formattedStartTime} to ${formattedEndTime} (${mentorName})`;
};

// Book a time slot with random mentor assignment from available mentors
const bookTimeSlot = async (selectedTimeSlotGroupId, userId, labId) => {
  try {
    const labIdInt = parseInt(labId);

    // Get available slots for this time group
    const availableSlots = await getAvailableTimeSlots(labIdInt);
    const targetSlotGroup = availableSlots.find((group) =>
      group.availableSlotIds.includes(parseInt(selectedTimeSlotGroupId)),
    );

    if (!targetSlotGroup || targetSlotGroup.availableMentors === 0) {
      throw new Error("No available mentors for selected time slot");
    }

    // Randomly select one of the available slots
    const randomIndex = Math.floor(
      Math.random() * targetSlotGroup.availableSlotIds.length,
    );
    const selectedSlotId = targetSlotGroup.availableSlotIds[randomIndex];

    // Book the selected time slot and create consultation with proper locking
    return await prisma.$transaction(
      async (tx) => {
        // Lock and verify the time slot is still available
        const timeSlot = await tx.timeSlot.findUnique({
          where: { id: selectedSlotId },
        });

        if (!timeSlot) {
          throw new Error("Time slot not found");
        }

        if (timeSlot.isBooked) {
          throw new Error("Time slot is no longer available");
        }

        // Mark time slot as booked first
        const reservation = await tx.timeSlot.updateMany({
          where: {
            id: selectedSlotId,
            isBooked: false,
          },
          data: { isBooked: true },
        });

        if (reservation.count === 0) {
          throw new Error("Time slot is no longer available");
        }

        // Create consultation
        const consultation = await tx.consultation.create({
          data: {
            userId: parseInt(userId),
            labId: labIdInt,
            timeSlotId: selectedSlotId,
            status: "SCHEDULED",
          },
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
            user: {
              select: { id: true, name: true, email: true },
            },
            lab: {
              select: { id: true, name: true, location: true },
            },
          },
        });

        return consultation;
      },
      {
        maxWait: 5000,
        timeout: 10000,
      },
    );
  } catch (error) {
    console.error("Error booking time slot:", error);
    throw error;
  }
};

// Schedule automatic time slot regeneration (call this weekly)
const scheduleTimeSlotRegeneration = () => {
  const schedule = require("node-cron");

  schedule.schedule("0 0 * * 0", async () => {
    try {
      await generateTimeSlotsBatch();
    } catch (error) {
      console.error("Weekly time slot regeneration failed:", error);
    }
  });
};

// Get time slots for a specific mentor
const getMentorTimeSlots = async (mentorId, date = null) => {
  try {
    const whereCondition = {
      mentorId: parseInt(mentorId),
      date: { gte: new Date() }, // Only future time slots
    };

    if (date) {
      const targetDate = new Date(date);
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);

      whereCondition.date = {
        gte: targetDate,
        lt: nextDay,
      };
    }

    const timeSlots = await prisma.timeSlot.findMany({
      where: whereCondition,
      orderBy: [{ date: "asc" }, { startTime: "asc" }],
      include: {
        lab: {
          select: { id: true, name: true },
        },
        consultation: {
          include: {
            user: {
              select: { id: true, name: true, email: true },
            },
            project: {
              select: { id: true, name: true },
            },
          },
        },
      },
    });

    return timeSlots;
  } catch (error) {
    console.error("Error fetching mentor time slots:", error);
    throw error;
  }
};

// Create time slots for peer mentors (utility function for seeding)
const createTimeSlots = async (mentorId, labId, date, timeSlots) => {
  try {
    const slotsData = timeSlots.map((slot) => ({
      mentorId: mentorId,
      labId: labId,
      date: new Date(date),
      startTime: slot.startTime,
      endTime: slot.endTime,
      isBooked: false,
    }));

    await prisma.timeSlot.createMany({
      data: slotsData,
      skipDuplicates: true,
    });
  } catch (error) {
    console.error("Error creating time slots:", error);
    throw error;
  }
};

module.exports = {
  generateTimeSlotsBatch,
  getAvailableTimeSlots,
  formatTimeSlotDisplay,
  formatTimeSlotDisplayAnonymous,
  scheduleTimeSlotRegeneration,
  getMentorTimeSlots,
  bookTimeSlot,
  createTimeSlots,
};
