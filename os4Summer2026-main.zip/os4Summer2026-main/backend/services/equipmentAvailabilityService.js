const prisma = require("../db/prisma");
const logger = require("../utils/logger");

let isProcessing = false;
let monitorHandle = null;

const processEquipmentAvailabilityTransitions = async () => {
  if (isProcessing) {
    return;
  }
  isProcessing = true;

  try {
    const now = new Date();
    const equipmentToReactivate = await prisma.equipment.findMany({
      where: {
        status: "OUT_OF_ORDER",
        outOfOrderNever: false,
        outOfOrderUntil: {
          lte: now,
        },
      },
      select: {
        id: true,
        name: true,
      },
    });

    if (equipmentToReactivate.length === 0) {
      return;
    }

    const equipmentIds = equipmentToReactivate.map((item) => item.id);

    await prisma.equipment.updateMany({
      where: {
        id: { in: equipmentIds },
      },
      data: {
        status: "AVAILABLE",
        outOfOrderUntil: null,
        outOfOrderNever: false,
      },
    });

    logger.info("Auto-reactivated equipment after out-of-order window", {
      equipmentIds,
      equipmentNames: equipmentToReactivate.map((item) => item.name),
    });
  } catch (error) {
    logger.error("Failed processing equipment availability transitions", {
      error: error.message,
      stack: error.stack,
    });
  } finally {
    isProcessing = false;
  }
};

const scheduleEquipmentAvailabilityMonitor = () => {
  if (monitorHandle) {
    return;
  }

  processEquipmentAvailabilityTransitions().catch(() => {});

  monitorHandle = setInterval(() => {
    processEquipmentAvailabilityTransitions().catch(() => {});
  }, 60 * 1000);
};

module.exports = {
  processEquipmentAvailabilityTransitions,
  scheduleEquipmentAvailabilityMonitor,
};
