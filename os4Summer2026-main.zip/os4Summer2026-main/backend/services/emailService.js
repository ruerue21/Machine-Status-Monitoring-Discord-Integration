const nodemailer = require("nodemailer");
const logger = require("../utils/logger");

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

const sendVerificationEmail = async (email, verificationToken) => {
  const verificationUrl = `${FRONTEND_URL}/verify-email?token=${verificationToken}`;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Verify Your Schedule Optimizer Account",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4F46E5;">Welcome to Schedule Optimizer!</h2>
        <p>Thank you for registering with your Purdue email address.</p>
        <p>Please click the button below to verify your email address:</p>
        <div style="text-align: center; margin: 20px 0;">
          <a href="${verificationUrl}" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Verify Email Address
          </a>
        </div>
        <p>Or copy and paste this link in your browser:</p>
        <p style="word-break: break-all; color: #6B7280;">${verificationUrl}</p>
        <p><strong>This link expires in 24 hours.</strong></p>
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          If you didn't create this account, please ignore this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Verification email sent", { email });
  } catch (error) {
    logger.error("Error sending verification email:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

const sendEmailChangeConfirmation = async (
  currentEmail,
  newEmail,
  verificationToken,
) => {
  const verificationUrl = `${FRONTEND_URL}/verify-email?token=${verificationToken}`;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: currentEmail,
    subject: "Confirm Your Email Change - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4F46E5;">Confirm Email Change</h2>
        <p>A request was made to change your account email address.</p>
        <p><strong>Current email:</strong> ${currentEmail}</p>
        <p><strong>Requested new email:</strong> ${newEmail}</p>
        <p>If this was you, confirm the change using the button below:</p>
        <div style="text-align: center; margin: 20px 0;">
          <a href="${verificationUrl}" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Confirm Email Change
          </a>
        </div>
        <p>Or copy and paste this link in your browser:</p>
        <p style="word-break: break-all; color: #6B7280;">${verificationUrl}</p>
        <p><strong>This link expires in 24 hours.</strong></p>
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          If you did not request this, you can safely ignore this email. Your account email will not change.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Email change confirmation sent", { currentEmail, newEmail });
  } catch (error) {
    logger.error("Error sending email change confirmation:", {
      error: error.message,
      currentEmail,
      newEmail,
    });
    throw error;
  }
};

const sendPasswordResetEmail = async (email, resetToken) => {
  const resetUrl = `${FRONTEND_URL}/reset-password?token=${resetToken}`;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Reset Your Schedule Optimizer Password",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4F46E5;">Password Reset Request</h2>
        <p>You requested to reset your password for your Schedule Optimizer account.</p>
        <p>Please click the button below to reset your password:</p>
        <div style="text-align: center; margin: 20px 0;">
          <a href="${resetUrl}" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Reset Password
          </a>
        </div>
        <p>Or copy and paste this link in your browser:</p>
        <p style="word-break: break-all; color: #6B7280;">${resetUrl}</p>
        <p><strong>This link expires in 1 hour.</strong></p>
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          If you didn't request this password reset, please ignore this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Password reset email sent", { email });
  } catch (error) {
    logger.error("Error sending password reset email:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

// Helper function to format date/time
const formatDateTime = (date, startTime = null) => {
  const dateObj = new Date(date);

  if (startTime) {
    // If we have a separate time string (e.g., "09:00"), parse it
    const [hours, minutes] = startTime.split(":");
    dateObj.setHours(parseInt(hours), parseInt(minutes), 0, 0);
  }

  return dateObj.toLocaleString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

// Project Proposal Confirmation (to Member)
const sendProjectProposalConfirmation = async (memberEmail, projectData) => {
  const equipmentList =
    projectData.equipment && projectData.equipment.length > 0
      ? projectData.equipment.map((e) => e.name).join(", ")
      : "None";

  // HTML for multiple consultations
  const consultationsHtml = projectData.consultationsList
    ? projectData.consultationsList
        .split("\n")
        .map(
          (session) => `
          <div style="background-color: #F9FAFB; padding: 10px; margin: 5px 0; border-left: 3px solid #4F46E5; border-radius: 4px;">
            ${session}
          </div>
        `,
        )
        .join("")
    : `
      <div style="background-color: #F9FAFB; padding: 10px; margin: 5px 0; border-left: 3px solid #4F46E5; border-radius: 4px;">
        ${formatDateTime(projectData.consultationDate, projectData.consultationTime)} with ${projectData.mentorName}
      </div>
    `;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Project Proposal Submitted - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #4F46E5; text-align: center;">Project Proposal Submitted Successfully!</h2>
        <p>Hi ${projectData.studentName},</p>
        <p>Your project proposal has been submitted and ${projectData.consultationsCount || 1} consultation session${(projectData.consultationsCount || 1) > 1 ? "s have" : " has"} been scheduled.</p>
        
        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${projectData.projectName}</p>
          <p><strong>Project Description:</strong> ${projectData.description || projectData.projectDescription}</p>
          <p><strong>Lab Requested:</strong> ${projectData.labName}</p>
          <p><strong>Equipment Requested:</strong> ${equipmentList}</p>
        </div>
        
        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">
            Consultation Session${(projectData.consultationsCount || 1) > 1 ? "s" : ""} Scheduled (${projectData.consultationsCount || 1})
          </h3>
          ${consultationsHtml}
          <p style="margin-top: 15px;"><strong>Location:</strong> ${projectData.labLocation}</p>
        </div>
        
        ${
          (projectData.consultationsCount || 1) > 1
            ? `
        <div style="background-color: #DBEAFE; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #3B82F6;">
          <p style="margin: 0; color: #1E40AF;">
            <strong>📅 Multiple Sessions:</strong> You have ${projectData.consultationsCount} consultation sessions scheduled. 
            Please attend all sessions to discuss different aspects of your project with the peer mentors.
          </p>
        </div>
        `
            : ""
        }
        
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; text-align: center;">Next Steps</h3>
          <p>• Review the member agreement if you haven't already</p>
          <p>• Prepare any questions for your consultation${(projectData.consultationsCount || 1) > 1 ? "s" : ""}</p>
          <p>• Arrive on time at the scheduled location${(projectData.consultationsCount || 1) > 1 ? " for each session" : ""}</p>
          ${
            (projectData.consultationsCount || 1) > 1
              ? "<p>• Check your calendar for all scheduled sessions</p>"
              : ""
          }
        </div>
        
        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/projects" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View My Projects
          </a>
        </div>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          If you have any questions, please contact us at ${process.env.EMAIL_USER}
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Project proposal confirmation sent to:", memberEmail);
  } catch (error) {
    console.error("Error sending project confirmation:", error);
    throw error;
  }
};

// Consultation Assignment (to Peer Mentor)
const sendConsultationAssignment = async (mentorEmail, consultationData) => {
  const equipmentList =
    Array.isArray(consultationData.equipment) &&
    consultationData.equipment.length > 0
      ? consultationData.equipment.map((e) => e.name).join(", ")
      : "None specified";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "New Consultation Assignment - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #4F46E5; text-align: center;">New Consultation Assignment</h2>
        <p>Hi ${consultationData.mentorName},</p>
        <p>You have been assigned a new consultation for a project proposal.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Student Information</h3>
          <p><strong>Name:</strong> ${consultationData.studentName}</p>
          <p><strong>Email:</strong> ${consultationData.studentEmail}</p>
        </div>

        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${consultationData.projectName}</p>
          <p><strong>Project Description:</strong> ${consultationData.description}</p>
          <p><strong>Lab Needed:</strong> ${consultationData.labName}</p>
          ${equipmentList ? `<p><strong>Equipment Needed:</strong> ${equipmentList}</p>` : ""}
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Consultation Schedule</h3>
          <p><strong>Date & Time:</strong> ${formatDateTime(consultationData.consultationDate, consultationData.consultationTime)}</p>
          <p><strong>Location:</strong> ${consultationData.labLocation}</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/admin-review" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Project Details
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Consultation assignment sent to:", mentorEmail);
  } catch (error) {
    console.error("Error sending consultation assignment:", error);
    throw error;
  }
};

// Mentor Reassignment Notification (to Previous Mentor)
const sendMentorReplacementNotification = async (
  mentorEmail,
  reassignmentData,
) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "Consultation Reassignment - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Consultation Reassignment</h2>
        <p>Hi ${reassignmentData.previousMentorName},</p>
        <p>A consultation that was assigned to you has been reassigned to another consultation peer mentor.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${reassignmentData.projectName}</p>
          <p><strong>Student:</strong> ${reassignmentData.studentName}</p>
          <p><strong>Student Email:</strong> ${reassignmentData.studentEmail}</p>
          <p><strong>Date & Time:</strong> ${formatDateTime(reassignmentData.consultationDate, reassignmentData.consultationTime)}</p>
          <p><strong>New Consultation Peer Mentor:</strong> ${reassignmentData.newMentorName}</p>
          <p><strong>New Consultation Peer Mentor Email:</strong> ${reassignmentData.newMentorEmail}</p>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          If you have any questions, please contact an administrator.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Mentor replacement notification sent to:", mentorEmail);
  } catch (error) {
    console.error("Error sending replacement notification:", error);
    throw error;
  }
};

// Consultation Cancelled - Project Deleted (to Assigned Mentor)
const sendConsultationCancelledProjectDeleted = async (
  mentorEmail,
  cancellationData,
) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "Consultation Cancelled - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Consultation Cancelled</h2>
        <p>Hi ${cancellationData.mentorName},</p>
        <p>A scheduled consultation has been cancelled because the student deleted their project proposal.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Cancelled Consultation Details</h3>
          <p><strong>Project Name:</strong> ${cancellationData.projectName}</p>
          <p><strong>Student:</strong> ${cancellationData.studentName}</p>
          <p><strong>Student Email:</strong> ${cancellationData.studentEmail}</p>
          <p><strong>Scheduled Date & Time:</strong> ${formatDateTime(cancellationData.consultationDate, cancellationData.consultationTime)}</p>
          <p><strong>Location:</strong> ${cancellationData.labLocation}</p>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          The time slot has been released and is now available for other students.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(
      "Consultation cancellation (project deleted) sent to:",
      mentorEmail,
    );
  } catch (error) {
    console.error(
      "Error sending consultation cancellation notification:",
      error,
    );
    throw error;
  }
};

// New Mentor Assignment Notification (to New Mentor)
const sendNewMentorAssignment = async (mentorEmail, assignmentData) => {
  const equipmentList =
    assignmentData.equipment && assignmentData.equipment.length > 0
      ? assignmentData.equipment.map((e) => e.name).join(", ")
      : "None";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "New Consultation Assignment - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">New Consultation Assignment</h2>
        <p>Hi ${assignmentData.newMentorName},</p>
        <p>You have been assigned a new consultation for a project proposal.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Student Information</h3>
          <p><strong>Name:</strong> ${assignmentData.studentName}</p>
          <p><strong>Email:</strong> ${assignmentData.studentEmail}</p>
        </div>

        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${assignmentData.projectName}</p>
          <p><strong>Project Description:</strong> ${assignmentData.description}</p>
          <p><strong>Lab Needed:</strong> ${assignmentData.labName}</p>
          ${equipmentList ? `<p><strong>Equipment Needed:</strong> ${equipmentList}</p>` : ""}
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Consultation Schedule</h3>
          <p><strong>Date & Time:</strong> ${formatDateTime(assignmentData.consultationDate, assignmentData.consultationTime)}</p>
          <p><strong>Location:</strong> ${assignmentData.labLocation}</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/admin-review" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Project Details
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("New mentor assignment sent to:", mentorEmail);
  } catch (error) {
    console.error("Error sending new mentor assignment:", error);
    throw error;
  }
};

// Send notification when project details are updated (name/description/equipment)
const sendProjectUpdateNotification = async (mentorEmail, updateData) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "Project Details Updated - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #F59E0B; text-align: center;">Project Details Updated</h2>
        <p>Hi ${updateData.mentorName},</p>
        <p>The student has updated their project proposal details.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Student Information</h3>
          <p><strong>Name:</strong> ${updateData.studentName}</p>
          <p><strong>Email:</strong> ${updateData.studentEmail}</p>
        </div>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">What Changed</h3>
          ${updateData.changes.map((change) => `<p><strong>${change.field}:</strong> ${change.newValue}</p>`).join("")}
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Consultation Schedule</h3>
          <p><strong>Date & Time:</strong> ${formatDateTime(updateData.consultationDate, updateData.consultationTime)}</p>
          <p><strong>Location:</strong> ${updateData.labLocation}</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/admin-review" 
              style="background-color: #F59E0B; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Updated Project
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Project update notification sent to:", mentorEmail);
  } catch (error) {
    console.error("Error sending project update notification:", error);
    throw error;
  }
};

// Send notification when project's lab or time changes (cancellation to old mentor)
const sendProjectLabOrTimeChangeOldMentor = async (
  mentorEmail,
  cancellationData,
) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "Consultation Reassigned - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Consultation Reassigned</h2>
        <p>Hi ${cancellationData.mentorName},</p>
        <p>A consultation assigned to you has been reassigned because the student changed the lab or consultation time.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Original Consultation Details</h3>
          <p><strong>Project Name:</strong> ${cancellationData.projectName}</p>
          <p><strong>Student:</strong> ${cancellationData.studentName}</p>
          <p><strong>Student Email:</strong> ${cancellationData.studentEmail}</p>
          <p><strong>Original Lab Requested:</strong> ${cancellationData.oldLabName}</p>
          <p><strong>Original Date & Time:</strong> ${formatDateTime(cancellationData.originalDate, cancellationData.originalTime)}</p>
        </div>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">New Consultation Details</h3>
          <p><strong>New Lab Requested:</strong> ${cancellationData.newLabName}</p>
          <p><strong>New Date & Time:</strong> ${formatDateTime(cancellationData.newDate, cancellationData.newTime)}</p>
          <p><strong>New Consultation Peer Mentor:</strong> ${cancellationData.newMentorName}</p>
          <p><strong>New Consultation Peer Mentor Email:</strong> ${cancellationData.newMentorEmail}</p>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          The consultation time slot has been released and is now available for other students.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(
      "Lab/time change cancellation sent to old mentor:",
      mentorEmail,
    );
  } catch (error) {
    console.error("Error sending lab/time change notification:", error);
    throw error;
  }
};

// Send notification to new mentor when project's lab or time changes
const sendProjectLabOrTimeChangeNewMentor = async (
  mentorEmail,
  assignmentData,
) => {
  const equipmentList =
    assignmentData.equipment && assignmentData.equipment.length > 0
      ? assignmentData.equipment.map((e) => e.name).join(", ")
      : "None";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "New Consultation Assignment - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">New Consultation Assignment</h2>
        <p>Hi ${assignmentData.newMentorName},</p>
        <p>You have been assigned a new consultation for a project proposal.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Student Information</h3>
          <p><strong>Name:</strong> ${assignmentData.studentName}</p>
          <p><strong>Email:</strong> ${assignmentData.studentEmail}</p>
        </div>

        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${assignmentData.projectName}</p>
          <p><strong>Project Description:</strong> ${assignmentData.description}</p>
          <p><strong>Lab Needed:</strong> ${assignmentData.labName}</p>
          ${equipmentList ? `<p><strong>Equipment Needed:</strong> ${equipmentList}</p>` : ""}
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Consultation Schedule</h3>
          <p><strong>Date & Time:</strong> ${formatDateTime(assignmentData.consultationDate, assignmentData.consultationTime)}</p>
          <p><strong>Location:</strong> ${assignmentData.labLocation}</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/admin-review" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Project Details
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Lab/time change assignment sent to new mentor:", mentorEmail);
  } catch (error) {
    console.error("Error sending new mentor assignment:", error);
    throw error;
  }
};

// Send notification to mentor when member cancels consultation
const sendMemberConsultationCancellation = async (
  mentorEmail,
  cancellationData,
) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "Consultation Cancelled by Student - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Student Cancelled Consultation</h2>
        <p>Hi ${cancellationData.mentorName},</p>
        <p>A student has cancelled their consultation.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Cancelled Consultation Details</h3>
          <p><strong>Project Name:</strong> ${cancellationData.projectName}</p>
          <p><strong>Student:</strong> ${cancellationData.studentName}</p>
          <p><strong>Student Email:</strong> ${cancellationData.studentEmail}</p>
          <p><strong>Scheduled Date & Time:</strong> ${formatDateTime(cancellationData.consultationDate, cancellationData.consultationTime)}</p>
          <p><strong>Location:</strong> ${cancellationData.labLocation}</p>
        </div>

        ${
          cancellationData.reason
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Cancellation Reason:</strong> ${cancellationData.reason}</p>
        </div>
        `
            : ""
        }

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          The time slot has been released and is now available for other students.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(
      "Member consultation cancellation sent to mentor:",
      mentorEmail,
    );
  } catch (error) {
    console.error("Error sending member cancellation notification:", error);
    throw error;
  }
};

// Send notification to member when admin cancels consultation
const sendAdminConsultationCancellation = async (
  memberEmail,
  cancellationData,
) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Consultation Cancelled - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Consultation Cancelled</h2>
        <p>Hi ${cancellationData.studentName},</p>
        <p>Your consultation has been cancelled by the administration team.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Cancelled Consultation Details</h3>
          <p><strong>Project Name:</strong> ${cancellationData.projectName}</p>
          <p><strong>Lab Requested:</strong> ${cancellationData.labName}</p>
          <p><strong>Scheduled Date & Time:</strong> ${formatDateTime(cancellationData.consultationDate, cancellationData.consultationTime)}</p>
          <p><strong>Consultation Peer Mentor:</strong> ${cancellationData.mentorName}</p>
        </div>

        ${
          cancellationData.reason
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Reason:</strong> ${cancellationData.reason}</p>
        </div>
        `
            : ""
        }

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Next Steps</h3>
          <p>• You can reschedule by creating a new project proposal</p>
          <p>• Your original project details are still saved</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/projects" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View My Projects
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Admin consultation cancellation sent to member:", memberEmail);
  } catch (error) {
    console.error("Error sending admin cancellation notification:", error);
    throw error;
  }
};

// Send notification to member when admin marks as absent
const sendAdminAbsentNotification = async (memberEmail, absentData) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Marked as Absent - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Marked as Absent</h2>
        <p>Hi ${absentData.studentName},</p>
        <p>You have been marked as absent by the administration team.</p>

        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B; text-align: center;">Consultation Details</h3>
          <p><strong>Project Name:</strong> ${absentData.projectName}</p>
          <p><strong>Lab Requested:</strong> ${absentData.labName}</p>
          <p><strong>Scheduled Date & Time:</strong> ${formatDateTime(absentData.consultationDate, absentData.consultationTime)}</p>
          <p><strong>Consultation Peer Mentor:</strong> ${absentData.mentorName}</p>
          <p><strong>Consultation Peer Mentor Email:</strong> ${absentData.mentorEmail}</p>
        </div>

        ${
          absentData.reason
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Note:</strong> ${absentData.reason}</p>
        </div>
        `
            : ""
        }

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Next Steps</h3>
          <p>• You can reschedule by creating a new project proposal</p>
          <p>• Your original project details are still saved</p>
          <p>• Please make sure to attend future scheduled consultations</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/projects" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View My Projects
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Admin absent notification sent to member:", memberEmail);
  } catch (error) {
    console.error("Error sending admin absent notification:", error);
    throw error;
  }
};

// Lab Session Confirmation (to Member)
const sendLabSessionConfirmation = async (memberEmail, sessionData) => {
  const equipmentList = sessionData.equipment.map((e) => e.name).join(", ");

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Lab Session Confirmed - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">Lab Session Confirmed</h2>
        <p>Hi ${sessionData.studentName},</p>
        <p>Your lab session has been confirmed.</p>

        <div style="background-color: #D1FAE5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #065F46; text-align: center;">Session Details</h3>
          <p><strong>Project Name:</strong> ${sessionData.projectName}</p>
          <p><strong>Lab Reserved:</strong> ${sessionData.labName}</p>
          <p><strong>Location:</strong> ${sessionData.labLocation}</p>
          <p><strong>Date & Time:</strong> ${formatDateTime(sessionData.startDate)}</p>
          <p><strong>Duration:</strong> ${formatDateTime(sessionData.startDate)} - ${formatDateTime(sessionData.endDate)}</p>
        </div>

        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Lab Peer Mentor</h3>
          <p><strong>Name:</strong> ${sessionData.labMentorName}</p>
          <p><strong>Email:</strong> ${sessionData.labMentorEmail}</p>
        </div>

        ${
          equipmentList
            ? `
        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Equipment Reserved</h3>
          <p>${equipmentList}</p>
        </div>
        `
            : ""
        }

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/lab-sessions" 
              style="background-color: #059669; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Lab Sessions
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          Please arrive on time and bring any necessary materials.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Lab session confirmation sent to:", memberEmail);
  } catch (error) {
    console.error("Error sending lab session confirmation:", error);
    throw error;
  }
};

// Lab Session Assignment (to Lab Peer Mentor)
const sendLabSessionAssignment = async (mentorEmail, sessionData) => {
  const equipmentList = sessionData.equipment.map((e) => e.name).join(", ");

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: "New Lab Session Assignment - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #4F46E5; text-align: center;">New Lab Session Assignment</h2>
        <p>Hi ${sessionData.labMentorName},</p>
        <p>You have been assigned to supervise a lab session.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Student Information</h3>
          <p><strong>Name:</strong> ${sessionData.studentName}</p>
          <p><strong>Email:</strong> ${sessionData.studentEmail}</p>
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Session Details</h3>
          <p><strong>Project Name:</strong> ${sessionData.projectName}</p>
          <p><strong>Lab Reserved:</strong> ${sessionData.labName} - ${sessionData.labLocation}</p>
          <p><strong>Date & Time:</strong> ${formatDateTime(sessionData.startDate)}</p>
          <p><strong>Duration:</strong> ${formatDateTime(sessionData.startDate)} - ${formatDateTime(sessionData.endDate)}</p>
        </div>

        ${
          equipmentList
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E;">Equipment Needed</h3>
          <p>${equipmentList}</p>
        </div>
        `
            : ""
        }

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/bookings" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View All Bookings
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          Please ensure all equipment is ready before the session starts.
        </p>
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Lab session assignment sent to:", mentorEmail);
  } catch (error) {
    console.error("Error sending lab session assignment:", error);
    throw error;
  }
};

// Lab Session Update Notification (to Member and Mentor)
const sendLabSessionUpdate = async (recipientEmail, updateData) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: recipientEmail,
    subject: "Lab Session Updated - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #F59E0B; text-align: center;">Lab Session Updated</h2>
        <p>Hi ${updateData.recipientName},</p>
        <p>A lab session has been updated. Please review the new details below.</p>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">Updated Session Details</h3>
          <p><strong>Project Name:</strong> ${updateData.projectName}</p>
          <p><strong>Lab Reserved:</strong> ${updateData.labName} - ${updateData.labLocation}</p>
          <p><strong>New Date & Time:</strong> ${formatDateTime(updateData.startDate)}</p>
          <p><strong>New Lab Peer Mentor:</strong> ${updateData.labMentorName}</p>
          <p><strong>New Lab Peer Mentor Email:</strong> ${updateData.labMentorEmail}</p>
        </div>

        ${
          updateData.notes
            ? `
        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Notes:</strong> ${updateData.notes}</p>
        </div>
        `
            : ""
        }

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/${updateData.isStudent ? "lab-sessions" : "bookings"}" 
              style="background-color: #F59E0B; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Updated Session
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Lab session update sent to:", recipientEmail);
  } catch (error) {
    console.error("Error sending lab session update:", error);
    throw error;
  }
};

const formatOutOfOrderWindow = (outOfOrderUntil) => {
  if (!outOfOrderUntil) {
    return "until further notice";
  }
  return `until ${formatDateTime(outOfOrderUntil)}`;
};

// Lab Session Equipment Adjustment (to Member and Mentor)
const sendLabSessionEquipmentAdjustment = async (recipientEmail, data) => {
  const remainingEquipmentList =
    data.remainingEquipment && data.remainingEquipment.length > 0
      ? data.remainingEquipment.map((item) => item.name).join(", ")
      : "None";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: recipientEmail,
    subject: "Lab Session Equipment Update - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #B45309; text-align: center;">Equipment Update for Upcoming Lab Session</h2>
        <p>Hi ${data.recipientName},</p>
        <p>One equipment item in an upcoming lab session was marked out of order and has been removed from the session.</p>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">What Changed</h3>
          <p><strong>Project Name:</strong> ${data.projectName}</p>
          <p><strong>Lab:</strong> ${data.labName} - ${data.labLocation}</p>
          <p><strong>Session Time:</strong> ${formatDateTime(data.startDate)} - ${formatDateTime(data.endDate)}</p>
          <p><strong>Removed Equipment:</strong> ${data.removedEquipmentName}</p>
          <p><strong>Out of Order Window:</strong> ${formatOutOfOrderWindow(data.outOfOrderUntil)}</p>
        </div>

        <div style="background-color: #ECFDF5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #065F46; text-align: center;">Equipment Still Reserved</h3>
          <p>${remainingEquipmentList}</p>
        </div>

        ${
          data.labMentorName
            ? `
        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Lab Peer Mentor</h3>
          <p><strong>Name:</strong> ${data.labMentorName}</p>
          <p><strong>Email:</strong> ${data.labMentorEmail || "N/A"}</p>
        </div>
        `
            : ""
        }

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/${data.isStudent ? "lab-sessions" : "bookings"}"
              style="background-color: #B45309; color: white; padding: 12px 30px;
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Session Details
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Lab session equipment adjustment sent to:", recipientEmail);
  } catch (error) {
    console.error("Error sending lab session equipment adjustment:", error);
    throw error;
  }
};

// Status Change Notification (Generic for both Consultation and Lab Session)
const sendStatusChangeNotification = async (recipientEmail, statusData) => {
  const statusColors = {
    SCHEDULED: { bg: "#DBEAFE", color: "#1E40AF", icon: "📅" },
    CONFIRMED: { bg: "#D1FAE5", color: "#065F46", icon: "✅" },
    COMPLETED: { bg: "#E0E7FF", color: "#4338CA", icon: "🎉" },
    CANCELLED: { bg: "#FEE2E2", color: "#991B1B", icon: "❌" },
    ABSENT: { bg: "#F3F4F6", color: "#374151", icon: "⚠️" },
  };

  const statusStyle =
    statusColors[statusData.newStatus] || statusColors.SCHEDULED;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: recipientEmail,
    subject: `${statusData.type} Status Update - Schedule Optimizer`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: ${statusStyle.color}; text-align: center;">${statusStyle.icon} ${statusData.type} Status Updated</h2>
        <p>Hi ${statusData.recipientName},</p>
        <p>The status of your ${statusData.type.toLowerCase()} has been updated.</p>

        <div style="background-color: ${statusStyle.bg}; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: ${statusStyle.color};">New Status: ${statusData.newStatus.replace("_", " ")}</h3>
          <p><strong>${statusData.type === "Consultation" ? "Project" : "Session"}:</strong> ${statusData.name}</p>
          <p><strong>Date & Time:</strong> ${formatDateTime(statusData.dateTime)}</p>
        </div>

        ${
          statusData.reason
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Reason:</strong> ${statusData.reason}</p>
        </div>
        `
            : ""
        }

        ${
          statusData.mentorFeedback && statusData.newStatus === "COMPLETED"
            ? `
        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Mentor Feedback:</strong> ${statusData.mentorFeedback}</p>
        </div>
        `
            : ""
        }

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/${statusData.type === "Consultation" ? "projects" : "lab-sessions"}" 
              style="background-color: ${statusStyle.color}; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Details
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #6B7280; font-size: 14px;">
          ${
            statusData.newStatus === "CANCELLED" ||
            statusData.newStatus === "ABSENT"
              ? "If you have any questions about this status change, please contact us."
              : "Thank you for using Schedule Optimizer!"
          }
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(
      `Status change notification (${statusData.newStatus}) sent to:`,
      recipientEmail,
    );
  } catch (error) {
    console.error("Error sending status change notification:", error);
    throw error;
  }
};

// Send notification to member when their consultation mentor is changed by admin
const sendMentorChangedToMember = async (memberEmail, changeData) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Consultation Peer Mentor Updated - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #F59E0B; text-align: center;">Consultation Peer Mentor Changed</h2>
        <p>Hi ${changeData.studentName},</p>
        <p>The peer mentor for your consultation has been changed by the administration team.</p>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">Peer Mentor Change</h3>
          <p><strong>Previous Consultation Peer Mentor:</strong> ${changeData.oldMentorName}</p>
          <p><strong>New Consultation Peer Mentor:</strong> ${changeData.newMentorName}</p>
          <p><strong>New Consultation Peer Mentor Email:</strong> ${changeData.newMentorEmail}</p>
        </div>

        <div style="background-color: #E0E7FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; text-align: center;">
            <strong>Note:</strong> Everything remains the same - only the peer mentor has changed.
          </p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/projects" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View My Projects
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Mentor change notification sent to member:", memberEmail);
  } catch (error) {
    console.error("Error sending mentor change notification to member:", error);
    throw error;
  }
};

// Send notification to member when project is approved
const sendProjectApprovalNotification = async (memberEmail, approvalData) => {
  const equipmentList =
    approvalData.equipment && approvalData.equipment.length > 0
      ? approvalData.equipment.map((e) => e.name).join(", ")
      : "None";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Project Proposal Approved - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">Project Proposal Approved</h2>
        <p>Hi ${approvalData.studentName},</p>
        <p>Your project proposal has been approved by the administration team.</p>

        <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${approvalData.projectName}</p>
          <p><strong>Lab Requested:</strong> ${approvalData.labName}</p>
          <p><strong>Equipment Requested:</strong> ${equipmentList}</p>
        </div>

        ${
          approvalData.comment
            ? `
        <div style="background-color: #E0E7FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Approval Comment:</strong> ${approvalData.comment}</p>
        </div>
        `
            : ""
        }

        ${
          approvalData.bookings && approvalData.bookings.length > 0
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">Lab Sessions Created</h3>
          <p style="margin-bottom: 10px;">The following lab sessions have been created for your project:</p>
          ${approvalData.bookings
            .map(
              (booking, index) => `
            <div style="background-color: white; padding: 12px; border-left: 4px solid #F59E0B; margin-bottom: 10px;">
              <p style="margin: 0; font-weight: bold;">Session ${index + 1}</p>
              <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Date & Time:</strong> ${formatDateTime(booking.startDate)}</p>
              <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Duration:</strong> ${formatDateTime(booking.startDate)} - ${formatDateTime(booking.endDate)}</p>
              <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Lab Peer Mentor:</strong> ${booking.labMentorName || "TBD"}</p>
              <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Location:</strong> ${booking.labLocation}</p>
            </div>
          `,
            )
            .join("")}
        </div>
        `
            : ""
        }

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Next Steps</h3>
          <p>• Review your lab session schedule</p>
          <p>• Prepare necessary materials for your sessions</p>
          <p>• Arrive on time at the scheduled location</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/lab-sessions" 
              style="background-color: #059669; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View Lab Sessions
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Project approval notification sent to:", memberEmail);
  } catch (error) {
    console.error("Error sending project approval notification:", error);
    throw error;
  }
};

// Send notification to member when project is declined
const sendProjectDeclineNotification = async (memberEmail, declineData) => {
  const equipmentList =
    declineData.equipment && declineData.equipment.length > 0
      ? declineData.equipment.map((e) => e.name).join(", ")
      : "None";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: "Project Proposal Declined - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Project Proposal Declined</h2>
        <p>Hi ${declineData.studentName},</p>
        <p>Your project proposal has been reviewed and declined by the administration team.</p>

        <div style="background-color: #F3F4F6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1F2937; text-align: center;">Project Details</h3>
          <p><strong>Project Name:</strong> ${declineData.projectName}</p>
          <p><strong>Lab Requested:</strong> ${declineData.labName}</p>
          <p><strong>Equipment Requested:</strong> ${equipmentList}</p>
        </div>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">Reason for Decline</h3>
          <p style="margin: 0;">${declineData.comment || "No reason provided"}</p>
        </div>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Next Steps</h3>
          <p>• Review the decline reason carefully</p>
          <p>• Make necessary adjustments to your proposal</p>
          <p>• Submit a new project proposal if you wish to proceed</p>
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/projects" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View My Projects
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 14px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Project decline notification sent to:", memberEmail);
  } catch (error) {
    console.error("Error sending project decline notification:", error);
    throw error;
  }
};

const sendBatchLabSessionConfirmation = async (memberEmail, sessionData) => {
  const sessionsHtml = sessionData.sessions
    .map(
      (session, index) => `
    <div style="background-color: white; padding: 12px; border-left: 4px solid #059669; margin-bottom: 10px;">
      <p style="margin: 0; font-weight: bold;">Session ${index + 1}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Date & Time:</strong> ${formatDateTime(session.startDate)}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Duration:</strong> ${formatDateTime(session.startDate)} - ${formatDateTime(session.endDate)}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Lab Peer Mentor:</strong> ${session.labMentorName}</p>
    </div>
  `,
    )
    .join("");

  const equipmentList = sessionData.equipment.map((e) => e.name).join(", ");

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: memberEmail,
    subject: `${sessionData.sessions.length} Lab Sessions Confirmed - Schedule Optimizer`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">${sessionData.sessions.length} Lab Sessions Confirmed</h2>
        <p>Hi ${sessionData.studentName},</p>
        <p>Your lab sessions have been confirmed for project: <strong>${sessionData.projectName}</strong></p>

        <div style="background-color: #D1FAE5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #065F46; text-align: center;">Lab Information</h3>
          <p><strong>Lab Reserved:</strong> ${sessionData.labName}</p>
          <p><strong>Location:</strong> ${sessionData.labLocation}</p>
          ${equipmentList ? `<p><strong>Equipment Reserved:</strong> ${equipmentList}</p>` : ""}
        </div>

        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #92400E; text-align: center;">Your Sessions (${sessionData.sessions.length})</h3>
          ${sessionsHtml}
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/lab-sessions" 
              style="background-color: #059669; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View All Lab Sessions
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  await transporter.sendMail(mailOptions);
  console.log("Batch lab session confirmation sent to:", memberEmail);
};

const sendBatchLabSessionAssignment = async (mentorEmail, sessionData) => {
  const sessionsHtml = sessionData.sessions
    .map(
      (session, index) => `
    <div style="background-color: white; padding: 12px; border-left: 4px solid #4F46E5; margin-bottom: 10px;">
      <p style="margin: 0; font-weight: bold;">Session ${index + 1}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Student:</strong> ${session.studentName}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Project:</strong> ${session.projectName}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Date & Time:</strong> ${formatDateTime(session.startDate)}</p>
      <p style="margin: 5px 0 0 0; font-size: 14px;"><strong>Equipment:</strong> ${session.equipment.map((e) => e.name).join(", ")}</p>
    </div>
  `,
    )
    .join("");

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: mentorEmail,
    subject: `${sessionData.sessions.length} New Lab Session Assignments - Schedule Optimizer`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #4F46E5; text-align: center;">${sessionData.sessions.length} New Lab Session Assignments</h2>
        <p>Hi ${sessionData.labMentorName},</p>
        <p>You have been assigned to supervise ${sessionData.sessions.length} lab sessions.</p>

        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #1E40AF; text-align: center;">Your Assigned Sessions</h3>
          ${sessionsHtml}
        </div>

        <div style="text-align: center; margin: 20px 0;">
          <a href="${FRONTEND_URL}/bookings" 
              style="background-color: #4F46E5; color: white; padding: 12px 30px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            View All Bookings
          </a>
        </div>

        <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
        <p style="color: #9CA3AF; font-size: 12px;">
          This is an automated message. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  await transporter.sendMail(mailOptions);
  console.log("Batch lab session assignment sent to:", mentorEmail);
};

// Send notification when user account is deleted
const sendAccountDeletionNotification = async (email, deletionData) => {
  const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Account Deletion Notice - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Account Deletion Notice</h2>
        
        <p>Dear ${deletionData.name},</p>
        
        <p>Your account has been permanently deleted from the Schedule Optimizer system.</p>
        
        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B;">Account Details</h3>
          <p><strong>Name:</strong> ${deletionData.name}</p>
          <p><strong>Email:</strong> ${deletionData.email}</p>
          <p><strong>Deleted At:</strong> ${formatDateTime(deletionData.deletedAt)}</p>
        </div>
        
        ${
          deletionData.cancelledBookings > 0
            ? `
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Note:</strong> ${deletionData.cancelledBookings} active booking(s) have been cancelled.</p>
        </div>
        `
            : ""
        }
        
        <p>If you believe this was done in error, please contact the administration team immediately.</p>
        
        <p style="margin-top: 30px; color: #6B7280; font-size: 12px;">
          This is an automated message from Schedule Optimizer. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Account deletion notification sent", { email });
  } catch (error) {
    logger.error("Error sending account deletion notification:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

// Send notification when admin cancels member agreement
const sendAgreementCancellationNotification = async (
  email,
  cancellationData,
) => {
  const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Member Agreement Cancelled - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #DC2626; text-align: center;">Member Agreement Cancelled</h2>
        
        <p>Dear ${cancellationData.userName},</p>
        
        <p>Your member agreement has been cancelled by the administration team.</p>
        
        <div style="background-color: #FEE2E2; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #991B1B;">Cancellation Details</h3>
          <p><strong>Cancelled At:</strong> ${formatDateTime(cancellationData.cancelledAt)}</p>
          <p><strong>Cancelled By:</strong> ${cancellationData.cancelledByName}</p>
          ${cancellationData.reason ? `<p><strong>Reason:</strong> ${cancellationData.reason}</p>` : ""}
        </div>
        
        <div style="background-color: #FEF3C7; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Important:</strong> You will need to sign a new member agreement to regain access to lab facilities and resources.</p>
        </div>
        
        <p>To sign a new agreement, please log in to your account:</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${FRONTEND_URL}/login" 
             style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
            Log In to Your Account
          </a>
        </div>
        
        <p>If you have questions about this cancellation, please contact the administration team.</p>
        
        <p style="margin-top: 30px; color: #6B7280; font-size: 12px;">
          This is an automated message from Schedule Optimizer. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Agreement cancellation notification sent", { email });
  } catch (error) {
    logger.error("Error sending agreement cancellation notification:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

// Send confirmation when student deletes their own project
const sendProjectDeletionConfirmation = async (email, deletionData) => {
  const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Project Deletion Confirmation - Schedule Optimizer",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">Project Deleted Successfully</h2>
        
        <p>Hi ${deletionData.studentName},</p>
        
        <p>This confirms that your project has been successfully deleted.</p>
        
        <div style="background-color: #D1FAE5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #065F46;">Deleted Project</h3>
          <p><strong>Project Name:</strong> ${deletionData.projectName}</p>
          <p><strong>Lab:</strong> ${deletionData.labName}</p>
          <p><strong>Deleted At:</strong> ${formatDateTime(deletionData.deletedAt)}</p>
        </div>
        
        ${
          deletionData.freedTimeSlots > 0
            ? `
        <div style="background-color: #DBEAFE; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Note:</strong> ${deletionData.freedTimeSlots} consultation/booking time slot(s) have been released and are now available for other students.</p>
        </div>
        `
            : ""
        }
        
        <p>You can create a new project proposal at any time by logging into your account.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${FRONTEND_URL}/projects" 
             style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
            Create New Project
          </a>
        </div>
        
        <p style="margin-top: 30px; color: #6B7280; font-size: 12px;">
          This is an automated message from Schedule Optimizer. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Project deletion confirmation sent", { email });
  } catch (error) {
    logger.error("Error sending project deletion confirmation:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

// Send welcome email after email verification
const sendWelcomeEmail = async (email, userData) => {
  const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Welcome to Schedule Optimizer! 🎉",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="margin: 15px 0; color: #059669; text-align: center;">Welcome to Schedule Optimizer! 🎉</h2>
        
        <p>Hi ${userData.name},</p>
        
        <p>Your email has been successfully verified! You're all set to start using Schedule Optimizer.</p>
        
        <div style="background-color: #D1FAE5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #065F46;">Next Steps</h3>
          <ul style="margin: 0; padding-left: 20px;">
            <li>Sign the member agreement to gain access to labs</li>
            <li>Create your first project proposal</li>
            <li>Schedule a consultation with a peer mentor</li>
            <li>Book lab equipment and sessions</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${FRONTEND_URL}/login" 
             style="background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
            Log In to Get Started
          </a>
        </div>
        
        <p>If you have any questions or need assistance, don't hesitate to reach out to our team.</p>
        
        <p>Welcome aboard!</p>
        
        <p style="margin-top: 30px; color: #6B7280; font-size: 12px;">
          This is an automated message from Schedule Optimizer. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    logger.info("Welcome email sent", { email });
  } catch (error) {
    logger.error("Error sending welcome email:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

const sendMentorChangeNotification = async (email, data) => {
  const subject = "Consultation Mentor Changed";
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="margin: 15px 0; color: #4F46E5; text-align: center;">Consultation Mentor Changed</h2>
      <p>Hi ${data.studentName},</p>
      <p>The peer mentor for your consultation has been changed.</p>
      
      <div style="background-color: #EEF2FF; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #4F46E5; text-align: center;">Updated Consultation Details</h3>
        <p><strong>Project:</strong> ${data.projectName}</p>
        <p><strong>New Peer Mentor:</strong> ${data.newMentorName}</p>
        <p><strong>Date & Time:</strong> ${data.consultationDate} at ${data.consultationTime}</p>
        <p><strong>Location:</strong> ${data.labName}</p>
      </div>
      
      <p>If you have any questions, please contact us.</p>
      
      <hr style="margin: 20px 0; border: none; border-top: 1px solid #E5E7EB;">
      <p style="color: #6B7280; font-size: 14px;">
        If you have any questions, please contact us at ${process.env.EMAIL_USER}
      </p>
      <p style="color: #9CA3AF; font-size: 12px;">
        This is an automated message. Please do not reply to this email.
      </p>
    </div>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject,
      html,
    });
    logger.info("Mentor change notification sent", { email });
  } catch (error) {
    logger.error("Error sending mentor change notification:", {
      error: error.message,
      email,
    });
    throw error;
  }
};

module.exports = {
  sendVerificationEmail,
  sendEmailChangeConfirmation,
  sendPasswordResetEmail,
  sendProjectProposalConfirmation,
  sendConsultationAssignment,
  sendMentorReplacementNotification,
  sendNewMentorAssignment,
  sendConsultationCancelledProjectDeleted,
  sendMentorChangedToMember,
  sendProjectUpdateNotification,
  sendProjectLabOrTimeChangeOldMentor,
  sendProjectLabOrTimeChangeNewMentor,
  sendMemberConsultationCancellation,
  sendAdminConsultationCancellation,
  sendAdminAbsentNotification,
  sendProjectApprovalNotification,
  sendProjectDeclineNotification,
  sendLabSessionConfirmation,
  sendLabSessionAssignment,
  sendLabSessionUpdate,
  sendLabSessionEquipmentAdjustment,
  sendStatusChangeNotification,
  sendBatchLabSessionConfirmation,
  sendBatchLabSessionAssignment,
  sendAccountDeletionNotification,
  sendAgreementCancellationNotification,
  sendProjectDeletionConfirmation,
  sendWelcomeEmail,
  sendMentorChangeNotification,
};
