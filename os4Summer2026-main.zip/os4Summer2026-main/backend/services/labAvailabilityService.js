const prisma = require("../db/prisma");
const logger = require("../utils/logger");

let isProcessing = false;
let monitorHandle = null;

const processLabAvailabilityTransitions = async () => {
  if (isProcessing) {
    return;
  }
  isProcessing = true;

  try {
    const now = new Date();
    const labsToReactivate = await prisma.lab.findMany({
      where: {
        isActive: false,
        deactivationNever: false,
        unavailableUntil: {
          lte: now,
        },
      },
      select: {
        id: true,
        name: true,
      },
    });

    if (labsToReactivate.length === 0) {
      return;
    }

    const labIds = labsToReactivate.map((lab) => lab.id);

    await prisma.lab.updateMany({
      where: {
        id: { in: labIds },
      },
      data: {
        isActive: true,
        unavailableUntil: null,
        deactivationNever: false,
      },
    });

    logger.info("Auto-reactivated labs after unavailability window", {
      labIds,
      labNames: labsToReactivate.map((lab) => lab.name),
    });
  } catch (error) {
    logger.error("Failed processing lab availability transitions", {
      error: error.message,
      stack: error.stack,
    });
  } finally {
    isProcessing = false;
  }
};

const scheduleLabAvailabilityMonitor = () => {
  if (monitorHandle) {
    return;
  }

  processLabAvailabilityTransitions().catch(() => {});

  monitorHandle = setInterval(() => {
    processLabAvailabilityTransitions().catch(() => {});
  }, 60 * 1000);
};

module.exports = {
  processLabAvailabilityTransitions,
  scheduleLabAvailabilityMonitor,
};
