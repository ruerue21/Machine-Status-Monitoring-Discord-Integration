const {
  sendProjectProposalConfirmation,
  sendConsultationAssignment,
  sendMentorReplacementNotification,
  sendNewMentorAssignment,
  sendConsultationCancelledProjectDeleted,
  sendMentorChangedToMember,
  sendProjectUpdateNotification,
  sendProjectLabOrTimeChangeOldMentor,
  sendProjectLabOrTimeChangeNewMentor,
  sendMemberConsultationCancellation,
  sendAdminConsultationCancellation,
  sendAdminAbsentNotification,
  sendProjectApprovalNotification,
  sendProjectDeclineNotification,
  sendLabSessionConfirmation,
  sendBatchLabSessionConfirmation,
  sendBatchLabSessionAssignment,
  sendLabSessionAssignment,
  sendLabSessionUpdate,
  sendLabSessionEquipmentAdjustment,
  sendStatusChangeNotification,
  sendMentorChangeNotification,
} = require("./emailService");

const prisma = require("../db/prisma");
const logger = require("../utils/logger");

// Add helper functions for date/time formatting
const formatDate = (date) => {
  return new Date(date).toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

const formatTime = (timeString) => {
  const [hours, minutes] = timeString.split(":");
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? "PM" : "AM";
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  return `${displayHour}:${minutes} ${ampm}`;
};

const notifyProjectProposalCreated = async (projectId) => {
  try {
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: true,
        lab: true,
        equipment: { include: { equipment: true } },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: true,
              },
            },
          },
          orderBy: {
            createdAt: "asc",
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0 ||
      !project.user
    ) {
      logger.error(
        "Project or consultation or user not found for notification",
      );
      return;
    }

    // Send email to ALL mentors (not just first one)
    const mentorEmails = [];
    for (const consultation of project.consultations) {
      const mentor = consultation.timeSlot?.mentor;
      if (mentor && mentor.email) {
        try {
          await sendConsultationAssignment(mentor.email, {
            mentorName: mentor.name,
            studentName: project.user.name,
            projectName: project.name,
            projectDescription: project.description,
            consultationDate: formatDate(consultation.timeSlot.date),
            consultationTime: `${formatTime(consultation.timeSlot.startTime)} - ${formatTime(consultation.timeSlot.endTime)}`,
            labName: project.lab.name,
            labLocation: project.lab.location,
          });
          mentorEmails.push(mentor.email);
          logger.info(
            `Consultation assignment email sent to mentor: ${mentor.email}`,
          );
        } catch (error) {
          logger.error(
            `Failed to send email to mentor ${mentor.email}:`,
            error,
          );
        }
      }
    }

    // Send ONE confirmation email to student with ALL consultations listed
    const consultationsList = project.consultations
      .map((consultation, index) => {
        const mentor = consultation.timeSlot?.mentor;
        return `Session ${index + 1}: ${formatDate(consultation.timeSlot.date)} at ${formatTime(consultation.timeSlot.startTime)} - ${formatTime(consultation.timeSlot.endTime)} with ${mentor?.name || "TBD"}`;
      })
      .join("\n");

    await sendProjectProposalConfirmation(project.user.email, {
      studentName: project.user.name,
      projectName: project.name,
      projectDescription: project.description,
      labName: project.lab.name,
      labLocation: project.lab.location,
      consultationsCount: project.consultations.length,
      consultationsList: consultationsList,
      equipmentList: project.equipment
        .map((pe) => pe.equipment.name)
        .join(", "),
    });

    logger.info(
      `Project proposal confirmation sent to student: ${project.user.email}`,
    );
    logger.info(
      `Notified ${mentorEmails.length} mentor(s) for project ${projectId}`,
    );
  } catch (error) {
    logger.error("Error sending project proposal notifications:", error);
  }
};

const notifyConsultationMentorChanged = async (
  consultationId,
  previousMentorId,
  newMentorId,
  changedByUserId,
) => {
  try {
    // Fetch consultation details
    const consultation = await prisma.consultation.findUnique({
      where: { id: consultationId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          include: {
            equipment: {
              include: {
                equipment: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        },
        timeSlot: {
          select: { date: true, startTime: true },
        },
        lab: {
          select: { name: true, location: true },
        },
      },
    });

    if (!consultation) {
      console.error("Consultation not found:", consultationId);
      return;
    }

    // Fetch previous mentor
    const previousMentor = await prisma.user.findUnique({
      where: { id: previousMentorId },
      select: { name: true, email: true },
    });

    // Fetch new mentor
    const newMentor = await prisma.user.findUnique({
      where: { id: newMentorId },
      select: { name: true, email: true },
    });

    // Fetch admin who made the change
    const changedByUser = await prisma.user.findUnique({
      where: { id: changedByUserId },
      select: { name: true, role: true },
    });

    if (!previousMentor || !newMentor || !changedByUser) {
      console.error("Missing user data for mentor change notification");
      return;
    }

    // Prepare data for previous mentor notification
    const replacementData = {
      previousMentorName: previousMentor.name,
      projectName: consultation.project.name,
      studentName: consultation.user.name,
      studentEmail: consultation.user.email,
      consultationDate: consultation.timeSlot.date,
      consultationTime: consultation.timeSlot.startTime,
      newMentorName: newMentor.name,
      newMentorEmail: newMentor.email,
      changedByName: changedByUser.name,
      changedByRole: changedByUser.role,
    };

    // Prepare data for new mentor notification
    const assignmentData = {
      newMentorName: newMentor.name,
      projectName: consultation.project.name,
      description: consultation.project.description,
      studentName: consultation.user.name,
      studentEmail: consultation.user.email,
      consultationDate: consultation.timeSlot.date,
      consultationTime: consultation.timeSlot.startTime,
      labName: consultation.lab.name,
      labLocation: consultation.lab.location,
      equipment: consultation.project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
      })),
    };

    // Prepare data for member notification
    const memberUpdateData = {
      studentName: consultation.user.name,
      projectName: consultation.project.name,
      oldMentorName: previousMentor.name,
      newMentorName: newMentor.name,
      newMentorEmail: newMentor.email,
      consultationDate: consultation.timeSlot.date,
      consultationTime: consultation.timeSlot.startTime,
      labName: consultation.lab.name,
      labLocation: consultation.lab.location,
    };

    // Send emails to all three parties
    await Promise.all([
      sendMentorReplacementNotification(previousMentor.email, replacementData),
      sendNewMentorAssignment(newMentor.email, assignmentData),
      sendMentorChangedToMember(consultation.user.email, memberUpdateData),
    ]);

    console.log(
      `Mentor change notifications sent for consultation #${consultationId} (including member)`,
    );
  } catch (error) {
    console.error("Error sending mentor change notifications:", error);
  }
};

const notifyProjectDeleted = async (projectId) => {
  try {
    // Fetch project details before it's deleted
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0
    ) {
      console.error("Project or consultation not found:", projectId);
      return;
    }

    const mentor = project.consultations[0].timeSlot?.mentor;
    if (!mentor) {
      console.error("Mentor not found for deleted project:", projectId);
      return;
    }

    // Prepare cancellation data
    const cancellationData = {
      mentorName: mentor.name,
      projectName: project.name,
      studentName: project.user.name,
      studentEmail: project.user.email,
      consultationDate: project.consultations[0].timeSlot.date,
      consultationTime: project.consultations[0].timeSlot.startTime,
      labLocation: project.lab.location,
    };

    // Send email to mentor
    await sendConsultationCancelledProjectDeleted(
      mentor.email,
      cancellationData,
    );

    console.log(
      `Project deletion notification sent to mentor for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending project deletion notification:", error);
  }
};

const notifyConsultationStatusChanged = async (
  consultationId,
  newStatus,
  oldStatus = null,
) => {
  try {
    const consultation = await prisma.consultation.findUnique({
      where: { id: consultationId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          select: { name: true },
        },
        timeSlot: {
          include: {
            mentor: {
              select: { name: true, email: true },
            },
          },
        },
      },
    });

    if (!consultation || !consultation.user) {
      console.error("Consultation or user not found:", consultationId);
      return;
    }

    const mentor = consultation.timeSlot?.mentor;

    // Prepare data for member notification
    const memberStatusData = {
      recipientName: consultation.user.name,
      type: "Consultation",
      name: consultation.project.name,
      newStatus: newStatus,
      oldStatus: oldStatus,
      dateTime: consultation.timeSlot?.date,
      reason: consultation.cancelReason || consultation.absentReason || null,
      mentorFeedback: consultation.mentorFeedback || null,
    };

    // Prepare data for mentor notification (if mentor exists)
    const mentorStatusData = mentor
      ? {
          recipientName: mentor.name,
          type: "Consultation",
          name: consultation.project.name,
          newStatus: newStatus,
          oldStatus: oldStatus,
          dateTime: consultation.timeSlot?.date,
          reason:
            consultation.cancelReason || consultation.absentReason || null,
          mentorFeedback: consultation.mentorFeedback || null,
        }
      : null;

    // Send emails
    const emailPromises = [
      sendStatusChangeNotification(consultation.user.email, memberStatusData),
    ];

    if (mentor && mentorStatusData) {
      emailPromises.push(
        sendStatusChangeNotification(mentor.email, mentorStatusData),
      );
    }

    await Promise.all(emailPromises);

    console.log(
      `Status change notifications sent for consultation #${consultationId} (${newStatus})`,
    );
  } catch (error) {
    console.error("Error sending consultation status notifications:", error);
  }
};

const notifyProjectDetailsUpdated = async (projectId, changes) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0
    ) {
      console.error("Project or consultation not found:", projectId);
      return;
    }

    const mentor = project.consultations[0].timeSlot?.mentor;
    if (!mentor) {
      console.error("Mentor not found for project:", projectId);
      return;
    }

    // Prepare update data
    const updateData = {
      mentorName: mentor.name,
      studentName: project.user.name,
      studentEmail: project.user.email,
      projectName: project.name,
      labLocation: project.lab.location,
      consultationDate: project.consultations[0].timeSlot.date,
      consultationTime: project.consultations[0].timeSlot.startTime,
      changes: changes,
    };

    // Send email to mentor
    await sendProjectUpdateNotification(mentor.email, updateData);

    console.log(
      `Project update notification sent to mentor for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending project update notification:", error);
  }
};

const notifyProjectLabOrTimeChanged = async (
  projectId,
  oldConsultationId,
  oldMentorId,
  newMentorId,
  oldLabId,
  newLabId,
  oldTimeSlot,
  newTimeSlot,
) => {
  try {
    // Fetch updated project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { id: true, name: true, location: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { id: true, name: true },
            },
          },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { id: true, name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (!project) {
      console.error("Project not found:", projectId);
      return;
    }

    // Get old mentor details
    const oldMentor = await prisma.user.findUnique({
      where: { id: oldMentorId },
      select: { name: true, email: true },
    });

    // Get old lab details if lab changed
    const oldLab = await prisma.lab.findUnique({
      where: { id: oldLabId },
      select: { name: true },
    });

    if (!oldMentor || !oldLab) {
      console.error("Old mentor or lab not found");
      return;
    }

    // Prepare cancellation data for old mentor
    const cancellationData = {
      mentorName: oldMentor.name,
      projectName: project.name,
      studentName: project.user.name,
      studentEmail: project.user.email,
      oldLabName: oldLab.name,
      newLabName: project.lab.name,
      originalDate: oldTimeSlot.date,
      originalTime: oldTimeSlot.startTime,
      newDate: newTimeSlot.date,
      newTime: newTimeSlot.startTime,
      newMentorName: project.consultations[0].timeSlot.mentor.name,
      newMentorEmail: project.consultations[0].timeSlot.mentor.email,
    };

    // Prepare assignment data for new mentor
    const assignmentData = {
      newMentorName: project.consultations[0].timeSlot.mentor.name,
      studentName: project.user.name,
      studentEmail: project.user.email,
      projectName: project.name,
      description: project.description,
      labName: project.lab.name,
      labLocation: project.lab.location,
      consultationDate: project.consultations[0].timeSlot.date,
      consultationTime: project.consultations[0].timeSlot.startTime,
      equipment: project.equipment.map((pe) => ({
        id: pe.equipment.id,
        name: pe.equipment.name,
      })),
    };

    // Send emails
    await Promise.all([
      sendProjectLabOrTimeChangeOldMentor(oldMentor.email, cancellationData),
      sendProjectLabOrTimeChangeNewMentor(
        project.consultations[0].timeSlot.mentor.email,
        assignmentData,
      ),
    ]);

    console.log(`Lab/time change notifications sent for project #${projectId}`);
  } catch (error) {
    console.error("Error sending lab/time change notifications:", error);
  }
};

const notifyMemberConsultationCancelled = async (projectId, reason) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0
    ) {
      console.error("Project or consultation not found:", projectId);
      return;
    }

    const mentor = project.consultations[0].timeSlot?.mentor;
    if (!mentor) {
      console.error("Mentor not found for project:", projectId);
      return;
    }

    // Prepare cancellation data
    const cancellationData = {
      mentorName: mentor.name,
      projectName: project.name,
      studentName: project.user.name,
      studentEmail: project.user.email,
      consultationDate: project.consultations[0].timeSlot.date,
      consultationTime: project.consultations[0].timeSlot.startTime,
      labLocation: project.lab.location,
      reason: reason || null,
    };

    // Send email to mentor
    await sendMemberConsultationCancellation(mentor.email, cancellationData);

    console.log(
      `Member consultation cancellation sent to mentor for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending member cancellation notification:", error);
  }
};

const notifyAdminConsultationCancelled = async (projectId, reason) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0 ||
      !project.user
    ) {
      console.error("Project, consultation, or user not found:", projectId);
      return;
    }

    // Prepare cancellation data
    const cancellationData = {
      studentName: project.user.name,
      projectName: project.name,
      labName: project.lab.name,
      consultationDate: project.consultations[0].timeSlot?.date || null,
      consultationTime: project.consultations[0].timeSlot?.startTime || null,
      mentorName: project.consultations[0].timeSlot?.mentor?.name || "TBD",
      reason: reason || null,
    };

    // Send email to member
    await sendAdminConsultationCancellation(
      project.user.email,
      cancellationData,
    );

    console.log(
      `Admin consultation cancellation sent to member for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending admin cancellation notification:", error);
  }
};

const notifyAdminNoShow = async (projectId, reason) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        consultations: {
          include: {
            timeSlot: {
              include: {
                mentor: {
                  select: { name: true, email: true },
                },
              },
            },
          },
        },
      },
    });

    if (
      !project ||
      !project.consultations ||
      project.consultations.length === 0 ||
      !project.user
    ) {
      console.error("Project, consultation, or user not found:", projectId);
      return;
    }

    // Prepare absent data
    const absentData = {
      studentName: project.user.name,
      projectName: project.name,
      labName: project.lab.name,
      consultationDate: project.consultations[0].timeSlot?.date || null,
      consultationTime: project.consultations[0].timeSlot?.startTime || null,
      mentorName: project.consultations[0].timeSlot?.mentor?.name || "TBD",
      mentorEmail: project.consultations[0].timeSlot?.mentor?.email || "TBD",
      reason: reason || null,
    };

    // Send email to member
    await sendAdminAbsentNotification(project.user.email, absentData);

    console.log(
      `Admin absent notification sent to member for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending admin absent notification:", error);
  }
};

const notifyLabSessionCreated = async (bookingId) => {
  try {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          select: { name: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { name: true },
            },
          },
        },
        labMentor: {
          select: { name: true, email: true },
        },
      },
    });

    if (!booking || !booking.user) {
      console.error("Booking or user not found:", bookingId);
      return;
    }

    // Prepare data for member confirmation
    const memberEmailData = {
      studentName: booking.user.name,
      projectName: booking.project.name,
      labName: booking.lab.name,
      labLocation: booking.lab.location,
      startDate: booking.startDate,
      endDate: booking.endDate,
      labMentorName: booking.labMentor?.name || "TBD",
      labMentorEmail: booking.labMentor?.email || "",
      equipment: booking.equipment.map((be) => ({
        name: be.equipment.name,
      })),
    };

    // Send member confirmation
    await sendLabSessionConfirmation(booking.user.email, memberEmailData);

    // Send mentor notification if assigned
    if (booking.labMentor) {
      const mentorEmailData = {
        labMentorName: booking.labMentor.name,
        studentName: booking.user.name,
        studentEmail: booking.user.email,
        projectName: booking.project.name,
        labName: booking.lab.name,
        labLocation: booking.lab.location,
        startDate: booking.startDate,
        endDate: booking.endDate,
        equipment: booking.equipment.map((be) => ({
          name: be.equipment.name,
        })),
      };

      await sendLabSessionAssignment(booking.labMentor.email, mentorEmailData);
    }

    console.log(`Lab session notifications sent for booking #${bookingId}`);
  } catch (error) {
    console.error("Error sending lab session notifications:", error);
  }
};

const notifyBatchLabSessionsCreated = async (bookingIds) => {
  try {
    if (bookingIds.length === 0) return;

    // Fetch all bookings
    const bookings = await prisma.booking.findMany({
      where: { id: { in: bookingIds } },
      include: {
        user: { select: { name: true, email: true } },
        project: { select: { name: true } },
        lab: { select: { name: true, location: true } },
        equipment: {
          include: {
            equipment: { select: { name: true } },
          },
        },
        labMentor: { select: { id: true, name: true, email: true } },
      },
    });

    if (bookings.length === 0) return;

    // Group by student (in case multiple students)
    const bookingsByStudent = {};
    bookings.forEach((booking) => {
      if (!booking.user) return;
      if (!bookingsByStudent[booking.user.email]) {
        bookingsByStudent[booking.user.email] = {
          studentName: booking.user.name,
          studentEmail: booking.user.email,
          bookings: [],
        };
      }
      bookingsByStudent[booking.user.email].bookings.push(booking);
    });

    // Send one email per student with all their sessions
    for (const studentData of Object.values(bookingsByStudent)) {
      const sessionData = {
        studentName: studentData.studentName,
        projectName: studentData.bookings[0].project.name,
        labName: studentData.bookings[0].lab.name,
        labLocation: studentData.bookings[0].lab.location,
        sessions: studentData.bookings.map((b) => ({
          startDate: b.startDate,
          endDate: b.endDate,
          labMentorName: b.labMentor?.name || "TBD",
          labMentorEmail: b.labMentor?.email || "",
        })),
        equipment: studentData.bookings[0].equipment.map((be) => ({
          name: be.equipment.name,
        })),
      };

      await sendBatchLabSessionConfirmation(
        studentData.studentEmail,
        sessionData,
      );
    }

    // Group by mentor
    const bookingsByMentor = {};
    bookings.forEach((booking) => {
      if (!booking.labMentor) return;
      if (!bookingsByMentor[booking.labMentor.email]) {
        bookingsByMentor[booking.labMentor.email] = {
          mentorName: booking.labMentor.name,
          mentorEmail: booking.labMentor.email,
          bookings: [],
        };
      }
      bookingsByMentor[booking.labMentor.email].bookings.push(booking);
    });

    // Send one email per mentor with all their sessions
    for (const mentorData of Object.values(bookingsByMentor)) {
      const sessionData = {
        labMentorName: mentorData.mentorName,
        sessions: mentorData.bookings.map((b) => ({
          studentName: b.user?.name || "[Deleted Account]",
          studentEmail: b.user?.email || "",
          projectName: b.project.name,
          labName: b.lab.name,
          labLocation: b.lab.location,
          startDate: b.startDate,
          endDate: b.endDate,
          equipment: b.equipment.map((be) => ({ name: be.equipment.name })),
        })),
      };

      await sendBatchLabSessionAssignment(mentorData.mentorEmail, sessionData);
    }

    console.log(
      `Batch lab session notifications sent for ${bookingIds.length} bookings`,
    );
  } catch (error) {
    console.error("Error sending batch lab session notifications:", error);
  }
};

const notifyLabSessionUpdated = async (bookingId, previousMentorId = null) => {
  try {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          select: { name: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        labMentor: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    if (!booking || !booking.user) {
      console.error("Booking or user not found:", bookingId);
      return;
    }

    // Prepare data for member update notification
    const memberUpdateData = {
      recipientName: booking.user.name,
      projectName: booking.project.name,
      labName: booking.lab.name,
      labLocation: booking.lab.location,
      startDate: booking.startDate,
      labMentorName: booking.labMentor?.name || "TBD",
      labMentorEmail: booking.labMentor?.email || "TBD",
      notes: booking.notes,
      isStudent: true,
    };

    // Send to member
    await sendLabSessionUpdate(booking.user.email, memberUpdateData);

    // Send to current lab mentor if assigned
    if (booking.labMentor) {
      const mentorUpdateData = {
        recipientName: booking.labMentor.name,
        projectName: booking.project.name,
        labName: booking.lab.name,
        labLocation: booking.lab.location,
        startDate: booking.startDate,
        labMentorName: booking.labMentor.name,
        labMentorEmail: booking.labMentor.email,
        notes: booking.notes,
        isStudent: false,
      };

      await sendLabSessionUpdate(booking.labMentor.email, mentorUpdateData);
    }

    // If mentor was changed, notify the previous mentor
    if (
      previousMentorId &&
      booking.labMentor &&
      previousMentorId !== booking.labMentor.id
    ) {
      const previousMentor = await prisma.user.findUnique({
        where: { id: previousMentorId },
        select: { name: true, email: true },
      });

      if (previousMentor) {
        const previousMentorData = {
          recipientName: previousMentor.name,
          projectName: booking.project.name,
          labName: booking.lab.name,
          labLocation: booking.lab.location,
          startDate: booking.startDate,
          labMentorName: booking.labMentor.name,
          labMentorEmail: booking.labMentor.email,
          notes: "You have been replaced as the lab mentor for this session.",
          isStudent: false,
        };

        await sendLabSessionUpdate(previousMentor.email, previousMentorData);
      }
    }

    console.log(
      `Lab session update notifications sent for booking #${bookingId}`,
    );
  } catch (error) {
    console.error("Error sending lab session update notifications:", error);
  }
};

const notifyLabSessionStatusChanged = async (
  bookingId,
  newStatus,
  oldStatus = null,
) => {
  try {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          select: { name: true },
        },
        labMentor: {
          select: { name: true, email: true },
        },
      },
    });

    if (!booking || !booking.user) {
      console.error("Booking or user not found:", bookingId);
      return;
    }

    // Prepare data for member notification
    const memberStatusData = {
      recipientName: booking.user.name,
      type: "Lab Session",
      name: booking.project.name,
      newStatus: newStatus,
      oldStatus: oldStatus,
      dateTime: booking.startDate,
      reason: booking.cancellationReason || null,
      mentorFeedback: booking.notes || null,
    };

    // Send to member
    await sendStatusChangeNotification(booking.user.email, memberStatusData);

    // Send to lab mentor if assigned
    if (booking.labMentor) {
      const mentorStatusData = {
        recipientName: booking.labMentor.name,
        type: "Lab Session",
        name: booking.project.name,
        newStatus: newStatus,
        oldStatus: oldStatus,
        dateTime: booking.startDate,
        reason: booking.cancellationReason || null,
        mentorFeedback: booking.notes || null,
      };

      await sendStatusChangeNotification(
        booking.labMentor.email,
        mentorStatusData,
      );
    }

    console.log(
      `Status change notifications sent for booking #${bookingId} (${newStatus})`,
    );
  } catch (error) {
    console.error("Error sending lab session status notifications:", error);
  }
};

const notifyLabSessionEquipmentAdjusted = async (
  bookingId,
  removedEquipmentName,
  outOfOrderUntil = null,
) => {
  try {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        project: {
          select: { name: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        labMentor: {
          select: { name: true, email: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { name: true },
            },
          },
        },
      },
    });

    if (!booking) {
      console.error("Booking not found for equipment adjustment:", bookingId);
      return;
    }

    const baseData = {
      projectName: booking.project.name,
      labName: booking.lab.name,
      labLocation: booking.lab.location,
      startDate: booking.startDate,
      endDate: booking.endDate,
      removedEquipmentName,
      remainingEquipment: booking.equipment.map((be) => ({
        name: be.equipment.name,
      })),
      outOfOrderUntil,
      labMentorName: booking.labMentor?.name || null,
      labMentorEmail: booking.labMentor?.email || null,
    };

    if (booking.user?.email) {
      await sendLabSessionEquipmentAdjustment(booking.user.email, {
        ...baseData,
        recipientName: booking.user.name,
        isStudent: true,
      });
    }

    if (booking.labMentor?.email) {
      await sendLabSessionEquipmentAdjustment(booking.labMentor.email, {
        ...baseData,
        recipientName: booking.labMentor.name,
        isStudent: false,
      });
    }
  } catch (error) {
    console.error("Error sending equipment adjustment notifications:", error);
  }
};

const notifyProjectApproved = async (projectId, comment, bookings = []) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true, location: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { name: true },
            },
          },
        },
      },
    });

    if (!project || !project.user) {
      console.error("Project or user not found:", projectId);
      return;
    }

    // Format bookings if provided
    const formattedBookings = bookings.map((booking) => ({
      startDate: booking.startDate,
      endDate: booking.endDate,
      labMentorName: booking.labMentor?.name || "TBD",
      labLocation: project.lab.location,
    }));

    // Prepare approval data
    const approvalData = {
      studentName: project.user.name,
      projectName: project.name,
      labName: project.lab.name,
      equipment: project.equipment.map((pe) => ({
        name: pe.equipment.name,
      })),
      comment: comment || null,
      bookings: formattedBookings,
    };

    // Send email to member
    await sendProjectApprovalNotification(project.user.email, approvalData);

    console.log(
      `Project approval notification sent to member for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending project approval notification:", error);
  }
};

const notifyProjectDeclined = async (projectId, comment) => {
  try {
    // Fetch project details
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        user: {
          select: { name: true, email: true },
        },
        lab: {
          select: { name: true },
        },
        equipment: {
          include: {
            equipment: {
              select: { name: true },
            },
          },
        },
      },
    });

    if (!project || !project.user) {
      console.error("Project or user not found:", projectId);
      return;
    }

    // Prepare decline data
    const declineData = {
      studentName: project.user.name,
      projectName: project.name,
      labName: project.lab.name,
      equipment: project.equipment.map((pe) => ({
        name: pe.equipment.name,
      })),
      comment: comment, // Required for decline
    };

    // Send email to member
    await sendProjectDeclineNotification(project.user.email, declineData);

    console.log(
      `Project decline notification sent to member for project #${projectId}`,
    );
  } catch (error) {
    console.error("Error sending project decline notification:", error);
  }
};

const notifyMentorChanged = async (projectId, consultationId, mentorInfo) => {
  try {
    const consultation = await prisma.consultation.findUnique({
      where: { id: consultationId },
      include: {
        project: {
          include: {
            user: true,
            lab: true,
          },
        },
        timeSlot: {
          include: {
            mentor: true,
          },
        },
      },
    });

    if (!consultation) {
      console.error("Consultation not found for mentor change notification");
      return;
    }

    // Notify student
    await sendMentorChangeNotification(consultation.project.user.email, {
      studentName: consultation.project.user.name,
      projectName: consultation.project.name,
      newMentorName: consultation.timeSlot.mentor.name,
      consultationDate: formatDate(consultation.timeSlot.date),
      consultationTime: `${formatTime(consultation.timeSlot.startTime)} - ${formatTime(consultation.timeSlot.endTime)}`,
      labName: consultation.project.lab.name,
    });

    // Notify new mentor
    await sendConsultationAssignment(consultation.timeSlot.mentor.email, {
      mentorName: consultation.timeSlot.mentor.name,
      studentName: consultation.project.user.name,
      projectName: consultation.project.name,
      projectDescription: consultation.project.description,
      consultationDate: formatDate(consultation.timeSlot.date),
      consultationTime: `${formatTime(consultation.timeSlot.startTime)} - ${formatTime(consultation.timeSlot.endTime)}`,
      labName: consultation.project.lab.name,
      labLocation: consultation.project.lab.location,
    });

    console.log(
      `Mentor change notifications sent for consultation ${consultationId}`,
    );
  } catch (error) {
    console.error("Error sending mentor change notifications:", error);
  }
};

const notifyConsultationCancelled = async (projectId, consultationId) => {
  try {
    const consultation = await prisma.consultation.findUnique({
      where: { id: consultationId },
      include: {
        project: {
          include: {
            user: true,
            lab: true,
          },
        },
        timeSlot: {
          include: {
            mentor: true,
          },
        },
      },
    });

    if (!consultation) {
      logger.error(
        `Consultation ${consultationId} not found for cancellation notification`,
      );
      return;
    }

    const { project, timeSlot } = consultation;

    // Notify student
    if (project.user) {
      await sendMemberConsultationCancellation(project.user.email, {
        studentName: project.user.name,
        projectName: project.name,
        consultationDate: timeSlot ? formatDate(timeSlot.date) : "TBD",
        consultationTime: timeSlot
          ? `${formatTime(timeSlot.startTime)} - ${formatTime(timeSlot.endTime)}`
          : "TBD",
        labName: project.lab.name,
        labLocation: project.lab.location,
        reason: consultation.cancelReason || "No reason provided",
      });

      logger.info(
        `Consultation cancellation email sent to student: ${project.user.email}`,
      );
    }

    // Notify mentor if assigned
    if (timeSlot && timeSlot.mentor) {
      await sendAdminConsultationCancellation(timeSlot.mentor.email, {
        mentorName: timeSlot.mentor.name,
        projectName: project.name,
        studentName: project.user.name,
        consultationDate: formatDate(timeSlot.date),
        consultationTime: `${formatTime(timeSlot.startTime)} - ${formatTime(timeSlot.endTime)}`,
        labName: project.lab.name,
        reason: consultation.cancelReason || "No reason provided",
      });

      logger.info(
        `Consultation cancellation email sent to mentor: ${timeSlot.mentor.email}`,
      );
    }

    logger.info(
      `Consultation cancellation notifications sent for consultation ${consultationId}`,
    );
  } catch (error) {
    logger.error(
      "Error sending consultation cancellation notifications:",
      error,
    );
  }
};

/**
 * Notify when a specific consultation is marked absent (NEW - for multi-consultation system)
 */
const notifyConsultationAbsent = async (projectId, consultationId) => {
  try {
    const consultation = await prisma.consultation.findUnique({
      where: { id: consultationId },
      include: {
        project: {
          include: {
            user: true,
            lab: true,
          },
        },
        timeSlot: {
          include: {
            mentor: true,
          },
        },
      },
    });

    if (!consultation) {
      logger.error(
        `Consultation ${consultationId} not found for absent notification`,
      );
      return;
    }

    const { project, timeSlot } = consultation;

    // Notify student
    if (project.user) {
      await sendAdminAbsentNotification(project.user.email, {
        studentName: project.user.name,
        projectName: project.name,
        consultationDate: timeSlot ? formatDate(timeSlot.date) : "TBD",
        consultationTime: timeSlot
          ? `${formatTime(timeSlot.startTime)} - ${formatTime(timeSlot.endTime)}`
          : "TBD",
        labName: project.lab.name,
        reason: consultation.absentReason || "No reason provided",
      });

      logger.info(
        `Consultation absent email sent to student: ${project.user.email}`,
      );
    }

    logger.info(
      `Consultation absent notifications sent for consultation ${consultationId}`,
    );
  } catch (error) {
    logger.error("Error sending consultation absent notifications:", error);
  }
};

module.exports = {
  notifyProjectProposalCreated,
  notifyConsultationMentorChanged,
  notifyConsultationStatusChanged,
  notifyProjectDeleted,
  notifyProjectDetailsUpdated,
  notifyProjectLabOrTimeChanged,
  notifyMemberConsultationCancelled,
  notifyAdminConsultationCancelled,
  notifyAdminNoShow,
  notifyProjectApproved,
  notifyProjectDeclined,
  notifyLabSessionCreated,
  notifyBatchLabSessionsCreated,
  notifyLabSessionUpdated,
  notifyLabSessionStatusChanged,
  notifyLabSessionEquipmentAdjusted,
  notifyMentorChanged,
  notifyConsultationCancelled,
  notifyConsultationAbsent,
};
