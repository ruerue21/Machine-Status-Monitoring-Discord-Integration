import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import EmailVerification from "./pages/EmailVerification";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import Profile from "./pages/Profile";
import AdminReview from "./pages/AdminReview";
import MemberAgreement from "./pages/MemberAgreement";
import UserManagement from "./pages/UserManagement";
import PeerMentorSchedule from "./pages/PeerMentorSchedule";
import Bookings from "./pages/Bookings";
import LabSessions from "./pages/LabSessions";
import ProtectedRoute from "./components/ProtectedRoute";
import SupervisorSchedule from "./pages/SupervisorSchedule";
import LabManagement from "./pages/LabManagement";
import LabAgreements from "./pages/LabAgreements";
import Archive from "./pages/Archive";
import AdminCalendar from "./pages/AdminCalendar";
import MySchedule from "./pages/MySchedule";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/verify-email" element={<EmailVerification />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/projects"
          element={
            <ProtectedRoute>
              <Projects />
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin-review"
          element={
            <ProtectedRoute>
              <AdminReview />
            </ProtectedRoute>
          }
        />
        <Route
          path="/member-agreement"
          element={
            <ProtectedRoute>
              <MemberAgreement />
            </ProtectedRoute>
          }
        />
        <Route
          path="/user-management"
          element={
            <ProtectedRoute>
              <UserManagement />
            </ProtectedRoute>
          }
        />
        <Route
          path="/schedule-management"
          element={
            <ProtectedRoute>
              <PeerMentorSchedule mentorType="CONSULTATION" />
            </ProtectedRoute>
          }
        />
        <Route
          path="/bookings"
          element={
            <ProtectedRoute>
              <Bookings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/lab-peer-mentor-schedule"
          element={
            <ProtectedRoute>
              <PeerMentorSchedule mentorType="LAB" />
            </ProtectedRoute>
          }
        />
        <Route
          path="/lab-sessions"
          element={
            <ProtectedRoute>
              <LabSessions />
            </ProtectedRoute>
          }
        />
        <Route
          path="/supervisor-schedule"
          element={
            <ProtectedRoute>
              <SupervisorSchedule />
            </ProtectedRoute>
          }
        />
        <Route
          path="/lab-management"
          element={
            <ProtectedRoute>
              <LabManagement />
            </ProtectedRoute>
          }
        />
        <Route
          path="/lab-agreements"
          element={
            <ProtectedRoute>
              <LabAgreements />
            </ProtectedRoute>
          }
        />
        <Route
          path="/archive"
          element={
            <ProtectedRoute>
              <Archive />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin-calendar"
          element={
            <ProtectedRoute>
              <AdminCalendar />
            </ProtectedRoute>
          }
        />
        <Route
          path="/my-schedule"
          element={
            <ProtectedRoute>
              <MySchedule />
            </ProtectedRoute>
          }
        />
        <Route path="/" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
