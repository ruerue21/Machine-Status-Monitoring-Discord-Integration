import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { getUserFromToken, removeToken, isEmployee } from "../services/auth";
import { authAPI } from "../services/api";
import SessionTimeoutWarning from "./SessionTimeoutWarning";
import { DISCORD_LINKS } from "../config/discordLinks";

const STAFF_PAGES = [
  "admin-review",
  "bookings",
  "user-management",
  "lab-management",
  "schedule-management",
  "lab-peer-mentor-schedule",
  "supervisor-schedule",
  "my-schedule",
  "archive",
  "calendar",
];

const MEMBER_PAGES = [
  "member-agreement",
  "lab-agreements",
  "projects",
  "lab-sessions",
];

const STAFF_LINKS = [
  { to: "/admin-review", label: "Review Projects", adminOnly: false },
  { to: "/bookings", label: "Manage Bookings", adminOnly: false },
  { to: "/user-management", label: "User Management", adminOnly: true },
  { to: "/lab-management", label: "Lab Management", adminOnly: true },
  {
    to: "/schedule-management",
    label: "Consultation Peer Mentor Schedule",
    adminOnly: true,
  },
  {
    to: "/lab-peer-mentor-schedule",
    label: "Lab Peer Mentor Schedule",
    adminOnly: true,
  },
  { to: "/supervisor-schedule", label: "Supervisor Schedule", adminOnly: true },
  {
    to: "/my-schedule",
    label: "My Work Schedule",
    adminOnly: false,
    roles: ["SUPERVISOR", "PEER_MENTOR"],
  },
  { to: "/admin-calendar", label: "Calendar", adminOnly: false },
  { to: "/archive", label: "Archive", adminOnly: true },
];

const MEMBER_LINKS = [
  { to: "/member-agreement", label: "Member Agreement" },
  { to: "/lab-agreements", label: "Lab Agreements" },
  { to: "/projects", label: "My Projects" },
  { to: "/lab-sessions", label: "My Lab Sessions" },
];

function Navbar({ activePage = "" }) {
  const navigate = useNavigate();
  const user = getUserFromToken();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openMenu, setOpenMenu] = useState(null);

  const handleLogout = async () => {
    try {
      await authAPI.logout();
    } catch (error) {
      // Best-effort logout: clear local session state regardless of API errors
    }
    removeToken();
    navigate("/login");
  };

  const handleNavClick = () => {
    setMobileOpen(false);
    setOpenMenu(null);
  };

  const resolvedActive = STAFF_PAGES.includes(activePage)
    ? "staff"
    : MEMBER_PAGES.includes(activePage)
      ? "member"
      : activePage;

  const activeClass =
    "text-indigo-600 px-3 py-2 text-sm font-medium border-b-2 border-indigo-600";
  const inactiveClass =
    "text-gray-700 hover:text-indigo-600 px-3 py-2 text-sm font-medium";

  const topLinkClass = (isActive) => (isActive ? activeClass : inactiveClass);

  const toggleMenu = (menuName) => {
    setOpenMenu((current) => (current === menuName ? null : menuName));
  };

  const canSeeStaffLink = (link) => {
    if (link.adminOnly && user?.role !== "ADMIN") {
      return false;
    }
    if (Array.isArray(link.roles) && !link.roles.includes(user?.role)) {
      return false;
    }
    return true;
  };

  return (
    <>
      <SessionTimeoutWarning />

      <nav className="bg-white shadow" aria-label="Primary navigation">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-4 md:gap-8">
              <h1 className="text-lg md:text-xl font-semibold">
                Schedule Optimizer
              </h1>

              <div className="hidden md:flex items-center gap-2">
                <Link
                  to="/dashboard"
                  onClick={handleNavClick}
                  className={topLinkClass(resolvedActive === "dashboard")}
                >
                  Dashboard
                </Link>

                {isEmployee(user) && (
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => toggleMenu("staff")}
                      className={`${topLinkClass(resolvedActive === "staff")} flex items-center`}
                      aria-haspopup="menu"
                      aria-expanded={openMenu === "staff"}
                    >
                      Staff Menu
                    </button>
                    {openMenu === "staff" && (
                      <div className="absolute left-0 mt-2 w-64 bg-white rounded-md shadow-lg z-20 border border-gray-100 py-1">
                        {STAFF_LINKS.filter(canSeeStaffLink).map((link) => (
                          <Link
                            key={link.to}
                            to={link.to}
                            onClick={handleNavClick}
                            className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600"
                          >
                            {link.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => toggleMenu("member")}
                    className={`${topLinkClass(resolvedActive === "member")} flex items-center`}
                    aria-haspopup="menu"
                    aria-expanded={openMenu === "member"}
                  >
                    Member Menu
                  </button>
                  {openMenu === "member" && (
                    <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg z-20 border border-gray-100 py-1">
                      {MEMBER_LINKS.map((link) => (
                        <Link
                          key={link.to}
                          to={link.to}
                          onClick={handleNavClick}
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600"
                        >
                          {link.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => toggleMenu("discord")}
                    className={`${inactiveClass} flex items-center`}
                    aria-haspopup="menu"
                    aria-expanded={openMenu === "discord"}
                  >
                    Discord
                  </button>
                  {openMenu === "discord" && (
                    <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg z-20 border border-gray-100 py-1">
                      {DISCORD_LINKS.map((link) => (
                        <a
                          key={link.label}
                          href={link.url}
                          target="_blank"
                          rel="noreferrer"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600"
                          onClick={handleNavClick}
                        >
                          {link.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>

                <Link
                  to="/profile"
                  onClick={handleNavClick}
                  className={topLinkClass(resolvedActive === "profile")}
                >
                  Profile
                </Link>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <span className="text-gray-700">
                Welcome, {user?.name || "User"}
              </span>
              <span className="text-sm text-gray-500">
                ({user?.role || "MEMBER"})
              </span>
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Logout
              </button>
            </div>

            <button
              type="button"
              className="md:hidden inline-flex items-center justify-center rounded-md p-2 text-gray-700 hover:bg-gray-100"
              onClick={() => setMobileOpen((open) => !open)}
              aria-expanded={mobileOpen}
              aria-controls="mobile-menu"
            >
              <span className="sr-only">Open main menu</span>
              <svg
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                {mobileOpen ? (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                ) : (
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                )}
              </svg>
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div
            id="mobile-menu"
            className="md:hidden border-t border-gray-200 px-4 pb-4"
          >
            <div className="pt-3 space-y-1">
              <Link
                to="/dashboard"
                className="block px-2 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600"
                onClick={handleNavClick}
              >
                Dashboard
              </Link>

              {isEmployee(user) && (
                <>
                  <p className="px-2 pt-3 text-xs font-semibold text-gray-500 uppercase">
                    Staff
                  </p>
                  {STAFF_LINKS.filter(canSeeStaffLink).map((link) => (
                    <Link
                      key={link.to}
                      to={link.to}
                      className="block px-2 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600"
                      onClick={handleNavClick}
                    >
                      {link.label}
                    </Link>
                  ))}
                </>
              )}

              <p className="px-2 pt-3 text-xs font-semibold text-gray-500 uppercase">
                Member
              </p>
              {MEMBER_LINKS.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="block px-2 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600"
                  onClick={handleNavClick}
                >
                  {link.label}
                </Link>
              ))}

              <p className="px-2 pt-3 text-xs font-semibold text-gray-500 uppercase">
                Discord
              </p>
              {DISCORD_LINKS.map((link) => (
                <a
                  key={link.label}
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                  className="block px-2 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600"
                  onClick={handleNavClick}
                >
                  {link.label}
                </a>
              ))}

              <Link
                to="/profile"
                className="block px-2 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600"
                onClick={handleNavClick}
              >
                Profile
              </Link>

              <div className="pt-3 border-t border-gray-200 mt-3">
                <p className="px-2 text-sm text-gray-700">
                  {user?.name || "User"}
                </p>
                <p className="px-2 text-xs text-gray-500 mb-2">
                  {user?.role || "MEMBER"}
                </p>
                <button
                  onClick={handleLogout}
                  className="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}

export default Navbar;
