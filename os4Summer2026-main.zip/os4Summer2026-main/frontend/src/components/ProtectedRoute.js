import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { authAPI } from "../services/api";
import { isRemembered, isTokenValid, setSession } from "../services/auth";
import Spinner from "./Spinner";

function ProtectedRoute({ children }) {
  const [loading, setLoading] = useState(!isTokenValid());
  const [authorized, setAuthorized] = useState(isTokenValid());

  useEffect(() => {
    if (authorized) {
      return;
    }

    let active = true;

    const bootstrapFromCookieSession = async () => {
      try {
        const response = await authAPI.getMe();
        if (!active) return;

        const { user, exp } = response.data || {};
        if (user && exp) {
          setSession(user, exp, isRemembered());
          setAuthorized(true);
        } else {
          setAuthorized(false);
        }
      } catch (error) {
        if (active) {
          setAuthorized(false);
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    bootstrapFromCookieSession();

    return () => {
      active = false;
    };
  }, [authorized]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Spinner size="xl" />
      </div>
    );
  }

  if (!authorized) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

export default ProtectedRoute;
