import { getFileIcon } from "../services/utils";
import { getAgreementFileDownloadUrl } from "../services/api";
import Spinner from "./Spinner";

function LabAgreementModal({
  labId,
  labName,
  labLocation,
  files = [],
  isSigned = false,
  signedAt,
  nextBooking,
  isUrgent = false,
  signing = false,
  onSign,
  onClose,
}) {
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-10 mx-auto p-6 border w-full max-w-2xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
        <div className="mt-3">
          {/* Header */}
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-lg font-medium text-gray-900">
                {isSigned ? "Lab Agreement" : "Lab Agreement Required"}
                {labName && ` – ${labName}`}
              </h3>
              {labLocation && (
                <p className="text-sm text-gray-600 mt-1">{labLocation}</p>
              )}
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
              disabled={signing}
            >
              ✕
            </button>
          </div>

          {/* Status Banner */}
          {isSigned ? (
            <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800">
                You have signed this lab agreement.
              </p>
              {signedAt && (
                <p className="text-xs text-green-700 mt-1">
                  Signed on {new Date(signedAt).toLocaleDateString()}
                </p>
              )}
            </div>
          ) : isUrgent ? (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">
                <strong>Action Required:</strong> You must review and sign this
                lab agreement before you can use this lab's equipment.
              </p>
              {nextBooking && (
                <p className="text-sm text-red-700 mt-2">
                  Your next scheduled session is on{" "}
                  <strong>{new Date(nextBooking).toLocaleDateString()}</strong>.
                  Please sign before then to avoid issues.
                </p>
              )}
            </div>
          ) : (
            <div className="mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                You must review and sign this agreement before using this lab's
                equipment.
              </p>
            </div>
          )}

          {/* Agreement Files */}
          <div className="mb-6">
            <h4 className="text-md font-medium text-gray-900 mb-3">
              Agreement Documents ({files.length})
            </h4>

            {files.length === 0 ? (
              <p className="text-sm text-gray-500 italic text-center py-4">
                {signing
                  ? "Loading agreement files..."
                  : "No agreement files available"}
              </p>
            ) : (
              <div className="space-y-2">
                {files.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">
                        {getFileIcon(file.fileType)}
                      </span>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {file.fileName}
                        </p>
                        <p className="text-xs text-gray-500">
                          Uploaded{" "}
                          {new Date(file.uploadedAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <a
                      href={getAgreementFileDownloadUrl(labId, file.id)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 text-xs border border-blue-300 text-blue-700 rounded hover:bg-blue-50"
                    >
                      View
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sign confirmation text – only when not yet signed */}
          {!isSigned && (
            <div className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <p className="text-sm text-gray-700">
                By clicking "Sign Agreement" below, I confirm that I have read,
                understood, and agree to comply with all terms and conditions
                outlined in the lab agreement documents.
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-3">
            {!isSigned ? (
              <>
                <button
                  onClick={onSign}
                  disabled={signing || files.length === 0}
                  className={`flex-1 px-4 py-2 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed ${
                    isUrgent
                      ? "bg-red-600 hover:bg-red-700"
                      : "bg-indigo-600 hover:bg-indigo-700"
                  }`}
                >
                  {signing ? (
                    <div className="flex items-center justify-center">
                      <Spinner
                        size="sm"
                        color="border-white"
                        className="mr-2"
                      />
                      Signing...
                    </div>
                  ) : (
                    "Sign Agreement"
                  )}
                </button>
                <button
                  onClick={onClose}
                  disabled={signing}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={onClose}
                className="w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
              >
                Close
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default LabAgreementModal;
