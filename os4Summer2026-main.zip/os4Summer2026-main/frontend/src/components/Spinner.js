const sizes = {
  sm: "h-4 w-4",
  md: "h-6 w-6",
  lg: "h-8 w-8",
  xl: "h-12 w-12",
};

export default function Spinner({
  size = "lg",
  color = "border-indigo-600",
  className = "",
}) {
  return (
    <div
      className={`animate-spin rounded-full border-b-2 ${sizes[size]} ${color} ${className}`}
    ></div>
  );
}
