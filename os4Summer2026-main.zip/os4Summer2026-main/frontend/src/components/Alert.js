const styles = {
  default: {
    error: "mb-6 p-4 bg-red-50 border border-red-200 rounded-md",
    success: "mb-6 p-4 bg-green-50 border border-green-200 rounded-md",
  },
  auth: {
    error: "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded",
    success:
      "bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded",
  },
};

const textColor = {
  default: { error: "text-sm text-red-600", success: "text-sm text-green-600" },
};

export default function Alert({ type, variant = "default", children }) {
  return (
    <div className={styles[variant][type]}>
      {variant === "default" ? (
        <p className={textColor.default[type]}>{children}</p>
      ) : (
        children
      )}
    </div>
  );
}
