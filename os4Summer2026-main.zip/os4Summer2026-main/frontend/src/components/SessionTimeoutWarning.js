import { useState, useEffect, useCallback } from "react";
import { getUserFromToken, removeToken, isTokenValid } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { authAPI } from "../services/api";

function SessionTimeoutWarning() {
  const [showWarning, setShowWarning] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ minutes: 0, seconds: 0 });
  const navigate = useNavigate();

  const handleLogout = useCallback(async () => {
    try {
      await authAPI.logout();
    } catch (error) {
      // Best-effort logout
    }
    removeToken();
    setShowWarning(false);
    setDismissed(false);
    navigate("/login");
  }, [navigate]);

  useEffect(() => {
    const checkTokenExpiration = () => {
      const user = getUserFromToken();
      if (!user || !isTokenValid()) {
        // Token has expired or is invalid
        handleLogout();
        return;
      }

      const expirationTime = user.exp * 1000; // Convert to milliseconds
      const currentTime = Date.now();
      const timeUntilExpiration = expirationTime - currentTime;

      // Show warning 5 minutes before expiration
      const warningTime = 5 * 60 * 1000; // 5 minutes in milliseconds

      if (timeUntilExpiration <= warningTime && timeUntilExpiration > 0) {
        setShowWarning(!dismissed);
        // Calculate minutes and seconds
        const totalSeconds = Math.ceil(timeUntilExpiration / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        setTimeLeft({ minutes, seconds });
      } else if (timeUntilExpiration <= 0) {
        // Token has expired
        handleLogout();
      } else {
        setShowWarning(false);
        setDismissed(false);
      }
    };

    // Check immediately
    checkTokenExpiration();

    // Check every 1 second for real time countdown
    const interval = setInterval(checkTokenExpiration, 1000);

    return () => clearInterval(interval);
  }, [dismissed, handleLogout]);

  const handleDismiss = () => {
    setShowWarning(false);
    setDismissed(true);
  };

  const formatTimeLeft = () => {
    if (timeLeft.minutes > 0) {
      return `${timeLeft.minutes}m ${timeLeft.seconds}s`;
    } else {
      return `${timeLeft.seconds}s`;
    }
  };

  if (!showWarning) return null;

  return (
    <div className="fixed top-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded shadow-lg z-50 max-w-sm">
      <div className="flex">
        <div className="ml-3">
          <h3 className="text-sm font-medium text-red-800">
            Session Expiring Soon
          </h3>
          <p className="text-xs mt-1">
            Your session will expire in {formatTimeLeft()}. You'll be
            automatically logged out.
          </p>
          <div className="mt-3 flex space-x-2">
            <button
              onClick={handleDismiss}
              className="text-xs bg-red-200 hover:bg-red-300 text-red-800 px-2 py-1 rounded"
            >
              Dismiss
            </button>
            <button
              onClick={handleLogout}
              className="text-xs bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded"
            >
              Logout Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SessionTimeoutWarning;
