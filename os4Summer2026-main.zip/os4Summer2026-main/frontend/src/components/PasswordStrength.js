function PasswordStrength({ password }) {
  const getPasswordStrength = (password) => {
    let score = 0;
    let feedback = [];

    // Check length first - this is mandatory for any score
    const hasMinLength = password.length >= 8;
    if (!hasMinLength) {
      feedback.push('At least 8 characters');
    }

    // Only give points for character types if minimum length is met
    if (hasMinLength) {
      if (/[a-z]/.test(password)) {
        score += 1;
      } else {
        feedback.push('Include lowercase letters');
      }

      if (/[A-Z]/.test(password)) {
        score += 1;
      } else {
        feedback.push('Include uppercase letters');
      }

      if (/[0-9]/.test(password)) {
        score += 1;
      } else {
        feedback.push('Include numbers');
      }

      if (/[^A-Za-z0-9]/.test(password)) {
        score += 1;
      } else {
        feedback.push('Include special characters');
      }
    } else {
      // If password is too short, add all other feedback
      if (!/[a-z]/.test(password)) feedback.push('Include lowercase letters');
      if (!/[A-Z]/.test(password)) feedback.push('Include uppercase letters');
      if (!/[0-9]/.test(password)) feedback.push('Include numbers');
      if (!/[^A-Za-z0-9]/.test(password)) feedback.push('Include special characters');
    }

    const strength = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'][score];
    const colorClass = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-blue-500', 'bg-green-500'][score];
    const textClass = ['text-red-500', 'text-orange-500', 'text-yellow-500', 'text-blue-500', 'text-green-500'][score];

    return { score, strength, colorClass, textClass, feedback };
  };

  if (!password) return null;

  const { score, strength, colorClass, textClass, feedback } = getPasswordStrength(password);

  return (
    <div className="mt-2">
      <div className="flex items-center space-x-2">
        <div className="flex-1 bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full ${colorClass} transition-all duration-300`}
            style={{ width: `${Math.max((score / 4) * 100, 12.5)}%` }}
          />
        </div>
        <span className={`text-xs font-medium ${textClass}`}>
          {strength}
        </span>
      </div>
      {feedback.length > 0 && (
        <ul className="mt-1 text-xs text-gray-600 list-disc list-inside">
          {feedback.slice(0, 4).map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default PasswordStrength;