import { useState, useEffect } from "react";
import { labAPI, projectAPI, labAgreementAPI } from "../services/api";
import { formatTime } from "../services/utils";
import LabAgreementModal from "./LabAgreementModal";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";

const mapProjectConsultationsForEdit = (project) => {
  if (!project) return [];

  const source =
    Array.isArray(project.consultations) && project.consultations.length
      ? project.consultations
      : project.consultation
        ? [project.consultation]
        : [];

  return source
    .filter(
      (consultation) =>
        consultation?.status === "SCHEDULED" &&
        consultation?.timeSlot?.id &&
        consultation?.date &&
        consultation?.startTime &&
        consultation?.endTime,
    )
    .map((consultation) => ({
      date: new Date(consultation.date).toISOString().split("T")[0],
      timeSlotId: consultation.timeSlot.id.toString(),
      timeSlotDetails: {
        id: consultation.timeSlot.id,
        startTime: consultation.startTime,
        endTime: consultation.endTime,
        mentor: consultation.mentor ? { name: consultation.mentor } : null,
        isCurrentSlot: true,
      },
    }));
};

function ProjectForm({ onSuccess, onCancel, editProject = null }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    labId: "",
    equipmentIds: [],
  });

  // State for managing multiple consultations
  const [selectedConsultations, setSelectedConsultations] = useState([]);
  const [currentConsultation, setCurrentConsultation] = useState({
    date: "",
    timeSlotId: "",
  });

  const [labs, setLabs] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [timeSlots, setTimeSlots] = useState([]);

  const [loading, setLoading] = useState(false);
  const [labsLoading, setLabsLoading] = useState(true);
  const [equipmentLoading, setEquipmentLoading] = useState(false);
  const [timeSlotsLoading, setTimeSlotsLoading] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Lab Agreement states
  const [labAgreementStatus, setLabAgreementStatus] = useState(null);
  const [checkingAgreement, setCheckingAgreement] = useState(false);
  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [agreementFiles, setAgreementFiles] = useState([]);
  const [signingAgreement, setSigningAgreement] = useState(false);

  const [rescheduleInfo, setRescheduleInfo] = useState(null);

  const isEditing = editProject !== null;

  // Load initial data
  useEffect(() => {
    loadLabs();

    // Check for reschedule data from sessionStorage
    const stored = sessionStorage.getItem("rescheduleData");
    if (stored && !isEditing) {
      try {
        const data = JSON.parse(stored);
        setRescheduleInfo(data);
        setFormData((prev) => ({
          ...prev,
          name: data.name,
          description: data.description,
          labId: data.labId.toString(),
          equipmentIds: data.equipmentIds.map((id) => id.toString()),
        }));
        setSuccess(
          "Form pre-filled with your previous project details. Please select a new consultation time.",
        );
        setTimeout(() => setSuccess(""), 5000);
      } catch (err) {
        console.error("Error loading reschedule data:", err);
      }
    }
  }, [isEditing]);

  // Load edit project data
  useEffect(() => {
    if (isEditing && editProject) {
      setFormData({
        name: editProject.name || "",
        description: editProject.description || "",
        labId: editProject.lab?.id?.toString() || "",
        equipmentIds: editProject.equipment?.map((e) => e.id.toString()) || [],
      });
      setSelectedConsultations(mapProjectConsultationsForEdit(editProject));
    }
  }, [editProject, isEditing]);

  // Check lab agreement when lab changes
  useEffect(() => {
    if (formData.labId) {
      checkLabAgreement(formData.labId);
      loadEquipment(formData.labId);
    } else {
      setLabAgreementStatus(null);
      setEquipment([]);
      setTimeSlots([]);
      if (!isEditing) {
        setFormData((prev) => ({
          ...prev,
          equipmentIds: [],
        }));
      }
    }
  }, [formData.labId, isEditing]);

  // Load time slots when lab and date change
  useEffect(() => {
    if (formData.labId && currentConsultation.date) {
      loadTimeSlots(formData.labId, currentConsultation.date);
    } else {
      setTimeSlots([]);
      setCurrentConsultation((prev) => ({ ...prev, timeSlotId: "" }));
    }
  }, [formData.labId, currentConsultation.date]);

  // Clear reschedule data if user opens form manually (not from reschedule button)
  useEffect(() => {
    // Only clear if we're not editing and there's no reschedule info loaded
    if (!isEditing && !rescheduleInfo) {
      const stored = sessionStorage.getItem("rescheduleData");
      if (stored) {
        // If there's reschedule data but we haven't loaded it, user opened form manually
        // Check if form is empty (user just opened create form)
        if (!formData.name && !formData.description && !formData.labId) {
          sessionStorage.removeItem("rescheduleData");
          console.log(
            "Cleared reschedule data - user opened create form manually",
          );
        }
      }
    }
  }, []);

  const loadLabs = async () => {
    try {
      setLabsLoading(true);
      const response = await labAPI.getAllLabs();
      setLabs(response.data.labs);
    } catch (err) {
      setError("Failed to load labs. Please refresh the page.");
      console.error("Load labs error:", err);
    } finally {
      setLabsLoading(false);
    }
  };

  const checkLabAgreement = async (labId) => {
    try {
      setCheckingAgreement(true);
      const response = await labAgreementAPI.getLabAgreementStatus(labId);
      setLabAgreementStatus(response.data);

      // If agreement is required but not signed, show modal
      if (response.data.required && !response.data.signed) {
        setAgreementFiles(response.data.files || []);
        setShowAgreementModal(true);
      }
    } catch (err) {
      console.error("Check lab agreement error:", err);
      setLabAgreementStatus(null);
    } finally {
      setCheckingAgreement(false);
    }
  };

  const handleSignAgreement = async () => {
    if (!formData.labId) return;

    try {
      setSigningAgreement(true);
      setError("");

      await labAgreementAPI.signLabAgreement(formData.labId);

      setSuccess("Lab agreement signed successfully!");
      setTimeout(() => setSuccess(""), 3000);

      // Reload agreement status
      await checkLabAgreement(formData.labId);
      setShowAgreementModal(false);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to sign agreement. Please try again.",
      );
      console.error("Sign lab agreement error:", err);
    } finally {
      setSigningAgreement(false);
    }
  };

  const filterPastTimeSlots = (slots, dateString) => {
    // If not today, return all
    const today = new Date();
    const todayLocal = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
    );
    const selected = new Date(`${dateString}T00:00:00`);
    const selectedLocal = new Date(
      selected.getFullYear(),
      selected.getMonth(),
      selected.getDate(),
    );

    if (selectedLocal.getTime() !== todayLocal.getTime()) return slots;

    // Today: filter out past end times
    const now = new Date();
    const nowMinutes = now.getHours() * 60 + now.getMinutes();

    return slots.filter((slot) => {
      const [h, m] = slot.endTime.split(":").map(Number);
      const endMinutes = h * 60 + m;
      return endMinutes > nowMinutes;
    });
  };

  const loadEquipment = async (labId) => {
    try {
      setEquipmentLoading(true);
      const response = await labAPI.getLabEquipment(labId);
      setEquipment(response.data.equipment);

      // Only reset equipment selection when creating new project
      if (!isEditing) {
        setFormData((prev) => ({ ...prev, equipmentIds: [] })); // Reset equipment selection
      }
    } catch (err) {
      setError("Failed to load equipment for selected lab.");
      console.error("Load equipment error:", err);
    } finally {
      setEquipmentLoading(false);
    }
  };

  const loadTimeSlots = async (labId, date) => {
    try {
      setTimeSlotsLoading(true);
      const response = await labAPI.getLabTimeSlots(labId, date);

      // Filter out past time slots if date is today
      let filteredSlots = filterPastTimeSlots(response.data.timeSlots, date);

      // Include currently selected consultations in edit mode even if API returns only free slots
      if (isEditing && editProject?.lab?.id?.toString() === labId.toString()) {
        const selectedForDate = selectedConsultations.filter(
          (consultation) => consultation.date === date,
        );

        for (const consultation of selectedForDate) {
          const slotId = parseInt(consultation.timeSlotId);
          const slotExists = filteredSlots.some((slot) => slot.id === slotId);

          if (!slotExists) {
            filteredSlots = [
              {
                id: slotId,
                startTime: consultation.timeSlotDetails.startTime,
                endTime: consultation.timeSlotDetails.endTime,
                availableMentors: 0,
                totalMentors: 1,
                isCurrentSlot: true,
                mentor: consultation.timeSlotDetails.mentor || null,
              },
              ...filteredSlots,
            ];
          }
        }
      }

      setTimeSlots(filteredSlots);
    } catch (err) {
      setError("Failed to load available consultation times.");
      console.error("Load time slots error:", err);
    } finally {
      setTimeSlotsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (
      name === "labId" &&
      isEditing &&
      value !== editProject?.lab?.id?.toString()
    ) {
      setSelectedConsultations([]);
      setCurrentConsultation({ date: "", timeSlotId: "" });
      setTimeSlots([]);
      setFormData((prev) => ({ ...prev, [name]: value, equipmentIds: [] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }

    // Clear error when user starts typing
    if (error) setError("");
  };

  const handleEquipmentChange = (equipmentId, checked) => {
    setFormData((prev) => {
      if (checked) {
        // Add equipment ID if checked
        return {
          ...prev,
          equipmentIds: [...prev.equipmentIds, equipmentId],
        };
      }
      return {
        ...prev,
        equipmentIds: prev.equipmentIds.filter((id) => id !== equipmentId),
      };
    });

    // Clear error when user selects equipment
    if (error) setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Lab agreement gate
    if (labAgreementStatus?.required && !labAgreementStatus?.signed) {
      setError(
        "You must sign the lab agreement before creating a project for this lab.",
      );
      setShowAgreementModal(true);
      return;
    }

    // Validate required fields
    if (!formData.name.trim() || !formData.description.trim()) {
      setError("Project name and description are required.");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    if (isEditing) {
      // Equipment is required
      if (formData.equipmentIds.length === 0) {
        setError("Please select at least one piece of equipment.");
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }

      if (selectedConsultations.length === 0) {
        setError("Please keep at least one consultation session selected.");
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
    } else {
      // For new projects, all fields required
      if (
        !formData.labId ||
        formData.equipmentIds.length === 0 ||
        selectedConsultations.length === 0
      ) {
        setError(
          "Please fill in all required fields including consultation date, at least one piece of equipment and consultation time.",
        );
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
    }

    try {
      setLoading(true);
      setError("");

      if (isEditing) {
        const labChanged = formData.labId !== editProject.lab?.id?.toString();

        // If changing to a lab that requires agreement, check it
        if (
          labChanged &&
          labAgreementStatus?.required &&
          !labAgreementStatus?.signed
        ) {
          setError(
            "You must sign the new lab's agreement before switching labs.",
          );
          setShowAgreementModal(true);
          setLoading(false);
          return;
        }

        const currentEquipmentIds =
          editProject.equipment?.map((e) => e.id.toString()).sort() || [];
        const newEquipmentIds = [...formData.equipmentIds].sort();
        const equipmentChanged =
          JSON.stringify(currentEquipmentIds) !==
          JSON.stringify(newEquipmentIds);
        const originalSlotIds = mapProjectConsultationsForEdit(editProject)
          .map((consultation) => consultation.timeSlotId)
          .sort();
        const newSlotIds = selectedConsultations
          .map((consultation) => consultation.timeSlotId)
          .sort();
        const consultationChanged =
          JSON.stringify(originalSlotIds) !== JSON.stringify(newSlotIds);

        // Check if anything changed
        const nameChanged = formData.name.trim() !== editProject.name;
        const descriptionChanged =
          formData.description.trim() !== editProject.description;

        if (
          labChanged ||
          equipmentChanged ||
          consultationChanged ||
          nameChanged ||
          descriptionChanged
        ) {
          // Build update data
          const updateData = {
            name: formData.name.trim(),
            description: formData.description.trim(),
          };

          // Add changed fields
          if (labChanged) updateData.labId = parseInt(formData.labId);
          if (equipmentChanged)
            updateData.equipmentIds = formData.equipmentIds.map((id) =>
              parseInt(id),
            );
          if (consultationChanged || labChanged) {
            updateData.timeSlotIds = selectedConsultations.map((c) =>
              parseInt(c.timeSlotId),
            );
          }

          const response = await projectAPI.updateProject(
            editProject.id,
            updateData,
          );
          setSuccess("Project updated successfully!");

          if (onSuccess) {
            onSuccess(response.data.project);
          }
        } else {
          setError("No changes detected.");
          setLoading(false);
          return;
        }
      } else {
        // Create project with consultation ID and multiple equipment
        const projectData = {
          name: formData.name.trim(),
          description: formData.description.trim(),
          labId: parseInt(formData.labId),
          equipmentIds: formData.equipmentIds.map((id) => parseInt(id)),
          timeSlotIds: selectedConsultations.map((c) => parseInt(c.timeSlotId)),
        };

        if (rescheduleInfo?.originalProjectId) {
          projectData.isReschedule = true;
          projectData.rescheduledFromId = parseInt(
            rescheduleInfo.originalProjectId,
          );
        }

        const projectResponse = await projectAPI.createProject(projectData);
        setSuccess(
          rescheduleInfo
            ? "Consultation rescheduled successfully!"
            : "Project proposal submitted successfully!",
        );

        // Clear form
        setFormData({
          name: "",
          description: "",
          labId: "",
          equipmentIds: [],
        });
        setSelectedConsultations([]);
        setCurrentConsultation({ date: "", timeSlotId: "" });

        if (rescheduleInfo) {
          sessionStorage.removeItem("rescheduleData");
          setRescheduleInfo(null);
        }

        if (onSuccess) {
          onSuccess(projectResponse.data.project);
        }
      }
    } catch (err) {
      console.error("Submit project error:", err);
      setError(
        err.response?.data?.message ||
          "Failed to save project. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  // Helper functions for mentor availability display
  const formatTimeSlot = (timeSlot) => {
    return `${formatTime(timeSlot.startTime)} - ${formatTime(timeSlot.endTime)}`;
  };

  const getMentorAvailabilityColor = (availableMentors, totalMentors) => {
    if (!totalMentors) return "text-gray-500";
    const ratio = availableMentors / totalMentors;
    if (ratio >= 0.7) return "text-green-600";
    if (ratio >= 0.4) return "text-yellow-600";
    return "text-red-600";
  };

  // Get minimum date (today)
  const getMinDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  // Handler to add consultation to selection
  const handleAddConsultation = () => {
    if (!currentConsultation.date || !currentConsultation.timeSlotId) {
      setError("Please select both date and time slot");
      return;
    }

    // Check if already added
    const alreadyAdded = selectedConsultations.some(
      (c) => c.timeSlotId === currentConsultation.timeSlotId,
    );

    if (alreadyAdded) {
      setError("This time slot is already selected");
      setTimeout(() => setError(""), 3000);
      return;
    }

    // Check maximum limit
    if (selectedConsultations.length >= 5) {
      setError("Maximum 5 consultation sessions allowed per project");
      setTimeout(() => setError(""), 3000);
      return;
    }

    // Get full time slot details
    const timeSlotDetails = timeSlots.find(
      (slot) => slot.id.toString() === currentConsultation.timeSlotId,
    );

    if (!timeSlotDetails) {
      setError("Selected time slot not found");
      return;
    }

    // Add to list
    setSelectedConsultations((prev) => {
      const updated = [
        ...prev,
        {
          date: currentConsultation.date,
          timeSlotId: currentConsultation.timeSlotId,
          timeSlotDetails: timeSlotDetails,
        },
      ];

      return updated.sort((a, b) => {
        const aDateTime = new Date(
          `${a.date}T${a.timeSlotDetails?.startTime || "00:00"}`,
        );
        const bDateTime = new Date(
          `${b.date}T${b.timeSlotDetails?.startTime || "00:00"}`,
        );
        return aDateTime - bDateTime;
      });
    });

    // Reset current selection
    setCurrentConsultation({ date: "", timeSlotId: "" });
    setTimeSlots([]);
    setSuccess("Consultation session added!");
    setTimeout(() => setSuccess(""), 2000);
  };

  // Handler to remove consultation
  const handleRemoveConsultation = (index) => {
    setSelectedConsultations((prev) => prev.filter((_, i) => i !== index));
  };

  if (labsLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Spinner />
        <span className="ml-2">Loading labs...</span>
      </div>
    );
  }

  return (
    <>
      <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          {isEditing ? "Edit Project Proposal" : "Create Project Proposal"}
        </h2>

        {error && <Alert type="error">{error}</Alert>}

        {success && <Alert type="success">{success}</Alert>}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Project Name */}
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Project Name *
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Enter your project name"
            />
          </div>

          {/* Project Description */}
          <div>
            <label
              htmlFor="description"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Project Description *
            </label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Describe your project, what you want to build, and any specific requirements"
            />
          </div>

          {/* Lab Selection */}
          <div>
            <label
              htmlFor="labId"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Select Lab *
            </label>
            <select
              id="labId"
              name="labId"
              value={formData.labId}
              onChange={handleInputChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">Choose a lab...</option>
              {labs.map((lab) => (
                <option key={lab.id} value={lab.id}>
                  {lab.name} - {lab.location}
                  {lab.agreementRequired ? " (Agreement Required)" : ""}
                </option>
              ))}
            </select>

            {formData.labId && (
              <div className="mt-2 p-3 bg-gray-50 rounded-md">
                <p className="text-sm text-gray-600">
                  <strong>Selected Lab:</strong>{" "}
                  {
                    labs.find((l) => l.id === parseInt(formData.labId))
                      ?.description
                  }
                </p>
              </div>
            )}

            {/* Lab Agreement Status Indicator */}
            {checkingAgreement && formData.labId && (
              <div className="mt-2 flex items-center text-sm text-gray-500">
                <Spinner size="sm" className="mr-2" />
                Checking lab agreement status...
              </div>
            )}

            {labAgreementStatus && formData.labId && (
              <div className="mt-2">
                {labAgreementStatus.required && labAgreementStatus.signed && (
                  <div className="flex items-center p-2 bg-green-50 border border-green-200 rounded-md">
                    <span className="text-green-700 text-sm">
                      ✓ Lab agreement signed
                    </span>
                  </div>
                )}
                {labAgreementStatus.required && !labAgreementStatus.signed && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                    <p className="text-sm font-medium text-yellow-800">
                      Agreement Required
                    </p>
                    <p className="text-xs text-yellow-700 mt-1">
                      This lab requires you to sign an agreement before use.
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowAgreementModal(true)}
                      className="mt-2 text-xs bg-yellow-600 text-white px-3 py-1 rounded hover:bg-yellow-700"
                    >
                      View & Sign Agreement
                    </button>
                  </div>
                )}
              </div>
            )}

            {isEditing && (
              <p className="text-xs text-yellow-600 mt-1">
                Changing lab will reset equipment and consultation selections
              </p>
            )}
          </div>

          {/* Equipment Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Equipment *
            </label>

            {!formData.labId ? (
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                <p className="text-sm text-gray-500">
                  Select a lab first to see available equipment
                </p>
              </div>
            ) : labAgreementStatus?.required && !labAgreementStatus?.signed ? (
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                <p className="text-sm text-yellow-700">
                  Sign the lab agreement to access equipment
                </p>
              </div>
            ) : equipmentLoading ? (
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                <p className="text-sm text-gray-500">Loading equipment...</p>
              </div>
            ) : equipment.length === 0 ? (
              <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                <p className="text-sm text-gray-500">
                  No equipment available for this lab
                </p>
              </div>
            ) : (
              <div className="space-y-3 border border-gray-300 rounded-md p-4 max-h-48 overflow-y-auto">
                {equipment.map((equip) => (
                  <div key={equip.id} className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id={`equipment-${equip.id}`}
                      checked={formData.equipmentIds.includes(
                        equip.id.toString(),
                      )}
                      onChange={(e) =>
                        handleEquipmentChange(
                          equip.id.toString(),
                          e.target.checked,
                        )
                      }
                      className="mt-1 h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                    />
                    <label
                      htmlFor={`equipment-${equip.id}`}
                      className="flex-1 cursor-pointer"
                    >
                      <div className="text-sm font-medium text-gray-900">
                        {equip.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {equip.description} - Status: {equip.status}
                      </div>
                    </label>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Consultation Sessions
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Select one or more consultation time slots. For complex projects,
              you can schedule multiple 30-minute sessions with peer mentors.
            </p>
            {isEditing && selectedConsultations.length > 0 && (
              <div className="mb-4 rounded-md border border-blue-200 bg-blue-50 p-3 text-sm text-blue-800">
                Existing scheduled sessions are preloaded below. You can remove
                them or add more before saving.
              </div>
            )}

            {/* Current Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label
                  htmlFor="consultationDate"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Select Date
                </label>
                <input
                  type="date"
                  id="consultationDate"
                  value={currentConsultation.date}
                  onChange={(e) =>
                    setCurrentConsultation((prev) => ({
                      ...prev,
                      date: e.target.value,
                      timeSlotId: "",
                    }))
                  }
                  min={new Date().toISOString().split("T")[0]}
                  disabled={
                    !formData.labId ||
                    (labAgreementStatus?.required &&
                      !labAgreementStatus?.signed)
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 disabled:bg-gray-100"
                />
              </div>

              <div>
                <label
                  htmlFor="timeSlot"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Select Time Slot
                </label>
                {timeSlotsLoading ? (
                  <div className="flex items-center justify-center py-2">
                    <Spinner size="sm" />
                  </div>
                ) : timeSlots.length > 0 ? (
                  <select
                    id="timeSlot"
                    value={currentConsultation.timeSlotId}
                    onChange={(e) =>
                      setCurrentConsultation((prev) => ({
                        ...prev,
                        timeSlotId: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    <option value="">Select time</option>
                    {timeSlots.map((slot) => (
                      <option key={slot.id} value={slot.id}>
                        {formatTime(slot.startTime)} -{" "}
                        {formatTime(slot.endTime)}
                        {slot.mentor && ` (Mentor: ${slot.mentor.name})`}
                      </option>
                    ))}
                  </select>
                ) : currentConsultation.date ? (
                  <p className="text-sm text-gray-500 py-2">
                    No available time slots for this date
                  </p>
                ) : (
                  <p className="text-sm text-gray-500 py-2">
                    Select a date first
                  </p>
                )}
              </div>
            </div>

            {/* Add Button */}
            <button
              type="button"
              onClick={handleAddConsultation}
              disabled={
                !currentConsultation.date || !currentConsultation.timeSlotId
              }
              className="w-full md:w-auto px-4 py-2 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Add Consultation Session
            </button>

            {/* Selected Consultations List */}
            {selectedConsultations.length > 0 && (
              <div className="mt-6">
                <h4 className="font-medium text-gray-900 mb-3">
                  Selected Consultation Sessions ({selectedConsultations.length}
                  )
                </h4>
                <div className="space-y-3">
                  {selectedConsultations.map((consultation, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-200 rounded-lg"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">
                          Session {index + 1}:{" "}
                          {new Date(consultation.date).toLocaleDateString()}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          {formatTime(consultation.timeSlotDetails.startTime)} -{" "}
                          {formatTime(consultation.timeSlotDetails.endTime)}
                        </p>
                        {consultation.timeSlotDetails.mentor && (
                          <p className="text-sm text-gray-500 mt-1">
                            Mentor: {consultation.timeSlotDetails.mentor.name}
                          </p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveConsultation(index)}
                        className="ml-4 p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-md transition-colors"
                        title="Remove consultation"
                      ></button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Warning if no consultations selected */}
            {selectedConsultations.length === 0 && (
              <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                <p className="text-sm text-yellow-800">
                  You must select at least one consultation session to continue
                </p>
              </div>
            )}
          </div>

          {/* Lab Agreement Warning Before Submit */}
          {formData.labId &&
            labAgreementStatus?.required &&
            !labAgreementStatus?.signed && (
              <div className="p-4 bg-red-50 border-2 border-red-300 rounded-md">
                <div className="flex items-center">
                  <div className="ml-3 flex-1">
                    <h3 className="text-sm font-medium text-red-800">
                      Cannot Submit - Lab Agreement Required
                    </h3>
                    <p className="text-sm text-red-700 mt-1">
                      You must sign the lab agreement for{" "}
                      {labAgreementStatus.lab.name} before you can submit this
                      project proposal.
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowAgreementModal(true)}
                      className="mt-2 text-sm font-medium text-red-800 underline hover:text-red-900"
                    >
                      Click here to view and sign the agreement
                    </button>
                  </div>
                </div>
              </div>
            )}

          {/* Form Actions */}
          <div className="flex space-x-4 pt-4">
            <button
              type="submit"
              disabled={
                loading ||
                !formData.labId ||
                (labAgreementStatus?.required && !labAgreementStatus?.signed)
              }
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
              title={
                labAgreementStatus?.required && !labAgreementStatus?.signed
                  ? "Sign the lab agreement to submit"
                  : ""
              }
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <Spinner size="sm" color="border-white" className="mr-2" />
                  {isEditing ? "Updating..." : "Submitting Proposal..."}
                </div>
              ) : isEditing ? (
                "Update Project Proposal"
              ) : (
                "Submit Project Proposal"
              )}
            </button>

            {onCancel && (
              <button
                type="button"
                onClick={() => {
                  // Clear reschedule data when canceling
                  if (rescheduleInfo) {
                    sessionStorage.removeItem("rescheduleData");
                    setRescheduleInfo(null);
                  }
                  onCancel();
                }}
                disabled={loading}
                className="flex-1 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Lab Agreement Modal */}
      {showAgreementModal && labAgreementStatus && (
        <LabAgreementModal
          labId={formData.labId}
          labName={labAgreementStatus.lab.name}
          labLocation={labAgreementStatus.lab.location || ""}
          files={agreementFiles}
          isSigned={false}
          signing={signingAgreement}
          onSign={handleSignAgreement}
          onClose={() => setShowAgreementModal(false)}
        />
      )}
    </>
  );
}

export default ProjectForm;
