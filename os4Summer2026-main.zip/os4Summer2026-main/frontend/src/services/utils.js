export const formatDate = (date) => {
  return new Date(date).toLocaleDateString();
};

export const formatTime = (timeString) => {
  const [hours, minutes] = timeString.split(":");
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? "PM" : "AM";
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  return `${displayHour}:${minutes} ${ampm}`;
};

export const formatDateTime = (date) => {
  return new Date(date).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export const getStatusColor = (status) => {
  switch (status) {
    case "IN_PROCESS":
      return "bg-yellow-100 text-yellow-800";
    case "CONSULTATION_CANCELLED":
      return "bg-red-100 text-red-800";
    case "CONSULTATION_ABSENT":
      return "bg-orange-100 text-orange-800";
    case "APPROVED":
      return "bg-green-100 text-green-800";
    case "DECLINED":
      return "bg-red-100 text-red-800";
    case "CONFIRMED":
      return "bg-green-100 text-green-800";
    case "COMPLETED":
      return "bg-gray-100 text-gray-800";
    case "CANCELLED":
      return "bg-red-100 text-red-800";
    case "ABSENT":
      return "bg-orange-100 text-orange-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

export const getStatusLabel = (status) => {
  switch (status) {
    case "IN_PROCESS":
      return "Under Review";
    case "CONSULTATION_CANCELLED":
      return "Consultation Cancelled";
    case "CONSULTATION_ABSENT":
      return "Absent from Consultation";
    case "APPROVED":
      return "Approved";
    case "DECLINED":
      return "Declined";
    case "CONFIRMED":
      return "Confirmed";
    case "COMPLETED":
      return "Completed";
    case "CANCELLED":
      return "Cancelled";
    case "ABSENT":
      return "Absent";
    default:
      return status;
  }
};

export const getFileIcon = (fileType) => {
  switch (fileType) {
    case "pdf":
      return "📄";
    case "docx":
      return "📝";
    case "image":
      return "🖼️";
    default:
      return "📎";
  }
};

export const getDayDisplayName = (day) => {
  return day.charAt(0).toUpperCase() + day.slice(1);
};

export const DAYS_OF_WEEK = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
  "sunday",
];
