import axios from "axios";
import { removeToken } from "./auth";

const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL || "http://localhost:3001";

export const getAgreementFileDownloadUrl = (labId, fileId) => {
  return `${API_BASE_URL}/lab-agreements/${labId}/files/${fileId}/download`;
};

export const getMemberAgreementFileDownloadUrl = (fileId) => {
  return `${API_BASE_URL}/auth/member-agreement/files/${fileId}/download`;
};

export const getMemberAgreementFileViewUrl = (fileId) => {
  return `${API_BASE_URL}/auth/member-agreement/files/${fileId}/view`;
};

const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

// Handle token expiration
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      removeToken();
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  },
);

// Auth API functions
export const authAPI = {
  register: (name, email, password) =>
    api.post("/auth/register", { name, email, password }),

  login: (email, password) => api.post("/auth/login", { email, password }),

  verifyEmail: (token) => api.get(`/auth/verify-email?token=${token}`),

  forgotPassword: (email) => api.post("/auth/forgot-password", { email }),

  resetPassword: (token, newPassword) =>
    api.post("/auth/reset-password", { token, newPassword }),

  resendVerification: (email) =>
    api.post("/auth/resend-verification", { email }),
  logout: () => api.post("/auth/logout"),
  getMe: () => api.get("/auth/me"),

  updateProfile: (name, email) => api.put("/auth/profile", { name, email }),
  changePassword: (currentPassword, newPassword) =>
    api.put("/auth/change-password", { currentPassword, newPassword }),

  getAgreementStatus: () => api.get("/auth/member-agreement/status"),
  getMemberAgreementFiles: () => api.get("/auth/member-agreement/files"),

  submitMemberAgreement: () => api.post("/auth/member-agreement/submit"),

  cancelConsultation: (consultationId, cancelReason) =>
    api.put(`/auth/consultations/${consultationId}/cancel`, { cancelReason }),
};

// Lab API functions
export const labAPI = {
  getAllLabs: () => api.get("/auth/labs"),

  getLabEquipment: (labId) => api.get(`/auth/labs/${labId}/equipment`),

  getLabTimeSlots: (labId, date = null) => {
    const url = `/auth/labs/${labId}/timeslots`;
    const params = date ? { date } : {};
    return api.get(url, { params });
  },

  bookConsultation: (consultationData) =>
    api.post("/auth/consultations", consultationData),

  getUserConsultations: () => api.get("/auth/consultations"),
};

// Project API functions
export const projectAPI = {
  createProject: (projectData) => api.post("/auth/projects", projectData),

  getUserProjects: () => api.get("/auth/projects"),

  getProjectDetails: (projectId) => api.get(`/auth/projects/${projectId}`),

  updateProject: (projectId, projectData) =>
    api.put(`/auth/projects/${projectId}`, projectData),

  deleteProject: (projectId) => api.delete(`/auth/projects/${projectId}`),

  cancelConsultation: (projectId, reason) =>
    api.put(`/auth/projects/${projectId}/cancel-consultation`, { reason }),
};

// Admin API functions
export const adminAPI = {
  getProjectStats: () => api.get("/admin/stats"),

  getRecentProjects: () => api.get("/admin/recent-projects"),
  getMySchedule: () => api.get("/admin/my-schedule"),

  getAvailableMentorsForProject: (projectId, consultationId = null) =>
    api.get(`/admin/projects/${projectId}/available-mentors`, {
      params: consultationId ? { consultationId } : {},
    }),

  changeProjectMentor: (projectId, newMentorId) =>
    api.put(`/admin/projects/${projectId}/change-mentor`, { newMentorId }),

  getApprovedProjectsWithoutBookings: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);

    return api.get(
      `/admin/approved-projects-without-bookings?${searchParams.toString()}`,
    );
  },

  getAllProjects: (params = {}) => {
    const queryParams = new URLSearchParams();

    if (params.status && params.status !== "ALL") {
      queryParams.append("status", params.status);
    }
    if (params.lab && params.lab !== "ALL") {
      queryParams.append("lab", params.lab);
    }
    if (params.search) {
      queryParams.append("search", params.search);
    }
    if (params.sortBy) {
      queryParams.append("sortBy", params.sortBy);
    }
    if (params.page) {
      queryParams.append("page", params.page);
    }
    if (params.limit) {
      queryParams.append("limit", params.limit);
    }

    const queryString = queryParams.toString();
    const url = queryString
      ? `/admin/projects?${queryString}`
      : "/admin/projects";

    return api.get(url);
  },

  getProjectDetails: (projectId) => api.get(`/admin/projects/${projectId}`),

  reviewProject: (projectId, reviewData) =>
    api.put(`/admin/projects/${projectId}/review`, reviewData),

  updateProjectComment: (projectId, comment) =>
    api.put(`/admin/projects/${projectId}/comment`, { comment }),

  cancelConsultation: (projectId, reason) =>
    api.put(`/admin/projects/${projectId}/cancel-consultation`, { reason }),

  markAbsent: (projectId, reason) =>
    api.put(`/admin/projects/${projectId}/mark-absent`, { reason }),

  getLabsForFilter: () => api.get("/admin/labs"),

  getSupervisors: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);
    return api.get(`/admin/supervisors?${searchParams.toString()}`);
  },

  getSupervisorScheduleForLab: (supervisorId, labId) =>
    api.get(`/admin/supervisors/${supervisorId}/schedule/${labId}`),

  updateSupervisorScheduleForLab: (supervisorId, labId, data) =>
    api.put(`/admin/supervisors/${supervisorId}/schedule/${labId}`, data),

  cancelSpecificConsultation: (consultationId, cancelReason) =>
    api.put(`/admin/consultations/${consultationId}/cancel`, { cancelReason }),

  markConsultationAbsent: (consultationId, absentReason) =>
    api.put(`/admin/consultations/${consultationId}/absent`, { absentReason }),

  changeConsultationMentor: (consultationId, newMentorId) =>
    api.put(`/admin/consultations/${consultationId}/change-mentor`, {
      newMentorId,
    }),

  updateConsultationComment: (consultationId, comment) =>
    api.put(`/admin/consultations/${consultationId}/comment`, { comment }),

  getMemberAgreementConfig: () => api.get("/admin/member-agreement/config"),

  updateMemberAgreementConfig: (configData) =>
    api.put("/admin/member-agreement/config", configData),

  uploadMemberAgreementFile: (formData) =>
    api.post("/admin/member-agreement/files", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    }),

  replaceMemberAgreementFile: (fileId, formData) =>
    api.put(`/admin/member-agreement/files/${fileId}`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    }),

  updateMemberAgreementFileSchedule: (fileId, scheduleData) =>
    api.put(`/admin/member-agreement/files/${fileId}/schedule`, scheduleData),

  deleteMemberAgreementFile: (fileId) =>
    api.delete(`/admin/member-agreement/files/${fileId}`),
};

// User Management API functions
export const userManagementAPI = {
  createUserAccount: (data) => api.post("/admin/users", data),

  updateUserAccount: (userId, data) =>
    api.put(`/admin/users/${userId}/account`, data),

  getAllUsers: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);
    if (params.role) searchParams.append("role", params.role);
    if (params.mentorType) searchParams.append("mentorType", params.mentorType);

    return api.get(`/admin/users?${searchParams.toString()}`);
  },

  updateUserRole: (userId, roleData) => {
    return api.put(`/admin/users/${userId}/role`, roleData);
  },

  updateLabAssignments: (userId, assignmentData) => {
    return api.put(`/admin/users/${userId}/lab-assignments`, assignmentData);
  },

  getLabsForAssignment: () => {
    return api.get("/admin/labs-simple");
  },

  cancelMemberAgreement: (userId, reason) =>
    api.put(`/admin/users/${userId}/cancel-agreement`, { reason }),

  getAgreementCancellationHistory: (userId) =>
    api.get(`/admin/users/${userId}/agreement-history`),

  updateCancellationReason: (userId, cancellationId, reason) =>
    api.put(`/admin/users/${userId}/agreement-history/${cancellationId}`, {
      reason,
    }),

  getUserStats: () => api.get("/admin/user-stats"),

  inactivateUser: (userId) => api.put(`/admin/users/${userId}/inactivate`),

  reactivateUser: (userId) => api.put(`/admin/users/${userId}/reactivate`),

  deleteUserAccount: (userId) =>
    api.delete(`/admin/users/${userId}/delete-account`),
};

// Unified Peer Mentor Schedule API functions (both CONSULTATION and LAB)
export const peerMentorScheduleAPI = {
  getAllPeerMentors: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);
    if (params.lab) searchParams.append("lab", params.lab);
    if (params.mentorType) searchParams.append("mentorType", params.mentorType);

    return api.get(`/admin/peer-mentors?${searchParams.toString()}`);
  },

  getMentorAssignmentSchedule: (mentorId, assignmentId) =>
    api.get(
      `/admin/peer-mentors/${mentorId}/assignments/${assignmentId}/schedule`,
    ),

  updateMentorAssignmentSchedule: (mentorId, assignmentId, scheduleData) =>
    api.put(
      `/admin/peer-mentors/${mentorId}/assignments/${assignmentId}/schedule`,
      scheduleData,
    ),

  getLabsForAssignment: () => api.get("/admin/labs-simple"),
};

// Booking API functions
export const bookingAPI = {
  getProjectBookings: (projectId) => api.get(`/bookings/project/${projectId}`),

  getMyBookings: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.status) searchParams.append("status", params.status);
    if (params.upcoming) searchParams.append("upcoming", params.upcoming);

    return api.get(`/bookings/my-bookings?${searchParams.toString()}`);
  },

  getLabBookings: (labId, params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.status) searchParams.append("status", params.status);
    if (params.date) searchParams.append("date", params.date);

    return api.get(`/bookings/lab/${labId}?${searchParams.toString()}`);
  },

  getAllBookings: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.status && params.status !== "ALL") {
      searchParams.append("status", params.status);
    }
    if (params.lab && params.lab !== "ALL") {
      searchParams.append("lab", params.lab);
    }
    if (params.student) {
      searchParams.append("student", params.student);
    }
    if (params.sortBy) {
      searchParams.append("sortBy", params.sortBy);
    }
    if (params.page) {
      searchParams.append("page", params.page);
    }
    if (params.limit) {
      searchParams.append("limit", params.limit);
    }

    const queryString = searchParams.toString();
    const url = queryString ? `/bookings?${queryString}` : "/bookings";

    return api.get(url);
  },

  getBookingStats: () => api.get("/bookings/stats"),

  getBookingDetails: (bookingId) => api.get(`/bookings/${bookingId}`),

  updateBooking: (bookingId, updateData) =>
    api.put(`/bookings/${bookingId}`, updateData),

  deleteBooking: (bookingId) => api.delete(`/bookings/${bookingId}`),

  getAvailableSlots: (labId, params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.startDate) searchParams.append("startDate", params.startDate);
    if (params.endDate) searchParams.append("endDate", params.endDate);

    return api.get(
      `/bookings/available-slots/${labId}?${searchParams.toString()}`,
    );
  },

  getMyLabBookings: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.status) searchParams.append("status", params.status);
    if (params.date) searchParams.append("date", params.date);

    return api.get(`/bookings/my-lab-bookings?${searchParams.toString()}`);
  },

  createBooking: (bookingData) => api.post("/bookings", bookingData),

  createBatchBooking: (batchData) => api.post("/bookings/batch", batchData),

  cancelBooking: (bookingId, data) =>
    api.put(`/bookings/${bookingId}/cancel`, data),
};

// Lab Management API functions
export const labManagementAPI = {
  getAllLabs: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);
    if (params.status) searchParams.append("status", params.status);
    if (params.agreementRequired)
      searchParams.append("agreementRequired", params.agreementRequired);
    return api.get(`/lab-management/labs?${searchParams.toString()}`);
  },

  getLabDetails: (labId) => api.get(`/lab-management/labs/${labId}`),

  createLab: (data) => api.post("/lab-management/labs", data),

  updateLab: (labId, data) => api.put(`/lab-management/labs/${labId}`, data),

  deleteLab: (labId) => api.delete(`/lab-management/labs/${labId}`),

  addEquipment: (labId, data) =>
    api.post(`/lab-management/labs/${labId}/equipment`, data),

  updateEquipment: (labId, equipmentId, data) =>
    api.put(`/lab-management/labs/${labId}/equipment/${equipmentId}`, data),

  deleteEquipment: (labId, equipmentId) =>
    api.delete(`/lab-management/labs/${labId}/equipment/${equipmentId}`),

  toggleAgreementRequired: (labId, agreementRequired) =>
    api.put(`/lab-management/labs/${labId}/agreement-required`, {
      agreementRequired,
    }),

  uploadAgreementFile: (labId, file) => {
    const formData = new FormData();
    formData.append("file", file);
    return api.post(`/lab-management/labs/${labId}/agreement-files`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  },

  getAgreementFiles: (labId) =>
    api.get(`/lab-management/labs/${labId}/agreement-files`),

  deleteAgreementFile: (labId, fileId) =>
    api.delete(`/lab-management/labs/${labId}/agreement-files/${fileId}`),

  getLabAgreementSigners: (labId, params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append("search", params.search);
    return api.get(
      `/lab-management/labs/${labId}/agreement-signers?${searchParams.toString()}`,
    );
  },

  cancelLabAgreement: (labId, userId, data) =>
    api.put(
      `/lab-management/labs/${labId}/users/${userId}/cancel-agreement`,
      data,
    ),

  getLabAgreementHistory: (labId, userId, params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.limit) searchParams.append("limit", params.limit);
    if (params.offset) searchParams.append("offset", params.offset);

    const queryString = searchParams.toString();
    const url = queryString
      ? `/lab-management/labs/${labId}/users/${userId}/agreement-history?${queryString}`
      : `/lab-management/labs/${labId}/users/${userId}/agreement-history`;

    return api.get(url);
  },

  updateLabAgreementCancellationReason: (labId, userId, cancellationId, data) =>
    api.put(
      `/lab-management/labs/${labId}/users/${userId}/agreement-history/${cancellationId}`,
      data,
    ),
};

export const memberAPI = {
  getMemberStats: () => api.get("/member/stats"),
  getRecentProposals: () => api.get("/member/recent-proposals"),
  getUpcomingBookings: () => api.get("/member/upcoming-bookings"),
};

// Lab Agreement API functions
export const labAgreementAPI = {
  getLabAgreementStatus: (labId) => api.get(`/lab-agreements/${labId}/status`),

  getUnsignedAgreements: () => api.get("/lab-agreements/unsigned"),

  getLabAgreementFiles: (labId) => api.get(`/lab-agreements/${labId}/files`),

  downloadAgreementFile: (labId, fileId) =>
    api.get(`/lab-agreements/${labId}/files/${fileId}/download`, {
      responseType: "blob",
    }),

  signLabAgreement: (labId) => api.post(`/lab-agreements/${labId}/sign`),
};

// Archive API functions
export const archiveAPI = {
  getArchivedProjects: (params) => api.get("/archive/projects", { params }),

  getArchivedBookings: (params) => api.get("/archive/bookings", { params }),

  archiveProject: (projectId) =>
    api.put(`/archive/projects/${projectId}/archive`),

  unarchiveProject: (projectId) =>
    api.put(`/archive/projects/${projectId}/unarchive`),

  archiveBooking: (bookingId) =>
    api.put(`/archive/bookings/${bookingId}/archive`),

  unarchiveBooking: (bookingId) =>
    api.put(`/archive/bookings/${bookingId}/unarchive`),

  getArchiveStats: () => api.get("/archive/stats"),
};

export default api;
