const AUTH_SESSION_KEY = "auth_session";

const getStorage = () => {
  if (localStorage.getItem(AUTH_SESSION_KEY)) {
    return localStorage;
  }
  if (sessionStorage.getItem(AUTH_SESSION_KEY)) {
    return sessionStorage;
  }
  return null;
};

const readSession = () => {
  const storage = getStorage();
  if (!storage) {
    return null;
  }

  try {
    const raw = storage.getItem(AUTH_SESSION_KEY);
    if (!raw) {
      return null;
    }
    return JSON.parse(raw);
  } catch (error) {
    storage.removeItem(AUTH_SESSION_KEY);
    return null;
  }
};

const decodeJwtPayload = (token) => {
  const base64Payload = token
    .split(".")[1]
    ?.replace(/-/g, "+")
    .replace(/_/g, "/");
  if (!base64Payload) return null;
  return JSON.parse(atob(base64Payload));
};

// Compatibility shim: JWT is no longer persisted in web storage
export const getToken = () => null;

export const setSession = (user, exp, rememberMe = false) => {
  if (!user || !exp) {
    removeToken();
    return;
  }

  const session = {
    exp,
    user: {
      ...user,
      exp,
    },
  };

  const targetStorage = rememberMe ? localStorage : sessionStorage;
  const otherStorage = rememberMe ? sessionStorage : localStorage;
  targetStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(session));
  otherStorage.removeItem(AUTH_SESSION_KEY);
};

// Persist non-sensitive session metadata only (no raw JWT)
export const setToken = (token, rememberMe = false, userFromApi = null) => {
  try {
    const payload = decodeJwtPayload(token);
    if (!payload?.exp) {
      throw new Error("Invalid token payload");
    }

    setSession(
      {
        id: userFromApi?.id ?? payload.userId ?? null,
        name: userFromApi?.name ?? payload.name ?? "",
        email: userFromApi?.email ?? payload.email ?? "",
        role: userFromApi?.role ?? payload.role ?? "MEMBER",
        mentorType: userFromApi?.mentorType ?? payload.mentorType ?? null,
      },
      payload.exp,
      rememberMe,
    );
  } catch (error) {
    removeToken();
  }
};

export const removeToken = () => {
  localStorage.removeItem(AUTH_SESSION_KEY);
  sessionStorage.removeItem(AUTH_SESSION_KEY);
};

export const getUserFromToken = () => {
  const session = readSession();
  return session?.user || null;
};

export const isTokenValid = () => {
  const session = readSession();
  if (!session?.exp) return false;

  const isValid = session.exp > Date.now() / 1000;
  if (!isValid) {
    removeToken();
  }
  return isValid;
};

export const isRemembered = () => {
  return !!localStorage.getItem(AUTH_SESSION_KEY);
};

export const isEmployee = (user) =>
  !!user && ["ADMIN", "SUPERVISOR", "PEER_MENTOR"].includes(user.role);

export const isAdmin = (user) =>
  !!user && ["ADMIN", "SUPERVISOR"].includes(user.role);

export const isLabBookingManager = (user) => {
  if (!user) return false;
  if (["ADMIN", "SUPERVISOR"].includes(user.role)) return true;
  return user.role === "PEER_MENTOR";
};
