export const DISCORD_LINKS = [
  {
    label: "Main Server",
    url: process.env.REACT_APP_DISCORD_MAIN_URL || "https://discord.com",
  },
  {
    label: "Consultation Mentors",
    url:
      process.env.REACT_APP_DISCORD_CONSULTATION_URL || "https://discord.com",
  },
  {
    label: "Lab Mentors",
    url: process.env.REACT_APP_DISCORD_LAB_URL || "https://discord.com",
  },
];
