const mockApiClient = {
  get: jest.fn(() => Promise.resolve({ data: {} })),
  post: jest.fn(() => Promise.resolve({ data: {} })),
  put: jest.fn(() => Promise.resolve({ data: {} })),
  delete: jest.fn(() => Promise.resolve({ data: {} })),
  interceptors: {
    request: { use: jest.fn() },
    response: { use: jest.fn() },
  },
};

jest.mock("axios", () => ({
  create: jest.fn(() => mockApiClient),
}));

jest.mock("../services/auth", () => ({
  getToken: jest.fn(() => "token"),
  removeToken: jest.fn(),
}));

describe("api smoke tests", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.REACT_APP_API_BASE_URL = "http://localhost:3001";
  });

  test("agreement download url is built correctly", () => {
    const { getAgreementFileDownloadUrl } = require("../services/api");

    const url = getAgreementFileDownloadUrl(7, 13);
    expect(url).toBe(
      "http://localhost:3001/lab-agreements/7/files/13/download",
    );
  });

  test("booking batch endpoint call works", async () => {
    const { bookingAPI } = require("../services/api");

    await bookingAPI.createBatchBooking({
      projectId: 1,
      bookingSlots: [{ timeSlotId: 5, equipmentIds: [1] }],
    });

    expect(mockApiClient.post).toHaveBeenCalledWith("/bookings/batch", {
      projectId: 1,
      bookingSlots: [{ timeSlotId: 5, equipmentIds: [1] }],
    });
  });

  test("booking list query params are generated", async () => {
    const { bookingAPI } = require("../services/api");

    await bookingAPI.getAllBookings({
      status: "CONFIRMED",
      lab: "Physics Lab",
      student: "alice",
      sortBy: "newest",
    });

    expect(mockApiClient.get).toHaveBeenCalledWith(
      "/bookings?status=CONFIRMED&lab=Physics+Lab&student=alice&sortBy=newest",
    );
  });

  test("lab agreement sign endpoint call works", async () => {
    const { labAgreementAPI } = require("../services/api");

    await labAgreementAPI.signLabAgreement(9);

    expect(mockApiClient.post).toHaveBeenCalledWith("/lab-agreements/9/sign");
  });
});
