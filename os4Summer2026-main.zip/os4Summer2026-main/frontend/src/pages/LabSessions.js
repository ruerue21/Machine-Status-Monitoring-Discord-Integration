import { useState, useEffect, useCallback } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { bookingAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { formatDate, formatDateTime } from "../services/utils";

function LabSessions() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // State management
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [upcomingOnly, setUpcomingOnly] = useState(true);

  // Modal states
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  // Cancel modal states
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [cancelling, setCancelling] = useState(false);
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    loadBookings();
  }, [statusFilter, upcomingOnly]);

  const loadBookings = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const params = {
        status: statusFilter !== "ALL" ? statusFilter : undefined,
        upcoming: upcomingOnly ? "true" : undefined,
        sortOrder: "desc",
      };

      const response = await bookingAPI.getMyBookings(params);
      setBookings(response.data.bookings || []);
    } catch (err) {
      setError("Failed to load lab sessions. Please try again.");
      console.error("Load bookings error:", err);
    } finally {
      setLoading(false);
    }
  }, [statusFilter, upcomingOnly]);

  const openDetailsModal = (booking) => {
    setSelectedBooking(booking);
    setShowDetailsModal(true);
  };

  const closeDetailsModal = () => {
    setSelectedBooking(null);
    setShowDetailsModal(false);
  };

  const openCancelModal = (booking) => {
    setBookingToCancel(booking);
    setShowCancelModal(true);
    setCancellationReason("");
  };

  const closeCancelModal = () => {
    setBookingToCancel(null);
    setShowCancelModal(false);
    setCancellationReason("");
  };

  const handleCancelBooking = async () => {
    if (!bookingToCancel) return;

    try {
      setCancelling(true);
      setError("");

      await bookingAPI.cancelBooking(bookingToCancel.id, {
        cancellationReason: cancellationReason.trim() || null,
      });

      setSuccess("Lab session cancelled successfully!");
      setTimeout(() => setSuccess(""), 5000);

      closeCancelModal();
      closeDetailsModal();
      loadBookings();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to cancel booking. Please try again.",
      );
      console.error("Cancel booking error:", err);
      setTimeout(() => setError(""), 5000);
    } finally {
      setCancelling(false);
    }
  };

  const canCancelBooking = (booking) => {
    if (booking.status !== "CONFIRMED") {
      return false;
    }
    return new Date(booking.startDate) > new Date();
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "CONFIRMED":
        return "bg-green-100 text-green-800";
      case "COMPLETED":
        return "bg-blue-100 text-blue-800";
      case "CANCELLED":
        return "bg-red-100 text-red-800";
      case "ABSENT":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const isUpcoming = (dateString) => {
    return new Date(dateString) > new Date();
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="lab-sessions" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              My Lab Sessions
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              View your scheduled lab sessions and equipment reservations.
            </p>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}
          {success && <Alert type="success">{success}</Alert>}

          {/* Filters */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="status"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Status
                </label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="CONFIRMED">Confirmed</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="CANCELLED">Cancelled</option>
                  <option value="ABSENT">Absent</option>
                </select>
              </div>
              <div className="flex items-end">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={upcomingOnly}
                    onChange={(e) => setUpcomingOnly(e.target.checked)}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <span className="text-sm text-slate-700">
                    Show upcoming sessions only
                  </span>
                </label>
              </div>
            </div>
          </section>

          {/* Bookings List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading lab sessions...
              </span>
            </div>
          ) : bookings.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No lab sessions found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                {upcomingOnly
                  ? "You don't have any upcoming lab sessions scheduled."
                  : "You don't have any lab sessions."}
              </p>
              <div className="mt-6">
                <a
                  href="/projects"
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  View My Projects
                </a>
              </div>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              <ul className="divide-y divide-slate-200">
                {bookings.map((booking) => (
                  <li key={booking.id}>
                    <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-lg font-medium text-indigo-600">
                                {booking.project.name}
                              </p>
                              <p className="text-sm text-gray-900 mt-1">
                                {booking.lab.name} - {booking.lab.location}{" "}
                              </p>
                            </div>
                            <div className="ml-2 flex-shrink-0">
                              <span
                                className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(
                                  booking.status,
                                )}`}
                              >
                                {booking.status === "ABSENT"
                                  ? "Absent"
                                  : booking.status}
                              </span>
                            </div>
                          </div>

                          <div className="mt-2 sm:flex sm:justify-between">
                            <div className="sm:flex">
                              <p className="flex items-center text-sm text-gray-500">
                                {formatDate(booking.startDate)}
                              </p>
                              <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                {formatDateTime(booking.startDate)} -{" "}
                                {formatDateTime(booking.endDate)}
                              </p>
                            </div>
                            {isUpcoming(booking.startDate) && (
                              <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-100 text-indigo-800">
                                  Upcoming
                                </span>
                              </div>
                            )}
                          </div>

                          {/* Lab Mentor Info */}
                          {booking.labMentor && (
                            <div className="mt-2">
                              <p className="text-sm text-gray-500">
                                <span className="font-medium">Lab Mentor:</span>{" "}
                                {booking.labMentor.name}
                              </p>
                            </div>
                          )}

                          {/* Equipment Preview */}
                          {booking.equipment &&
                            booking.equipment.length > 0 && (
                              <div className="mt-2">
                                <p className="text-sm text-gray-500">
                                  <span className="font-medium">
                                    Equipment:
                                  </span>{" "}
                                  {booking.equipment
                                    .slice(0, 3)
                                    .map((e) => e.name)
                                    .join(", ")}
                                  {booking.equipment.length > 3 &&
                                    ` +${booking.equipment.length - 3} more`}
                                </p>
                              </div>
                            )}

                          {/* Notes Preview */}
                          {booking.notes && (
                            <div className="mt-2">
                              <p className="text-sm text-gray-500 italic">
                                "{booking.notes.substring(0, 100)}
                                {booking.notes.length > 100 ? "..." : ""}"
                              </p>
                            </div>
                          )}
                        </div>

                        {/* View Details Button */}
                        <div className="ml-4">
                          <button
                            onClick={() => openDetailsModal(booking)}
                            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                          >
                            View Details
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </main>

      {/* Details Modal */}
      {showDetailsModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-3xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Lab Session Details
                </h3>
                <button
                  onClick={closeDetailsModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                {/* Project Info */}
                <div className="border-b border-gray-200 pb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Project
                  </h4>
                  <p className="text-lg text-indigo-600">
                    {selectedBooking.project.name}
                  </p>
                </div>

                {/* Date and Time */}
                <div className="border-b border-gray-200 pb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Session Date & Time
                  </h4>
                  <p className="text-sm text-gray-700">
                    <strong>Date:</strong>{" "}
                    {formatDate(selectedBooking.startDate)}
                  </p>
                  <p className="text-sm text-gray-700">
                    <strong>Time:</strong>{" "}
                    {formatDateTime(selectedBooking.startDate)} -{" "}
                    {formatDateTime(selectedBooking.endDate)}
                  </p>
                </div>

                {/* Lab Info */}
                <div className="border-b border-gray-200 pb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Lab Location
                  </h4>
                  <p className="text-sm text-gray-700">
                    {selectedBooking.lab.name}
                  </p>
                  <p className="text-sm text-gray-500">
                    {selectedBooking.lab.location}
                  </p>
                </div>

                {/* Lab Mentor */}
                {selectedBooking.labMentor && (
                  <div className="border-b border-gray-200 pb-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">
                      Lab Mentor
                    </h4>
                    <p className="text-sm text-gray-700">
                      {selectedBooking.labMentor.name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {selectedBooking.labMentor.email}
                    </p>
                  </div>
                )}

                {/* Equipment List */}
                {selectedBooking.equipment &&
                  selectedBooking.equipment.length > 0 && (
                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="text-sm font-medium text-gray-900 mb-2">
                        Reserved Equipment
                      </h4>
                      <ul className="list-disc list-inside space-y-1">
                        {selectedBooking.equipment.map((equip) => (
                          <li key={equip.id} className="text-sm text-gray-700">
                            {equip.name}
                            {equip.description && (
                              <span className="text-gray-500">
                                {" "}
                                - {equip.description}
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                {/* Status */}
                <div className="border-b border-gray-200 pb-4">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Status
                  </h4>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeColor(
                        selectedBooking.status,
                      )}`}
                    >
                      {selectedBooking.status === "ABSENT"
                        ? "Absent"
                        : selectedBooking.status}
                    </span>
                    {selectedBooking.status === "CANCELLED" &&
                      selectedBooking.cancelledBy && (
                        <span className="text-sm text-gray-600">
                          {selectedBooking.cancelledBy === user.userId
                            ? "• Cancelled by you"
                            : "• Cancelled by staff"}
                        </span>
                      )}
                    {selectedBooking.status === "ABSENT" && (
                      <span className="text-sm text-gray-600">
                        Marked by Admin
                      </span>
                    )}
                  </div>
                </div>

                {/* Notes */}
                {selectedBooking.notes && (
                  <div className="border-b border-gray-200 pb-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">
                      Notes
                    </h4>
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {selectedBooking.notes}
                    </p>
                  </div>
                )}

                {/* Cancellation Reason */}
                {selectedBooking.status === "CANCELLED" &&
                  selectedBooking.cancellationReason && (
                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="text-sm font-medium text-gray-900 mb-2">
                        Cancellation Reason
                      </h4>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">
                        {selectedBooking.cancellationReason}
                      </p>
                    </div>
                  )}

                {/* Booking Date */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">
                    Booking Created
                  </h4>
                  <p className="text-sm text-gray-500">
                    {new Date(selectedBooking.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                {canCancelBooking(selectedBooking) && (
                  <button
                    onClick={() => openCancelModal(selectedBooking)}
                    className="flex-1 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    Cancel Session
                  </button>
                )}
                <button
                  onClick={closeDetailsModal}
                  className={`px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 ${
                    canCancelBooking(selectedBooking) ? "flex-1" : "w-full"
                  }`}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Booking Modal */}
      {showCancelModal && bookingToCancel && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Cancel Lab Session
                </h3>
                <button
                  onClick={closeCancelModal}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={cancelling}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                {/* Warning */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                  <p className="text-sm text-yellow-800">
                    <strong>Warning:</strong> This action cannot be undone. The
                    time slot will be released and made available for other
                    students.
                  </p>
                </div>

                {/* Booking Details */}
                <div className="bg-gray-50 rounded-md p-3">
                  <p className="text-sm text-gray-700">
                    <strong>Project:</strong> {bookingToCancel.project.name}
                  </p>
                  <p className="text-sm text-gray-700 mt-1">
                    <strong>Date:</strong>{" "}
                    {formatDate(bookingToCancel.startDate)}
                  </p>
                  <p className="text-sm text-gray-700 mt-1">
                    <strong>Time:</strong>{" "}
                    {formatDateTime(bookingToCancel.startDate)} -{" "}
                    {formatDateTime(bookingToCancel.endDate)}
                  </p>
                  <p className="text-sm text-gray-700 mt-1">
                    <strong>Lab:</strong> {bookingToCancel.lab.name}
                  </p>
                </div>

                {/* Cancellation Reason */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Reason for Cancellation (Optional)
                  </label>
                  <textarea
                    value={cancellationReason}
                    onChange={(e) => setCancellationReason(e.target.value)}
                    placeholder="Please share why you're cancelling this session..."
                    rows={4}
                    maxLength={500}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-red-500 focus:border-red-500"
                    disabled={cancelling}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {cancellationReason.length}/500 characters
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={closeCancelModal}
                  disabled={cancelling}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50"
                >
                  Keep Session
                </button>
                <button
                  onClick={handleCancelBooking}
                  disabled={cancelling}
                  className="flex-1 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
                >
                  {cancelling ? "Cancelling..." : "Cancel Session"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LabSessions;
