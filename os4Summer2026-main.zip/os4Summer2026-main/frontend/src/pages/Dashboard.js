import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { adminAPI, memberAPI, labAgreementAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import LabAgreementModal from "../components/LabAgreementModal";
import {
  formatDate,
  formatDateTime,
  formatTime,
  getStatusColor,
  getStatusLabel,
} from "../services/utils";

function Dashboard() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // Admin dashboard state
  const [adminStats, setAdminStats] = useState(null);
  const [recentProjects, setRecentProjects] = useState([]);

  // Member dashboard state
  const [memberStats, setMemberStats] = useState(null);
  const [memberProposals, setMemberProposals] = useState([]);
  const [memberBookings, setMemberBookings] = useState([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [unsignedLabAgreements, setUnsignedLabAgreements] = useState([]);
  const [loadingAgreements, setLoadingAgreements] = useState(false);
  const [showLabAgreementModal, setShowLabAgreementModal] = useState(false);
  const [selectedLabAgreement, setSelectedLabAgreement] = useState(null);
  const [agreementFiles, setAgreementFiles] = useState([]);
  const [signingAgreement, setSigningAgreement] = useState(false);

  // Check if user has admin privileges
  const normalizedRole = String(user?.role || "").toUpperCase();
  const isEmployeeUser =
    normalizedRole === "ADMIN" ||
    normalizedRole === "SUPERVISOR" ||
    normalizedRole === "PEER_MENTOR";
  const canViewAdminDashboard = isEmployeeUser;

  // View toggle state (only for employees)
  const [view, setView] = useState(
    canViewAdminDashboard ? "admin" : "personal",
  ); // "admin" or "personal"

  useEffect(() => {
    if (canViewAdminDashboard) {
      if (view === "admin") {
        loadAdminData();
      } else {
        loadMemberData();
        loadUnsignedLabAgreements();
      }
    } else {
      loadMemberData();
      loadUnsignedLabAgreements();
    }
  }, [canViewAdminDashboard, view]);

  const loadAdminData = async () => {
    try {
      setLoading(true);

      const [statsResponse, recentResponse] = await Promise.all([
        adminAPI.getProjectStats(),
        adminAPI.getRecentProjects(),
      ]);

      setAdminStats(statsResponse.data.stats);
      setRecentProjects(recentResponse.data.projects);
    } catch (err) {
      setError("Failed to load admin data");
      console.error("Admin data loading error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadMemberData = async () => {
    try {
      setLoading(true);

      const [statsResponse, proposalsResponse, bookingsResponse] =
        await Promise.all([
          memberAPI.getMemberStats(),
          memberAPI.getRecentProposals(),
          memberAPI.getUpcomingBookings(),
        ]);

      setMemberStats(statsResponse.data.stats);
      setMemberProposals(proposalsResponse.data.proposals);
      setMemberBookings(bookingsResponse.data.bookings);
    } catch (err) {
      setError("Failed to load dashboard data");
      console.error("Member data loading error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadUnsignedLabAgreements = async () => {
    try {
      setLoadingAgreements(true);
      const response = await labAgreementAPI.getUnsignedAgreements();
      setUnsignedLabAgreements(response.data.unsignedAgreements);
    } catch (err) {
      console.error("Load unsigned lab agreements error:", err);
    } finally {
      setLoadingAgreements(false);
    }
  };

  const openLabAgreementModal = async (labAgreement) => {
    setSelectedLabAgreement(labAgreement);
    setShowLabAgreementModal(true);

    try {
      const response = await labAgreementAPI.getLabAgreementStatus(
        labAgreement.labId,
      );
      setAgreementFiles(response.data.files || []);
    } catch (err) {
      console.error("Load lab agreement files error:", err);
      setAgreementFiles([]);
    }
  };

  const closeLabAgreementModal = () => {
    setShowLabAgreementModal(false);
    setSelectedLabAgreement(null);
    setAgreementFiles([]);
  };

  const handleSignLabAgreement = async () => {
    if (!selectedLabAgreement) return;

    try {
      setSigningAgreement(true);

      await labAgreementAPI.signLabAgreement(selectedLabAgreement.labId);

      setSuccess("Lab agreement signed successfully!");
      setTimeout(() => setSuccess(""), 3000);

      // Reload unsigned agreements
      await loadUnsignedLabAgreements();
      closeLabAgreementModal();

      // Reload member data if in personal view
      if (!isEmployeeUser || view === "personal") {
        loadMemberData();
      }
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to sign agreement. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Sign lab agreement error:", err);
    } finally {
      setSigningAgreement(false);
    }
  };

  const getConsultationDateTime = (consultation) => {
    if (!consultation?.date || !consultation?.startTime) return null;

    const normalizedDate = String(consultation.date).split("T")[0];
    const dateTime = new Date(`${normalizedDate}T${consultation.startTime}`);
    return Number.isNaN(dateTime.getTime()) ? null : dateTime;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="dashboard" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Error Alert */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* View Toggle - Only for Employees */}
          {canViewAdminDashboard && (
            <div className="flex justify-center">
              <div className="inline-flex rounded-lg border border-slate-200 bg-white p-1 shadow-sm">
                <button
                  onClick={() => setView("admin")}
                  className={`px-6 py-2 text-sm font-medium rounded-md transition-colors ${
                    view === "admin"
                      ? "bg-indigo-600 text-white"
                      : "text-slate-700 hover:text-indigo-600"
                  }`}
                >
                  Staff View
                </button>
                <button
                  onClick={() => setView("personal")}
                  className={`px-6 py-2 text-sm font-medium rounded-md transition-colors ${
                    view === "personal"
                      ? "bg-indigo-600 text-white"
                      : "text-slate-700 hover:text-indigo-600"
                  }`}
                >
                  My Activity
                </button>
              </div>
            </div>
          )}

          {/* Admin/Staff Dashboard */}
          {canViewAdminDashboard && view === "admin" ? (
            <div className="space-y-6">
              {/* Page Header */}
              <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="min-w-0">
                    <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                      {user.role
                        .toLowerCase()
                        .split("_")
                        .map(
                          (word) =>
                            word.charAt(0).toUpperCase() + word.slice(1),
                        )
                        .join(" ")}{" "}
                      Dashboard
                    </h2>
                    <p className="mt-2 text-sm text-blue-100">
                      Manage and review project proposals across the system.
                    </p>
                  </div>
                  <div className="flex">
                    <button
                      onClick={() => navigate("/admin-review")}
                      className="inline-flex items-center rounded-lg border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/40"
                    >
                      Review Projects
                    </button>
                  </div>
                </div>
              </section>

              {/* Statistics Cards */}
              {loading ? (
                <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
                  <Spinner />
                  <span className="ml-2 text-sm text-slate-600">
                    Loading dashboard data...
                  </span>
                </div>
              ) : (
                adminStats && (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-6">
                    {/* Total Projects */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Total Projects
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.total}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* In Process */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Awaiting Review
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.inProcess}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Consultation Cancelled */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-red-600 truncate">
                                Cancelled
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.consultationCancelled || 0}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Consultation Absent */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-orange-600 truncate">
                                Absent
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.consultationAbsent || 0}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Approved */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Approved
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.approved}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Declined */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Declined
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.declined}
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Approval Rate */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="p-5">
                        <div className="flex items-center">
                          <div className="ml-1 w-0 flex-1">
                            <dl>
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Approval Rate
                              </dt>
                              <dd className="text-lg font-medium text-gray-900">
                                {adminStats.approvalRate}%
                              </dd>
                            </dl>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              )}

              {/* Recent Projects Awaiting Review */}
              <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="px-4 py-5 sm:p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">
                      Recent Projects Awaiting Review
                    </h3>
                    <button
                      onClick={() => navigate("/admin-review")}
                      className="text-sm text-indigo-600 hover:text-indigo-500"
                    >
                      View all
                    </button>
                  </div>

                  {recentProjects.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">
                      No projects awaiting review
                    </p>
                  ) : (
                    <div className="flow-root">
                      <ul className="-my-5 divide-y divide-gray-200">
                        {recentProjects.slice(0, 5).map((project) => (
                          <li key={project.id} className="py-4">
                            <div className="flex items-center space-x-4">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {project.name}
                                </p>
                                <p className="text-sm text-gray-500">
                                  by {project.user} • {project.lab} •{" "}
                                  {formatDate(project.createdAt)}
                                </p>
                              </div>
                              <div className="flex-shrink-0">
                                <span
                                  className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                    project.status,
                                  )}`}
                                >
                                  {project.status === "IN_PROCESS"
                                    ? "Awaiting Review"
                                    : project.status}
                                </span>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="px-4 py-5 sm:p-6">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                    Quick Actions
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <button
                      onClick={() => navigate("/admin-review?filter=approved")}
                      className="flex items-center p-4 border border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors"
                    >
                      <div className="ml-3 text-left">
                        <p className="text-sm font-medium text-gray-900">
                          View Approved
                        </p>
                        <p className="text-xs text-gray-500">
                          See all approved projects
                        </p>
                      </div>
                    </button>

                    <button
                      onClick={() => navigate("/admin-review?filter=declined")}
                      className="flex items-center p-4 border border-gray-300 rounded-lg hover:border-red-500 hover:bg-red-50 transition-colors"
                    >
                      <div className="ml-3 text-left">
                        <p className="text-sm font-medium text-gray-900">
                          View Declined
                        </p>
                        <p className="text-xs text-gray-500">
                          See all declined projects
                        </p>
                      </div>
                    </button>

                    <button
                      onClick={() =>
                        navigate("/admin-review?filter=in_process")
                      }
                      className="flex items-center p-4 border border-gray-300 rounded-lg hover:border-yellow-500 hover:bg-yellow-50 transition-colors"
                    >
                      <div className="ml-3 text-left">
                        <p className="text-sm font-medium text-gray-900">
                          View Pending
                        </p>
                        <p className="text-xs text-gray-500">
                          See projects awaiting review
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Personal/Member Dashboard (for employees in personal view OR regular members) */
            <div className="space-y-6">
              {/* Page Header */}
              <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
                <div className="min-w-0">
                  <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                    My Dashboard
                  </h2>
                  <p className="mt-2 text-sm text-blue-100">
                    Track your project proposals and lab bookings
                  </p>
                </div>
              </section>

              {/* Member Agreement Warning */}
              {memberStats && !memberStats.agreement.signed && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex">
                    <div className="flex-1">
                      <h3 className="text-sm font-medium text-yellow-800">
                        Action Required: Sign Member Agreement
                      </h3>
                      <p className="mt-1 text-sm text-yellow-700">
                        You must sign the member agreement before submitting
                        project proposals.
                        {memberStats.agreement.cancellations > 0 && (
                          <span className="block mt-1">
                            Previous cancellations:{" "}
                            {memberStats.agreement.cancellations}
                          </span>
                        )}
                      </p>
                      <button
                        onClick={() => navigate("/member-agreement")}
                        className="mt-3 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 text-sm font-medium"
                      >
                        Sign Agreement
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Unsigned Lab Agreements Warning */}
              {!loadingAgreements && unsignedLabAgreements.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex">
                    <div className="ml-3 flex-1">
                      <h3 className="text-sm font-medium text-red-800">
                        Lab Agreement
                        {unsignedLabAgreements.length > 1 ? "s" : ""} Required
                      </h3>
                      <div className="mt-2 text-sm text-red-700">
                        <p className="mb-2">
                          You must sign lab agreement
                          {unsignedLabAgreements.length > 1 ? "s" : ""} for the
                          following lab
                          {unsignedLabAgreements.length > 1 ? "s" : ""} before
                          your scheduled sessions:
                        </p>
                        <ul className="list-disc list-inside space-y-1">
                          {unsignedLabAgreements.map((agreement) => (
                            <li key={agreement.labId}>
                              <strong>{agreement.labName}</strong> (
                              {agreement.labLocation})
                              {agreement.hasBookings &&
                                agreement.nextBooking && (
                                  <span className="ml-2 text-xs">
                                    • Next session:{" "}
                                    {new Date(
                                      agreement.nextBooking,
                                    ).toLocaleDateString()}
                                  </span>
                                )}
                              <button
                                onClick={() => openLabAgreementModal(agreement)}
                                className="ml-2 text-xs underline hover:text-red-900"
                              >
                                Sign Now
                              </button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Loading State */}
              {loading ? (
                <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
                  <Spinner />
                  <span className="ml-2 text-sm text-slate-600">
                    Loading dashboard data...
                  </span>
                </div>
              ) : (
                memberStats && (
                  <>
                    {/* Statistics Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="p-5">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Total Proposals
                              </dt>
                              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                                {memberStats.proposals.total}
                              </dd>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="p-5">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Under Review
                              </dt>
                              <dd className="mt-1 text-3xl font-semibold text-yellow-600">
                                {memberStats.proposals.inProcess}
                              </dd>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="p-5">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Approved
                              </dt>
                              <dd className="mt-1 text-3xl font-semibold text-green-600">
                                {memberStats.proposals.approved}
                              </dd>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="p-5">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Upcoming Sessions
                              </dt>
                              <dd className="mt-1 text-3xl font-semibold text-indigo-600">
                                {memberStats.bookings.upcoming}
                              </dd>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="p-5">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <dt className="text-sm font-medium text-gray-500 truncate">
                                Upcoming Consultations
                              </dt>
                              <dd className="mt-1 text-3xl font-semibold text-purple-600">
                                {(() => {
                                  let count = 0;
                                  const now = new Date();
                                  memberProposals.forEach((proposal) => {
                                    if (
                                      proposal.consultations &&
                                      Array.isArray(proposal.consultations)
                                    ) {
                                      proposal.consultations.forEach(
                                        (consultation) => {
                                          if (
                                            consultation.status ===
                                              "SCHEDULED" &&
                                            consultation.date
                                          ) {
                                            const consultationDate =
                                              getConsultationDateTime(
                                                consultation,
                                              );
                                            if (consultationDate > now) {
                                              count++;
                                            }
                                          }
                                        },
                                      );
                                    }
                                  });
                                  return count;
                                })()}
                              </dd>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="px-4 py-5 sm:p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Recent Proposals
                          </h3>
                          <button
                            onClick={() => navigate("/projects")}
                            className="text-sm text-indigo-600 hover:text-indigo-500"
                          >
                            View all
                          </button>
                        </div>

                        {memberProposals.length === 0 ? (
                          <div className="text-center py-8">
                            <p className="text-gray-500 mb-4">
                              You haven't submitted any proposals yet
                            </p>
                          </div>
                        ) : (
                          <div className="flow-root">
                            <ul className="-my-5 divide-y divide-gray-200">
                              {memberProposals.map((proposal) => (
                                <li key={proposal.id} className="py-4">
                                  <div className="flex items-center justify-between">
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-medium text-gray-900 truncate">
                                        {proposal.name}
                                      </p>
                                      <p className="text-sm text-gray-500">
                                        {proposal.labName} -{" "}
                                        {formatDate(proposal.createdAt)}
                                      </p>
                                    </div>
                                    <div className="ml-4 flex-shrink-0 flex items-center space-x-2">
                                      <span
                                        className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                          proposal.status,
                                        )}`}
                                      >
                                        {getStatusLabel(proposal.status)}
                                      </span>
                                    </div>
                                  </div>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Upcoming Consultations Section */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="px-4 py-5 sm:p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Upcoming Consultations
                          </h3>
                          <button
                            onClick={() => navigate("/projects")}
                            className="text-sm text-indigo-600 hover:text-indigo-500"
                          >
                            View all
                          </button>
                        </div>

                        {(() => {
                          const allConsultations = [];
                          memberProposals.forEach((proposal) => {
                            if (
                              proposal.consultations &&
                              Array.isArray(proposal.consultations)
                            ) {
                              proposal.consultations.forEach((consultation) => {
                                if (
                                  consultation.status === "SCHEDULED" &&
                                  consultation.date
                                ) {
                                  allConsultations.push({
                                    ...consultation,
                                    projectName: proposal.name,
                                    projectId: proposal.id,
                                    labName: proposal.labName,
                                  });
                                }
                              });
                            }
                          });

                          allConsultations.sort((a, b) => {
                            const dateA = getConsultationDateTime(a);
                            const dateB = getConsultationDateTime(b);
                            if (!dateA && !dateB) return 0;
                            if (!dateA) return 1;
                            if (!dateB) return -1;
                            return dateA - dateB;
                          });

                          const now = new Date();
                          const upcomingConsultations = allConsultations.filter(
                            (consultation) => {
                              const consultationDate =
                                getConsultationDateTime(consultation);
                              return consultationDate > now;
                            },
                          );

                          if (upcomingConsultations.length === 0) {
                            return (
                              <p className="text-gray-500 text-center py-4">
                                No upcoming consultations scheduled
                              </p>
                            );
                          }

                          return (
                            <div className="space-y-3">
                              {upcomingConsultations
                                .slice(0, 5)
                                .map((consultation, index) => (
                                  <div
                                    key={`${consultation.projectId}-${consultation.id}`}
                                    className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors cursor-pointer"
                                    onClick={() => navigate("/projects")}
                                  >
                                    <div className="flex items-start justify-between mb-2">
                                      <div className="flex-1">
                                        <p className="text-sm font-medium text-gray-900">
                                          {consultation.projectName}
                                        </p>
                                        <p className="text-xs text-gray-500 mt-0.5">
                                          {consultation.labName}
                                        </p>
                                      </div>
                                      <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                                        Scheduled
                                      </span>
                                    </div>

                                    <div className="flex items-center justify-between text-sm mt-2">
                                      <div className="flex items-center text-gray-600">
                                        <span className="font-medium">📅</span>
                                        <span className="ml-1.5">
                                          {formatDate(consultation.date)}
                                        </span>
                                      </div>
                                      <div className="flex items-center text-gray-600">
                                        <span className="font-medium">🕐</span>
                                        <span className="ml-1.5">
                                          {formatTime(consultation.startTime)}
                                        </span>
                                      </div>
                                    </div>

                                    {consultation.mentor && (
                                      <div className="mt-2 pt-2 border-t border-gray-100">
                                        <p className="text-xs text-gray-500">
                                          Peer Mentor:{" "}
                                          <span className="font-medium text-gray-700">
                                            {consultation.mentor}
                                          </span>
                                        </p>
                                      </div>
                                    )}
                                  </div>
                                ))}

                              {upcomingConsultations.length > 5 && (
                                <p className="text-xs text-center text-gray-500 pt-2">
                                  +{upcomingConsultations.length - 5} more
                                  consultation
                                  {upcomingConsultations.length - 5 > 1
                                    ? "s"
                                    : ""}
                                </p>
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="px-4 py-5 sm:p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Upcoming Lab Sessions
                          </h3>
                          <button
                            onClick={() => navigate("/lab-sessions")}
                            className="text-sm text-indigo-600 hover:text-indigo-500"
                          >
                            View all
                          </button>
                        </div>

                        {memberBookings.length === 0 ? (
                          <p className="text-gray-500 text-center py-4">
                            No upcoming lab sessions scheduled
                          </p>
                        ) : (
                          <div className="space-y-4">
                            {memberBookings.map((booking) => (
                              <div
                                key={booking.id}
                                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <div>
                                    <p className="text-sm font-medium text-gray-900">
                                      {booking.projectName}
                                    </p>
                                    <p className="text-sm text-gray-500">
                                      {booking.labName} - {booking.labLocation}
                                    </p>
                                  </div>
                                  <span
                                    className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                      booking.status,
                                    )}`}
                                  >
                                    {getStatusLabel(booking.status)}
                                  </span>
                                </div>
                                <div className="flex items-center justify-between text-sm">
                                  <span className="text-gray-600">
                                    {formatDateTime(booking.startDate)} -{" "}
                                    {formatDateTime(booking.endDate)}
                                  </span>
                                  {booking.equipment.length > 0 && (
                                    <span className="text-gray-500">
                                      {booking.equipment.length} equipment
                                      item(s)
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                      <div className="px-4 py-5 sm:p-6">
                        <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                          Quick Actions
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <button
                            onClick={() => navigate("/projects")}
                            className="flex items-center p-4 border border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                          >
                            <div className="text-left">
                              <p className="text-sm font-medium text-gray-900">
                                My Proposals
                              </p>
                              <p className="text-xs text-gray-500">
                                View all your projects
                              </p>
                            </div>
                          </button>

                          <button
                            onClick={() => navigate("/lab-sessions")}
                            className="flex items-center p-4 border border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors"
                          >
                            <div className="text-left">
                              <p className="text-sm font-medium text-gray-900">
                                Lab Sessions
                              </p>
                              <p className="text-xs text-gray-500">
                                View your bookings
                              </p>
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )
              )}
            </div>
          )}
        </div>
      </main>

      {/* Lab Agreement Modal – shared component */}
      {showLabAgreementModal && selectedLabAgreement && (
        <LabAgreementModal
          labId={selectedLabAgreement.labId}
          labName={selectedLabAgreement.labName}
          labLocation={selectedLabAgreement.labLocation}
          files={agreementFiles}
          isSigned={false}
          nextBooking={
            selectedLabAgreement.hasBookings
              ? selectedLabAgreement.nextBooking
              : null
          }
          isUrgent={true}
          signing={signingAgreement}
          onSign={handleSignLabAgreement}
          onClose={closeLabAgreementModal}
        />
      )}
    </div>
  );
}

export default Dashboard;
