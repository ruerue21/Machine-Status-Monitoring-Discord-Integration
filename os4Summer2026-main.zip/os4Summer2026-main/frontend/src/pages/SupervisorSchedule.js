import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { adminAPI, labAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { formatTime, getDayDisplayName, DAYS_OF_WEEK } from "../services/utils";

const HOUR_OPTIONS = Array.from({ length: 12 }, (_, index) =>
  String(index + 1),
);
const MINUTE_OPTIONS = Array.from({ length: 60 }, (_, index) =>
  String(index).padStart(2, "0"),
);
const PERIOD_OPTIONS = ["AM", "PM"];

function to12HourParts(timeValue) {
  if (!timeValue || !String(timeValue).includes(":")) {
    return { hour: "", minute: "", period: "" };
  }

  const [hourString, minuteString] = String(timeValue).split(":");
  const parsedHour = Number.parseInt(hourString, 10);
  const parsedMinute = Number.parseInt(minuteString, 10);

  if (!Number.isInteger(parsedHour) || parsedHour < 0 || parsedHour > 23) {
    return { hour: "", minute: "", period: "" };
  }

  const minute =
    Number.isInteger(parsedMinute) && parsedMinute >= 0 && parsedMinute <= 59
      ? String(parsedMinute).padStart(2, "0")
      : "00";
  const period = parsedHour >= 12 ? "PM" : "AM";
  const hour12 = parsedHour % 12 === 0 ? 12 : parsedHour % 12;

  return {
    hour: String(hour12),
    minute,
    period,
  };
}

function to24HourValue(hour12Value, minuteValue, periodValue) {
  if (!hour12Value || !minuteValue || !periodValue) {
    return "";
  }

  const parsedHour12 = Number.parseInt(hour12Value, 10);
  const safeHour12 =
    Number.isInteger(parsedHour12) && parsedHour12 >= 1 && parsedHour12 <= 12
      ? parsedHour12
      : 0;
  if (!safeHour12) {
    return "";
  }

  const parsedMinute = Number.parseInt(minuteValue, 10);
  const safeMinute =
    Number.isInteger(parsedMinute) && parsedMinute >= 0 && parsedMinute <= 59
      ? parsedMinute
      : 0;

  const safePeriod =
    periodValue === "PM" || periodValue === "AM" ? periodValue : "";
  if (!safePeriod) {
    return "";
  }

  let hour24 = safeHour12 % 12;
  if (safePeriod === "PM") {
    hour24 += 12;
  }

  return `${String(hour24).padStart(2, "0")}:${String(safeMinute).padStart(2, "0")}`;
}

function createEditableSlot(slot = {}) {
  const startParts = to12HourParts(slot.startTime);
  const endParts = to12HourParts(slot.endTime);

  return {
    startHour: startParts.hour,
    startMinute: startParts.minute,
    startPeriod: startParts.period,
    endHour: endParts.hour,
    endMinute: endParts.minute,
    endPeriod: endParts.period,
    startTime:
      slot.startTime ||
      to24HourValue(startParts.hour, startParts.minute, startParts.period),
    endTime:
      slot.endTime ||
      to24HourValue(endParts.hour, endParts.minute, endParts.period),
  };
}

function toEditableSchedule(schedule = {}) {
  const editable = {};
  DAYS_OF_WEEK.forEach((day) => {
    editable[day] = (schedule[day] || []).map((slot) =>
      createEditableSlot(slot),
    );
  });
  return editable;
}

function SupervisorSchedule() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // State management
  const [supervisors, setSupervisors] = useState([]);
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Filter and search states
  const [searchTerm, setSearchTerm] = useState("");

  // Schedule editing states
  const [selectedSupervisor, setSelectedSupervisor] = useState(null);
  const [selectedLab, setSelectedLab] = useState(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleData, setScheduleData] = useState(null);
  const [loadingSchedule, setLoadingSchedule] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState({});
  const [submittingSchedule, setSubmittingSchedule] = useState(false);

  // Lab selection modal state
  const [showAddLabModal, setShowAddLabModal] = useState(false);
  const [selectedSupervisorForLabAdd, setSelectedSupervisorForLabAdd] =
    useState(null);

  // Check if user has access
  const hasAccess = user?.role === "ADMIN";

  useEffect(() => {
    if (!hasAccess) {
      navigate("/dashboard");
      return;
    }
    loadSupervisors();
    loadLabs();
  }, [hasAccess, navigate]);

  useEffect(() => {
    if (hasAccess) {
      loadSupervisors();
    }
  }, [searchTerm, hasAccess]);

  const loadSupervisors = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchTerm,
      };

      const response = await adminAPI.getSupervisors(params);
      setSupervisors(response.data.supervisors);
    } catch (err) {
      setError("Failed to load supervisors. Please try again.");
      console.error("Load supervisors error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadLabs = async () => {
    try {
      const response = await labAPI.getAllLabs();
      setLabs(response.data.labs);
    } catch (err) {
      console.error("Load labs error:", err);
    }
  };

  const openScheduleModal = async (supervisor, lab) => {
    setSelectedSupervisor(supervisor);
    setSelectedLab(lab);
    setShowScheduleModal(true);
    setLoadingSchedule(true);
    setError("");

    try {
      const response = await adminAPI.getSupervisorScheduleForLab(
        supervisor.id,
        lab.labId,
      );
      setScheduleData(response.data);
      setEditingSchedule(
        toEditableSchedule(response.data.currentSchedule || {}),
      );
    } catch (err) {
      setError("Failed to load schedule for this lab.");
      console.error("Load schedule error:", err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  const openNewLabScheduleModal = async (supervisor, labId) => {
    const lab = labs.find((l) => l.id === labId);
    if (!lab) return;

    setSelectedSupervisor(supervisor);
    setSelectedLab({
      labId: lab.id,
      labName: lab.name,
      labLocation: lab.location,
      schedule: {},
      hasConfiguredSchedule: false,
      activeTimeSlotsCount: 0,
    });
    setShowScheduleModal(true);
    setLoadingSchedule(true);
    setError("");

    try {
      const response = await adminAPI.getSupervisorScheduleForLab(
        supervisor.id,
        lab.id,
      );
      setScheduleData(response.data);
      setEditingSchedule(
        toEditableSchedule(response.data.currentSchedule || {}),
      );
    } catch (err) {
      setError("Failed to load schedule for this lab.");
      console.error("Load schedule error:", err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  const closeScheduleModal = () => {
    setSelectedSupervisor(null);
    setSelectedLab(null);
    setShowScheduleModal(false);
    setScheduleData(null);
    setEditingSchedule({});
  };

  const addTimeSlot = (day) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: [...(prev[day] || []), createEditableSlot()],
    }));
  };

  const removeTimeSlot = (day, index) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: prev[day]?.filter((_, i) => i !== index) || [],
    }));
  };

  const updateTimeSlotPart = (day, index, boundary, part, value) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]:
        prev[day]?.map((slot, i) => {
          if (i !== index) return slot;

          const nextSlot = { ...slot };
          if (boundary === "start") {
            if (part === "hour") nextSlot.startHour = value;
            if (part === "minute") nextSlot.startMinute = value;
            if (part === "period") nextSlot.startPeriod = value;
            nextSlot.startTime = to24HourValue(
              nextSlot.startHour,
              nextSlot.startMinute,
              nextSlot.startPeriod,
            );
          } else {
            if (part === "hour") nextSlot.endHour = value;
            if (part === "minute") nextSlot.endMinute = value;
            if (part === "period") nextSlot.endPeriod = value;
            nextSlot.endTime = to24HourValue(
              nextSlot.endHour,
              nextSlot.endMinute,
              nextSlot.endPeriod,
            );
          }

          return nextSlot;
        }) || [],
    }));
  };

  const clearDaySchedule = (day) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: [],
    }));
  };

  const handleSaveSchedule = async () => {
    for (const day of DAYS_OF_WEEK) {
      const slots = editingSchedule[day] || [];
      for (let index = 0; index < slots.length; index += 1) {
        const slot = slots[index];
        if (!slot.startTime || !slot.endTime) {
          setError(
            `${getDayDisplayName(day)} slot ${index + 1} is incomplete. Please select start and end time.`,
          );
          return;
        }

        const [startHour, startMinute] = slot.startTime.split(":").map(Number);
        const [endHour, endMinute] = slot.endTime.split(":").map(Number);
        const startTotal = startHour * 60 + startMinute;
        const endTotal = endHour * 60 + endMinute;

        if (
          !Number.isFinite(startTotal) ||
          !Number.isFinite(endTotal) ||
          endTotal <= startTotal
        ) {
          setError(
            `${getDayDisplayName(day)} slot ${index + 1} has an invalid range. End time must be after start time.`,
          );
          return;
        }
      }
    }

    try {
      setSubmittingSchedule(true);
      setError("");

      const schedulePayload = {
        schedule: DAYS_OF_WEEK.reduce((acc, day) => {
          acc[day] = (editingSchedule[day] || []).map((slot) => ({
            startTime: slot.startTime,
            endTime: slot.endTime,
          }));
          return acc;
        }, {}),
      };

      const response = await adminAPI.updateSupervisorScheduleForLab(
        selectedSupervisor.id,
        selectedLab.labId,
        schedulePayload,
      );

      let message = response.data.message;
      if (response.data.warnings && response.data.warnings.length > 0) {
        message +=
          "\n\nUpdates:\n" +
          response.data.warnings.map((w) => `• ${w}`).join("\n");
      }

      setSuccess(message);
      setTimeout(() => setSuccess(""), 8000);
      closeScheduleModal();
      loadSupervisors();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update schedule. Please try again.",
      );
      console.error("Save schedule error:", err);
    } finally {
      setSubmittingSchedule(false);
    }
  };

  const getAvailableLabsForSupervisor = (supervisor) => {
    const assignedLabIds = supervisor.labs.map((l) => l.labId);
    return labs.filter((lab) => !assignedLabIds.includes(lab.id));
  };

  if (!hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="supervisor-schedule" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              Supervisor Schedule Management
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              Manage supervisor schedules per lab.
            </p>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Search */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <label
              htmlFor="search"
              className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
            >
              Search Supervisors
            </label>
            <input
              type="text"
              id="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name or email..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
            />
          </section>

          {/* Supervisors List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading supervisors...
              </span>
            </div>
          ) : supervisors.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No supervisors found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Try adjusting your search or promote some users to Supervisor
                first.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {supervisors.map((supervisor) => (
                <div
                  key={supervisor.id}
                  className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
                >
                  <div className="bg-slate-50 px-4 py-5 sm:px-6">
                    <h3 className="text-lg font-semibold text-slate-900">
                      {supervisor.name}
                    </h3>
                    <p className="mt-1 max-w-2xl text-sm text-slate-500">
                      {supervisor.email}
                    </p>
                  </div>

                  <div className="border-t border-slate-200">
                    <div className="px-4 py-5 sm:px-6">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="text-sm font-medium text-gray-900">
                          Lab Schedules ({supervisor.labs.length})
                        </h4>

                        {getAvailableLabsForSupervisor(supervisor).length >
                          0 && (
                          <button
                            onClick={() => {
                              setSelectedSupervisorForLabAdd(supervisor);
                              setShowAddLabModal(true);
                            }}
                            className="inline-flex items-center px-3 py-2 border border-green-300 shadow-sm text-sm leading-4 font-medium rounded-md text-green-700 bg-white hover:bg-green-50"
                          >
                            Add Schedule
                          </button>
                        )}
                      </div>

                      {supervisor.labs.length === 0 ? (
                        <p className="text-sm text-gray-500 italic">
                          No schedules configured. Click "Add Schedule" to
                          create one.
                        </p>
                      ) : (
                        <div className="space-y-4">
                          {supervisor.labs.map((lab) => (
                            <div
                              key={lab.labId}
                              className="border border-gray-200 rounded-lg p-4"
                            >
                              <div className="flex items-center justify-between mb-3">
                                <div>
                                  <p className="text-base font-medium text-gray-900">
                                    {lab.labName}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {lab.labLocation}
                                  </p>
                                  <div className="mt-1">
                                    <span
                                      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                                        lab.hasConfiguredSchedule &&
                                        "bg-green-100 text-green-800"
                                      }`}
                                    >
                                      {lab.hasConfiguredSchedule &&
                                        "Schedule Configured"}
                                    </span>
                                    <span className="ml-2 text-sm text-gray-500">
                                      {lab.activeTimeSlotsCount} active slots
                                    </span>
                                  </div>
                                </div>

                                <button
                                  onClick={() =>
                                    openScheduleModal(supervisor, lab)
                                  }
                                  className="inline-flex items-center px-3 py-2 border border-indigo-300 shadow-sm text-sm leading-4 font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                >
                                  {lab.hasConfiguredSchedule && "Edit Schedule"}
                                </button>
                              </div>

                              {/* Schedule Preview */}
                              {lab.schedule &&
                                Object.keys(lab.schedule).length > 0 && (
                                  <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
                                    <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-600">
                                      Current Schedule:
                                    </p>
                                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                      {DAYS_OF_WEEK.map((day) => (
                                        <div
                                          key={day}
                                          className="rounded border border-slate-200 bg-white p-2"
                                        >
                                          <p className="mb-1 text-xs font-semibold text-slate-700">
                                            {getDayDisplayName(day)}
                                          </p>
                                          {lab.schedule[day]?.length > 0 ? (
                                            <div className="flex flex-wrap gap-1">
                                              {lab.schedule[day].map(
                                                (slot, idx) => (
                                                  <span
                                                    key={idx}
                                                    className="inline-flex items-center rounded bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700"
                                                  >
                                                    {formatTime(slot.startTime)}{" "}
                                                    - {formatTime(slot.endTime)}
                                                  </span>
                                                ),
                                              )}
                                            </div>
                                          ) : (
                                            <span className="text-xs text-slate-400">
                                              No scheduled times
                                            </span>
                                          )}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Add Lab Modal */}
      {showAddLabModal && selectedSupervisorForLabAdd && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Add Schedule for {selectedSupervisorForLabAdd.name}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Select a lab to create a schedule
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowAddLabModal(false);
                    setSelectedSupervisorForLabAdd(null);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2 max-h-96 overflow-y-auto">
                {getAvailableLabsForSupervisor(selectedSupervisorForLabAdd).map(
                  (lab) => (
                    <button
                      key={lab.id}
                      onClick={() => {
                        openNewLabScheduleModal(
                          selectedSupervisorForLabAdd,
                          lab.id,
                        );
                        setShowAddLabModal(false);
                        setSelectedSupervisorForLabAdd(null);
                      }}
                      className="w-full text-left px-4 py-3 border border-gray-200 rounded-md hover:bg-indigo-50 hover:border-indigo-300 transition-colors"
                    >
                      <p className="font-medium text-gray-900">{lab.name}</p>
                      <p className="text-sm text-gray-600">{lab.location}</p>
                      {lab.description && (
                        <p className="text-xs text-gray-500 mt-1">
                          {lab.description}
                        </p>
                      )}
                    </button>
                  ),
                )}
              </div>

              <div className="mt-6">
                <button
                  onClick={() => {
                    setShowAddLabModal(false);
                    setSelectedSupervisorForLabAdd(null);
                  }}
                  className="w-full px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Modal */}
      {showScheduleModal && selectedSupervisor && selectedLab && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-8 mx-auto p-5 border max-w-6xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Supervisor Schedule - {selectedSupervisor.name}
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedLab.labName} - {selectedLab.labLocation}
                  </p>
                </div>
                <button
                  onClick={closeScheduleModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              {loadingSchedule ? (
                <div className="flex justify-center items-center p-8">
                  <Spinner />
                  <span className="ml-2">Loading schedule...</span>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Weekly Schedule Section */}
                  <div>
                    <h4 className="text-md font-medium text-gray-900 mb-3">
                      Weekly Schedule for {selectedLab.labName}
                    </h4>
                    <div className="space-y-4">
                      {DAYS_OF_WEEK.map((day) => (
                        <div
                          key={day}
                          className="border border-gray-200 rounded-lg p-4"
                        >
                          <div className="flex justify-between items-center mb-3">
                            <h5 className="font-medium text-gray-800">
                              {getDayDisplayName(day)}
                            </h5>
                            <div className="space-x-2">
                              <button
                                onClick={() => addTimeSlot(day)}
                                className="text-sm bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700"
                              >
                                Add Time
                              </button>
                              {editingSchedule[day]?.length > 0 && (
                                <button
                                  onClick={() => clearDaySchedule(day)}
                                  className="text-sm bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                                >
                                  Clear Day
                                </button>
                              )}
                            </div>
                          </div>

                          {editingSchedule[day]?.length > 0 ? (
                            <div className="space-y-2">
                              {editingSchedule[day].map((slot, index) => (
                                <div
                                  key={index}
                                  className="flex items-center space-x-3 bg-gray-50 p-2 rounded"
                                >
                                  <select
                                    value={slot.startHour || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "start",
                                        "hour",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      Hour
                                    </option>
                                    {HOUR_OPTIONS.map((option) => (
                                      <option
                                        key={`start-hour-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <span className="text-gray-500">:</span>
                                  <select
                                    value={slot.startMinute || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "start",
                                        "minute",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      Min
                                    </option>
                                    {MINUTE_OPTIONS.map((option) => (
                                      <option
                                        key={`start-minute-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <select
                                    value={slot.startPeriod || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "start",
                                        "period",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      AM/PM
                                    </option>
                                    {PERIOD_OPTIONS.map((option) => (
                                      <option
                                        key={`start-period-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <span className="text-gray-500">to</span>
                                  <select
                                    value={slot.endHour || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "end",
                                        "hour",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      Hour
                                    </option>
                                    {HOUR_OPTIONS.map((option) => (
                                      <option
                                        key={`end-hour-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <span className="text-gray-500">:</span>
                                  <select
                                    value={slot.endMinute || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "end",
                                        "minute",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      Min
                                    </option>
                                    {MINUTE_OPTIONS.map((option) => (
                                      <option
                                        key={`end-minute-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <select
                                    value={slot.endPeriod || ""}
                                    onChange={(e) =>
                                      updateTimeSlotPart(
                                        day,
                                        index,
                                        "end",
                                        "period",
                                        e.target.value,
                                      )
                                    }
                                    className="text-sm border border-gray-300 rounded px-2 py-1"
                                  >
                                    <option value="" disabled>
                                      AM/PM
                                    </option>
                                    {PERIOD_OPTIONS.map((option) => (
                                      <option
                                        key={`end-period-${option}`}
                                        value={option}
                                      >
                                        {option}
                                      </option>
                                    ))}
                                  </select>
                                  <button
                                    onClick={() => removeTimeSlot(day, index)}
                                    className="text-red-600 hover:text-red-800 text-lg font-bold"
                                  >
                                    ×
                                  </button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-gray-500 italic">
                              No times scheduled for this day
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Current Active Slots Info */}
                  {scheduleData?.totalActiveSlots > 0 && (
                    <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> This lab currently has{" "}
                        {scheduleData.totalActiveSlots} active time slots.
                        Updating will remove unbooked slots and generate new
                        ones.
                      </p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex space-x-3 pt-4 border-t">
                    <button
                      onClick={handleSaveSchedule}
                      disabled={submittingSchedule}
                      className="flex-1 px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {submittingSchedule
                        ? "Updating Schedule..."
                        : "Save Schedule"}
                    </button>
                    <button
                      onClick={closeScheduleModal}
                      disabled={submittingSchedule}
                      className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SupervisorSchedule;
