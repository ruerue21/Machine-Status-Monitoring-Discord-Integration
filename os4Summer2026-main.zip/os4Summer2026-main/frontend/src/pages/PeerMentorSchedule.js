import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { peerMentorScheduleAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { formatTime, getDayDisplayName, DAYS_OF_WEEK } from "../services/utils";

const HOUR_OPTIONS = Array.from({ length: 12 }, (_, index) =>
  String(index + 1),
);
const MINUTE_OPTIONS = Array.from({ length: 60 }, (_, index) =>
  String(index).padStart(2, "0"),
);
const PERIOD_OPTIONS = ["AM", "PM"];

function to12HourParts(timeValue) {
  if (!timeValue || !String(timeValue).includes(":")) {
    return { hour: "", minute: "", period: "" };
  }

  const [hourString, minuteString] = String(timeValue).split(":");
  const parsedHour = Number.parseInt(hourString, 10);
  const parsedMinute = Number.parseInt(minuteString, 10);

  if (!Number.isInteger(parsedHour) || parsedHour < 0 || parsedHour > 23) {
    return { hour: "", minute: "", period: "" };
  }

  const minute =
    Number.isInteger(parsedMinute) && parsedMinute >= 0 && parsedMinute <= 59
      ? String(parsedMinute).padStart(2, "0")
      : "00";
  const period = parsedHour >= 12 ? "PM" : "AM";
  const hour12 = parsedHour % 12 === 0 ? 12 : parsedHour % 12;

  return {
    hour: String(hour12),
    minute,
    period,
  };
}

function to24HourValue(hour12Value, minuteValue, periodValue) {
  if (!hour12Value || !minuteValue || !periodValue) {
    return "";
  }

  const parsedHour12 = Number.parseInt(hour12Value, 10);
  const safeHour12 =
    Number.isInteger(parsedHour12) && parsedHour12 >= 1 && parsedHour12 <= 12
      ? parsedHour12
      : 0;
  if (!safeHour12) {
    return "";
  }

  const parsedMinute = Number.parseInt(minuteValue, 10);
  const safeMinute =
    Number.isInteger(parsedMinute) && parsedMinute >= 0 && parsedMinute <= 59
      ? parsedMinute
      : 0;

  const safePeriod =
    periodValue === "PM" || periodValue === "AM" ? periodValue : "";
  if (!safePeriod) {
    return "";
  }
  let hour24 = safeHour12 % 12;
  if (safePeriod === "PM") {
    hour24 += 12;
  }

  return `${String(hour24).padStart(2, "0")}:${String(safeMinute).padStart(2, "0")}`;
}

function createEditableSlot(slot = {}) {
  const startParts = to12HourParts(slot.startTime);
  const endParts = to12HourParts(slot.endTime);

  return {
    startHour: startParts.hour,
    startMinute: startParts.minute,
    startPeriod: startParts.period,
    endHour: endParts.hour,
    endMinute: endParts.minute,
    endPeriod: endParts.period,
    startTime:
      slot.startTime ||
      to24HourValue(startParts.hour, startParts.minute, startParts.period),
    endTime:
      slot.endTime ||
      to24HourValue(endParts.hour, endParts.minute, endParts.period),
  };
}

function toEditableSchedule(schedule = {}) {
  const editable = {};
  DAYS_OF_WEEK.forEach((day) => {
    editable[day] = (schedule[day] || []).map((slot) =>
      createEditableSlot(slot),
    );
  });
  return editable;
}

function PeerMentorSchedule({ mentorType = "CONSULTATION" }) {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // Derived labels based on mentorType
  const typeLabel = mentorType === "CONSULTATION" ? "Consultation" : "Lab";
  const activePage =
    mentorType === "CONSULTATION"
      ? "schedule-management"
      : "lab-peer-mentor-schedule";
  const pageDescription =
    mentorType === "CONSULTATION"
      ? "Manage consultation peer mentor schedules per lab for project reviews."
      : "Manage lab peer mentor schedules per lab for lab sessions.";

  // State management
  const [peerMentors, setPeerMentors] = useState([]);
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Filter and search states
  const [searchTerm, setSearchTerm] = useState("");
  const [labFilter, setLabFilter] = useState("ALL");

  // Schedule editing states
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [assignmentSchedule, setAssignmentSchedule] = useState(null);
  const [loadingSchedule, setLoadingSchedule] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState({});
  const [submittingSchedule, setSubmittingSchedule] = useState(false);

  // Check if user has access
  const hasAccess = user?.role === "ADMIN";

  useEffect(() => {
    if (!hasAccess) {
      navigate("/dashboard");
      return;
    }
    loadPeerMentors();
    loadLabs();
  }, [hasAccess, navigate]);

  useEffect(() => {
    if (hasAccess) {
      loadPeerMentors();
    }
  }, [searchTerm, labFilter, hasAccess]);

  const loadPeerMentors = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchTerm,
        lab: labFilter,
        mentorType: mentorType,
      };

      const response = await peerMentorScheduleAPI.getAllPeerMentors(params);
      setPeerMentors(response.data.peerMentors);
    } catch (err) {
      setError(
        `Failed to load ${typeLabel.toLowerCase()} peer mentors. Please try again.`,
      );
      console.error(`Load ${typeLabel.toLowerCase()} peer mentors error:`, err);
    } finally {
      setLoading(false);
    }
  };

  const loadLabs = async () => {
    try {
      const response = await peerMentorScheduleAPI.getLabsForAssignment();
      setLabs(response.data.labs);
    } catch (err) {
      console.error("Load labs error:", err);
    }
  };

  const openScheduleModal = async (mentor, labAssignment) => {
    setSelectedMentor(mentor);
    setSelectedAssignment(labAssignment);
    setShowScheduleModal(true);
    setLoadingSchedule(true);
    setError("");

    try {
      const response = await peerMentorScheduleAPI.getMentorAssignmentSchedule(
        mentor.id,
        labAssignment.assignmentId,
      );
      setAssignmentSchedule(response.data);
      setEditingSchedule(
        toEditableSchedule(response.data.currentSchedule || {}),
      );
    } catch (err) {
      setError("Failed to load schedule for this lab.");
      console.error("Load schedule error:", err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  const closeScheduleModal = () => {
    setSelectedMentor(null);
    setSelectedAssignment(null);
    setShowScheduleModal(false);
    setAssignmentSchedule(null);
    setEditingSchedule({});
  };

  const addTimeSlot = (day) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: [...(prev[day] || []), createEditableSlot()],
    }));
  };

  const removeTimeSlot = (day, index) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: prev[day]?.filter((_, i) => i !== index) || [],
    }));
  };

  const updateTimeSlotPart = (day, index, boundary, part, value) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]:
        prev[day]?.map((slot, i) => {
          if (i !== index) return slot;

          const nextSlot = { ...slot };
          if (boundary === "start") {
            if (part === "hour") nextSlot.startHour = value;
            if (part === "minute") nextSlot.startMinute = value;
            if (part === "period") nextSlot.startPeriod = value;
            nextSlot.startTime = to24HourValue(
              nextSlot.startHour,
              nextSlot.startMinute,
              nextSlot.startPeriod,
            );
          } else {
            if (part === "hour") nextSlot.endHour = value;
            if (part === "minute") nextSlot.endMinute = value;
            if (part === "period") nextSlot.endPeriod = value;
            nextSlot.endTime = to24HourValue(
              nextSlot.endHour,
              nextSlot.endMinute,
              nextSlot.endPeriod,
            );
          }

          return nextSlot;
        }) || [],
    }));
  };

  const clearDaySchedule = (day) => {
    setEditingSchedule((prev) => ({
      ...prev,
      [day]: [],
    }));
  };

  const handleSaveSchedule = async () => {
    for (const day of DAYS_OF_WEEK) {
      const slots = editingSchedule[day] || [];
      for (let index = 0; index < slots.length; index += 1) {
        const slot = slots[index];
        if (!slot.startTime || !slot.endTime) {
          setError(
            `${getDayDisplayName(day)} slot ${index + 1} is incomplete. Please select start and end time.`,
          );
          return;
        }

        const [startHour, startMinute] = slot.startTime.split(":").map(Number);
        const [endHour, endMinute] = slot.endTime.split(":").map(Number);
        const startTotal = startHour * 60 + startMinute;
        const endTotal = endHour * 60 + endMinute;

        if (
          !Number.isFinite(startTotal) ||
          !Number.isFinite(endTotal) ||
          endTotal <= startTotal
        ) {
          setError(
            `${getDayDisplayName(day)} slot ${index + 1} has an invalid range. End time must be after start time.`,
          );
          return;
        }
      }
    }

    try {
      setSubmittingSchedule(true);
      setError("");

      const scheduleData = {
        schedule: DAYS_OF_WEEK.reduce((acc, day) => {
          acc[day] = (editingSchedule[day] || []).map((slot) => ({
            startTime: slot.startTime,
            endTime: slot.endTime,
          }));
          return acc;
        }, {}),
      };

      const response =
        await peerMentorScheduleAPI.updateMentorAssignmentSchedule(
          selectedMentor.id,
          selectedAssignment.assignmentId,
          scheduleData,
        );

      let message = response.data.message;
      if (response.data.warnings && response.data.warnings.length > 0) {
        message +=
          "\n\nUpdates:\n" +
          response.data.warnings.map((w) => `• ${w}`).join("\n");
      }

      setSuccess(message);
      setTimeout(() => setSuccess(""), 8000);
      closeScheduleModal();
      loadPeerMentors(); // Refresh the list
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update schedule. Please try again.",
      );
      console.error("Save schedule error:", err);
    } finally {
      setSubmittingSchedule(false);
    }
  };

  if (!hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage={activePage} />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              {typeLabel} Peer Mentor Schedule Management
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              {pageDescription}
            </p>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Filters */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="mb-4">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                Filters
              </h3>
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label
                  htmlFor="search"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Search {typeLabel} Peer Mentors
                </label>
                <input
                  type="text"
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Name or email"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>
              <div>
                <label
                  htmlFor="lab"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Lab
                </label>
                <select
                  id="lab"
                  value={labFilter}
                  onChange={(e) => setLabFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Labs</option>
                  {labs.map((lab) => (
                    <option key={lab.id} value={lab.id}>
                      {lab.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          {/* Peer Mentors List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading {typeLabel.toLowerCase()} peer mentors...
              </span>
            </div>
          ) : peerMentors.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No {typeLabel.toLowerCase()} peer mentors found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Try adjusting your search or filter criteria, or promote users
                to {typeLabel} Peer Mentor first.
              </p>
            </div>
          ) : (
            <section className="space-y-4">
              {peerMentors.map((mentor) => (
                <article
                  key={mentor.id}
                  className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900">
                        {mentor.name}
                      </h3>
                      <p className="text-sm text-slate-500">{mentor.email}</p>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                      {mentor.labs.length} lab assignment
                      {mentor.labs.length !== 1 ? "s" : ""}
                    </span>
                  </div>

                  <div className="mt-4 space-y-3">
                    {mentor.labs.map((labAssignment) => (
                      <div
                        key={labAssignment.assignmentId}
                        className="rounded-xl border border-slate-200 bg-slate-50 p-4"
                      >
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div>
                            <p className="text-base font-semibold text-slate-900">
                              {labAssignment.labName}
                            </p>
                            <p className="text-sm text-slate-500">
                              {labAssignment.labLocation}
                            </p>
                            <div className="mt-2 flex flex-wrap items-center gap-2">
                              <span
                                className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${
                                  labAssignment.hasConfiguredSchedule
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-rose-100 text-rose-700"
                                }`}
                              >
                                {labAssignment.hasConfiguredSchedule
                                  ? "Schedule Configured"
                                  : "No Schedule"}
                              </span>
                              <span className="text-xs font-medium text-slate-500">
                                {labAssignment.activeTimeSlotsCount} active
                                slots
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() =>
                              openScheduleModal(mentor, labAssignment)
                            }
                            className="inline-flex items-center justify-center rounded-lg border border-indigo-200 bg-white px-3 py-2 text-sm font-medium text-indigo-700 shadow-sm transition hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                          >
                            {labAssignment.hasConfiguredSchedule
                              ? "Edit Schedule"
                              : "Create Schedule"}
                          </button>
                        </div>

                        {/* Schedule Preview */}
                        {labAssignment.schedule &&
                          Object.keys(labAssignment.schedule).length > 0 && (
                            <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
                              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-600">
                                Current Schedule
                              </p>
                              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                {DAYS_OF_WEEK.map((day) => (
                                  <div
                                    key={day}
                                    className="rounded border border-slate-200 bg-white p-2"
                                  >
                                    <p className="mb-1 text-xs font-semibold text-slate-700">
                                      {getDayDisplayName(day)}
                                    </p>
                                    {labAssignment.schedule[day]?.length > 0 ? (
                                      <div className="flex flex-wrap gap-1">
                                        {labAssignment.schedule[day].map(
                                          (slot, idx) => (
                                            <span
                                              key={idx}
                                              className="inline-flex items-center rounded bg-indigo-100 px-2 py-0.5 text-xs font-medium text-indigo-700"
                                            >
                                              {formatTime(slot.startTime)} -{" "}
                                              {formatTime(slot.endTime)}
                                            </span>
                                          ),
                                        )}
                                      </div>
                                    ) : (
                                      <span className="text-xs text-slate-400">
                                        No scheduled times
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                      </div>
                    ))}
                  </div>
                </article>
              ))}
            </section>
          )}
        </div>
      </main>

      {/* Schedule Modal */}
      {showScheduleModal && selectedMentor && selectedAssignment && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 p-4">
          <div className="relative mx-auto mt-4 max-w-6xl rounded-2xl border border-slate-200 bg-white shadow-xl">
            <div className="border-b border-slate-200 bg-slate-50 px-5 py-4 sm:px-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">
                    {typeLabel} Schedule - {selectedMentor.name}
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    {selectedAssignment.labName} -{" "}
                    {selectedAssignment.labLocation}
                  </p>
                </div>
                <button
                  onClick={closeScheduleModal}
                  className="rounded-md px-2 py-1 text-slate-400 transition hover:bg-slate-200 hover:text-slate-600"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-5 sm:p-6">
              {loadingSchedule ? (
                <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-slate-50 p-8">
                  <Spinner />
                  <span className="ml-2 text-sm text-slate-600">
                    Loading schedule...
                  </span>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Weekly Schedule Section */}
                  <div>
                    <h4 className="mb-1 text-base font-semibold text-slate-900">
                      Weekly Schedule for {selectedAssignment.labName}
                    </h4>
                    <p className="mb-4 text-sm text-slate-500">
                      {mentorType === "CONSULTATION"
                        ? "Set consultation times when this mentor will review projects for this lab."
                        : "Set lab session times when this mentor will be available for this lab."}
                    </p>
                    <div className="space-y-3">
                      {DAYS_OF_WEEK.map((day) => (
                        <div
                          key={day}
                          className="rounded-xl border border-slate-200 bg-slate-50 p-4"
                        >
                          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                            <h5 className="font-semibold text-slate-800">
                              {getDayDisplayName(day)}
                            </h5>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => addTimeSlot(day)}
                                className="rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-medium text-white transition hover:bg-emerald-700"
                              >
                                Add Time
                              </button>
                              {editingSchedule[day]?.length > 0 && (
                                <button
                                  onClick={() => clearDaySchedule(day)}
                                  className="rounded-lg bg-rose-600 px-2.5 py-1.5 text-xs font-medium text-white transition hover:bg-rose-700"
                                >
                                  Clear Day
                                </button>
                              )}
                            </div>
                          </div>

                          {editingSchedule[day]?.length > 0 ? (
                            <div className="space-y-2">
                              {editingSchedule[day].map((slot, index) => (
                                <div
                                  key={index}
                                  className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white p-2"
                                >
                                  {(() => {
                                    const startParts = {
                                      hour: slot.startHour || "",
                                      minute: slot.startMinute || "",
                                      period: slot.startPeriod || "",
                                    };
                                    const endParts = {
                                      hour: slot.endHour || "",
                                      minute: slot.endMinute || "",
                                      period: slot.endPeriod || "",
                                    };

                                    return (
                                      <>
                                        <select
                                          value={startParts.hour}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "start",
                                              "hour",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            Hour
                                          </option>
                                          {HOUR_OPTIONS.map((option) => (
                                            <option
                                              key={`start-hour-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>
                                        <span className="text-sm text-slate-500">
                                          :
                                        </span>
                                        <select
                                          value={startParts.minute}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "start",
                                              "minute",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            Min
                                          </option>
                                          {MINUTE_OPTIONS.map((option) => (
                                            <option
                                              key={`start-minute-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>
                                        <select
                                          value={startParts.period}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "start",
                                              "period",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            AM/PM
                                          </option>
                                          {PERIOD_OPTIONS.map((option) => (
                                            <option
                                              key={`start-period-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>

                                        <span className="text-sm text-slate-500">
                                          to
                                        </span>

                                        <select
                                          value={endParts.hour}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "end",
                                              "hour",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            Hour
                                          </option>
                                          {HOUR_OPTIONS.map((option) => (
                                            <option
                                              key={`end-hour-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>
                                        <span className="text-sm text-slate-500">
                                          :
                                        </span>
                                        <select
                                          value={endParts.minute}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "end",
                                              "minute",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            Min
                                          </option>
                                          {MINUTE_OPTIONS.map((option) => (
                                            <option
                                              key={`end-minute-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>
                                        <select
                                          value={endParts.period}
                                          onChange={(e) =>
                                            updateTimeSlotPart(
                                              day,
                                              index,
                                              "end",
                                              "period",
                                              e.target.value,
                                            )
                                          }
                                          className="rounded-md border border-slate-300 px-2 py-1 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                        >
                                          <option value="" disabled>
                                            AM/PM
                                          </option>
                                          {PERIOD_OPTIONS.map((option) => (
                                            <option
                                              key={`end-period-${option}`}
                                              value={option}
                                            >
                                              {option}
                                            </option>
                                          ))}
                                        </select>
                                      </>
                                    );
                                  })()}
                                  <button
                                    onClick={() => removeTimeSlot(day, index)}
                                    className="ml-auto rounded-md px-2 py-1 text-lg font-bold text-rose-600 transition hover:bg-rose-50 hover:text-rose-800"
                                  >
                                    ×
                                  </button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm italic text-slate-500">
                              No times scheduled for this day
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Current Active Slots Info */}
                  {assignmentSchedule?.totalActiveSlots > 0 && (
                    <div className="rounded-xl border border-blue-200 bg-blue-50 p-3">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> This lab currently has{" "}
                        {assignmentSchedule.totalActiveSlots} active time slots.
                        Updating will remove unbooked slots and generate new
                        ones.
                      </p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex flex-col-reverse gap-3 border-t border-slate-200 pt-4 sm:flex-row">
                    <button
                      onClick={closeScheduleModal}
                      disabled={submittingSchedule}
                      className="flex-1 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveSchedule}
                      disabled={submittingSchedule}
                      className="flex-1 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {submittingSchedule
                        ? "Updating Schedule..."
                        : "Save Schedule"}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PeerMentorSchedule;
