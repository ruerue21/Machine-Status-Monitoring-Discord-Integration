import { useState, useEffect, useCallback } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import {
  authAPI,
  adminAPI,
  getMemberAgreementFileViewUrl,
} from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";

const SCHEDULE_OPTIONS = [
  { value: "YEARLY", label: "Every Year" },
  { value: "MONTHLY", label: "Every Month" },
  { value: "WEEKLY", label: "Every Week" },
  { value: "SPECIFIC_DATE", label: "On Specific Date" },
];

function toDateInputValue(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString().slice(0, 10);
}

function isValidDateValue(value) {
  if (!value) return false;
  const date = new Date(value);
  return !Number.isNaN(date.getTime());
}

function formatScheduleText(status) {
  if (!status) return "";
  const anchorDate = toDateInputValue(status.anchorDate);
  const specificDate = toDateInputValue(status.specificDate);

  if (status.resignType === "SPECIFIC_DATE") {
    return specificDate
      ? `Users must re-sign on or after ${specificDate}.`
      : "Users must re-sign on the configured date.";
  }

  if (status.resignType === "MONTHLY") {
    return anchorDate
      ? `Users must re-sign every month starting from day ${anchorDate.slice(8, 10)}.`
      : "Users must re-sign every month.";
  }

  if (status.resignType === "WEEKLY") {
    return anchorDate
      ? `Users must re-sign every week (schedule anchor: ${anchorDate}).`
      : "Users must re-sign every week.";
  }

  return anchorDate
    ? `Users must re-sign every year (schedule anchor: ${anchorDate}).`
    : "Users must re-sign every year.";
}

function formatFileScheduleText(file) {
  const resignType = file?.resignType || "YEARLY";
  const anchorDate = toDateInputValue(file?.anchorDate);
  const specificDate = toDateInputValue(file?.specificDate);

  if (resignType === "SPECIFIC_DATE") {
    return specificDate
      ? `Re-sign on or after ${specificDate}`
      : "Re-sign on configured date";
  }
  if (resignType === "MONTHLY") {
    return anchorDate
      ? `Re-sign monthly (day ${anchorDate.slice(8, 10)})`
      : "Re-sign monthly";
  }
  if (resignType === "WEEKLY") {
    return anchorDate
      ? `Re-sign weekly (anchor ${anchorDate})`
      : "Re-sign weekly";
  }
  return anchorDate
    ? `Re-sign yearly (anchor ${anchorDate})`
    : "Re-sign yearly";
}

function MemberAgreement() {
  const navigate = useNavigate();
  const user = getUserFromToken();
  const isAdmin = String(user?.role || "").toUpperCase() === "ADMIN";

  const [agreed, setAgreed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [userAgreementStatus, setUserAgreementStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  const [agreementFiles, setAgreementFiles] = useState([]);
  const [selectedFileId, setSelectedFileId] = useState(null);

  const [adminConfig, setAdminConfig] = useState(null);
  const [configForm, setConfigForm] = useState({
    resignType: "YEARLY",
    anchorDate: "",
    specificDate: "",
  });
  const [savingConfig, setSavingConfig] = useState(false);

  const [uploadingFile, setUploadingFile] = useState(false);
  const [selectedNewFile, setSelectedNewFile] = useState(null);
  const [replacingFileId, setReplacingFileId] = useState(null);
  const [savingFileScheduleId, setSavingFileScheduleId] = useState(null);
  const [fileScheduleForm, setFileScheduleForm] = useState({});

  const loadAgreementData = useCallback(async () => {
    try {
      setLoading(true);

      const statusResponse = await authAPI.getAgreementStatus();
      const statusData = statusResponse.data;

      setUserAgreementStatus(statusData);
      setAgreementFiles(statusData.files || []);
      setFileScheduleForm(
        Object.fromEntries(
          (statusData.files || []).map((file) => [
            file.id,
            {
              resignType: file.resignType || "YEARLY",
              anchorDate: toDateInputValue(file.anchorDate),
              specificDate: toDateInputValue(file.specificDate),
            },
          ]),
        ),
      );

      if (statusData.files?.length > 0) {
        setSelectedFileId((current) => current || statusData.files[0].id);
      } else {
        setSelectedFileId(null);
      }

      if (isAdmin) {
        try {
          const configResponse = await adminAPI.getMemberAgreementConfig();
          const config = configResponse.data.config;
          setAdminConfig(config);
          setConfigForm({
            resignType: config.resignType,
            anchorDate: toDateInputValue(config.anchorDate),
            specificDate: toDateInputValue(config.specificDate),
          });
        } catch (adminErr) {
          console.error(
            "Error loading admin member agreement config:",
            adminErr,
          );
          setAdminConfig(null);
        }
      }
    } catch (err) {
      console.error("Error loading member agreement data:", err);
      setError(
        err.response?.data?.message || "Failed to load agreement details",
      );
    } finally {
      setLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    loadAgreementData();
  }, [loadAgreementData]);

  const handleSubmitAgreement = async () => {
    if (!agreed) {
      setError("You must agree to the terms before submitting");
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      await authAPI.submitMemberAgreement();
      await loadAgreementData();

      setSuccess("Member agreement submitted successfully!");
      setTimeout(() => {
        navigate("/projects");
      }, 1500);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to submit agreement. Please try again.",
      );
      console.error("Submit agreement error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveSchedule = async () => {
    try {
      setSavingConfig(true);
      setError("");

      await adminAPI.updateMemberAgreementConfig({
        resignType: configForm.resignType,
        anchorDate: configForm.anchorDate || null,
        specificDate:
          configForm.resignType === "SPECIFIC_DATE"
            ? configForm.specificDate || null
            : null,
      });

      setSuccess("Re-sign schedule saved successfully.");
      await loadAgreementData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to save re-sign schedule. Please try again.",
      );
    } finally {
      setSavingConfig(false);
    }
  };

  const uploadNewFile = async () => {
    if (!selectedNewFile) {
      setError("Choose a file before uploading.");
      return;
    }

    try {
      setUploadingFile(true);
      setError("");

      const formData = new FormData();
      formData.append("agreementFile", selectedNewFile);
      await adminAPI.uploadMemberAgreementFile(formData);

      setSelectedNewFile(null);
      setSuccess("Agreement document uploaded. Users will need to re-sign.");
      await loadAgreementData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to upload agreement document. Please try again.",
      );
    } finally {
      setUploadingFile(false);
    }
  };

  const replaceFile = async (fileId, file) => {
    if (!file) return;

    try {
      setReplacingFileId(fileId);
      setError("");

      const formData = new FormData();
      formData.append("agreementFile", file);
      await adminAPI.replaceMemberAgreementFile(fileId, formData);

      setSuccess("Agreement document replaced. Users will need to re-sign.");
      await loadAgreementData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to replace agreement document. Please try again.",
      );
    } finally {
      setReplacingFileId(null);
    }
  };

  const deleteFile = async (fileId, fileName) => {
    const confirmed = window.confirm(
      `Delete "${fileName}"? Users will need to re-sign the agreement set.`,
    );
    if (!confirmed) return;

    try {
      setError("");
      await adminAPI.deleteMemberAgreementFile(fileId);
      setSuccess("Agreement document deleted. Users will need to re-sign.");
      await loadAgreementData();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to delete agreement document. Please try again.",
      );
    }
  };

  const saveFileSchedule = async (fileId) => {
    const schedule = fileScheduleForm[fileId];
    if (!schedule) return;

    try {
      setSavingFileScheduleId(fileId);
      setError("");
      await adminAPI.updateMemberAgreementFileSchedule(fileId, {
        resignType: schedule.resignType,
        anchorDate:
          schedule.resignType === "SPECIFIC_DATE"
            ? null
            : schedule.anchorDate || null,
        specificDate:
          schedule.resignType === "SPECIFIC_DATE"
            ? schedule.specificDate || null
            : null,
      });

      setSuccess("File schedule saved.");
      await loadAgreementData();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to save file schedule.");
    } finally {
      setSavingFileScheduleId(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Spinner />
        <span className="ml-2 text-sm text-slate-600">Loading...</span>
      </div>
    );
  }

  const selectedFile = agreementFiles.find(
    (file) => file.id === selectedFileId,
  );
  const selectedFileUrl = selectedFile
    ? getMemberAgreementFileViewUrl(selectedFile.id)
    : null;
  const hasAgreementFiles = agreementFiles.length > 0;
  const hasValidAgreementDate = isValidDateValue(
    userAgreementStatus?.memberAgreementDate,
  );

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="member-agreement" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              Member Agreement
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              Review all required documents and submit your agreement to access
              project proposal creation.
            </p>
          </section>

          {error && <Alert type="error">{error}</Alert>}
          {success && <Alert type="success">{success}</Alert>}

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-5 sm:p-6 space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">
              Re-Sign Policy
            </h3>
            <p className="text-sm text-slate-700">
              {formatScheduleText(userAgreementStatus)}
            </p>
            <p className="text-xs text-slate-500">
              Each file can also have its own schedule configured by admin.
            </p>
            {userAgreementStatus?.cycleStartDate && (
              <p className="text-xs text-slate-500">
                Current cycle started on{" "}
                {toDateInputValue(userAgreementStatus.cycleStartDate)}
              </p>
            )}
          </div>

          {hasAgreementFiles &&
            (userAgreementStatus?.memberAgreementSigned ? (
              <div className="rounded-xl border border-green-200 bg-green-50 p-4">
                <p className="text-sm font-medium text-green-800">
                  Member Agreement Signed
                </p>
                {hasValidAgreementDate && (
                  <p className="text-xs text-green-600">
                    Signed on{" "}
                    {new Date(
                      userAgreementStatus.memberAgreementDate,
                    ).toLocaleDateString()}
                  </p>
                )}
              </div>
            ) : (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                <p className="text-sm font-medium text-amber-800">
                  Signature Required
                </p>
                <p className="text-xs text-amber-700">
                  You need a current signature before creating projects.
                </p>
              </div>
            ))}

          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="px-4 py-5 sm:p-6 space-y-5">
              <h3 className="text-lg font-semibold text-slate-900">
                Agreement Documents ({agreementFiles.length})
              </h3>

              {agreementFiles.length === 0 ? (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-700">
                  No agreement files are configured yet.
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap gap-2">
                    {agreementFiles.map((file) => (
                      <button
                        key={file.id}
                        onClick={() => setSelectedFileId(file.id)}
                        className={`rounded-lg border px-3 py-2 text-sm ${
                          selectedFileId === file.id
                            ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                            : "border-slate-200 text-slate-700 hover:border-slate-300"
                        }`}
                      >
                        {file.fileName}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-2">
                    {agreementFiles.map((file) => (
                      <div
                        key={`meta-${file.id}`}
                        className="text-xs text-slate-600 rounded border border-slate-200 px-3 py-2"
                      >
                        <strong>{file.fileName}:</strong>{" "}
                        {formatFileScheduleText(file)}
                        {file.signedAt ? (
                          <span className="ml-2 text-emerald-700">
                            Signed {new Date(file.signedAt).toLocaleString()}
                          </span>
                        ) : (
                          <span className="ml-2 text-amber-700">
                            Not signed
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  {selectedFileUrl && (
                    <>
                      <div
                        className="overflow-hidden rounded-lg border border-slate-300"
                        style={{ height: "600px" }}
                      >
                        <iframe
                          src={selectedFileUrl}
                          width="100%"
                          height="100%"
                          style={{ border: "none" }}
                          title="Member Agreement File"
                        >
                          <p className="p-4 text-center">
                            Your browser does not support file preview.
                          </p>
                        </iframe>
                      </div>
                      <div className="text-center">
                        <a
                          href={selectedFileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm font-medium text-indigo-600 hover:text-indigo-700"
                        >
                          Open selected file in new tab
                        </a>
                      </div>
                    </>
                  )}
                </>
              )}

              {!userAgreementStatus?.memberAgreementSigned &&
                hasAgreementFiles && (
                  <div className="border-t border-slate-200 pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="flex items-center h-5">
                          <input
                            id="agreement-checkbox"
                            type="checkbox"
                            checked={agreed}
                            onChange={(e) => setAgreed(e.target.checked)}
                            className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          />
                        </div>
                        <div className="ml-3 text-sm">
                          <label
                            htmlFor="agreement-checkbox"
                            className="font-medium text-slate-700"
                          >
                            I agree to all required member agreement documents
                          </label>
                          <p className="text-slate-500">
                            By checking this box, I confirm I reviewed and
                            accepted every required agreement document shown
                            above.
                          </p>
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <button
                          onClick={handleSubmitAgreement}
                          disabled={!agreed || submitting}
                          className={`rounded-lg px-6 py-2 text-sm font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-200 ${
                            agreed && !submitting
                              ? "bg-indigo-600 hover:bg-indigo-700"
                              : "cursor-not-allowed bg-slate-400"
                          }`}
                        >
                          {submitting ? "Submitting..." : "Submit Agreement"}
                        </button>
                      </div>
                    </div>
                  </div>
                )}

              {userAgreementStatus?.memberAgreementSigned && (
                <div className="border-t border-slate-200 pt-6 text-center">
                  <p className="text-slate-600">
                    {hasAgreementFiles
                      ? "You have already signed the current member agreement."
                      : "No member agreement documents are currently required."}
                  </p>
                  <button
                    onClick={() => navigate("/projects")}
                    className="mt-4 rounded-lg bg-indigo-600 px-6 py-2 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  >
                    Go to Projects
                  </button>
                </div>
              )}
            </div>
          </div>

          {isAdmin && (
            <section className="rounded-2xl border border-slate-200 bg-white shadow-sm p-5 sm:p-6 space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">
                  Admin Agreement Management
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Manage files and re-sign schedule directly from this page.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Re-sign cadence
                  </label>
                  <select
                    value={configForm.resignType}
                    onChange={(e) =>
                      setConfigForm((prev) => ({
                        ...prev,
                        resignType: e.target.value,
                      }))
                    }
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none"
                  >
                    {SCHEDULE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>

                {configForm.resignType !== "SPECIFIC_DATE" && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Anchor date
                    </label>
                    <input
                      type="date"
                      value={configForm.anchorDate}
                      onChange={(e) =>
                        setConfigForm((prev) => ({
                          ...prev,
                          anchorDate: e.target.value,
                        }))
                      }
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                )}

                {configForm.resignType === "SPECIFIC_DATE" && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                      Specific re-sign date
                    </label>
                    <input
                      type="date"
                      value={configForm.specificDate}
                      onChange={(e) =>
                        setConfigForm((prev) => ({
                          ...prev,
                          specificDate: e.target.value,
                        }))
                      }
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                )}

                <div className="flex items-end">
                  <button
                    onClick={handleSaveSchedule}
                    disabled={savingConfig}
                    className="w-full rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:bg-slate-400"
                  >
                    {savingConfig ? "Saving..." : "Save Schedule"}
                  </button>
                </div>
              </div>

              <div className="border-t border-slate-200 pt-5 space-y-4">
                <h4 className="text-base font-semibold text-slate-900">
                  Documents
                </h4>

                <div className="flex flex-col gap-3 md:flex-row md:items-center">
                  <input
                    type="file"
                    accept=".pdf,.docx,.png,.jpg,.jpeg"
                    onChange={(e) =>
                      setSelectedNewFile(e.target.files?.[0] || null)
                    }
                    className="block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700"
                  />
                  <button
                    onClick={uploadNewFile}
                    disabled={uploadingFile}
                    className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-slate-400"
                  >
                    {uploadingFile ? "Uploading..." : "Upload New Document"}
                  </button>
                </div>

                <div className="space-y-3">
                  {agreementFiles.map((file) => (
                    <div
                      key={file.id}
                      className="rounded-lg border border-slate-200 p-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between"
                    >
                      <div>
                        <p className="text-sm font-medium text-slate-800">
                          {file.fileName}
                        </p>
                        <p className="text-xs text-slate-500">
                          Uploaded{" "}
                          {new Date(file.uploadedAt).toLocaleString([], {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                          {formatFileScheduleText(file)}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-2 items-center">
                        <a
                          href={getMemberAgreementFileViewUrl(file.id)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:border-slate-400"
                        >
                          View
                        </a>

                        <label className="rounded-lg border border-indigo-300 px-3 py-1.5 text-xs font-medium text-indigo-700 hover:border-indigo-400 cursor-pointer">
                          {replacingFileId === file.id
                            ? "Replacing..."
                            : "Replace"}
                          <input
                            type="file"
                            accept=".pdf,.docx,.png,.jpg,.jpeg"
                            className="hidden"
                            onChange={(e) =>
                              replaceFile(file.id, e.target.files?.[0])
                            }
                            disabled={replacingFileId === file.id}
                          />
                        </label>

                        <button
                          onClick={() => deleteFile(file.id, file.fileName)}
                          className="rounded-lg border border-red-300 px-3 py-1.5 text-xs font-medium text-red-700 hover:border-red-400"
                        >
                          Delete
                        </button>
                      </div>

                      <div className="w-full grid grid-cols-1 md:grid-cols-4 gap-2">
                        <select
                          value={
                            fileScheduleForm[file.id]?.resignType || "YEARLY"
                          }
                          onChange={(e) =>
                            setFileScheduleForm((prev) => ({
                              ...prev,
                              [file.id]: {
                                ...(prev[file.id] || {}),
                                resignType: e.target.value,
                              },
                            }))
                          }
                          className="rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-none"
                        >
                          {SCHEDULE_OPTIONS.map((option) => (
                            <option
                              key={`${file.id}-${option.value}`}
                              value={option.value}
                            >
                              {option.label}
                            </option>
                          ))}
                        </select>

                        {fileScheduleForm[file.id]?.resignType !==
                          "SPECIFIC_DATE" && (
                          <input
                            type="date"
                            value={fileScheduleForm[file.id]?.anchorDate || ""}
                            onChange={(e) =>
                              setFileScheduleForm((prev) => ({
                                ...prev,
                                [file.id]: {
                                  ...(prev[file.id] || {}),
                                  anchorDate: e.target.value,
                                },
                              }))
                            }
                            className="rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-none"
                          />
                        )}

                        {fileScheduleForm[file.id]?.resignType ===
                          "SPECIFIC_DATE" && (
                          <input
                            type="date"
                            value={
                              fileScheduleForm[file.id]?.specificDate || ""
                            }
                            onChange={(e) =>
                              setFileScheduleForm((prev) => ({
                                ...prev,
                                [file.id]: {
                                  ...(prev[file.id] || {}),
                                  specificDate: e.target.value,
                                },
                              }))
                            }
                            className="rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-indigo-500 focus:outline-none"
                          />
                        )}

                        <button
                          onClick={() => saveFileSchedule(file.id)}
                          disabled={savingFileScheduleId === file.id}
                          className="rounded-lg bg-indigo-600 px-3 py-2 text-xs font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:bg-slate-400"
                        >
                          {savingFileScheduleId === file.id
                            ? "Saving..."
                            : "Save File Schedule"}
                        </button>
                      </div>
                    </div>
                  ))}

                  {agreementFiles.length === 0 && (
                    <p className="text-sm text-slate-500">
                      No documents uploaded yet.
                    </p>
                  )}
                </div>
              </div>

              {adminConfig && (
                <p className="text-xs text-slate-500">
                  Current agreement version: {adminConfig.currentVersion}
                </p>
              )}
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

export default MemberAgreement;
