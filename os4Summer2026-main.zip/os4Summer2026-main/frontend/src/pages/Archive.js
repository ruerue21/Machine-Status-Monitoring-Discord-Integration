import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { archiveAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import {
  formatDate,
  formatDateTime,
  getStatusColor,
  getStatusLabel,
} from "../services/utils";

function Archive() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  const [activeTab, setActiveTab] = useState("projects");

  // Projects state
  const [projects, setProjects] = useState([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [projectSearchTerm, setProjectSearchTerm] = useState("");
  const [projectStatusFilter, setProjectStatusFilter] = useState("ALL");
  const [projectSortBy, setProjectSortBy] = useState("newest");

  // Bookings state
  const [bookings, setBookings] = useState([]);
  const [bookingsLoading, setBookingsLoading] = useState(false);
  const [bookingSearchTerm, setBookingSearchTerm] = useState("");
  const [bookingStatusFilter, setBookingStatusFilter] = useState("ALL");
  const [bookingLabFilter, setBookingLabFilter] = useState("ALL");
  const [bookingSortBy, setBookingSortBy] = useState("newest");

  // Modal states
  const [showProjectDetailsModal, setShowProjectDetailsModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showBookingDetailsModal, setShowBookingDetailsModal] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [unarchivingProjectId, setUnarchivingProjectId] = useState(null);
  const [unarchivingBookingId, setUnarchivingBookingId] = useState(null);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [stats, setStats] = useState(null);

  // Check if user is admin/supervisor
  const isAdmin = user?.role === "ADMIN";

  const loadStats = async () => {
    try {
      const response = await archiveAPI.getArchiveStats();
      setStats(response.data.stats);
    } catch (err) {
      console.error("Load stats error:", err);
    }
  };

  const loadProjects = async () => {
    try {
      setProjectsLoading(true);
      setError("");

      const params = {
        search: projectSearchTerm || undefined,
        status: projectStatusFilter !== "ALL" ? projectStatusFilter : undefined,
        sortBy: projectSortBy,
      };

      const response = await archiveAPI.getArchivedProjects(params);
      setProjects(response.data.projects || []);
    } catch (err) {
      setError("Failed to load archived projects. Please try again.");
      console.error("Load archived projects error:", err);
    } finally {
      setProjectsLoading(false);
    }
  };

  const loadBookings = async () => {
    try {
      setBookingsLoading(true);
      setError("");

      const params = {
        search: bookingSearchTerm || undefined,
        status: bookingStatusFilter !== "ALL" ? bookingStatusFilter : undefined,
        lab: bookingLabFilter !== "ALL" ? bookingLabFilter : undefined,
        sortBy: bookingSortBy,
      };

      const response = await archiveAPI.getArchivedBookings(params);
      setBookings(response.data.bookings || []);
    } catch (err) {
      setError("Failed to load archived bookings. Please try again.");
      console.error("Load archived bookings error:", err);
    } finally {
      setBookingsLoading(false);
    }
  };

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (!isAdmin) {
      navigate("/dashboard");
      return;
    }

    loadStats();
  }, []);

  useEffect(() => {
    if (!user || !isAdmin) return;

    if (activeTab === "projects") {
      loadProjects();
    }
  }, [activeTab, projectSearchTerm, projectStatusFilter, projectSortBy]);

  useEffect(() => {
    if (!user || !isAdmin) return;

    if (activeTab === "bookings") {
      loadBookings();
    }
  }, [
    activeTab,
    bookingSearchTerm,
    bookingStatusFilter,
    bookingLabFilter,
    bookingSortBy,
  ]);

  const openProjectDetailsModal = (project) => {
    setSelectedProject(project);
    setShowProjectDetailsModal(true);
  };

  const closeProjectDetailsModal = () => {
    setShowProjectDetailsModal(false);
    setSelectedProject(null);
  };

  const openBookingDetailsModal = (booking) => {
    setSelectedBooking(booking);
    setShowBookingDetailsModal(true);
  };

  const closeBookingDetailsModal = () => {
    setShowBookingDetailsModal(false);
    setSelectedBooking(null);
  };

  const handleUnarchiveProject = async (projectId, projectName) => {
    if (unarchivingProjectId === projectId) return;

    if (
      !window.confirm(
        `Are you sure you want to unarchive "${projectName}"? This will move it back to the Review Projects page.`,
      )
    ) {
      return;
    }

    try {
      setUnarchivingProjectId(projectId);
      await archiveAPI.unarchiveProject(projectId);
      setSuccess(`Project "${projectName}" has been unarchived`);
      setTimeout(() => setSuccess(""), 3000);
      loadProjects();
      loadStats();
      closeProjectDetailsModal();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to unarchive project");
      setTimeout(() => setError(""), 5000);
      console.error("Unarchive project error:", err);
    } finally {
      setUnarchivingProjectId(null);
    }
  };

  const handleUnarchiveBooking = async (bookingId, projectName) => {
    if (unarchivingBookingId === bookingId) return;

    if (
      !window.confirm(
        `Are you sure you want to unarchive this booking for "${projectName}"? This will move it back to the Manage Bookings page.`,
      )
    ) {
      return;
    }

    try {
      setUnarchivingBookingId(bookingId);
      await archiveAPI.unarchiveBooking(bookingId);
      setSuccess(`Booking has been unarchived`);
      setTimeout(() => setSuccess(""), 3000);
      loadBookings();
      loadStats();
      closeBookingDetailsModal();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to unarchive booking");
      setTimeout(() => setError(""), 5000);
      console.error("Unarchive booking error:", err);
    } finally {
      setUnarchivingBookingId(null);
    }
  };

  const uniqueLabs = ["ALL", ...new Set(bookings.map((b) => b.lab))];

  if (!user || !isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="archive" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              Archive
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              View and manage archived project proposals and lab sessions
            </p>
          </section>

          {/* Statistics */}
          {stats && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                  Archive Statistics
                </h3>
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="rounded-xl border border-indigo-100 bg-indigo-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-indigo-700/80">
                    Archived Projects
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-indigo-700">
                    {stats.archivedProjects}
                  </dd>
                </div>
                <div className="rounded-xl border border-blue-100 bg-blue-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-blue-700/80">
                    Archived Bookings
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-blue-700">
                    {stats.archivedBookings}
                  </dd>
                </div>
              </div>
            </section>
          )}

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Tab Toggle */}
          <div className="flex justify-center">
            <div
              className="inline-flex rounded-lg border border-slate-200 bg-white p-1 shadow-sm"
              role="group"
            >
              <button
                onClick={() => setActiveTab("projects")}
                className={`rounded-md px-6 py-2 text-sm font-medium ${
                  activeTab === "projects"
                    ? "bg-indigo-600 text-white"
                    : "text-slate-700 hover:bg-slate-100"
                }`}
              >
                Project Proposals
              </button>
              <button
                onClick={() => setActiveTab("bookings")}
                className={`rounded-md px-6 py-2 text-sm font-medium ${
                  activeTab === "bookings"
                    ? "bg-indigo-600 text-white"
                    : "text-slate-700 hover:bg-slate-100"
                }`}
              >
                Lab Sessions
              </button>
            </div>
          </div>

          {/* Projects Tab */}
          {activeTab === "projects" && (
            <>
              {/* Projects Filters */}
              <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label
                      htmlFor="projectSearch"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Search Projects
                    </label>
                    <input
                      type="text"
                      id="projectSearch"
                      value={projectSearchTerm}
                      onChange={(e) => setProjectSearchTerm(e.target.value)}
                      placeholder="Search by name, description, or student..."
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="projectStatus"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Filter by Status
                    </label>
                    <select
                      id="projectStatus"
                      value={projectStatusFilter}
                      onChange={(e) => setProjectStatusFilter(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    >
                      <option value="ALL">All Statuses</option>
                      <option value="IN_PROCESS">In Review</option>
                      <option value="CONSULTATION_CANCELLED">Cancelled</option>
                      <option value="CONSULTATION_ABSENT">Absent</option>
                      <option value="APPROVED">Approved</option>
                      <option value="DECLINED">Declined</option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="projectSort"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Sort by
                    </label>
                    <select
                      id="projectSort"
                      value={projectSortBy}
                      onChange={(e) => setProjectSortBy(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    >
                      <option value="newest">Newest First</option>
                      <option value="oldest">Oldest First</option>
                      <option value="student">Student Name</option>
                      <option value="status">Status</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Projects List */}
              {projectsLoading ? (
                <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
                  <Spinner />
                  <span className="ml-2 text-sm text-slate-600">
                    Loading archived projects...
                  </span>
                </div>
              ) : projects.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                  <h3 className="text-sm font-semibold text-slate-900">
                    No archived projects
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    Archived projects will appear here
                  </p>
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <ul className="divide-y divide-slate-200">
                    {projects.map((project) => (
                      <li key={project.id}>
                        <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <p className="text-lg font-medium text-indigo-600">
                                    {project.name}
                                  </p>
                                  <span
                                    className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                      project.status,
                                    )}`}
                                  >
                                    {getStatusLabel(project.status)}
                                  </span>
                                </div>
                              </div>

                              <div className="mt-2 sm:flex sm:justify-between">
                                <div className="sm:flex space-x-6 text-sm text-gray-500">
                                  <p>
                                    <span className="font-medium">By:</span>{" "}
                                    {project.student}
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="ml-4">
                              <button
                                onClick={() => openProjectDetailsModal(project)}
                                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 mr-2"
                              >
                                View Details
                              </button>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {/* Bookings Tab */}
          {activeTab === "bookings" && (
            <>
              {/* Bookings Filters */}
              <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label
                      htmlFor="bookingSearch"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Search Bookings
                    </label>
                    <input
                      type="text"
                      id="bookingSearch"
                      value={bookingSearchTerm}
                      onChange={(e) => setBookingSearchTerm(e.target.value)}
                      placeholder="Search by student, project..."
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="bookingStatus"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Filter by Status
                    </label>
                    <select
                      id="bookingStatus"
                      value={bookingStatusFilter}
                      onChange={(e) => setBookingStatusFilter(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    >
                      <option value="ALL">All Statuses</option>
                      <option value="CONFIRMED">Confirmed</option>
                      <option value="COMPLETED">Completed</option>
                      <option value="CANCELLED">Cancelled</option>
                      <option value="ABSENT">Absent</option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="bookingLab"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Filter by Lab
                    </label>
                    <select
                      id="bookingLab"
                      value={bookingLabFilter}
                      onChange={(e) => setBookingLabFilter(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    >
                      {uniqueLabs.map((lab) => (
                        <option key={lab} value={lab}>
                          {lab === "ALL" ? "All Labs" : lab}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="bookingSort"
                      className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                    >
                      Sort by
                    </label>
                    <select
                      id="bookingSort"
                      value={bookingSortBy}
                      onChange={(e) => setBookingSortBy(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    >
                      <option value="newest">Newest First</option>
                      <option value="oldest">Oldest First</option>
                      <option value="student">Student Name</option>
                      <option value="status">Status</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Bookings List */}
              {bookingsLoading ? (
                <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
                  <Spinner />
                  <span className="ml-2 text-sm text-slate-600">
                    Loading archived bookings...
                  </span>
                </div>
              ) : bookings.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                  <h3 className="text-sm font-semibold text-slate-900">
                    No archived bookings
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">
                    Archived lab sessions will appear here
                  </p>
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <ul className="divide-y divide-slate-200">
                    {bookings.map((booking) => (
                      <li key={booking.id}>
                        <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <p className="text-lg font-medium text-indigo-600">
                                    {booking.project}
                                  </p>
                                  <span
                                    className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                      booking.status,
                                    )}`}
                                  >
                                    {getStatusLabel(booking.status)}
                                  </span>
                                </div>
                              </div>

                              <div className="mt-2 sm:flex sm:justify-between">
                                <div className="sm:flex space-x-6 text-sm text-gray-500">
                                  <p>
                                    <span className="font-medium">By:</span>{" "}
                                    {booking.student}
                                  </p>
                                </div>
                              </div>
                            </div>

                            <div className="ml-4">
                              <button
                                onClick={() => openBookingDetailsModal(booking)}
                                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                              >
                                View Details
                              </button>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Project Details Modal */}
      {showProjectDetailsModal && selectedProject && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-indigo-600">
                    {selectedProject.name}
                  </h2>
                  <div className="mt-2 flex items-center space-x-3">
                    <span
                      className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(
                        selectedProject.status,
                      )}`}
                    >
                      {getStatusLabel(selectedProject.status)}
                    </span>
                    <span className="text-sm text-gray-500">
                      Created {formatDate(selectedProject.createdAt)}
                    </span>
                  </div>
                </div>
                <button
                  onClick={closeProjectDetailsModal}
                  className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                <div className="border-b border-gray-200 pb-4">
                  <p className="text-gray-700">By: {selectedProject.student}</p>
                  <p className="text-sm text-gray-500">
                    Email: {selectedProject.studentEmail}
                  </p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">
                    Description:
                  </h3>
                  <p className="text-gray-700">{selectedProject.description}</p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">
                    Lab Details:
                  </h3>
                  <p className="text-gray-700">Lab: {selectedProject.lab}</p>
                  <p className="text-sm text-gray-500">
                    Location: {selectedProject.labLocation}
                  </p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">
                    Lab Equipment
                    {selectedProject.equipment.length > 1 ? "s" : ""}:
                  </h3>
                  <div className="space-y-1">
                    {selectedProject.equipment.map((equip) => (
                      <div key={equip.id} className="text-gray-700">
                        • {equip.name}
                      </div>
                    ))}
                  </div>
                </div>

                {(selectedProject.status === "APPROVED" ||
                  selectedProject.status === "DECLINED") && (
                  <div className="border-b border-gray-200 pb-4">
                    <h3 className="text-sm font-medium text-gray-900 mb-2">
                      {selectedProject.status === "APPROVED"
                        ? "Approval Reason"
                        : "Decline Reason"}
                      :
                    </h3>
                    <p className="text-gray-700 italic">
                      {selectedProject.consultation?.mentorFeedback ||
                        "No comment provided"}
                    </p>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={() =>
                    handleUnarchiveProject(
                      selectedProject.id,
                      selectedProject.name,
                    )
                  }
                  disabled={unarchivingProjectId === selectedProject.id}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  {unarchivingProjectId === selectedProject.id
                    ? "Unarchiving..."
                    : "Unarchive Project"}
                </button>
                <button
                  onClick={closeProjectDetailsModal}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Booking Details Modal */}
      {showBookingDetailsModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-indigo-600">
                    {selectedBooking.project}
                  </h2>
                  <div className="mt-2 flex items-center space-x-3">
                    <span
                      className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(
                        selectedBooking.status,
                      )}`}
                    >
                      {getStatusLabel(selectedBooking.status)}
                    </span>
                    <span className="text-sm text-gray-500">
                      {formatDateTime(selectedBooking.startDate)} -{" "}
                      {formatDateTime(selectedBooking.endDate)}
                    </span>
                  </div>
                </div>
                <button
                  onClick={closeBookingDetailsModal}
                  className="text-gray-400 hover:text-gray-600 text-2xl font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                <div className="border-b border-gray-200 pb-4">
                  <p className="text-gray-700">By: {selectedBooking.student}</p>
                  <p className="text-sm text-gray-500">
                    Email: {selectedBooking.studentEmail}
                  </p>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-2">
                    Lab Details:
                  </h3>
                  <p className="text-gray-700">Lab: {selectedBooking.lab}</p>
                  <p className="text-sm text-gray-500">
                    Location: {selectedBooking.labLocation}
                  </p>
                </div>

                {selectedBooking.equipment &&
                  selectedBooking.equipment.length > 0 && (
                    <div className="border-b border-gray-200 pb-4">
                      <h3 className="text-sm font-medium text-gray-900 mb-2">
                        Reserved Equipment:
                      </h3>
                      <div className="space-y-1">
                        {selectedBooking.equipment.map((equip) => (
                          <div key={equip.id} className="text-gray-700">
                            • {equip.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                {selectedBooking.labMentor && (
                  <div className="border-b border-gray-200 pb-4">
                    <h3 className="text-sm font-medium text-gray-900 mb-2">
                      Lab Mentor: {selectedBooking.labMentor.name}
                    </h3>
                    <p className="text-sm text-gray-500">
                      Email: {selectedBooking.labMentor.email}
                    </p>
                  </div>
                )}

                {selectedBooking.notes && (
                  <div className="border-b border-gray-200 pb-4">
                    <h3 className="text-sm font-medium text-gray-900 mb-2">
                      Notes:
                    </h3>
                    <p className="text-gray-700 whitespace-pre-wrap">
                      {selectedBooking.notes}
                    </p>
                  </div>
                )}

                {selectedBooking.status === "CANCELLED" &&
                  selectedBooking.cancellationReason && (
                    <div className="border-b border-gray-200 pb-4">
                      <h3 className="text-sm font-medium text-gray-900 mb-2">
                        Cancellation Reason:
                      </h3>
                      <p className="text-gray-700 italic whitespace-pre-wrap">
                        {selectedBooking.cancellationReason}
                      </p>
                    </div>
                  )}
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={() =>
                    handleUnarchiveBooking(
                      selectedBooking.id,
                      selectedBooking.project,
                    )
                  }
                  disabled={unarchivingBookingId === selectedBooking.id}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  {unarchivingBookingId === selectedBooking.id
                    ? "Unarchiving..."
                    : "Unarchive Booking"}
                </button>
                <button
                  onClick={closeBookingDetailsModal}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Archive;
