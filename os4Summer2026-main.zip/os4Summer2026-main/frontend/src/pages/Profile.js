import { useState, useEffect } from "react";
import {
  getUserFromToken,
  setToken,
  setSession,
  isRemembered,
} from "../services/auth";
import { authAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";

const roleLabels = {
  ADMIN: "Administrator",
  SUPERVISOR: "Supervisor",
  PEER_MENTOR: "Peer Mentor",
  MEMBER: "Member",
};

const mentorTypeLabels = {
  CONSULTATION: "Consultation Mentor",
  LAB: "Lab Mentor",
};

function Profile() {
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);

  useEffect(() => {
    let isActive = true;

    const userData = getUserFromToken();
    if (userData) {
      setUser(userData);
      setFormData({
        name: userData.name || "",
        email: userData.email || "",
      });
    }

    const syncProfile = async () => {
      try {
        const response = await authAPI.getMe();
        if (!isActive) return;

        const { user: freshUser, exp } = response.data || {};
        if (freshUser && exp) {
          setSession(freshUser, exp, isRemembered());
          setUser({ ...freshUser, exp });
          setFormData({
            name: freshUser.name || "",
            email: freshUser.email || "",
          });
        }
      } catch (_error) {
        // Keep existing local session fallback if sync fails
      }
    };

    syncProfile();

    return () => {
      isActive = false;
    };
  }, []);

  const handleEdit = () => {
    setIsEditing(true);
    setError("");
    setSuccess("");
  };

  const handleCancel = () => {
    setIsEditing(false);
    setFormData({
      name: user?.name || "",
      email: user?.email || "",
    });
    setError("");
    setSuccess("");
  };

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handlePasswordInput = (e) => {
    setPasswordData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    if (!formData.email.endsWith("@purdue.edu")) {
      setError("Please use your @purdue.edu email address");
      setLoading(false);
      return;
    }

    try {
      const response = await authAPI.updateProfile(
        formData.name,
        formData.email,
      );

      if (response.data.token) {
        setToken(response.data.token, isRemembered(), response.data.user);
      }

      setSuccess(response.data.message);
      setIsEditing(false);

      const meResponse = await authAPI.getMe();
      const { user: freshUser, exp } = meResponse.data || {};
      if (freshUser && exp) {
        setSession(freshUser, exp, isRemembered());
        setUser({ ...freshUser, exp });
      } else {
        const fallbackUser = getUserFromToken();
        setUser(fallbackUser);
      }
    } catch (submitError) {
      setError(submitError.response?.data?.message || "Profile update failed");
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPasswordError("");
    setPasswordSuccess("");

    if (!passwordData.currentPassword || !passwordData.newPassword) {
      setPasswordError("Current and new password are required.");
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordError("New password and confirmation do not match.");
      return;
    }

    setPasswordLoading(true);
    try {
      const response = await authAPI.changePassword(
        passwordData.currentPassword,
        passwordData.newPassword,
      );
      setPasswordSuccess(
        response.data.message || "Password changed successfully.",
      );
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (passwordChangeError) {
      setPasswordError(
        passwordChangeError.response?.data?.message ||
          "Failed to change password",
      );
    } finally {
      setPasswordLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Spinner size="xl" className="mx-auto" />
          <p className="mt-4 text-slate-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  const displayRole = roleLabels[user.role] || user.role;
  const displayMentorType = user.mentorType
    ? mentorTypeLabels[user.mentorType] || user.mentorType
    : null;

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="profile" />

      <main className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              Profile
            </h2>
            <p className="mt-2 text-sm text-blue-100">
              Manage your account, responsibilities, and security settings.
            </p>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-200 px-6 py-4">
              <h3 className="text-lg font-semibold text-slate-900">
                Account Information
              </h3>
              <p className="mt-1 text-sm text-slate-600">
                Update your basic profile details.
              </p>
            </div>

            <div className="px-6 py-5">
              {error && (
                <Alert type="error" variant="auth">
                  {error}
                </Alert>
              )}
              {success && (
                <Alert type="success" variant="auth">
                  {success}
                </Alert>
              )}

              {!isEditing ? (
                <div className="space-y-5">
                  <div>
                    <p className="text-sm font-medium text-slate-500">
                      Full Name
                    </p>
                    <p className="mt-1 text-sm text-slate-900">{user.name}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-500">
                      Email Address
                    </p>
                    <p className="mt-1 text-sm text-slate-900">{user.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-500">Role</p>
                    <p className="mt-1 text-sm text-slate-900">{displayRole}</p>
                  </div>
                  {displayMentorType && (
                    <div>
                      <p className="text-sm font-medium text-slate-500">
                        Mentor Type
                      </p>
                      <p className="mt-1 text-sm text-slate-900">
                        {displayMentorType}
                      </p>
                    </div>
                  )}
                  <div className="pt-1">
                    <button
                      onClick={handleEdit}
                      className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-700"
                    >
                      Edit Profile
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleProfileSubmit} className="space-y-5">
                  <div>
                    <label
                      htmlFor="name"
                      className="block text-sm font-medium text-slate-600"
                    >
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      value={formData.name}
                      onChange={handleChange}
                      disabled={loading}
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-slate-600"
                    >
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      id="email"
                      required
                      className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      value={formData.email}
                      onChange={handleChange}
                      disabled={loading}
                    />
                    <p className="mt-2 text-sm text-slate-500">
                      Email changes are applied only after confirmation from
                      your current email address.
                    </p>
                  </div>
                  <div className="flex gap-3 pt-1">
                    <button
                      type="submit"
                      disabled={loading}
                      className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-700 disabled:opacity-50"
                    >
                      {loading ? "Saving..." : "Save Changes"}
                    </button>
                    <button
                      type="button"
                      onClick={handleCancel}
                      className="rounded-lg bg-slate-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-700"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-200 px-6 py-4">
              <h3 className="text-lg font-semibold text-slate-900">Security</h3>
              <p className="mt-1 text-sm text-slate-600">
                Change your password. Minimum: 8 characters, uppercase,
                lowercase, number.
              </p>
            </div>
            <div className="px-6 py-5">
              {passwordError && (
                <Alert type="error" variant="auth">
                  {passwordError}
                </Alert>
              )}
              {passwordSuccess && (
                <Alert type="success" variant="auth">
                  {passwordSuccess}
                </Alert>
              )}

              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <label
                    htmlFor="currentPassword"
                    className="block text-sm font-medium text-slate-600"
                  >
                    Current Password
                  </label>
                  <input
                    id="currentPassword"
                    name="currentPassword"
                    type="password"
                    required
                    value={passwordData.currentPassword}
                    onChange={handlePasswordInput}
                    disabled={passwordLoading}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                </div>
                <div>
                  <label
                    htmlFor="newPassword"
                    className="block text-sm font-medium text-slate-600"
                  >
                    New Password
                  </label>
                  <input
                    id="newPassword"
                    name="newPassword"
                    type="password"
                    required
                    value={passwordData.newPassword}
                    onChange={handlePasswordInput}
                    disabled={passwordLoading}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                </div>
                <div>
                  <label
                    htmlFor="confirmPassword"
                    className="block text-sm font-medium text-slate-600"
                  >
                    Confirm New Password
                  </label>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    required
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordInput}
                    disabled={passwordLoading}
                    className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                </div>

                <button
                  type="submit"
                  disabled={passwordLoading}
                  className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-700 disabled:opacity-50"
                >
                  {passwordLoading ? "Updating..." : "Change Password"}
                </button>
              </form>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

export default Profile;
