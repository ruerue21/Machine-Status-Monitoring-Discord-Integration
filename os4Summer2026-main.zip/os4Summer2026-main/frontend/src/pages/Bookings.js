import { useState, useEffect } from "react";
import {
  getUserFromToken,
  isAdmin,
  isLabBookingManager,
} from "../services/auth";
import { useNavigate } from "react-router-dom";
import {
  bookingAPI,
  userManagementAPI,
  labAPI,
  adminAPI,
  archiveAPI,
} from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import {
  formatDateTime,
  getStatusColor,
  getStatusLabel,
} from "../services/utils";
import {
  filterPastTimeSlots,
  getLocalDateString,
} from "./shared/timeSlotUtils";

function Bookings() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // State management
  const [bookings, setBookings] = useState([]);
  const [, setPagination] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Filter states
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [labFilter, setLabFilter] = useState("ALL");
  const [studentSearch, setStudentSearch] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  // Modal states
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showAddSessionsModal, setShowAddSessionsModal] = useState(false);

  const [archiving, setArchiving] = useState(false);

  // Sessions state
  const [addSessionsData, setAddSessionsData] = useState({
    selectedTimeSlots: [],
    timeSlotEquipment: {},
    notes: "",
    availableSlots: [],
    allLabEquipment: [],
  });

  const [addingSession, setAddingSession] = useState(false);
  const [loadingAddSessionData, setLoadingAddSessionData] = useState(false);

  // Edit form state
  const [editData, setEditData] = useState({
    status: "",
    timeSlotId: "",
    notes: "",
    labMentorId: "",
    availableSlots: [],
  });

  // Create booking from approved project modal
  const [showCreateFromProjectModal, setShowCreateFromProjectModal] =
    useState(false);
  const [approvedProjects, setApprovedProjects] = useState([]);
  const [selectedProjectForBooking, setSelectedProjectForBooking] =
    useState(null);
  const [projectSearchTerm, setProjectSearchTerm] = useState("");
  const [loadingProjects, setLoadingProjects] = useState(false);

  // Booking creation state
  const [createBookingData, setCreateBookingData] = useState({
    selectedTimeSlots: [],
    timeSlotEquipment: {},
    notes: "",
    availableSlots: [],
    allLabEquipment: [],
  });
  const [creatingBookingFromProject, setCreatingBookingFromProject] =
    useState(false);
  const [loadingBookingData, setLoadingBookingData] = useState(false);

  // Lab mentors for assignment
  const [labMentors, setLabMentors] = useState([]);

  const hasAdminAccess = isAdmin(user);
  const isSystemAdmin = user?.role === "ADMIN";
  const isSupervisor = user?.role === "SUPERVISOR";
  const isPeerMentor = user?.role === "PEER_MENTOR";
  const isConsultationPeerMentor =
    isPeerMentor && user?.mentorType === "CONSULTATION";
  const hasBookingAccess = isLabBookingManager(user);
  const canCreateFromApprovedProject =
    hasBookingAccess && !isConsultationPeerMentor;
  const canManageBooking = (booking) =>
    isSystemAdmin ||
    isSupervisor ||
    (isPeerMentor &&
      !isConsultationPeerMentor &&
      booking?.labMentor?.id === user?.id);
  const canEditTimeSlot =
    selectedBooking &&
    canManageBooking(selectedBooking) &&
    selectedBooking?.status === "CONFIRMED" &&
    Boolean(selectedBooking?.timeSlot);

  const parseSlotDate = (slotDate) => {
    if (!slotDate) return null;
    const normalized = String(slotDate).split("T")[0];
    const [year, month, day] = normalized.split("-").map(Number);
    if (!year || !month || !day) return null;
    return new Date(year, month - 1, day);
  };

  useEffect(() => {
    if (!hasBookingAccess) {
      navigate("/dashboard");
      return;
    }
    loadData();
  }, [hasBookingAccess, navigate]);

  useEffect(() => {
    if (hasBookingAccess) {
      loadBookings();
    }
  }, [statusFilter, labFilter, studentSearch, sortBy, hasBookingAccess]);

  const loadData = async () => {
    try {
      setLoading(true);
      await Promise.all([loadBookings(), loadStats(), loadLabMentors()]);
    } catch (err) {
      setError("Failed to load data. Please try again.");
      console.error("Load data error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadBookings = async () => {
    try {
      const params = {
        status: statusFilter,
        lab: labFilter,
        student: studentSearch,
        sortBy: sortBy,
      };

      const response = await bookingAPI.getAllBookings(params);
      setBookings(response.data.data); // The bookings are in response.data.data
      setPagination(response.data.pagination); // Optional: store pagination info
    } catch (err) {
      console.error("Load bookings error:", err);
    }
  };

  const loadStats = async () => {
    try {
      if (hasBookingAccess) {
        const response = await bookingAPI.getBookingStats();
        setStats(response.data.stats);
      }
    } catch (err) {
      console.error("Load stats error:", err);
    }
  };

  const loadLabMentors = async () => {
    try {
      if (hasAdminAccess) {
        const response = await userManagementAPI.getAllUsers({
          role: "PEER_MENTOR",
        });
        const users = response.data.users || response.data.data || [];
        const mentors = users.filter((u) => u.role === "PEER_MENTOR");
        setLabMentors(mentors);
      }
    } catch (err) {
      console.error("Load lab mentors error:", err);
    }
  };

  const openDetailsModal = async (booking) => {
    try {
      const response = await bookingAPI.getBookingDetails(booking.id);
      setSelectedBooking(response.data.booking);
      setShowDetailsModal(true);
    } catch (err) {
      setError("Failed to load booking details.");
      console.error("Load booking details error:", err);
    }
  };

  const closeDetailsModal = () => {
    setShowDetailsModal(false);
    setSelectedBooking(null);
  };

  const openEditModal = async (booking) => {
    setSelectedBooking(booking);

    try {
      // Fetch available time slots for the booking's lab
      const slotsResponse = await bookingAPI.getAvailableSlots(booking.labId, {
        startDate: getLocalDateString(),
      });
      let availableSlots = slotsResponse.data.availableSlots;

      // Add current booking's slot to available slots
      if (booking.timeSlot) {
        const currentSlot = {
          id: booking.timeSlot.id,
          date: booking.timeSlot.date,
          startTime: booking.timeSlot.startTime,
          endTime: booking.timeSlot.endTime,
          mentor: booking.labMentor || { id: null, name: "Unknown", email: "" },
          lab: {
            id: booking.labId,
            name: booking.lab,
            location: booking.labLocation,
          },
        };

        // Check if current slot is not already in available slots
        const slotExists = availableSlots.some(
          (slot) => slot.id === currentSlot.id,
        );
        if (!slotExists) {
          availableSlots.unshift(currentSlot); // Add current slot at the beginning
        }
      }

      // Filter out past time slots
      availableSlots = availableSlots.filter((slot) => {
        return filterPastTimeSlots([slot], slot.date).length > 0;
      });

      setEditData({
        status: booking.status,
        timeSlotId: booking.timeSlot?.id?.toString() || "",
        notes: booking.notes || "",
        labMentorId: booking.labMentor?.id || "",
        availableSlots: availableSlots,
      });

      setShowEditModal(true);
    } catch (err) {
      setError("Failed to load available time slots. Please try again.");
      console.error("Load available slots error:", err);
    }
  };

  const closeEditModal = () => {
    setShowEditModal(false);
    setSelectedBooking(null);
    setEditData({
      status: "",
      timeSlotId: "",
      notes: "",
      labMentorId: "",
      availableSlots: [],
    });
  };

  const handleUpdateBooking = async () => {
    try {
      if (canEditTimeSlot && !editData.timeSlotId) {
        setError("Please select a time slot");
        setTimeout(() => setError(""), 3000);
        return;
      }

      const updatePayload = {
        status: editData.status,
        notes: editData.notes ?? "",
      };
      if (canEditTimeSlot && editData.timeSlotId) {
        updatePayload.timeSlotId = parseInt(editData.timeSlotId);
      }

      await bookingAPI.updateBooking(selectedBooking.id, updatePayload);

      setSuccess("Booking updated successfully!");
      setTimeout(() => setSuccess(""), 3000);

      closeEditModal();
      loadBookings();
      loadStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update booking. Please try again.",
      );
      console.error("Update booking error:", err);
      setTimeout(() => setError(""), 5000);
    }
  };

  const openDeleteModal = (booking) => {
    setSelectedBooking(booking);
    setShowDeleteModal(true);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setSelectedBooking(null);
  };

  const handleDeleteBooking = async () => {
    try {
      await bookingAPI.deleteBooking(selectedBooking.id);

      setSuccess("Booking deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);

      closeDeleteModal();
      loadBookings();
      loadStats();
    } catch (err) {
      setError("Failed to delete booking. Please try again.");
      console.error("Delete booking error:", err);
      setTimeout(() => setError(""), 5000);
    }
  };

  const openAddSessionsModal = async (booking) => {
    setSelectedBooking(booking);
    setShowAddSessionsModal(true);
    setLoadingAddSessionData(true);

    try {
      // Fetch available time slots for this lab
      const slotsResponse = await bookingAPI.getAvailableSlots(booking.labId, {
        startDate: getLocalDateString(),
      });
      let availableSlots = slotsResponse.data.availableSlots;

      // Filter out past time slots
      availableSlots = availableSlots.filter((slot) => {
        return filterPastTimeSlots([slot], slot.date).length > 0;
      });

      // Fetch all equipment for this lab
      const equipmentResponse = await labAPI.getLabEquipment(booking.labId);
      const allLabEquipment = equipmentResponse.data.equipment;

      setAddSessionsData({
        selectedTimeSlots: [],
        timeSlotEquipment: {},
        notes: "",
        availableSlots: availableSlots,
        allLabEquipment: allLabEquipment,
      });
    } catch (err) {
      setError("Failed to load available slots. Please try again.");
      console.error("Load add sessions data error:", err);
    } finally {
      setLoadingAddSessionData(false);
    }
  };

  const closeAddSessionsModal = () => {
    setShowAddSessionsModal(false);
    setSelectedBooking(null);
    setAddSessionsData({
      selectedTimeSlots: [],
      timeSlotEquipment: {},
      notes: "",
      availableSlots: [],
      allLabEquipment: [],
    });
  };

  const handleTimeSlotToggleForAddSessions = (timeSlotId) => {
    setAddSessionsData((prev) => {
      const isCurrentlySelected = prev.selectedTimeSlots.includes(timeSlotId);

      if (isCurrentlySelected) {
        // Remove time slot
        const newSelectedSlots = prev.selectedTimeSlots.filter(
          (id) => id !== timeSlotId,
        );
        const newTimeSlotEquipment = { ...prev.timeSlotEquipment };
        delete newTimeSlotEquipment[timeSlotId];

        return {
          ...prev,
          selectedTimeSlots: newSelectedSlots,
          timeSlotEquipment: newTimeSlotEquipment,
        };
      } else {
        // Add time slot with default equipment (only currently available)
        const availableEquipmentIds = new Set(
          (prev.allLabEquipment || [])
            .filter((e) => e.status === "AVAILABLE")
            .map((e) => e.id),
        );
        const defaultEquipment = selectedBooking.equipment
          .map((e) => e.id)
          .filter((id) => availableEquipmentIds.has(id));

        return {
          ...prev,
          selectedTimeSlots: [...prev.selectedTimeSlots, timeSlotId],
          timeSlotEquipment: {
            ...prev.timeSlotEquipment,
            [timeSlotId]: defaultEquipment,
          },
        };
      }
    });
  };

  const handleEquipmentToggleForAddSessions = (timeSlotId, equipmentId) => {
    setAddSessionsData((prev) => {
      const currentEquipment = prev.timeSlotEquipment[timeSlotId] || [];
      const newEquipment = currentEquipment.includes(equipmentId)
        ? currentEquipment.filter((id) => id !== equipmentId)
        : [...currentEquipment, equipmentId];

      return {
        ...prev,
        timeSlotEquipment: {
          ...prev.timeSlotEquipment,
          [timeSlotId]: newEquipment,
        },
      };
    });
  };

  const handleAddSessions = async () => {
    try {
      // Validate
      if (addSessionsData.selectedTimeSlots.length === 0) {
        setError("Please select at least one time slot");
        setTimeout(() => setError(""), 3000);
        return;
      }

      // Validate each slot has equipment
      for (const timeSlotId of addSessionsData.selectedTimeSlots) {
        const equipment = (addSessionsData.timeSlotEquipment[timeSlotId] || [])
          .map((id) => parseInt(id))
          .filter((id) =>
            addSessionsData.allLabEquipment.some(
              (equip) => equip.id === id && equip.status === "AVAILABLE",
            ),
          );
        if (equipment.length === 0) {
          setError("Please select at least one equipment for each time slot");
          setTimeout(() => setError(""), 3000);
          return;
        }
      }

      setAddingSession(true);

      const bookingSlots = addSessionsData.selectedTimeSlots.map(
        (timeSlotId) => ({
          timeSlotId: parseInt(timeSlotId),
          equipmentIds: (addSessionsData.timeSlotEquipment[timeSlotId] || [])
            .map((id) => parseInt(id))
            .filter((id) =>
              addSessionsData.allLabEquipment.some(
                (equip) => equip.id === id && equip.status === "AVAILABLE",
              ),
            ),
        }),
      );

      const batchBookingPayload = {
        projectId: selectedBooking.projectId,
        bookingSlots: bookingSlots,
        notes: addSessionsData.notes || null,
      };

      await bookingAPI.createBatchBooking(batchBookingPayload);

      setSuccess(
        `${bookingSlots.length} additional session(s) added successfully!`,
      );
      setTimeout(() => setSuccess(""), 5000);

      closeAddSessionsModal();
      loadBookings();
      loadStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to add sessions. Please try again.",
      );
      console.error("Add sessions error:", err);
      setTimeout(() => setError(""), 5000);
    } finally {
      setAddingSession(false);
    }
  };

  const openCreateFromProjectModal = async () => {
    setShowCreateFromProjectModal(true);
    setLoadingProjects(true);

    try {
      const response = await adminAPI.getApprovedProjectsWithoutBookings({
        search: projectSearchTerm,
      });
      setApprovedProjects(response.data.data || response.data.projects || []);
    } catch (err) {
      setError("Failed to load approved projects. Please try again.");
      console.error("Load approved projects error:", err);
    } finally {
      setLoadingProjects(false);
    }
  };

  const closeCreateFromProjectModal = () => {
    setShowCreateFromProjectModal(false);
    setApprovedProjects([]);
    setSelectedProjectForBooking(null);
    setProjectSearchTerm("");
    setCreateBookingData({
      selectedTimeSlots: [],
      timeSlotEquipment: {},
      notes: "",
      availableSlots: [],
      allLabEquipment: [],
    });
  };

  const handleSearchProjects = async () => {
    setLoadingProjects(true);
    try {
      const response = await adminAPI.getApprovedProjectsWithoutBookings({
        search: projectSearchTerm,
      });
      setApprovedProjects(response.data.data || response.data.projects || []);
    } catch (err) {
      setError("Failed to search projects. Please try again.");
      console.error("Search projects error:", err);
    } finally {
      setLoadingProjects(false);
    }
  };

  const selectProjectForBooking = async (project) => {
    setSelectedProjectForBooking(project);
    setLoadingBookingData(true);

    try {
      // Fetch available time slots for this lab
      const slotsResponse = await bookingAPI.getAvailableSlots(project.lab.id, {
        startDate: getLocalDateString(),
      });
      let availableSlots = slotsResponse.data.availableSlots;

      // Filter out past time slots
      availableSlots = availableSlots.filter((slot) => {
        return filterPastTimeSlots([slot], slot.date).length > 0;
      });

      // Fetch all equipment for this lab
      const equipmentResponse = await labAPI.getLabEquipment(project.lab.id);
      const allLabEquipment = equipmentResponse.data.equipment;

      setCreateBookingData({
        selectedTimeSlots: [],
        timeSlotEquipment: {},
        notes: "",
        availableSlots: availableSlots,
        allLabEquipment: allLabEquipment,
      });
    } catch (err) {
      setError("Failed to load booking data. Please try again.");
      console.error("Load booking data error:", err);
    } finally {
      setLoadingBookingData(false);
    }
  };

  const backToProjectList = () => {
    setSelectedProjectForBooking(null);
    setCreateBookingData({
      selectedTimeSlots: [],
      timeSlotEquipment: {},
      notes: "",
      availableSlots: [],
      allLabEquipment: [],
    });
  };

  const handleTimeSlotToggleForCreate = (timeSlotId) => {
    setCreateBookingData((prev) => {
      const isCurrentlySelected = prev.selectedTimeSlots.includes(timeSlotId);

      if (isCurrentlySelected) {
        const newSelectedSlots = prev.selectedTimeSlots.filter(
          (id) => id !== timeSlotId,
        );
        const newTimeSlotEquipment = { ...prev.timeSlotEquipment };
        delete newTimeSlotEquipment[timeSlotId];

        return {
          ...prev,
          selectedTimeSlots: newSelectedSlots,
          timeSlotEquipment: newTimeSlotEquipment,
        };
      } else {
        // Add time slot with default equipment (only currently available)
        const availableEquipmentIds = new Set(
          (prev.allLabEquipment || [])
            .filter((e) => e.status === "AVAILABLE")
            .map((e) => e.id),
        );
        const defaultEquipment = selectedProjectForBooking.equipment
          .map((e) => e.id)
          .filter((id) => availableEquipmentIds.has(id));

        return {
          ...prev,
          selectedTimeSlots: [...prev.selectedTimeSlots, timeSlotId],
          timeSlotEquipment: {
            ...prev.timeSlotEquipment,
            [timeSlotId]: defaultEquipment,
          },
        };
      }
    });
  };

  const handleEquipmentToggleForCreate = (timeSlotId, equipmentId) => {
    setCreateBookingData((prev) => {
      const currentEquipment = prev.timeSlotEquipment[timeSlotId] || [];
      const newEquipment = currentEquipment.includes(equipmentId)
        ? currentEquipment.filter((id) => id !== equipmentId)
        : [...currentEquipment, equipmentId];

      return {
        ...prev,
        timeSlotEquipment: {
          ...prev.timeSlotEquipment,
          [timeSlotId]: newEquipment,
        },
      };
    });
  };

  const handleCreateBookingFromProject = async () => {
    try {
      // Validate
      if (createBookingData.selectedTimeSlots.length === 0) {
        setError("Please select at least one time slot");
        setTimeout(() => setError(""), 3000);
        return;
      }

      // Validate each slot has equipment
      for (const timeSlotId of createBookingData.selectedTimeSlots) {
        const equipment = (
          createBookingData.timeSlotEquipment[timeSlotId] || []
        )
          .map((id) => parseInt(id))
          .filter((id) =>
            createBookingData.allLabEquipment.some(
              (equip) => equip.id === id && equip.status === "AVAILABLE",
            ),
          );
        if (equipment.length === 0) {
          setError("Please select at least one equipment for each time slot");
          setTimeout(() => setError(""), 3000);
          return;
        }
      }

      setCreatingBookingFromProject(true);

      const bookingSlots = createBookingData.selectedTimeSlots.map(
        (timeSlotId) => ({
          timeSlotId: parseInt(timeSlotId),
          equipmentIds: (createBookingData.timeSlotEquipment[timeSlotId] || [])
            .map((id) => parseInt(id))
            .filter((id) =>
              createBookingData.allLabEquipment.some(
                (equip) => equip.id === id && equip.status === "AVAILABLE",
              ),
            ),
        }),
      );

      const batchBookingPayload = {
        projectId: selectedProjectForBooking.id,
        bookingSlots: bookingSlots,
        notes: createBookingData.notes || null,
      };

      await bookingAPI.createBatchBooking(batchBookingPayload);

      setSuccess(
        `${bookingSlots.length} booking(s) created successfully for ${selectedProjectForBooking.name}!`,
      );
      setTimeout(() => setSuccess(""), 5000);

      closeCreateFromProjectModal();
      loadBookings();
      loadStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to create bookings. Please try again.",
      );
      console.error("Create booking from project error:", err);
      setTimeout(() => setError(""), 5000);
    } finally {
      setCreatingBookingFromProject(false);
    }
  };

  const handleArchiveBooking = async (bookingId, projectName, studentName) => {
    if (
      !window.confirm(
        `Are you sure you want to archive this booking for "${projectName}" by ${studentName}? This will move it to the Archive page.`,
      )
    ) {
      return;
    }

    try {
      setArchiving(true);
      await archiveAPI.archiveBooking(bookingId);

      setSuccess(`Booking has been archived`);
      setTimeout(() => setSuccess(""), 3000);

      // Reload bookings
      loadBookings();
      loadStats();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to archive booking");
      setTimeout(() => setError(""), 5000);
      console.error("Archive booking error:", err);
    } finally {
      setArchiving(false);
    }
  };

  // Get unique labs for filter
  const uniqueLabs = ["ALL", ...new Set(bookings.map((b) => b.lab))];

  if (!hasBookingAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="bookings" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="min-w-0">
                <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                  Lab Bookings Management
                </h2>
                <p className="mt-2 max-w-3xl text-sm text-blue-100">
                  View and manage all lab bookings.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                {canCreateFromApprovedProject && (
                  <button
                    onClick={openCreateFromProjectModal}
                    className="inline-flex items-center rounded-lg bg-emerald-500 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-200"
                  >
                    Create from Approved Project
                  </button>
                )}
                <button
                  onClick={() => navigate("/dashboard")}
                  className="inline-flex items-center rounded-lg border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/40"
                >
                  Back to Dashboard
                </button>
              </div>
            </div>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Statistics Cards */}
          {hasBookingAccess && stats && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                  Booking Statistics
                </h3>
              </div>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-slate-500">
                    Total Bookings
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-slate-900">
                    {stats.total}
                  </dd>
                </div>
                <div className="rounded-xl border border-blue-100 bg-blue-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-blue-700/80">
                    Confirmed
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-blue-700">
                    {stats.confirmed}
                  </dd>
                </div>
                <div className="rounded-xl border border-green-100 bg-green-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-green-700/80">
                    Completed
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-green-700">
                    {stats.completed}
                  </dd>
                </div>
                <div className="rounded-xl border border-red-100 bg-red-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-red-700/80">
                    Cancelled
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-red-700">
                    {stats.cancelled}
                  </dd>
                </div>
                <div className="rounded-xl border border-indigo-100 bg-indigo-50 px-3 py-3 text-center">
                  <dt className="text-xs font-medium text-indigo-700/80">
                    Upcoming
                  </dt>
                  <dd className="mt-1 text-2xl font-semibold text-indigo-700">
                    {stats.upcoming}
                  </dd>
                </div>
              </div>
            </section>
          )}

          {/* Filters */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label
                  htmlFor="student"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Search Student
                </label>
                <input
                  type="text"
                  id="student"
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search by student name or email..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>

              <div>
                <label
                  htmlFor="status"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Status
                </label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Status</option>
                  <option value="CONFIRMED">Confirmed</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="CANCELLED">Cancelled</option>
                  <option value="ABSENT">Absent</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="lab"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Lab
                </label>
                <select
                  id="lab"
                  value={labFilter}
                  onChange={(e) => setLabFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  {uniqueLabs.map((lab) => (
                    <option key={lab} value={lab}>
                      {lab === "ALL" ? "All Labs" : lab}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="sort"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Sort by
                </label>
                <select
                  id="sort"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="newest">Newest Booking First</option>
                  <option value="oldest">Oldest Booking First</option>
                  <option value="student">Student Name</option>
                  <option value="status">Status</option>
                </select>
              </div>
            </div>
          </section>

          {/* Bookings List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading bookings...
              </span>
            </div>
          ) : bookings.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No bookings found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              <ul className="divide-y divide-slate-200">
                {bookings.map((booking) => (
                  <li key={booking.id}>
                    <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <p className="text-lg font-medium text-indigo-600">
                                {booking.student}
                              </p>
                              <span
                                className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                  booking.status,
                                )}`}
                              >
                                {getStatusLabel(booking.status)}
                              </span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {formatDateTime(booking.startDate)} -{" "}
                              {formatDateTime(booking.endDate)}
                            </div>
                          </div>

                          <div className="mt-2 sm:flex sm:justify-between">
                            <div className="sm:flex space-x-6 text-sm text-gray-500">
                              <p>
                                <span className="font-medium">Project:</span>{" "}
                                {booking.project}
                              </p>
                              <p>
                                <span className="font-medium">Lab:</span>{" "}
                                {booking.lab}
                              </p>
                              <p>
                                <span className="font-medium">Equipment:</span>{" "}
                                {booking.equipment.length} item(s)
                              </p>
                              {booking.labMentor && (
                                <p>
                                  <span className="font-medium">
                                    Lab Mentor:
                                  </span>{" "}
                                  {booking.labMentor.name}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="ml-4 flex space-x-2">
                          <button
                            onClick={() => openDetailsModal(booking)}
                            className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                          >
                            View Details
                          </button>

                          {canManageBooking(booking) && (
                            <button
                              onClick={() => openAddSessionsModal(booking)}
                              className="inline-flex items-center px-3 py-2 border border-green-300 shadow-sm text-sm leading-4 font-medium rounded-md text-green-700 bg-white hover:bg-green-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                            >
                              {booking.status === "CANCELLED"
                                ? "Recreate Session"
                                : "Add Sessions"}
                            </button>
                          )}

                          {canManageBooking(booking) && (
                            <button
                              onClick={() => openEditModal(booking)}
                              className="inline-flex items-center px-3 py-2 border border-indigo-300 shadow-sm text-sm leading-4 font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                            >
                              Edit
                            </button>
                          )}

                          {canManageBooking(booking) && (
                            <button
                              onClick={() => openDeleteModal(booking)}
                              className="inline-flex items-center px-3 py-2 border border-red-300 shadow-sm text-sm leading-4 font-medium rounded-md text-red-700 bg-white hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                            >
                              Delete
                            </button>
                          )}

                          {["ADMIN", "SUPERVISOR"].includes(user?.role) &&
                            (booking.status === "COMPLETED" ||
                              booking.status === "CANCELLED" ||
                              booking.status === "ABSENT") && (
                              <button
                                onClick={() =>
                                  handleArchiveBooking(
                                    booking.id,
                                    booking.project,
                                    booking.student,
                                  )
                                }
                                disabled={archiving}
                                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50"
                                title="Move to Archive"
                              >
                                Archive
                              </button>
                            )}
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </main>

      {/* Details Modal */}
      {showDetailsModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Booking Details
              </h3>

              <div className="space-y-4">
                {/* Student Info */}
                <div>
                  <span className="font-medium text-gray-700">Student:</span>
                  <p className="text-gray-600 mt-1">
                    {selectedBooking.student.name}
                    <br />
                    {selectedBooking.student.email}
                  </p>
                </div>

                {/* Status */}
                <div>
                  <span className="font-medium text-gray-700">Status:</span>
                  <div className="mt-1 space-y-2">
                    <div>
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                          selectedBooking.status,
                        )}`}
                      >
                        {getStatusLabel(selectedBooking.status)}
                      </span>
                    </div>
                    {selectedBooking.status === "CANCELLED" &&
                      selectedBooking.cancelledBy && (
                        <div className="mt-2 pt-2 border-t border-gray-200">
                          <p className="text-sm text-gray-700">
                            <strong>Cancelled by:</strong>{" "}
                            {selectedBooking.cancelledBy.name}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {selectedBooking.cancelledBy.email}
                          </p>
                          <p className="text-xs text-gray-500">
                            Role: {selectedBooking.cancelledBy.role}
                          </p>
                        </div>
                      )}
                  </div>
                </div>

                {/* Project */}
                <div>
                  <span className="font-medium text-gray-700">Project:</span>
                  <p className="text-gray-600 mt-1">
                    {selectedBooking.project.name}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedBooking.project.description}
                  </p>
                </div>

                {/* Lab */}
                <div>
                  <span className="font-medium text-gray-700">Lab:</span>
                  <p className="text-gray-600 mt-1">
                    {selectedBooking.lab.name} - {selectedBooking.lab.location}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedBooking.lab.description}
                  </p>
                </div>

                {/* Start and End Times */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <span className="font-medium text-gray-700">Start:</span>
                    <p className="text-gray-600 mt-1">
                      {formatDateTime(selectedBooking.startDate)}
                    </p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">End:</span>
                    <p className="text-gray-600 mt-1">
                      {formatDateTime(selectedBooking.endDate)}
                    </p>
                  </div>
                </div>

                {/* Equipment */}
                <div>
                  <span className="font-medium text-gray-700">Equipment:</span>
                  <ul className="mt-1 text-gray-600">
                    {selectedBooking.equipment.map((equip) => (
                      <li key={equip.id} className="ml-4 list-disc">
                        {equip.name}
                        {equip.description && (
                          <span className="text-sm text-gray-500">
                            {" "}
                            - {equip.description}
                          </span>
                        )}
                        <span
                          className={`ml-2 text-xs ${
                            equip.status === "AVAILABLE"
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          ({equip.status})
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Lab Mentor */}
                {selectedBooking.labMentor && (
                  <div>
                    <span className="font-medium text-gray-700">
                      Assigned Lab Mentor:
                    </span>
                    <p className="text-gray-600 mt-1">
                      {selectedBooking.labMentor.name}
                      <br />
                      {selectedBooking.labMentor.email}
                    </p>
                  </div>
                )}

                {/* Notes */}
                {selectedBooking.notes && (
                  <div>
                    <span className="font-medium text-gray-700">Notes:</span>
                    <p className="text-gray-600 mt-1 italic">
                      {selectedBooking.notes}
                    </p>
                  </div>
                )}

                {/* Cancellation Reason */}
                {selectedBooking.status === "CANCELLED" &&
                  selectedBooking.cancellationReason && (
                    <div>
                      <span className="font-medium text-gray-700">
                        Cancellation Reason:
                      </span>
                      <p className="text-gray-600 mt-1 italic">
                        {selectedBooking.cancellationReason}
                      </p>
                    </div>
                  )}

                {/* Created and Updated Timestamps */}
                <div className="grid grid-cols-2 gap-4 text-sm text-gray-500">
                  <div>
                    <span className="font-medium">Created:</span>{" "}
                    {formatDateTime(selectedBooking.createdAt)}
                  </div>
                  <div>
                    <span className="font-medium">Last Updated:</span>{" "}
                    {formatDateTime(selectedBooking.updatedAt)}
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <button
                  onClick={closeDetailsModal}
                  className="w-full px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {showEditModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-3xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Edit Booking
              </h3>

              <div className="space-y-4">
                {/* Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={editData.status}
                    onChange={(e) =>
                      setEditData((prev) => ({
                        ...prev,
                        status: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    {selectedBooking.status === "CONFIRMED" && (
                      <option value="CONFIRMED">Confirmed</option>
                    )}
                    <option value="COMPLETED">Completed</option>
                    <option value="CANCELLED">Cancelled</option>
                    <option value="ABSENT">Absent</option>
                  </select>
                </div>

                {/* Time Slot Selection */}
                {canEditTimeSlot ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select New Time Slot{" "}
                      <span className="text-red-500">*</span>
                    </label>

                    {editData.availableSlots?.length === 0 ? (
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                        <p className="text-sm text-yellow-800">
                          No available time slots found for this lab.
                        </p>
                      </div>
                    ) : (
                      <div className="border border-gray-300 rounded-md max-h-64 overflow-y-auto">
                        {editData.availableSlots?.map((slot) => {
                          const slotDate = parseSlotDate(slot.date);
                          const isSelected =
                            editData.timeSlotId === slot.id.toString();
                          const isCurrentSlot =
                            slot.id === selectedBooking.timeSlot?.id;

                          return (
                            <div
                              key={slot.id}
                              onClick={() =>
                                setEditData((prev) => ({
                                  ...prev,
                                  timeSlotId: slot.id.toString(),
                                }))
                              }
                              className={`p-3 border-b border-gray-200 cursor-pointer hover:bg-gray-50 ${
                                isSelected
                                  ? "bg-indigo-50 border-indigo-300"
                                  : ""
                              } ${isCurrentSlot ? "bg-green-50" : ""}`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <input
                                    type="radio"
                                    name="editTimeSlot"
                                    checked={isSelected}
                                    onChange={() =>
                                      setEditData((prev) => ({
                                        ...prev,
                                        timeSlotId: slot.id.toString(),
                                      }))
                                    }
                                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                                  />
                                  <div>
                                    <p className="text-sm font-medium text-gray-900">
                                      {slotDate
                                        ? slotDate.toLocaleDateString("en-US", {
                                            weekday: "long",
                                            year: "numeric",
                                            month: "long",
                                            day: "numeric",
                                          })
                                        : "Date unavailable"}
                                    </p>
                                    <p className="text-sm text-gray-600">
                                      {slot.startTime} - {slot.endTime}
                                    </p>
                                    {isCurrentSlot && (
                                      <p className="text-xs text-green-600 font-medium">
                                        Current booking slot
                                      </p>
                                    )}
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="text-sm font-medium text-indigo-600">
                                    {slot.mentor.name}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {slot.lab.location}
                                  </p>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {editData.availableSlots?.length > 0 && (
                      <p className="text-xs text-gray-500 mt-2">
                        Showing {editData.availableSlots.length} available time
                        slots
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <p className="text-sm text-blue-800">
                      Time slot updates are not available for this booking. You
                      can only update status.
                    </p>
                  </div>
                )}

                {/* Notes */}
                {hasAdminAccess && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Notes
                    </label>
                    <textarea
                      value={editData.notes}
                      onChange={(e) =>
                        setEditData((prev) => ({
                          ...prev,
                          notes: e.target.value,
                        }))
                      }
                      rows={3}
                      placeholder="Add any notes or special instructions..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    />
                  </div>
                )}
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleUpdateBooking}
                  disabled={canEditTimeSlot && !editData.timeSlotId}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Update Booking
                </button>
                <button
                  onClick={closeEditModal}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Delete Booking
              </h3>
              <p className="text-sm text-gray-600 mb-6">
                Are you sure you want to delete this booking for{" "}
                <strong>{selectedBooking.student}</strong>? This action cannot
                be undone.
              </p>

              <div className="flex space-x-3">
                <button
                  onClick={handleDeleteBooking}
                  className="flex-1 px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Delete Booking
                </button>
                <button
                  onClick={closeDeleteModal}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sessions Modal */}
      {showAddSessionsModal && selectedBooking && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Add More Sessions for "{selectedBooking.project}"
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Student: <strong>{selectedBooking.student}</strong> | Lab:{" "}
                <strong>{selectedBooking.lab}</strong>
              </p>

              {loadingAddSessionData ? (
                <div className="flex justify-center items-center p-8">
                  <Spinner />
                  <span className="ml-2">Loading available slots...</span>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Time Slot Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Additional Time Slot(s){" "}
                      <span className="text-red-500">*</span>
                    </label>

                    {addSessionsData.availableSlots?.length === 0 ? (
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                        <p className="text-sm text-yellow-800">
                          No available time slots found for this lab.
                        </p>
                      </div>
                    ) : (
                      <div className="border border-gray-300 rounded-md max-h-96 overflow-y-auto">
                        {addSessionsData.availableSlots?.map((slot) => {
                          const [year, month, day] = slot.date
                            .split("-")
                            .map(Number);
                          const slotDate = new Date(year, month - 1, day);
                          const isSelected =
                            addSessionsData.selectedTimeSlots.includes(slot.id);

                          return (
                            <div
                              key={slot.id}
                              className="border-b border-gray-200 last:border-b-0"
                            >
                              {/* Time Slot Header */}
                              <div
                                onClick={() =>
                                  handleTimeSlotToggleForAddSessions(slot.id)
                                }
                                className={`p-3 cursor-pointer hover:bg-gray-50 ${
                                  isSelected ? "bg-green-50" : ""
                                }`}
                              >
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start space-x-3">
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={() =>
                                        handleTimeSlotToggleForAddSessions(
                                          slot.id,
                                        )
                                      }
                                      className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                                    />
                                    <div>
                                      <p className="text-sm font-medium text-gray-900">
                                        {slotDate.toLocaleDateString("en-US", {
                                          weekday: "long",
                                          year: "numeric",
                                          month: "long",
                                          day: "numeric",
                                        })}
                                      </p>
                                      <p className="text-sm text-gray-600">
                                        {slot.startTime} - {slot.endTime}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm font-medium text-green-600">
                                      {slot.mentor.name}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                      {slot.lab.location}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              {/* Equipment Selection for This Slot */}
                              {isSelected && (
                                <div className="px-3 pb-3 bg-gray-50 border-t border-gray-200">
                                  <p className="text-xs font-semibold text-gray-700 uppercase pt-2 mb-2">
                                    Equipment for this time slot:
                                  </p>

                                  <div className="space-y-1">
                                    {addSessionsData.allLabEquipment
                                      .filter((e) => e.status === "AVAILABLE")
                                      .map((equip) => (
                                        <div
                                          key={equip.id}
                                          className="flex items-center"
                                        >
                                          <input
                                            type="checkbox"
                                            id={`add-slot-${slot.id}-equip-${equip.id}`}
                                            checked={
                                              addSessionsData.timeSlotEquipment[
                                                slot.id
                                              ]?.includes(equip.id) || false
                                            }
                                            onChange={() =>
                                              handleEquipmentToggleForAddSessions(
                                                slot.id,
                                                equip.id,
                                              )
                                            }
                                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                                          />
                                          <label
                                            htmlFor={`add-slot-${slot.id}-equip-${equip.id}`}
                                            className="ml-2 text-sm text-gray-700"
                                          >
                                            {equip.name}
                                            {equip.description && (
                                              <span className="text-gray-500 text-xs ml-1">
                                                ({equip.description})
                                              </span>
                                            )}
                                          </label>
                                        </div>
                                      ))}
                                  </div>

                                  <p className="text-xs text-gray-500 mt-2">
                                    {addSessionsData.timeSlotEquipment[slot.id]
                                      ?.length || 0}{" "}
                                    equipment selected
                                  </p>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {addSessionsData.availableSlots?.length > 0 && (
                      <p className="text-xs text-gray-500 mt-2">
                        {addSessionsData.selectedTimeSlots.length} time slot(s)
                        selected
                      </p>
                    )}
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Notes (Optional)
                    </label>
                    <textarea
                      value={addSessionsData.notes}
                      onChange={(e) =>
                        setAddSessionsData((prev) => ({
                          ...prev,
                          notes: e.target.value,
                        }))
                      }
                      rows={2}
                      placeholder="Add any notes for these additional sessions..."
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleAddSessions}
                  disabled={
                    addingSession ||
                    addSessionsData.selectedTimeSlots.length === 0 ||
                    addSessionsData.selectedTimeSlots.some(
                      (slotId) =>
                        !addSessionsData.timeSlotEquipment[slotId] ||
                        addSessionsData.timeSlotEquipment[slotId].length === 0,
                    )
                  }
                  className="flex-1 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {addingSession
                    ? "Adding Sessions..."
                    : `Add ${addSessionsData.selectedTimeSlots.length} Session(s)`}
                </button>
                <button
                  onClick={closeAddSessionsModal}
                  disabled={addingSession}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Booking from Approved Project Modal */}
      {showCreateFromProjectModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-6xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              {!selectedProjectForBooking ? (
                <>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        Create Booking from Approved Project
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Select an approved project without active bookings
                      </p>
                    </div>
                    <button
                      onClick={closeCreateFromProjectModal}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Search */}
                  <div className="mb-4">
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={projectSearchTerm}
                        onChange={(e) => setProjectSearchTerm(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") handleSearchProjects();
                        }}
                        placeholder="Search by project name, student, or description..."
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                      <button
                        onClick={handleSearchProjects}
                        className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                      >
                        Search
                      </button>
                    </div>
                  </div>

                  {/* Projects List */}
                  {loadingProjects ? (
                    <div className="flex justify-center items-center p-8">
                      <Spinner color="border-green-600" />
                      <span className="ml-2">Loading projects...</span>
                    </div>
                  ) : approvedProjects.length === 0 ? (
                    <div className="text-center py-12 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">
                        No approved projects without bookings found.
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        Try adjusting your search or check if all approved
                        projects already have bookings.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {approvedProjects.map((project) => (
                        <div
                          key={project.id}
                          className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                          onClick={() => selectProjectForBooking(project)}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="text-base font-medium text-gray-900">
                                {project.name}
                              </h4>
                              <p className="text-sm text-gray-600 mt-1">
                                {project.description}
                              </p>
                              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-gray-500">
                                <span>
                                  <strong>Student:</strong> {project.user.name}
                                </span>
                                <span>
                                  <strong>Lab:</strong> {project.lab.name}
                                </span>
                                <span>
                                  <strong>Equipment:</strong>{" "}
                                  {project.equipment.length} item(s)
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => selectProjectForBooking(project)}
                              className="ml-4 px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                            >
                              Select
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-6">
                    <button
                      onClick={closeCreateFromProjectModal}
                      className="w-full px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                // Booking Creation View
                <>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        Create Bookings for "{selectedProjectForBooking.name}"
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Student:{" "}
                        <strong>{selectedProjectForBooking.user.name}</strong> |
                        Lab:{" "}
                        <strong>{selectedProjectForBooking.lab.name}</strong>
                      </p>
                    </div>
                    <button
                      onClick={closeCreateFromProjectModal}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      ✕
                    </button>
                  </div>

                  {loadingBookingData ? (
                    <div className="flex justify-center items-center p-8">
                      <Spinner color="border-green-600" />
                      <span className="ml-2">Loading booking options...</span>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Time Slot Selection */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Select Time Slot(s){" "}
                          <span className="text-red-500">*</span>
                        </label>

                        {createBookingData.availableSlots?.length === 0 ? (
                          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                            <p className="text-sm text-yellow-800">
                              No available time slots found for this lab.
                            </p>
                          </div>
                        ) : (
                          <div className="border border-gray-300 rounded-md max-h-96 overflow-y-auto">
                            {createBookingData.availableSlots?.map((slot) => {
                              const [year, month, day] = slot.date
                                .split("-")
                                .map(Number);
                              const slotDate = new Date(year, month - 1, day);
                              const isSelected =
                                createBookingData.selectedTimeSlots.includes(
                                  slot.id,
                                );

                              return (
                                <div
                                  key={slot.id}
                                  className="border-b border-gray-200 last:border-b-0"
                                >
                                  {/* Time Slot Header */}
                                  <div
                                    onClick={() =>
                                      handleTimeSlotToggleForCreate(slot.id)
                                    }
                                    className={`p-3 cursor-pointer hover:bg-gray-50 ${
                                      isSelected ? "bg-green-50" : ""
                                    }`}
                                  >
                                    <div className="flex items-start justify-between">
                                      <div className="flex items-start space-x-3">
                                        <input
                                          type="checkbox"
                                          checked={isSelected}
                                          onChange={() =>
                                            handleTimeSlotToggleForCreate(
                                              slot.id,
                                            )
                                          }
                                          className="mt-1 h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                                        />
                                        <div>
                                          <p className="text-sm font-medium text-gray-900">
                                            {slotDate.toLocaleDateString(
                                              "en-US",
                                              {
                                                weekday: "long",
                                                year: "numeric",
                                                month: "long",
                                                day: "numeric",
                                              },
                                            )}
                                          </p>
                                          <p className="text-sm text-gray-600">
                                            {slot.startTime} - {slot.endTime}
                                          </p>
                                        </div>
                                      </div>
                                      <div className="text-right">
                                        <p className="text-sm font-medium text-green-600">
                                          {slot.mentor.name}
                                        </p>
                                        <p className="text-xs text-gray-500">
                                          {slot.lab.location}
                                        </p>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Equipment Selection */}
                                  {isSelected && (
                                    <div className="px-3 pb-3 bg-gray-50 border-t border-gray-200">
                                      <p className="text-xs font-semibold text-gray-700 uppercase pt-2 mb-2">
                                        Equipment for this time slot:
                                      </p>

                                      <div className="space-y-1">
                                        {createBookingData.allLabEquipment
                                          .filter(
                                            (e) => e.status === "AVAILABLE",
                                          )
                                          .map((equip) => (
                                            <div
                                              key={equip.id}
                                              className="flex items-center"
                                            >
                                              <input
                                                type="checkbox"
                                                id={`create-slot-${slot.id}-equip-${equip.id}`}
                                                checked={
                                                  createBookingData.timeSlotEquipment[
                                                    slot.id
                                                  ]?.includes(equip.id) || false
                                                }
                                                onChange={() =>
                                                  handleEquipmentToggleForCreate(
                                                    slot.id,
                                                    equip.id,
                                                  )
                                                }
                                                className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                                              />
                                              <label
                                                htmlFor={`create-slot-${slot.id}-equip-${equip.id}`}
                                                className="ml-2 text-sm text-gray-700"
                                              >
                                                {equip.name}
                                                {equip.description && (
                                                  <span className="text-gray-500 text-xs ml-1">
                                                    ({equip.description})
                                                  </span>
                                                )}
                                              </label>
                                            </div>
                                          ))}
                                      </div>

                                      <p className="text-xs text-gray-500 mt-2">
                                        {createBookingData.timeSlotEquipment[
                                          slot.id
                                        ]?.length || 0}{" "}
                                        equipment selected
                                      </p>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {createBookingData.availableSlots?.length > 0 && (
                          <p className="text-xs text-gray-500 mt-2">
                            {createBookingData.selectedTimeSlots.length} time
                            slot(s) selected
                          </p>
                        )}
                      </div>

                      {/* Notes */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Notes (Optional)
                        </label>
                        <textarea
                          value={createBookingData.notes}
                          onChange={(e) =>
                            setCreateBookingData((prev) => ({
                              ...prev,
                              notes: e.target.value,
                            }))
                          }
                          rows={2}
                          placeholder="Add any notes for these bookings..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-green-500 focus:border-green-500"
                        />
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="mt-6 flex space-x-3">
                    <button
                      onClick={backToProjectList}
                      disabled={creatingBookingFromProject}
                      className="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 disabled:opacity-50"
                    >
                      Back to Projects
                    </button>
                    <button
                      onClick={handleCreateBookingFromProject}
                      disabled={
                        creatingBookingFromProject ||
                        createBookingData.selectedTimeSlots.length === 0 ||
                        createBookingData.selectedTimeSlots.some(
                          (slotId) =>
                            !createBookingData.timeSlotEquipment[slotId] ||
                            createBookingData.timeSlotEquipment[slotId]
                              .length === 0,
                        )
                      }
                      className="flex-1 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {creatingBookingFromProject
                        ? "Creating Bookings..."
                        : `Create ${createBookingData.selectedTimeSlots.length} Booking(s)`}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Bookings;
