import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { labAPI, labAgreementAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import LabAgreementModal from "../components/LabAgreementModal";
import { formatDate } from "../services/utils";

function LabAgreements() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Modal states
  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [selectedLab, setSelectedLab] = useState(null);
  const [agreementFiles, setAgreementFiles] = useState([]);
  const [agreementStatus, setAgreementStatus] = useState(null);
  const [signingAgreement, setSigningAgreement] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    loadLabsWithAgreements();
  }, []);

  const loadLabsWithAgreements = async () => {
    try {
      setLoading(true);
      setError("");

      // Get all active labs
      const labsResponse = await labAPI.getAllLabs();
      const allLabs = labsResponse.data.labs;

      // Get agreement status for each lab that requires it
      const labsWithStatus = await Promise.all(
        allLabs
          .filter((lab) => lab.agreementRequired)
          .map(async (lab) => {
            try {
              const statusResponse =
                await labAgreementAPI.getLabAgreementStatus(lab.id);
              return {
                ...lab,
                agreementStatus: statusResponse.data,
              };
            } catch (err) {
              console.error(`Error loading status for lab ${lab.id}:`, err);
              return {
                ...lab,
                agreementStatus: { required: true, signed: false },
              };
            }
          }),
      );

      setLabs(labsWithStatus);
    } catch (err) {
      setError("Failed to load lab agreements. Please try again.");
      console.error("Load labs error:", err);
    } finally {
      setLoading(false);
    }
  };

  const openAgreementModal = async (lab) => {
    setSelectedLab(lab);
    setShowAgreementModal(true);

    try {
      const statusResponse = await labAgreementAPI.getLabAgreementStatus(
        lab.id,
      );
      setAgreementStatus(statusResponse.data);
      setAgreementFiles(statusResponse.data.files || []);
    } catch (err) {
      setError("Failed to load agreement details.");
      console.error("Load agreement details error:", err);
      setAgreementFiles([]);
    }
  };

  const closeAgreementModal = () => {
    setShowAgreementModal(false);
    setSelectedLab(null);
    setAgreementFiles([]);
    setAgreementStatus(null);
  };

  const handleSignAgreement = async () => {
    if (!selectedLab) return;

    try {
      setSigningAgreement(true);
      setError("");

      await labAgreementAPI.signLabAgreement(selectedLab.id);

      setSuccess(`Lab agreement for ${selectedLab.name} signed successfully!`);
      setTimeout(() => setSuccess(""), 5000);

      // Reload labs
      await loadLabsWithAgreements();
      closeAgreementModal();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to sign agreement. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Sign agreement error:", err);
    } finally {
      setSigningAgreement(false);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="lab-agreements" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              Lab Agreements
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              View and sign required lab agreements for equipment usage
            </p>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Loading State */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading lab agreements...
              </span>
            </div>
          ) : labs.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No Lab Agreements Required
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Currently, no labs require agreements to be signed.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {labs.map((lab) => (
                <div
                  key={lab.id}
                  className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:border-indigo-300"
                >
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-slate-900">
                        {lab.name}
                      </h3>
                      {lab.agreementStatus?.signed ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Signed
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Unsigned
                        </span>
                      )}
                    </div>

                    <p className="mb-4 text-sm text-slate-500">
                      {lab.location}
                    </p>

                    {lab.agreementStatus?.signed &&
                      lab.agreementStatus?.signedAt && (
                        <p className="mb-4 text-xs text-slate-500">
                          Signed on {formatDate(lab.agreementStatus.signedAt)}
                        </p>
                      )}

                    <button
                      onClick={() => openAgreementModal(lab)}
                      className={`w-full rounded-lg border px-4 py-2 text-sm font-medium shadow-sm focus:outline-none focus:ring-2 ${
                        lab.agreementStatus?.signed
                          ? "border-indigo-200 bg-white text-indigo-700 hover:bg-indigo-50 focus:ring-indigo-200"
                          : "border-transparent bg-red-600 text-white hover:bg-red-700 focus:ring-red-200"
                      }`}
                    >
                      {lab.agreementStatus?.signed
                        ? "View Agreement"
                        : "Sign Agreement"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Agreement Modal – shared component */}
      {showAgreementModal && selectedLab && (
        <LabAgreementModal
          labId={selectedLab.id}
          labName={selectedLab.name}
          labLocation={selectedLab.location}
          files={agreementFiles}
          isSigned={!!agreementStatus?.signed}
          signedAt={agreementStatus?.signedAt}
          isUrgent={false}
          signing={signingAgreement}
          onSign={handleSignAgreement}
          onClose={closeAgreementModal}
        />
      )}
    </div>
  );
}

export default LabAgreements;
