import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { userManagementAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { formatDateTime } from "../services/utils";

function UserManagement() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // State management
  const [users, setUsers] = useState([]);
  const [labs, setLabs] = useState([]);
  const [hasMemberAgreementFiles, setHasMemberAgreementFiles] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [userStats, setUserStats] = useState(null);
  const [showDeleteAccountModal, setShowDeleteAccountModal] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);

  // Filter and search states
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [mentorTypeFilter, setMentorTypeFilter] = useState("ALL");

  // Modal states
  const [selectedUser, setSelectedUser] = useState(null);
  const [showRoleChangeModal, setShowRoleChangeModal] = useState(false);
  const [showLabAssignmentModal, setShowLabAssignmentModal] = useState(false);
  const [newRole, setNewRole] = useState("");
  const [labAssignments, setLabAssignments] = useState([]);
  const [submittingRoleChange, setSubmittingRoleChange] = useState(false);
  const [submittingLabAssignment, setSubmittingLabAssignment] = useState(false);

  const [showCancelAgreementModal, setShowCancelAgreementModal] =
    useState(false);
  const [cancelAgreementReason, setCancelAgreementReason] = useState("");
  const [cancellingAgreement, setCancellingAgreement] = useState(false);

  const [showAgreementHistoryModal, setShowAgreementHistoryModal] =
    useState(false);
  const [agreementHistory, setAgreementHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const [editingCancellationId, setEditingCancellationId] = useState(null);
  const [editingReason, setEditingReason] = useState("");
  const [updatingReason, setUpdatingReason] = useState(false);
  const [showCreateAccountModal, setShowCreateAccountModal] = useState(false);
  const [showEditAccountModal, setShowEditAccountModal] = useState(false);
  const [savingAccount, setSavingAccount] = useState(false);
  const [createAccountForm, setCreateAccountForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "MEMBER",
    isActive: true,
    emailVerified: false,
  });
  const [editAccountForm, setEditAccountForm] = useState({
    name: "",
    email: "",
    password: "",
    isActive: true,
    emailVerified: false,
  });

  // Check if user has access to this page
  const hasAccess = user?.role === "ADMIN";

  useEffect(() => {
    if (!hasAccess) {
      navigate("/dashboard");
      return;
    }
    loadUsers();
    loadLabs();
    loadUserStats();
  }, [hasAccess, navigate]);

  useEffect(() => {
    if (hasAccess) {
      loadUsers();
    }
  }, [searchTerm, roleFilter, mentorTypeFilter, hasAccess]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchTerm,
        role: roleFilter,
        mentorType: mentorTypeFilter,
      };

      const response = await userManagementAPI.getAllUsers(params);
      setUsers(response.data.users || []);
      setHasMemberAgreementFiles(
        Boolean(response.data.hasMemberAgreementFiles),
      );
    } catch (err) {
      setError("Failed to load users. Please try again.");
      console.error("Load users error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadLabs = async () => {
    try {
      const response = await userManagementAPI.getLabsForAssignment();
      setLabs(response.data.labs);
    } catch (err) {
      console.error("Load labs error:", err);
    }
  };

  const canManageAccount = (targetUser) =>
    user.role === "ADMIN" || targetUser.role !== "ADMIN";

  const openCreateAccountModal = () => {
    setCreateAccountForm({
      name: "",
      email: "",
      password: "",
      role: "MEMBER",
      isActive: true,
      emailVerified: false,
    });
    setShowCreateAccountModal(true);
  };

  const closeCreateAccountModal = () => {
    setShowCreateAccountModal(false);
  };

  const openEditAccountModal = (targetUser) => {
    setSelectedUser(targetUser);
    setEditAccountForm({
      name: targetUser.name || "",
      email: targetUser.email || "",
      password: "",
      isActive: !!targetUser.isActive,
      emailVerified: !!targetUser.emailVerified,
    });
    setShowEditAccountModal(true);
  };

  const closeEditAccountModal = () => {
    setShowEditAccountModal(false);
    setSelectedUser(null);
    setEditAccountForm({
      name: "",
      email: "",
      password: "",
      isActive: true,
      emailVerified: false,
    });
  };

  const handleCreateAccount = async () => {
    if (
      !createAccountForm.name ||
      !createAccountForm.email ||
      !createAccountForm.password
    ) {
      setError("Name, email, and password are required.");
      return;
    }

    try {
      setSavingAccount(true);
      setError("");

      const response =
        await userManagementAPI.createUserAccount(createAccountForm);
      const verificationHint =
        response.data.user?.emailVerified || response.data.verificationEmailSent
          ? ""
          : " Verification email could not be sent automatically.";
      setSuccess(`${response.data.message}.${verificationHint}`);
      setTimeout(() => setSuccess(""), 6000);

      closeCreateAccountModal();
      loadUsers();
      loadUserStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to create account. Please try again.",
      );
      console.error("Create account error:", err);
    } finally {
      setSavingAccount(false);
    }
  };

  const handleEditAccount = async () => {
    if (!selectedUser) return;
    if (!editAccountForm.name || !editAccountForm.email) {
      setError("Name and email are required.");
      return;
    }

    try {
      setSavingAccount(true);
      setError("");

      const payload = {
        name: editAccountForm.name,
        email: editAccountForm.email,
        isActive: editAccountForm.isActive,
        emailVerified: editAccountForm.emailVerified,
      };

      if (editAccountForm.password.trim()) {
        payload.password = editAccountForm.password;
      }

      const response = await userManagementAPI.updateUserAccount(
        selectedUser.id,
        payload,
      );

      const verificationHint =
        response.data.user?.emailVerified || response.data.verificationEmailSent
          ? ""
          : " Verification email could not be sent automatically.";
      setSuccess(`${response.data.message}.${verificationHint}`);
      setTimeout(() => setSuccess(""), 6000);

      closeEditAccountModal();
      loadUsers();
      loadUserStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update account. Please try again.",
      );
      console.error("Update account error:", err);
    } finally {
      setSavingAccount(false);
    }
  };

  const openRoleChangeModal = (targetUser, targetRole) => {
    setSelectedUser(targetUser);
    setNewRole(targetRole);

    if (targetRole === "PEER_MENTOR") {
      setLabAssignments(targetUser.labAssignments || []);
    } else {
      setLabAssignments([]);
    }

    setShowRoleChangeModal(true);
  };

  const openLabAssignmentModal = (targetUser) => {
    setSelectedUser(targetUser);
    setLabAssignments(targetUser.labAssignments || []);
    setShowLabAssignmentModal(true);
  };

  const closeRoleChangeModal = () => {
    setSelectedUser(null);
    setNewRole("");
    setLabAssignments([]);
    setShowRoleChangeModal(false);
  };

  const closeLabAssignmentModal = () => {
    setSelectedUser(null);
    setLabAssignments([]);
    setShowLabAssignmentModal(false);
  };

  const handleRoleChange = async () => {
    if (!selectedUser || !newRole) return;

    if (newRole === "PEER_MENTOR" && labAssignments.length === 0) {
      setError("Please assign at least one lab with a mentor type");
      return;
    }

    try {
      setSubmittingRoleChange(true);
      setError("");

      const roleData = {
        newRole,
        labAssignments: newRole === "PEER_MENTOR" ? labAssignments : [],
      };

      const response = await userManagementAPI.updateUserRole(
        selectedUser.id,
        roleData,
      );

      let message = response.data.message;
      if (response.data.warnings && response.data.warnings.length > 0) {
        message +=
          "\n\nWarnings:\n" +
          response.data.warnings.map((w) => `• ${w}`).join("\n");
      }

      setSuccess(message);
      setTimeout(() => setSuccess(""), 10000);
      closeRoleChangeModal();

      loadUsers();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update user role. Please try again.",
      );
      console.error("Role change error:", err);
    } finally {
      setSubmittingRoleChange(false);
    }
  };

  const handleUpdateLabAssignments = async () => {
    if (!selectedUser) return;

    if (labAssignments.length === 0) {
      setError("Please assign at least one lab with a mentor type");
      return;
    }

    try {
      setSubmittingLabAssignment(true);
      setError("");

      const response = await userManagementAPI.updateLabAssignments(
        selectedUser.id,
        { labAssignments },
      );

      setSuccess(response.data.message);
      setTimeout(() => setSuccess(""), 5000);
      closeLabAssignmentModal();
      loadUsers();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update lab assignments. Please try again.",
      );
      console.error("Update lab assignments error:", err);
    } finally {
      setSubmittingLabAssignment(false);
    }
  };

  const toggleLabAssignment = (labId, mentorType) => {
    setLabAssignments((prev) => {
      const exists = prev.find(
        (a) => a.labId === labId && a.mentorType === mentorType,
      );

      if (exists) {
        return prev.filter(
          (a) => !(a.labId === labId && a.mentorType === mentorType),
        );
      } else {
        return [...prev, { labId, mentorType }];
      }
    });
  };

  const isLabAssigned = (labId, mentorType) => {
    return labAssignments.some(
      (a) => a.labId === labId && a.mentorType === mentorType,
    );
  };

  const openCancelAgreementModal = (user) => {
    setSelectedUser(user);
    setCancelAgreementReason("");
    setShowCancelAgreementModal(true);
  };

  const closeCancelAgreementModal = () => {
    setShowCancelAgreementModal(false);
    setSelectedUser(null);
    setCancelAgreementReason("");
  };

  const handleCancelAgreement = async () => {
    if (!selectedUser) return;

    if (
      !window.confirm(
        `Are you sure you want to cancel the member agreement for ${selectedUser.name}?\n\n` +
          `This will:\n` +
          `- Revoke their ability to submit project proposals\n` +
          `- Require them to sign the agreement again\n` +
          `- Increment their cancellation counter\n\n` +
          `Current cancellations: ${selectedUser.agreementCancellations || 0}`,
      )
    ) {
      return;
    }

    try {
      setCancellingAgreement(true);
      setError("");

      await userManagementAPI.cancelMemberAgreement(
        selectedUser.id,
        cancelAgreementReason,
      );

      setSuccess(
        `Member agreement cancelled for ${selectedUser.name}. They must sign again to submit proposals.`,
      );
      setTimeout(() => setSuccess(""), 5000);

      closeCancelAgreementModal();
      loadUsers();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to cancel member agreement. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Cancel agreement error:", err);
    } finally {
      setCancellingAgreement(false);
    }
  };

  const openAgreementHistoryModal = async (user) => {
    setSelectedUser(user);
    setShowAgreementHistoryModal(true);
    setLoadingHistory(true);

    try {
      const response = await userManagementAPI.getAgreementCancellationHistory(
        user.id,
      );
      setAgreementHistory(response.data.history);
    } catch (err) {
      setError("Failed to load agreement history");
      setTimeout(() => setError(""), 3000);
      console.error("Load agreement history error:", err);
    } finally {
      setLoadingHistory(false);
    }
  };

  const closeAgreementHistoryModal = () => {
    setShowAgreementHistoryModal(false);
    setSelectedUser(null);
    setAgreementHistory([]);
  };

  const startEditingReason = (cancellation) => {
    setEditingCancellationId(cancellation.id);
    setEditingReason(cancellation.reason || "");
  };

  const cancelEditingReason = () => {
    setEditingCancellationId(null);
    setEditingReason("");
  };

  const handleUpdateCancellationReason = async (cancellationId) => {
    if (!selectedUser) return;

    try {
      setUpdatingReason(true);
      setError("");

      await userManagementAPI.updateCancellationReason(
        selectedUser.id,
        cancellationId,
        editingReason,
      );

      setSuccess("Cancellation reason updated successfully");
      setTimeout(() => setSuccess(""), 3000);

      const response = await userManagementAPI.getAgreementCancellationHistory(
        selectedUser.id,
      );
      setAgreementHistory(response.data.history);

      setEditingCancellationId(null);
      setEditingReason("");
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update cancellation reason. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Update cancellation reason error:", err);
    } finally {
      setUpdatingReason(false);
    }
  };

  const getRoleDisplayName = (role) => {
    const displayNames = {
      MEMBER: "Member",
      PEER_MENTOR: "Peer Mentor",
      SUPERVISOR: "Supervisor",
      ADMIN: "Admin",
    };
    return displayNames[role] || role;
  };

  const getMentorTypeDisplayName = (type) => {
    const displayNames = {
      CONSULTATION: "Consultation",
      LAB: "Lab",
    };
    return displayNames[type] || type;
  };

  const loadUserStats = async () => {
    try {
      const response = await userManagementAPI.getUserStats();
      setUserStats(response.data.stats);
    } catch (err) {
      console.error("Load user stats error:", err);
    }
  };

  const handleInactivateUser = async (targetUser) => {
    if (
      !window.confirm(
        `Are you sure you want to mark ${targetUser.name} as inactive?`,
      )
    ) {
      return;
    }

    try {
      await userManagementAPI.inactivateUser(targetUser.id);
      setSuccess(`${targetUser.name} has been marked as inactive`);
      setTimeout(() => setSuccess(""), 3000);
      loadUsers();
      loadUserStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to inactivate user. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Inactivate user error:", err);
    }
  };

  const handleReactivateUser = async (targetUser) => {
    try {
      await userManagementAPI.reactivateUser(targetUser.id);
      setSuccess(`${targetUser.name} has been reactivated`);
      setTimeout(() => setSuccess(""), 3000);
      loadUsers();
      loadUserStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to reactivate user. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Reactivate user error:", err);
    }
  };

  const openDeleteAccountModal = (targetUser) => {
    setSelectedUser(targetUser);
    setShowDeleteAccountModal(true);
  };

  const closeDeleteAccountModal = () => {
    setShowDeleteAccountModal(false);
    setSelectedUser(null);
  };

  const handleDeleteAccount = async () => {
    if (!selectedUser) return;

    if (
      !window.confirm(
        `FINAL WARNING\n\n` +
          `Are you absolutely sure you want to permanently delete ${selectedUser.name}'s account?\n\n` +
          `This action CANNOT be undone. The user will:\n` +
          `• Lose all access to the system\n` +
          `• Not be able to access their past projects or bookings\n` +
          `• Need to create a completely new account to return\n\n` +
          `Type "DELETE" in the next prompt to confirm.`,
      )
    ) {
      return;
    }

    const confirmation = window.prompt(
      `Type "DELETE" (all caps) to permanently delete ${selectedUser.name}'s account:`,
    );

    if (confirmation !== "DELETE") {
      setError("Account deletion cancelled - confirmation text did not match");
      setTimeout(() => setError(""), 3000);
      return;
    }

    try {
      setDeletingAccount(true);
      const response = await userManagementAPI.deleteUserAccount(
        selectedUser.id,
      );

      let message = response.data.message;
      if (response.data.warnings && response.data.warnings.length > 0) {
        message += "\n\n" + response.data.warnings.join("\n");
      }

      setSuccess(message);
      setTimeout(() => setSuccess(""), 8000);

      closeDeleteAccountModal();
      loadUsers();
      loadUserStats();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to delete account. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Delete account error:", err);
    } finally {
      setDeletingAccount(false);
    }
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case "ADMIN":
        return "bg-red-100 text-red-800";
      case "SUPERVISOR":
        return "bg-purple-100 text-purple-800";
      case "PEER_MENTOR":
        return "bg-blue-100 text-blue-800";
      case "MEMBER":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getMentorTypeBadgeColor = (type) => {
    switch (type) {
      case "CONSULTATION":
        return "bg-indigo-100 text-indigo-800";
      case "LAB":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (!hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="user-management" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
              User Management
            </h2>
            <p className="mt-2 max-w-3xl text-sm text-blue-100">
              Manage roles, assignments, and account status with clear
              visibility across all users.
            </p>
          </section>

          {userStats && (
            <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                  User Statistics
                </h3>
              </div>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-8">
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-slate-900">
                    {userStats.totalUsers}
                  </p>
                  <p className="text-xs font-medium text-slate-500">
                    Total Users
                  </p>
                </div>
                <div className="rounded-xl border border-red-100 bg-red-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-red-700">
                    {userStats.totalAdmins}
                  </p>
                  <p className="text-xs font-medium text-red-700/80">Admins</p>
                </div>
                <div className="rounded-xl border border-fuchsia-100 bg-fuchsia-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-fuchsia-700">
                    {userStats.totalSupervisors}
                  </p>
                  <p className="text-xs font-medium text-fuchsia-700/80">
                    Supervisors
                  </p>
                </div>
                <div className="rounded-xl border border-indigo-100 bg-indigo-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-indigo-700">
                    {userStats.totalConsultationMentors}
                  </p>
                  <p className="text-xs font-medium text-indigo-700/80">
                    Consultation
                  </p>
                </div>
                <div className="rounded-xl border border-emerald-100 bg-emerald-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-emerald-700">
                    {userStats.totalLabMentors}
                  </p>
                  <p className="text-xs font-medium text-emerald-700/80">
                    Lab Mentors
                  </p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-slate-700">
                    {userStats.totalMembers}
                  </p>
                  <p className="text-xs font-medium text-slate-500">Members</p>
                </div>
                <div className="rounded-xl border border-green-100 bg-green-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-green-700">
                    {userStats.totalActive}
                  </p>
                  <p className="text-xs font-medium text-green-700/80">
                    Active
                  </p>
                </div>
                <div className="rounded-xl border border-amber-100 bg-amber-50 px-3 py-3 text-center">
                  <p className="text-2xl font-bold text-amber-700">
                    {userStats.totalInactive}
                  </p>
                  <p className="text-xs font-medium text-amber-700/80">
                    Inactive
                  </p>
                </div>
              </div>
            </section>
          )}

          {error && <Alert type="error">{error}</Alert>}
          {success && <Alert type="success">{success}</Alert>}

          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="mb-4 flex items-center justify-between gap-2">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                Filters
              </h3>
              <button
                onClick={openCreateAccountModal}
                className="rounded-lg bg-indigo-600 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-white hover:bg-indigo-700"
              >
                Create Account
              </button>
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <div>
                <label
                  htmlFor="search"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Search Users
                </label>
                <input
                  type="text"
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Name or email"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>
              <div>
                <label
                  htmlFor="role"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Role
                </label>
                <select
                  id="role"
                  value={roleFilter}
                  onChange={(e) => {
                    setRoleFilter(e.target.value);
                    if (e.target.value !== "PEER_MENTOR") {
                      setMentorTypeFilter("ALL");
                    }
                  }}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Roles</option>
                  <option value="MEMBER">Members</option>
                  <option value="PEER_MENTOR">Peer Mentors</option>
                  <option value="SUPERVISOR">Supervisors</option>
                  <option value="ADMIN">Admins</option>
                </select>
              </div>
              <div>
                <label
                  htmlFor="mentorType"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Mentor Type
                </label>
                <select
                  id="mentorType"
                  value={mentorTypeFilter}
                  onChange={(e) => setMentorTypeFilter(e.target.value)}
                  disabled={roleFilter !== "PEER_MENTOR"}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200 disabled:cursor-not-allowed disabled:bg-slate-100"
                >
                  <option value="ALL">All Mentor Types</option>
                  <option value="CONSULTATION">
                    Consultation Peer Mentors
                  </option>
                  <option value="LAB">Lab Peer Mentors</option>
                </select>
                {roleFilter !== "PEER_MENTOR" && (
                  <p className="mt-1 text-xs text-slate-500">
                    Enable by selecting role "Peer Mentors"
                  </p>
                )}
              </div>
            </div>
          </section>

          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading users...
              </span>
            </div>
          ) : users.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No users found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          ) : (
            <section className="space-y-4">
              {users.map((targetUser) => (
                <article
                  key={targetUser.id}
                  className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5"
                >
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h4 className="text-lg font-semibold text-slate-900">
                            {targetUser.name}
                          </h4>
                          <p className="text-sm text-slate-500">
                            {targetUser.email}
                          </p>
                        </div>
                        <p className="text-xs font-medium text-slate-500">
                          Joined {formatDateTime(targetUser.createdAt)}
                        </p>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        <span
                          className={`px-2.5 py-1 text-xs font-semibold rounded-full ${getRoleBadgeColor(
                            targetUser.role,
                          )}`}
                        >
                          {getRoleDisplayName(targetUser.role)}
                        </span>
                        {!targetUser.isActive && (
                          <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">
                            Inactive
                          </span>
                        )}
                        {!targetUser.emailVerified && (
                          <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                            Unverified Email
                          </span>
                        )}
                      </div>

                      {(targetUser.role === "PEER_MENTOR" ||
                        targetUser.role === "SUPERVISOR") &&
                        targetUser.labAssignments &&
                        targetUser.labAssignments.length > 0 && (
                          <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
                            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                              Lab Assignments
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {targetUser.role === "PEER_MENTOR"
                                ? targetUser.labAssignments.map(
                                    (assignment) => (
                                      <span
                                        key={`${assignment.labId}-${assignment.mentorType}`}
                                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700"
                                      >
                                        <span
                                          className={`rounded px-1.5 py-0.5 font-semibold ${getMentorTypeBadgeColor(
                                            assignment.mentorType,
                                          )}`}
                                        >
                                          {getMentorTypeDisplayName(
                                            assignment.mentorType,
                                          )}
                                        </span>
                                        {assignment.labName}
                                      </span>
                                    ),
                                  )
                                : targetUser.labAssignments.map(
                                    (assignment) => (
                                      <span
                                        key={assignment.labId}
                                        className="inline-flex items-center rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700"
                                      >
                                        {assignment.labName}
                                      </span>
                                    ),
                                  )}
                            </div>
                          </div>
                        )}

                      {hasMemberAgreementFiles && (
                        <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
                          <div className="mb-2 flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                              Member Agreement
                            </p>
                            {targetUser.memberAgreementSigned ? (
                              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                Signed
                              </span>
                            ) : (
                              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                Not Signed
                              </span>
                            )}
                          </div>

                          {targetUser.memberAgreementSigned &&
                            targetUser.memberAgreementDate && (
                              <p className="text-xs text-slate-600">
                                Signed on{" "}
                                {formatDateTime(targetUser.memberAgreementDate)}
                              </p>
                            )}

                          {targetUser.agreementCancellations > 0 && (
                            <div
                              className={`mt-2 rounded border p-2 ${
                                targetUser.agreementCancellations >= 3
                                  ? "border-red-300 bg-red-50"
                                  : "border-yellow-200 bg-yellow-50"
                              }`}
                            >
                              <p
                                className={`text-xs font-semibold ${
                                  targetUser.agreementCancellations >= 3
                                    ? "text-red-800"
                                    : "text-yellow-800"
                                }`}
                              >
                                Cancellations:{" "}
                                {targetUser.agreementCancellations}
                              </p>
                              {targetUser.lastAgreementCancelledAt && (
                                <p
                                  className={`mt-1 text-xs ${
                                    targetUser.agreementCancellations >= 3
                                      ? "text-red-700"
                                      : "text-yellow-700"
                                  }`}
                                >
                                  Last cancelled{" "}
                                  {formatDateTime(
                                    targetUser.lastAgreementCancelledAt,
                                  )}
                                </p>
                              )}
                              <button
                                onClick={() =>
                                  openAgreementHistoryModal(targetUser)
                                }
                                className="mt-2 text-xs font-medium text-indigo-700 hover:text-indigo-800"
                              >
                                View Full History
                              </button>
                            </div>
                          )}

                          {targetUser.memberAgreementSigned &&
                            (user.role === "ADMIN" ||
                              (user.role === "SUPERVISOR" &&
                                targetUser.role !== "ADMIN")) && (
                              <button
                                onClick={() =>
                                  openCancelAgreementModal(targetUser)
                                }
                                className="mt-3 rounded-lg border border-orange-300 px-3 py-1.5 text-sm font-medium text-orange-700 hover:bg-orange-50"
                              >
                                Cancel Agreement
                              </button>
                            )}
                        </div>
                      )}
                    </div>

                    <div className="w-full space-y-3 lg:w-64 lg:flex-shrink-0">
                      {canManageAccount(targetUser) && (
                        <button
                          onClick={() => openEditAccountModal(targetUser)}
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                        >
                          Edit Account
                        </button>
                      )}

                      {(targetUser.availablePromotions?.length > 0 ||
                        targetUser.availableDemotions?.length > 0) && (
                        <select
                          value=""
                          onChange={(e) => {
                            if (e.target.value) {
                              openRoleChangeModal(targetUser, e.target.value);
                              e.target.value = "";
                            }
                          }}
                          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                        >
                          <option value="">Change Role</option>
                          {targetUser.availablePromotions?.map((role) => (
                            <option key={`promote-${role}`} value={role}>
                              Promote to {getRoleDisplayName(role)}
                            </option>
                          ))}
                          {targetUser.availableDemotions?.map((role) => (
                            <option key={`demote-${role}`} value={role}>
                              Demote to {getRoleDisplayName(role)}
                            </option>
                          ))}
                        </select>
                      )}

                      {targetUser.role === "PEER_MENTOR" && (
                        <button
                          onClick={() => openLabAssignmentModal(targetUser)}
                          className="w-full rounded-lg border border-indigo-300 bg-indigo-50 px-3 py-2 text-sm font-medium text-indigo-700 hover:bg-indigo-100"
                        >
                          Manage Lab Assignments
                        </button>
                      )}

                      {(user.role === "ADMIN" ||
                        (user.role === "SUPERVISOR" &&
                          targetUser.role !== "ADMIN")) && (
                        <div className="rounded-xl border border-red-200 bg-red-50/60 p-3">
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-red-700">
                            Danger Zone
                          </p>
                          <div className="space-y-2">
                            {targetUser.isActive ? (
                              <button
                                onClick={() => handleInactivateUser(targetUser)}
                                className="w-full rounded-lg border border-orange-300 bg-white px-3 py-1.5 text-sm font-medium text-orange-700 hover:bg-orange-50"
                              >
                                Mark as Inactive
                              </button>
                            ) : (
                              <button
                                onClick={() => handleReactivateUser(targetUser)}
                                className="w-full rounded-lg border border-green-300 bg-white px-3 py-1.5 text-sm font-medium text-green-700 hover:bg-green-50"
                              >
                                Reactivate User
                              </button>
                            )}

                            <button
                              onClick={() => openDeleteAccountModal(targetUser)}
                              disabled={targetUser.id === user.id}
                              className="w-full rounded-lg border border-red-400 bg-white px-3 py-1.5 text-sm font-medium text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                              title={
                                targetUser.id === user.id
                                  ? "You cannot delete your own account"
                                  : ""
                              }
                            >
                              Delete Account
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              ))}
            </section>
          )}
        </div>
      </main>

      {showCreateAccountModal && (
        <div className="fixed inset-0 z-50 h-full w-full overflow-y-auto bg-gray-600 bg-opacity-50">
          <div className="relative top-20 mx-auto w-full max-w-xl rounded-md border bg-white p-6 shadow-lg">
            <div className="mt-2">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Create Account
                </h3>
                <button
                  onClick={closeCreateAccountModal}
                  disabled={savingAccount}
                  className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <input
                    type="text"
                    value={createAccountForm.name}
                    onChange={(e) =>
                      setCreateAccountForm((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    maxLength={100}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="Full name"
                    disabled={savingAccount}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    value={createAccountForm.email}
                    onChange={(e) =>
                      setCreateAccountForm((prev) => ({
                        ...prev,
                        email: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="user@purdue.edu"
                    disabled={savingAccount}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <input
                    type="password"
                    value={createAccountForm.password}
                    onChange={(e) =>
                      setCreateAccountForm((prev) => ({
                        ...prev,
                        password: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="At least 8 chars with upper/lowercase and number"
                    disabled={savingAccount}
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">
                      Role
                    </label>
                    <select
                      value={createAccountForm.role}
                      onChange={(e) =>
                        setCreateAccountForm((prev) => ({
                          ...prev,
                          role: e.target.value,
                        }))
                      }
                      className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      disabled={savingAccount}
                    >
                      <option value="MEMBER">Member</option>
                      <option value="PEER_MENTOR">Peer Mentor</option>
                      <option value="SUPERVISOR">Supervisor</option>
                      {user.role === "ADMIN" && (
                        <option value="ADMIN">Admin</option>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">
                      Status
                    </label>
                    <select
                      value={createAccountForm.isActive ? "ACTIVE" : "INACTIVE"}
                      onChange={(e) =>
                        setCreateAccountForm((prev) => ({
                          ...prev,
                          isActive: e.target.value === "ACTIVE",
                        }))
                      }
                      className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      disabled={savingAccount}
                    >
                      <option value="ACTIVE">Active</option>
                      <option value="INACTIVE">Inactive</option>
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">
                      Email Verified
                    </label>
                    <select
                      value={createAccountForm.emailVerified ? "YES" : "NO"}
                      onChange={(e) =>
                        setCreateAccountForm((prev) => ({
                          ...prev,
                          emailVerified: e.target.value === "YES",
                        }))
                      }
                      className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      disabled={savingAccount}
                    >
                      <option value="NO">No</option>
                      <option value="YES">Yes</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleCreateAccount}
                  disabled={savingAccount}
                  className="flex-1 rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {savingAccount ? "Creating..." : "Create Account"}
                </button>
                <button
                  onClick={closeCreateAccountModal}
                  disabled={savingAccount}
                  className="flex-1 rounded-md bg-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showEditAccountModal && selectedUser && (
        <div className="fixed inset-0 z-50 h-full w-full overflow-y-auto bg-gray-600 bg-opacity-50">
          <div className="relative top-20 mx-auto w-full max-w-xl rounded-md border bg-white p-6 shadow-lg">
            <div className="mt-2">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  Edit Account
                </h3>
                <button
                  onClick={closeEditAccountModal}
                  disabled={savingAccount}
                  className="text-gray-400 hover:text-gray-600 disabled:opacity-50"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 rounded border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">
                Updating{" "}
                <span className="font-semibold">{selectedUser.name}</span> (
                {selectedUser.role})
              </div>

              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <input
                    type="text"
                    value={editAccountForm.name}
                    onChange={(e) =>
                      setEditAccountForm((prev) => ({
                        ...prev,
                        name: e.target.value,
                      }))
                    }
                    maxLength={100}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    disabled={savingAccount}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    value={editAccountForm.email}
                    onChange={(e) =>
                      setEditAccountForm((prev) => ({
                        ...prev,
                        email: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    disabled={savingAccount}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">
                    Reset Password (Optional)
                  </label>
                  <input
                    type="password"
                    value={editAccountForm.password}
                    onChange={(e) =>
                      setEditAccountForm((prev) => ({
                        ...prev,
                        password: e.target.value,
                      }))
                    }
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                    placeholder="Leave blank to keep current password"
                    disabled={savingAccount}
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">
                      Status
                    </label>
                    <select
                      value={editAccountForm.isActive ? "ACTIVE" : "INACTIVE"}
                      onChange={(e) =>
                        setEditAccountForm((prev) => ({
                          ...prev,
                          isActive: e.target.value === "ACTIVE",
                        }))
                      }
                      className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      disabled={savingAccount}
                    >
                      <option value="ACTIVE">Active</option>
                      <option value="INACTIVE">Inactive</option>
                    </select>
                  </div>

                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">
                      Email Verified
                    </label>
                    <select
                      value={editAccountForm.emailVerified ? "YES" : "NO"}
                      onChange={(e) =>
                        setEditAccountForm((prev) => ({
                          ...prev,
                          emailVerified: e.target.value === "YES",
                        }))
                      }
                      className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                      disabled={savingAccount}
                    >
                      <option value="NO">No</option>
                      <option value="YES">Yes</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleEditAccount}
                  disabled={savingAccount}
                  className="flex-1 rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {savingAccount ? "Saving..." : "Save Changes"}
                </button>
                <button
                  onClick={closeEditAccountModal}
                  disabled={savingAccount}
                  className="flex-1 rounded-md bg-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Role Change Modal */}
      {showRoleChangeModal && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Change User Role
                </h3>
                <button
                  onClick={closeRoleChangeModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-600">
                  User: <span className="font-medium">{selectedUser.name}</span>
                </p>
                <p className="text-sm text-gray-600">
                  Current Role:{" "}
                  <span className="font-medium">
                    {getRoleDisplayName(selectedUser.role)}
                  </span>
                </p>
                <p className="text-sm text-gray-600">
                  New Role:{" "}
                  <span className="font-medium">
                    {getRoleDisplayName(newRole)}
                  </span>
                </p>
              </div>

              {/* Lab Assignments for Peer Mentors */}
              {newRole === "PEER_MENTOR" && (
                <div className="mb-4">
                  <h4 className="text-md font-medium text-gray-900 mb-3">
                    Lab Assignments <span className="text-red-500">*</span>
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Assign labs and specify mentor type for each. A mentor can
                    have different types for different labs.
                  </p>

                  <div className="border border-gray-300 rounded-md p-4 max-h-96 overflow-y-auto">
                    {labs.map((lab) => (
                      <div
                        key={lab.id}
                        className="mb-4 pb-4 border-b border-gray-200 last:border-b-0"
                      >
                        <p className="font-medium text-sm text-gray-900 mb-2">
                          {lab.name} - {lab.location}
                        </p>
                        <div className="ml-4 space-y-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={isLabAssigned(lab.id, "CONSULTATION")}
                              onChange={() =>
                                toggleLabAssignment(lab.id, "CONSULTATION")
                              }
                              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                            />
                            <span className="text-sm text-gray-700">
                              <span className="font-medium">
                                Consultation Peer Mentor
                              </span>
                              <span className="text-gray-500 ml-1">
                                (Reviews projects)
                              </span>
                            </span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={isLabAssigned(lab.id, "LAB")}
                              onChange={() =>
                                toggleLabAssignment(lab.id, "LAB")
                              }
                              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                            />
                            <span className="text-sm text-gray-700">
                              <span className="font-medium">
                                Lab Peer Mentor
                              </span>
                              <span className="text-gray-500 ml-1">
                                (Assists during lab sessions)
                              </span>
                            </span>
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>

                  {labAssignments.length === 0 && (
                    <p className="text-xs text-red-600 mt-2">
                      Please assign at least one lab with a mentor type
                    </p>
                  )}

                  {labAssignments.length > 0 && (
                    <div className="mt-3 p-2 bg-blue-50 rounded">
                      <p className="text-sm text-blue-800">
                        <strong>Summary:</strong> {labAssignments.length}{" "}
                        assignment(s) selected
                      </p>
                    </div>
                  )}
                </div>
              )}

              <div className="flex space-x-3">
                <button
                  onClick={handleRoleChange}
                  disabled={
                    submittingRoleChange ||
                    (newRole === "PEER_MENTOR" && labAssignments.length === 0)
                  }
                  className="flex-1 px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingRoleChange ? "Updating..." : "Confirm Change"}
                </button>
                <button
                  onClick={closeRoleChangeModal}
                  disabled={submittingRoleChange}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lab Assignment Modal */}
      {showLabAssignmentModal && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Manage Lab Assignments - {selectedUser.name}
                </h3>
                <button
                  onClick={closeLabAssignmentModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-3">
                  Assign labs and specify mentor type for each. A mentor can
                  have different types for different labs.
                </p>

                <div className="border border-gray-300 rounded-md p-4 max-h-96 overflow-y-auto">
                  {labs.map((lab) => (
                    <div
                      key={lab.id}
                      className="mb-4 pb-4 border-b border-gray-200 last:border-b-0"
                    >
                      <p className="font-medium text-sm text-gray-900 mb-2">
                        {lab.name} - {lab.location}
                      </p>
                      <div className="ml-4 space-y-2">
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isLabAssigned(lab.id, "CONSULTATION")}
                            onChange={() =>
                              toggleLabAssignment(lab.id, "CONSULTATION")
                            }
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <span className="text-sm text-gray-700">
                            <span className="font-medium">
                              Consultation Peer Mentor
                            </span>
                            <span className="text-gray-500 ml-1">
                              (Reviews projects)
                            </span>
                          </span>
                        </label>
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isLabAssigned(lab.id, "LAB")}
                            onChange={() => toggleLabAssignment(lab.id, "LAB")}
                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                          />
                          <span className="text-sm text-gray-700">
                            <span className="font-medium">Lab Peer Mentor</span>
                            <span className="text-gray-500 ml-1">
                              (Assists during lab sessions)
                            </span>
                          </span>
                        </label>
                      </div>
                    </div>
                  ))}
                </div>

                {labAssignments.length === 0 && (
                  <p className="text-xs text-red-600 mt-2">
                    Please assign at least one lab with a mentor type
                  </p>
                )}

                {labAssignments.length > 0 && (
                  <div className="mt-3 p-2 bg-blue-50 rounded">
                    <p className="text-sm text-blue-800">
                      <strong>Summary:</strong> {labAssignments.length}{" "}
                      assignment(s) selected
                    </p>
                  </div>
                )}
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={handleUpdateLabAssignments}
                  disabled={
                    submittingLabAssignment || labAssignments.length === 0
                  }
                  className="flex-1 px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingLabAssignment ? "Updating..." : "Save Changes"}
                </button>
                <button
                  onClick={closeLabAssignmentModal}
                  disabled={submittingLabAssignment}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Agreement Modal */}
      {showCancelAgreementModal && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Cancel Member Agreement
                </h3>
                <button
                  onClick={closeCancelAgreementModal}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={cancellingAgreement}
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
                <p className="text-sm text-yellow-800">
                  <strong>Warning:</strong> This will revoke {selectedUser.name}
                  's ability to submit project proposals until they sign the
                  agreement again.
                </p>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-700 mb-2">
                  <strong>User:</strong> {selectedUser.name} (
                  {selectedUser.email})
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Current Cancellations:</strong>{" "}
                  {selectedUser.agreementCancellations || 0}
                </p>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason for Cancellation (Optional)
                </label>
                <textarea
                  value={cancelAgreementReason}
                  onChange={(e) => setCancelAgreementReason(e.target.value)}
                  placeholder="Explain why the agreement is being cancelled..."
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  disabled={cancellingAgreement}
                  maxLength={500}
                />
                <p className="text-xs text-gray-500 mt-1">
                  {cancelAgreementReason.length}/500 characters
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={handleCancelAgreement}
                  disabled={cancellingAgreement}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {cancellingAgreement ? "Cancelling..." : "Cancel Agreement"}
                </button>
                <button
                  onClick={closeCancelAgreementModal}
                  disabled={cancellingAgreement}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agreement History Modal */}
      {showAgreementHistoryModal && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-3xl shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Agreement Cancellation History
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedUser.name} ({selectedUser.email})
                  </p>
                </div>
                <button
                  onClick={closeAgreementHistoryModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              {/* Summary */}
              <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500">Total Cancellations</p>
                    <p className="text-lg font-semibold text-gray-900">
                      {selectedUser.agreementCancellations}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Current Status</p>
                    <p className="text-lg font-semibold">
                      {selectedUser.memberAgreementSigned ? (
                        <span className="text-green-600">Signed</span>
                      ) : (
                        <span className="text-red-600">Not Signed</span>
                      )}
                    </p>
                  </div>
                </div>
              </div>

              {/* History Timeline */}
              {loadingHistory ? (
                <div className="flex justify-center items-center p-8">
                  <Spinner />
                  <span className="ml-2">Loading history...</span>
                </div>
              ) : (
                <div className="max-h-96 overflow-y-auto">
                  <div className="space-y-4">
                    {agreementHistory.map((record, index) => (
                      <div
                        key={record.id}
                        className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="px-2 py-1 text-xs font-medium rounded-full bg-orange-100 text-orange-800">
                              Cancellation #{agreementHistory.length - index}
                            </span>
                            <span className="text-sm text-gray-600">
                              {formatDateTime(record.createdAt)}
                            </span>
                          </div>

                          {editingCancellationId !== record.id &&
                            !updatingReason && (
                              <button
                                onClick={() => startEditingReason(record)}
                                className="text-xs text-indigo-600 hover:text-indigo-800"
                              >
                                Edit Reason
                              </button>
                            )}
                        </div>

                        <div className="space-y-2">
                          <div>
                            <p className="text-xs text-gray-500">
                              Cancelled By
                            </p>
                            <p className="text-sm font-medium text-gray-900">
                              {record.cancelledByUser.name} (
                              {record.cancelledByUser.role})
                            </p>
                            <p className="text-xs text-gray-600">
                              {record.cancelledByUser.email}
                            </p>
                          </div>

                          {editingCancellationId === record.id ? (
                            <div className="mt-3">
                              <label className="block text-xs font-medium text-gray-700 mb-1">
                                Edit Reason:
                              </label>
                              <textarea
                                value={editingReason}
                                onChange={(e) =>
                                  setEditingReason(e.target.value)
                                }
                                placeholder="Explain why the agreement was cancelled..."
                                rows={4}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                                disabled={updatingReason}
                                maxLength={500}
                              />
                              <div className="flex justify-between items-center mt-1">
                                <p className="text-xs text-gray-500">
                                  {editingReason.length}/500 characters
                                </p>
                                <div className="space-x-2">
                                  <button
                                    onClick={() =>
                                      handleUpdateCancellationReason(record.id)
                                    }
                                    disabled={updatingReason}
                                    className="px-3 py-1 text-xs bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:opacity-50"
                                  >
                                    {updatingReason ? "Saving..." : "Save"}
                                  </button>
                                  <button
                                    onClick={cancelEditingReason}
                                    disabled={updatingReason}
                                    className="px-3 py-1 text-xs bg-gray-300 text-gray-700 rounded hover:bg-gray-400 disabled:opacity-50"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <>
                              {record.reason ? (
                                <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
                                  <p className="text-xs font-medium text-gray-700 mb-1">
                                    Reason:
                                  </p>
                                  <p className="text-sm text-gray-800 whitespace-pre-wrap">
                                    {record.reason}
                                  </p>
                                </div>
                              ) : (
                                <p className="text-xs italic text-gray-400 mt-2">
                                  No reason provided
                                </p>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-6">
                <button
                  onClick={closeAgreementHistoryModal}
                  className="w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Account Modal */}
      {showDeleteAccountModal && selectedUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-red-700">
                  Delete Account
                </h3>
                <button
                  onClick={closeDeleteAccountModal}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={deletingAccount}
                >
                  ✕
                </button>
              </div>

              <div className="mb-4 p-4 bg-red-50 border border-red-300 rounded">
                <p className="text-sm text-red-800 font-medium mb-2">
                  This action is permanent and cannot be undone!
                </p>
                <ul className="text-sm text-red-700 space-y-1 list-disc list-inside">
                  <li>The user account will be permanently deleted</li>
                  <li>User will lose all system access</li>
                  <li>Projects and bookings will remain in the system</li>
                  <li>If they register again, it will be a new account</li>
                  <li>They cannot access old projects or bookings</li>
                </ul>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-700 mb-2">
                  <strong>User:</strong> {selectedUser.name} (
                  {selectedUser.email})
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Role:</strong> {getRoleDisplayName(selectedUser.role)}
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={handleDeleteAccount}
                  disabled={deletingAccount}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {deletingAccount ? "Deleting..." : "Permanently Delete"}
                </button>
                <button
                  onClick={closeDeleteAccountModal}
                  disabled={deletingAccount}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default UserManagement;
