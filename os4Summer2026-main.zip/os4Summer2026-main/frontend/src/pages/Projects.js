import { useState, useEffect } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { projectAPI, authAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import {
  formatDate,
  formatTime,
  getStatusColor,
  getStatusLabel,
} from "../services/utils";
import ProjectForm from "../components/ProjectForm";

function Projects() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [agreementStatus, setAgreementStatus] = useState(null);
  const [loadingAgreement, setLoadingAgreement] = useState(true);

  // Modal states
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [deletingProject, setDeletingProject] = useState(null);

  // Filter and search states
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");

  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [cancellingProject, setCancellingProject] = useState(null);

  const [selectedConsultation, setSelectedConsultation] = useState(null);

  useEffect(() => {
    loadProjects();
    checkAgreementStatus();
  }, []);

  const checkAgreementStatus = async () => {
    try {
      setLoadingAgreement(true);
      const response = await authAPI.getAgreementStatus();
      setAgreementStatus(response.data);
    } catch (err) {
      console.error("Check agreement status error:", err);
      setAgreementStatus({ memberAgreementSigned: false });
    } finally {
      setLoadingAgreement(false);
    }
  };

  const loadProjects = async () => {
    try {
      setLoading(true);
      const response = await projectAPI.getUserProjects();
      setProjects(response.data.projects || []);
    } catch (err) {
      setError("Failed to load projects. Please try again.");
      console.error("Load projects error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSuccess = async (newProject) => {
    setProjects((prev) => [newProject, ...prev]);
    setShowCreateForm(false);
    setSuccess("Project created successfully!");
    setTimeout(() => setSuccess(""), 5000);

    await loadProjects();
  };

  const handleEditSuccess = (updatedProject) => {
    setEditingProject(null);
    setSuccess("Project updated successfully!");
    setTimeout(() => setSuccess(""), 5000);

    loadProjects();
  };

  const handleDeleteProject = async (projectId) => {
    try {
      await projectAPI.deleteProject(projectId);
      setProjects((prev) => prev.filter((p) => p.id !== projectId));
      setDeletingProject(null);
      setSuccess("Project deleted successfully!");
      setTimeout(() => setSuccess(""), 5000);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to delete project. Please try again.",
      );
      console.error("Delete project error:", err);
    }
  };

  // Helper function to get who cancelled the consultation
  const getCancellationDisplay = (project) => {
    if (!project.consultation) return null;

    const { consultation } = project;

    if (consultation.status === "CANCELLED" && consultation.cancelledBy) {
      if (consultation.cancelledBy === project.userId) {
        return {
          type: "cancelled",
          who: "You",
          reason: consultation.cancelReason?.trim()
            ? consultation.cancelReason
            : "Not Provided",
          when: consultation.cancelledAt,
        };
      } else {
        return {
          type: "cancelled",
          who: "Admin",
          reason: consultation.cancelReason || "Not Provided",
          when: consultation.cancelledAt,
        };
      }
    }

    if (consultation.status === "ABSENT" && consultation.markedAbsentBy) {
      return {
        type: "absent",
        who: "Admin",
        reason: consultation.absentReason,
        when: consultation.absentAt,
      };
    }

    return null;
  };

  const handleCancelConsultation = async () => {
    if (!cancellingProject || !selectedConsultation) return;

    try {
      setLoading(true);

      await authAPI.cancelConsultation(selectedConsultation.id, cancelReason);

      setSuccess(`Session cancelled successfully!`);
      setTimeout(() => setSuccess(""), 3000);

      setShowCancelModal(false);
      setCancelReason("");
      setCancellingProject(null);
      setSelectedConsultation(null);

      await loadProjects();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to cancel consultation");
      setTimeout(() => setError(""), 5000);
    } finally {
      setLoading(false);
    }
  };

  const openCancelModal = (project, consultation) => {
    setCancellingProject(project);
    setSelectedConsultation(consultation);
    setCancelReason("");
    setShowCancelModal(true);
  };

  const handleReschedule = (project) => {
    const rescheduleData = {
      name: project.name,
      description: project.description,
      labId: project.lab.id,
      equipmentIds: project.equipment.map((e) => e.id),
      isReschedule: true,
      originalProjectId: project.id,
    };

    sessionStorage.setItem("rescheduleData", JSON.stringify(rescheduleData));

    setShowCreateForm(true);
  };

  // Filter projects based on search and status
  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.lab.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.equipment.some((equip) =>
        equip.name.toLowerCase().includes(searchTerm.toLowerCase()),
      );

    const matchesStatus =
      statusFilter === "ALL" || project.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const renderMain = () => {
    if (showCreateForm) {
      return (
        <ProjectForm
          onSuccess={handleCreateSuccess}
          onCancel={() => setShowCreateForm(false)}
        />
      );
    }

    if (editingProject) {
      return (
        <ProjectForm
          editProject={editingProject}
          onSuccess={handleEditSuccess}
          onCancel={() => setEditingProject(null)}
        />
      );
    }

    return (
      <div className="px-4 py-6 sm:px-0 space-y-6">
        {/* Page Header */}
        <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="min-w-0">
              <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                My Projects
              </h2>
              <p className="mt-2 max-w-3xl text-sm text-blue-100">
                Manage your project proposals and track their status.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {loadingAgreement ? (
                <div className="flex items-center text-sm text-blue-100">
                  <Spinner size="sm" className="mr-2" />
                  Checking agreement...
                </div>
              ) : !agreementStatus?.memberAgreementSigned ? (
                <button
                  onClick={() => navigate("/member-agreement")}
                  className="inline-flex items-center rounded-lg bg-amber-500 px-4 py-2 text-sm font-medium text-white transition hover:bg-amber-600"
                >
                  Sign Member Agreement
                </button>
              ) : (
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="inline-flex items-center rounded-lg border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/40"
                >
                  Create Project Proposal
                </button>
              )}
            </div>
          </div>
        </section>

        {/* Alerts */}
        {error && <Alert type="error">{error}</Alert>}

        {success && <Alert type="success">{success}</Alert>}

        {/* Filters */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="search"
                className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
              >
                Search Projects
              </label>
              <input
                type="text"
                id="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by project name, description, lab, or equipment..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              />
            </div>
            <div>
              <label
                htmlFor="status"
                className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
              >
                Filter by Status
              </label>
              <select
                id="status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="ALL">All Projects</option>
                <option value="IN_PROCESS">In Review</option>
                <option value="CONSULTATION_CANCELLED">Cancelled</option>
                <option value="CONSULTATION_ABSENT">Absent</option>
                <option value="APPROVED">Approved</option>
                <option value="DECLINED">Declined</option>
              </select>
            </div>
          </div>
        </section>

        {/* Projects List */}
        {loading ? (
          <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
            <Spinner />
            <span className="ml-2 text-sm text-slate-600">
              Loading projects...
            </span>
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900">
              No projects found
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              {projects.length === 0
                ? "Get started by creating your first project."
                : "Try adjusting your search or filter criteria."}
            </p>
            {projects.length === 0 &&
              agreementStatus?.memberAgreementSigned && (
                <div className="mt-6">
                  <button
                    onClick={() => setShowCreateForm(true)}
                    className="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-indigo-700"
                  >
                    Create Your First Project Proposal
                  </button>
                </div>
              )}
          </div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <ul className="divide-y divide-slate-200">
              {filteredProjects.map((project) => {
                const alreadyRescheduled =
                  Array.isArray(project.rescheduledTo) &&
                  project.rescheduledTo.length > 0;
                const primaryConsultation =
                  project.consultations?.find(
                    (c) => c.status === "SCHEDULED" && c.date && c.startTime,
                  ) ||
                  project.consultations?.[0] ||
                  project.consultation ||
                  null;
                const canEditOrDelete =
                  project.status === "IN_PROCESS" &&
                  primaryConsultation &&
                  !["CANCELLED", "ABSENT"].includes(
                    primaryConsultation.status,
                  ) &&
                  !alreadyRescheduled;
                const consultations = Array.isArray(project.consultations)
                  ? project.consultations
                  : [];
                const hasScheduledConsultation = consultations.some(
                  (c) => c.status === "SCHEDULED",
                );
                const hasCancelledOrAbsentConsultation = consultations.some(
                  (c) => ["CANCELLED", "ABSENT"].includes(c.status),
                );
                const canReschedule =
                  !alreadyRescheduled &&
                  (["CONSULTATION_CANCELLED", "CONSULTATION_ABSENT"].includes(
                    project.status,
                  ) ||
                    (hasCancelledOrAbsentConsultation &&
                      !hasScheduledConsultation &&
                      project.status !== "APPROVED" &&
                      project.status !== "DECLINED"));

                if (!project?.lab) {
                  return null;
                }

                return (
                  <li key={project.id}>
                    <div className="px-4 py-4 sm:px-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="text-lg font-medium text-indigo-600 truncate">
                              {project.name}
                            </p>
                            <div className="flex items-center text-sm text-gray-500">
                              <span
                                className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                  project.status,
                                )}`}
                              >
                                {getStatusLabel(project.status)}
                              </span>
                              <span className="ml-4">
                                Created {formatDate(project.createdAt)}
                              </span>
                            </div>
                          </div>

                          {/* Project Details */}
                          <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
                            <div className="space-y-2 text-sm">
                              <div>
                                <span className="font-medium text-slate-700">
                                  Project Description:
                                </span>
                                <span className="ml-2 text-slate-600">
                                  {project.description}
                                </span>
                              </div>
                              <div>
                                <span className="font-medium text-slate-700">
                                  Lab:
                                </span>
                                <span className="ml-2 text-slate-600">
                                  {project.lab.name}
                                </span>
                              </div>
                              <div>
                                <span className="font-medium text-slate-700">
                                  Lab Location:
                                </span>
                                <span className="ml-2 text-slate-600">
                                  {project.lab.location}
                                </span>
                              </div>
                              <div>
                                <span className="font-medium text-slate-700">
                                  Lab Equipment
                                  {project.equipment.length > 1 ? "s" : ""}:
                                </span>
                                <div className="ml-2 mt-1 space-y-1">
                                  {project.equipment.map((equip) => (
                                    <div
                                      key={equip.id}
                                      className="text-slate-600"
                                    >
                                      • {equip.name}
                                    </div>
                                  )) || (
                                    <span className="text-slate-500">
                                      No equipment
                                    </span>
                                  )}
                                </div>
                              </div>
                              {project.consultations &&
                                project.consultations.length > 0 && (
                                  <div className="border-t border-slate-300 pt-3">
                                    <h4 className="mb-2 font-semibold text-slate-700">
                                      Consultation Sessions (
                                      {project.consultations.length})
                                    </h4>

                                    {/* Show info badge if multiple consultations */}
                                    {project.consultations.length > 1 && (
                                      <div className="mb-3 p-2 bg-blue-50 border border-blue-200 rounded text-sm text-blue-800">
                                        📅 This project has{" "}
                                        {project.consultations.length}{" "}
                                        consultation sessions scheduled
                                      </div>
                                    )}

                                    {/* Display each consultation */}
                                    {project.consultations.map(
                                      (consultation, index) => {
                                        // Check for cancellation or absent status
                                        const getCancellationInfo = () => {
                                          if (
                                            consultation.status ===
                                              "CANCELLED" &&
                                            consultation.cancelledBy
                                          ) {
                                            return {
                                              type: "cancelled",
                                              reason:
                                                consultation.cancelReason ||
                                                "Not provided",
                                              when: consultation.cancelledAt,
                                            };
                                          }
                                          if (
                                            consultation.status === "ABSENT" &&
                                            consultation.markedAbsentBy
                                          ) {
                                            return {
                                              type: "absent",
                                              reason:
                                                consultation.absentReason ||
                                                "Not provided",
                                              when: consultation.absentAt,
                                            };
                                          }
                                          return null;
                                        };

                                        const cancellationInfo =
                                          getCancellationInfo();

                                        return (
                                          <div
                                            key={consultation.id}
                                            className={`mb-4 p-3 rounded-lg border ${
                                              index === 0
                                                ? "bg-indigo-50 border-indigo-200"
                                                : "bg-slate-50 border-slate-200"
                                            }`}
                                          >
                                            <div className="flex justify-between items-start mb-2">
                                              <h5 className="font-medium text-slate-900">
                                                Session {index + 1}
                                              </h5>
                                              <span
                                                className={`text-xs px-2 py-1 rounded ${
                                                  consultation.status ===
                                                  "SCHEDULED"
                                                    ? "bg-blue-100 text-blue-800"
                                                    : consultation.status ===
                                                        "COMPLETED"
                                                      ? "bg-green-100 text-green-800"
                                                      : consultation.status ===
                                                          "CANCELLED"
                                                        ? "bg-yellow-100 text-yellow-800"
                                                        : "bg-red-100 text-red-800"
                                                }`}
                                              >
                                                {consultation.status}
                                              </span>
                                            </div>

                                            {/* Cancellation/Absent Info */}
                                            {cancellationInfo && (
                                              <div
                                                className={`p-3 rounded-lg mb-3 ${
                                                  cancellationInfo.type ===
                                                  "cancelled"
                                                    ? "bg-yellow-50 border border-yellow-200"
                                                    : "bg-red-50 border border-red-200"
                                                }`}
                                              >
                                                <div>
                                                  <span
                                                    className={`font-semibold ${
                                                      cancellationInfo.type ===
                                                      "cancelled"
                                                        ? "text-yellow-800"
                                                        : "text-red-800"
                                                    }`}
                                                  >
                                                    {cancellationInfo.type ===
                                                    "cancelled"
                                                      ? "Cancelled"
                                                      : "Marked Absent"}
                                                  </span>
                                                </div>
                                                <p className="mt-2 text-sm text-slate-600">
                                                  Reason:{" "}
                                                  {cancellationInfo.reason}
                                                </p>
                                                {cancellationInfo.when && (
                                                  <p className="mt-1 text-xs text-slate-500">
                                                    {new Date(
                                                      cancellationInfo.when,
                                                    ).toLocaleString()}
                                                  </p>
                                                )}
                                              </div>
                                            )}

                                            {/* Consultation Details */}
                                            <div className="space-y-2 text-sm">
                                              <div>
                                                <span className="font-medium text-slate-700">
                                                  Time:
                                                </span>
                                                <span className="ml-2 text-slate-600">
                                                  {consultation.date &&
                                                  consultation.startTime
                                                    ? `${formatDate(consultation.date)} at ${formatTime(
                                                        consultation.startTime,
                                                      )}`
                                                    : "[Time Released]"}
                                                </span>
                                              </div>
                                              {consultation.mentor && (
                                                <div>
                                                  <span className="font-medium text-slate-700">
                                                    Mentor:
                                                  </span>
                                                  <span className="ml-2 text-slate-600">
                                                    {consultation.mentor}
                                                  </span>
                                                </div>
                                              )}
                                              {consultation.mentorFeedback && (
                                                <div>
                                                  <span className="font-medium text-slate-700">
                                                    Feedback:
                                                  </span>
                                                  <p className="ml-2 mt-1 italic text-slate-600">
                                                    "
                                                    {
                                                      consultation.mentorFeedback
                                                    }
                                                    "
                                                  </p>
                                                </div>
                                              )}
                                            </div>

                                            {/* Action Buttons for Scheduled Consultations */}
                                            {project.status === "IN_PROCESS" &&
                                              consultation.status ===
                                                "SCHEDULED" && (
                                                <div className="mt-3">
                                                  <button
                                                    onClick={() =>
                                                      openCancelModal(
                                                        project,
                                                        consultation,
                                                      )
                                                    }
                                                    className="px-3 py-1.5 bg-yellow-500 text-white rounded hover:bg-yellow-600 text-sm"
                                                  >
                                                    Cancel This Session
                                                  </button>
                                                </div>
                                              )}
                                          </div>
                                        );
                                      },
                                    )}

                                    {/* Reschedule Info */}
                                    {project.rescheduledTo &&
                                      Array.isArray(project.rescheduledTo) &&
                                      project.rescheduledTo.length > 0 && (
                                        <div className="mt-3 px-3 py-2 bg-green-100 text-green-800 rounded text-sm font-medium border border-green-200">
                                          Rescheduled (New consultation created
                                          on{" "}
                                          {new Date(
                                            project.rescheduledTo[0].createdAt,
                                          ).toLocaleDateString()}
                                          )
                                        </div>
                                      )}
                                  </div>
                                )}
                            </div>
                          </div>
                        </div>

                        {(canEditOrDelete || canReschedule) && (
                          <div className="ml-4 flex space-x-2">
                            {canEditOrDelete && (
                              <>
                                <button
                                  onClick={() => setEditingProject(project)}
                                  className="inline-flex items-center rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                                >
                                  Edit
                                </button>
                                <button
                                  onClick={() => setDeletingProject(project)}
                                  className="inline-flex items-center rounded-lg border border-red-200 bg-white px-3 py-2 text-sm font-medium text-red-700 shadow-sm transition hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-200"
                                >
                                  Delete
                                </button>
                              </>
                            )}
                            {canReschedule && (
                              <button
                                onClick={() => handleReschedule(project)}
                                className="inline-flex items-center rounded-lg border border-indigo-200 bg-white px-3 py-2 text-sm font-medium text-indigo-700 shadow-sm transition hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                              >
                                Reschedule
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="projects" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {renderMain()}
      </main>

      {/* Delete Confirmation Modal */}
      {deletingProject && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3 text-center">
              <div className="mt-2 px-7 py-3">
                <p className="text-sm text-gray-500">
                  Are you sure you want to delete "{deletingProject.name}"? This
                  action cannot be undone.
                </p>
              </div>
              <div className="items-center px-4 py-3">
                <button
                  onClick={() => handleDeleteProject(deletingProject.id)}
                  className="px-4 py-2 bg-red-500 text-white text-base font-medium rounded-md w-full shadow-hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-300 mr-2"
                >
                  Delete Project
                </button>
                <button
                  onClick={() => setDeletingProject(null)}
                  className="mt-3 px-4 py-2 bg-gray-500 text-white text-base font-medium rounded-md w-full shadow-hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-300"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Consultation Modal */}
      {showCancelModal && cancellingProject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">Cancel Consultation</h3>

            <p className="text-gray-600 mb-4">
              Are you sure you want to cancel the consultation for{" "}
              <span className="font-semibold">{cancellingProject.name}</span>?
            </p>

            <p className="text-sm text-gray-500 mb-4">
              After cancellation, you can reschedule by creating a new project
              proposal with the same details.
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for Cancellation (Optional)
              </label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Enter reason for cancellation..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="3"
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowCancelModal(false);
                  setCancelReason("");
                  setCancellingProject(null);
                  setSelectedConsultation(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                disabled={loading}
              >
                Keep Consultation
              </button>
              <button
                onClick={handleCancelConsultation}
                className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 disabled:opacity-50"
                disabled={loading}
              >
                {loading ? "Cancelling..." : "Cancel Consultation"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Projects;
