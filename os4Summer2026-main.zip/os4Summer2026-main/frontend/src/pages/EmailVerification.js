import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { authAPI } from "../services/api";
import { isRemembered, setSession } from "../services/auth";
import Spinner from "../components/Spinner";

function EmailVerification() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState("verifying");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const token = searchParams.get("token");

  useEffect(() => {
    let isActive = true;

    const verifyEmail = async () => {
      if (!token) {
        setStatus("error");
        setMessage("No verification token provided");
        return;
      }

      try {
        const response = await authAPI.verifyEmail(token);
        if (!isActive) return;

        // If user has an active session, refresh session metadata from DB so
        // profile/nav immediately show the updated email without re-login
        try {
          const meResponse = await authAPI.getMe();
          const { user, exp } = meResponse.data || {};
          if (user && exp) {
            setSession(user, exp, isRemembered());
          }
        } catch (_sessionError) {
          // Ignore when verification link is opened while logged out
        }

        setStatus("success");
        setMessage(response.data.message);
      } catch (error) {
        if (!isActive) return;
        setStatus("error");
        setMessage(
          error.response?.data?.message || "Email verification failed",
        );
      }
    };

    // Delay execution slightly so React StrictMode dev remount does not trigger
    // duplicate token verification requests
    const timer = setTimeout(verifyEmail, 50);

    return () => {
      isActive = false;
      clearTimeout(timer);
    };
  }, [token]);

  const handleLoginRedirect = () => {
    navigate("/login");
  };

  if (status === "verifying") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 text-center">
          <div>
            <Spinner size="xl" className="mx-auto" />
            <h2 className="mt-6 text-center text-2xl font-extrabold text-gray-900">
              Verifying your email...
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Please wait while we verify your account
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (status === "success") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 text-center">
          <div>
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
              <svg
                className="h-6 w-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                ></path>
              </svg>
            </div>
            <h2 className="mt-6 text-center text-2xl font-extrabold text-gray-900">
              Email Verified Successfully!
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">{message}</p>
          </div>
          <div>
            <button
              onClick={handleLoginRedirect}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Continue to Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (status === "error") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 text-center">
          <div>
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
              <svg
                className="h-6 w-6 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                ></path>
              </svg>
            </div>
            <h2 className="mt-6 text-center text-2xl font-extrabold text-gray-900">
              Verification Failed
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">{message}</p>
          </div>
          <div className="space-y-3">
            <button
              onClick={handleLoginRedirect}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Go to Login
            </button>
            <a
              href="/register"
              className="group relative w-full flex justify-center py-2 px-4 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Register Again
            </a>
          </div>
        </div>
      </div>
    );
  }
}

export default EmailVerification;
