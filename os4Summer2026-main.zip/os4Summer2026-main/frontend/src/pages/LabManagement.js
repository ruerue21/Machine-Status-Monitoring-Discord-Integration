import { useState, useEffect, useCallback } from "react";
import { getUserFromToken } from "../services/auth";
import { useNavigate } from "react-router-dom";
import { labManagementAPI, getAgreementFileDownloadUrl } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { formatDateTime, getFileIcon } from "../services/utils";

const toDateTimeLocalInputValue = (dateValue) => {
  if (!dateValue) {
    return "";
  }
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    return "";
  }

  const tzOffsetMs = date.getTimezoneOffset() * 60 * 1000;
  const local = new Date(date.getTime() - tzOffsetMs);
  return local.toISOString().slice(0, 16);
};

const normalizeEquipmentStatus = (status) =>
  status === "MAINTENANCE" ? "OUT_OF_ORDER" : status;

const getEquipmentOutOfOrderMode = (equipment) =>
  equipment.outOfOrderNever ? "NEVER" : "TEMPORARY";

const formatOutOfOrderWindowLabel = (equipment) => {
  if (!equipment) {
    return "";
  }
  if (equipment.outOfOrderNever) {
    return "Out of order until further notice";
  }
  if (equipment.outOfOrderUntil) {
    return `Out of order until ${new Date(equipment.outOfOrderUntil).toLocaleString()}`;
  }
  return "Out of order";
};

function LabManagement() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  // State management
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [agreementFilter, setAgreementFilter] = useState("ALL");

  // Modal states
  const [showCreateLabModal, setShowCreateLabModal] = useState(false);
  const [showEditLabModal, setShowEditLabModal] = useState(false);
  const [showAddEquipmentModal, setShowAddEquipmentModal] = useState(false);
  const [showEditEquipmentModal, setShowEditEquipmentModal] = useState(false);
  const [showDeactivationModal, setShowDeactivationModal] = useState(false);

  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [selectedLabForAgreement, setSelectedLabForAgreement] = useState(null);
  const [agreementFiles, setAgreementFiles] = useState([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [deletingFileId, setDeletingFileId] = useState(null);
  const [signatureCount, setSignatureCount] = useState(0);
  const [pendingFile, setPendingFile] = useState(null);
  const [showUploadConfirmation, setShowUploadConfirmation] = useState(false);
  const [togglingAgreement, setTogglingAgreement] = useState(false);

  // Selected items
  const [selectedLab, setSelectedLab] = useState(null);
  const [selectedEquipment, setSelectedEquipment] = useState(null);
  const [selectedLabForDeactivation, setSelectedLabForDeactivation] =
    useState(null);
  const [expandedLabId, setExpandedLabId] = useState(null);

  // Lab Agreement Cancellation States
  const [showSignersModal, setShowSignersModal] = useState(false);
  const [selectedLabForSigners, setSelectedLabForSigners] = useState(null);
  const [labSigners, setLabSigners] = useState([]);
  const [signersSearchTerm, setSignersSearchTerm] = useState("");
  const [debouncedSignersSearch, setDebouncedSignersSearch] = useState("");
  const [loadingSigners, setLoadingSigners] = useState(false);

  const [showCancelAgreementModal, setShowCancelAgreementModal] =
    useState(false);
  const [selectedSignerForCancel, setSelectedSignerForCancel] = useState(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [cancellingAgreement, setCancellingAgreement] = useState(false);

  const [showAgreementHistoryModal, setShowAgreementHistoryModal] =
    useState(false);
  const [selectedUserForHistory, setSelectedUserForHistory] = useState(null);
  const [agreementHistory, setAgreementHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [historyPagination, setHistoryPagination] = useState({
    total: 0,
    limit: 10,
    offset: 0,
    hasMore: false,
  });
  const [loadingMoreHistory, setLoadingMoreHistory] = useState(false);

  const [editingCancellationId, setEditingCancellationId] = useState(null);
  const [editingReason, setEditingReason] = useState("");
  const [updatingReason, setUpdatingReason] = useState(false);

  // Form states
  const [labForm, setLabForm] = useState({
    name: "",
    location: "",
    description: "",
  });

  const [equipmentForm, setEquipmentForm] = useState({
    name: "",
    description: "",
    status: "AVAILABLE",
    isActive: true,
    outOfOrderMode: "TEMPORARY",
    outOfOrderUntil: "",
  });
  const [deactivationForm, setDeactivationForm] = useState({
    mode: "TEMPORARY",
    unavailableUntil: "",
  });

  // Loading states
  const [submitting, setSubmitting] = useState(false);
  const [updatingDeactivation, setUpdatingDeactivation] = useState(false);

  // Check if user has access (all employees)
  const hasAccess = ["ADMIN", "SUPERVISOR"].includes(user?.role);

  useEffect(() => {
    if (!hasAccess) {
      navigate("/dashboard");
    }
  }, [hasAccess, navigate]);

  // Debounce search term
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  // Debounce signers search
  useEffect(() => {
    if (!showSignersModal) {
      setDebouncedSignersSearch("");
      return;
    }

    const timeoutId = setTimeout(() => {
      setDebouncedSignersSearch(signersSearchTerm);
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [signersSearchTerm, showSignersModal]);

  // Load signers when debounced search changes
  useEffect(() => {
    if (showSignersModal && selectedLabForSigners) {
      loadLabSigners(selectedLabForSigners.id, debouncedSignersSearch);
    }
  }, [debouncedSignersSearch, showSignersModal, selectedLabForSigners]);

  const loadLabs = useCallback(
    async (showRefreshLoader = false) => {
      try {
        if (showRefreshLoader) {
          setRefreshing(true);
        } else {
          setLoading(true);
        }

        const params = {};

        if (debouncedSearchTerm) {
          params.search = debouncedSearchTerm;
        }

        if (statusFilter && statusFilter !== "ALL") {
          params.status = statusFilter;
        }

        if (agreementFilter && agreementFilter !== "ALL") {
          params.agreementRequired = agreementFilter;
        }

        const response = await labManagementAPI.getAllLabs(params);
        setLabs(response.data.labs);
        setLastUpdated(new Date());
      } catch (err) {
        setError("Failed to load labs. Please try again.");
        console.error("Load labs error:", err);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [debouncedSearchTerm, statusFilter, agreementFilter],
  );

  // Load labs when filters change
  useEffect(() => {
    if (hasAccess) {
      loadLabs();
    }
  }, [hasAccess, loadLabs]);

  const handleRefreshStats = async () => {
    setError("");
    setSuccess("");
    await loadLabs(true);
    setSuccess("Stats refreshed successfully!");
    setTimeout(() => setSuccess(""), 2000);
  };

  // Lab CRUD operations
  const openCreateLabModal = () => {
    setLabForm({
      name: "",
      location: "",
      description: "",
    });
    setShowCreateLabModal(true);
  };

  const openEditLabModal = (lab) => {
    setSelectedLab(lab);
    setLabForm({
      name: lab.name,
      location: lab.location || "",
      description: lab.description || "",
    });
    setShowEditLabModal(true);
  };

  const closeLabModals = () => {
    setShowCreateLabModal(false);
    setShowEditLabModal(false);
    setSelectedLab(null);
    setLabForm({
      name: "",
      location: "",
      description: "",
    });
  };

  const handleCreateLab = async () => {
    if (!labForm.name || !labForm.name.trim()) {
      setError("Lab name is required");
      setTimeout(() => setError(""), 3000);
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      await labManagementAPI.createLab(labForm);

      setSuccess("Lab created successfully!");
      setTimeout(() => setSuccess(""), 3000);

      closeLabModals();
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to create lab. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Create lab error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateLab = async () => {
    if (!labForm.name || !labForm.name.trim()) {
      setError("Lab name is required");
      setTimeout(() => setError(""), 3000);
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      await labManagementAPI.updateLab(selectedLab.id, labForm);

      setSuccess("Lab updated successfully!");
      setTimeout(() => setSuccess(""), 3000);

      closeLabModals();
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update lab. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Update lab error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const openDeactivationModal = (lab) => {
    setSelectedLabForDeactivation(lab);
    setDeactivationForm({
      mode: lab.deactivationNever ? "NEVER" : "TEMPORARY",
      unavailableUntil: toDateTimeLocalInputValue(lab.unavailableUntil),
    });
    setShowDeactivationModal(true);
  };

  const closeDeactivationModal = () => {
    setShowDeactivationModal(false);
    setSelectedLabForDeactivation(null);
    setDeactivationForm({
      mode: "TEMPORARY",
      unavailableUntil: "",
    });
  };

  const handleActivateLab = async (lab) => {
    if (!window.confirm(`Are you sure you want to activate ${lab.name}?`)) {
      return;
    }

    try {
      await labManagementAPI.updateLab(lab.id, { isActive: true });
      setSuccess("Lab activated successfully!");
      setTimeout(() => setSuccess(""), 3000);
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to activate lab. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Activate lab error:", err);
    }
  };

  const handleSaveDeactivation = async () => {
    if (!selectedLabForDeactivation) {
      return;
    }
    if (
      deactivationForm.mode === "TEMPORARY" &&
      !deactivationForm.unavailableUntil
    ) {
      setError("Please select when the lab will become available again.");
      setTimeout(() => setError(""), 4000);
      return;
    }

    try {
      setUpdatingDeactivation(true);
      setError("");

      const payload =
        deactivationForm.mode === "NEVER"
          ? {
              isActive: false,
              deactivationNever: true,
            }
          : {
              isActive: false,
              deactivationNever: false,
              unavailableUntil: new Date(
                deactivationForm.unavailableUntil,
              ).toISOString(),
            };

      const response = await labManagementAPI.updateLab(
        selectedLabForDeactivation.id,
        payload,
      );

      const cancelledCount = response.data?.cancelledBookings || 0;
      const successMessage =
        deactivationForm.mode === "NEVER"
          ? `Lab deactivated indefinitely.${cancelledCount > 0 ? ` Cancelled ${cancelledCount} affected session(s).` : ""}`
          : `Lab deactivated until ${new Date(
              deactivationForm.unavailableUntil,
            ).toLocaleString()}.${cancelledCount > 0 ? ` Cancelled ${cancelledCount} affected session(s).` : ""}`;

      setSuccess(successMessage);
      setTimeout(() => setSuccess(""), 5000);

      closeDeactivationModal();
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update deactivation settings. Please try again.",
      );
      setTimeout(() => setError(""), 6000);
      console.error("Save deactivation error:", err);
    } finally {
      setUpdatingDeactivation(false);
    }
  };

  const handleDeleteLab = async (lab) => {
    if (
      !window.confirm(
        `Are you sure you want to delete ${lab.name}? This action cannot be undone.`,
      )
    ) {
      return;
    }

    try {
      await labManagementAPI.deleteLab(lab.id);

      setSuccess("Lab deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);

      loadLabs();
    } catch (err) {
      if (err.response?.data?.warnings) {
        setError(
          `${err.response.data.message}\n\n${err.response.data.warnings.join(
            "\n",
          )}\n\n${err.response.data.suggestion}`,
        );
      } else {
        setError(
          err.response?.data?.message ||
            "Failed to delete lab. Please try again.",
        );
      }
      setTimeout(() => setError(""), 8000);
      console.error("Delete lab error:", err);
    }
  };

  // Equipment CRUD operations
  const openAddEquipmentModal = (lab) => {
    setSelectedLab(lab);
    setEquipmentForm({
      name: "",
      description: "",
      status: "AVAILABLE",
      isActive: true,
      outOfOrderMode: "TEMPORARY",
      outOfOrderUntil: "",
    });
    setShowAddEquipmentModal(true);
  };

  const openEditEquipmentModal = (lab, equipment) => {
    setSelectedLab(lab);
    setSelectedEquipment(equipment);
    setEquipmentForm({
      name: equipment.name,
      description: equipment.description || "",
      status: normalizeEquipmentStatus(equipment.status),
      isActive: equipment.isActive,
      outOfOrderMode: getEquipmentOutOfOrderMode(equipment),
      outOfOrderUntil: toDateTimeLocalInputValue(equipment.outOfOrderUntil),
    });
    setShowEditEquipmentModal(true);
  };

  const closeEquipmentModals = () => {
    setShowAddEquipmentModal(false);
    setShowEditEquipmentModal(false);
    setSelectedLab(null);
    setSelectedEquipment(null);
    setEquipmentForm({
      name: "",
      description: "",
      status: "AVAILABLE",
      isActive: true,
      outOfOrderMode: "TEMPORARY",
      outOfOrderUntil: "",
    });
  };

  const getEquipmentPayloadFromForm = () => {
    const payload = {
      name: equipmentForm.name.trim(),
      description: equipmentForm.description,
      status: equipmentForm.status,
      isActive: equipmentForm.isActive,
    };

    if (equipmentForm.status === "OUT_OF_ORDER") {
      payload.outOfOrderNever = equipmentForm.outOfOrderMode === "NEVER";
      payload.outOfOrderUntil =
        equipmentForm.outOfOrderMode === "TEMPORARY"
          ? new Date(equipmentForm.outOfOrderUntil).toISOString()
          : null;
    } else {
      payload.outOfOrderNever = false;
      payload.outOfOrderUntil = null;
    }

    return payload;
  };

  const handleAddEquipment = async () => {
    if (!equipmentForm.name || !equipmentForm.name.trim()) {
      setError("Equipment name is required");
      setTimeout(() => setError(""), 3000);
      return;
    }

    if (
      equipmentForm.status === "OUT_OF_ORDER" &&
      equipmentForm.outOfOrderMode === "TEMPORARY" &&
      !equipmentForm.outOfOrderUntil
    ) {
      setError("Please select when this equipment will be available again");
      setTimeout(() => setError(""), 3000);
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      await labManagementAPI.addEquipment(
        selectedLab.id,
        getEquipmentPayloadFromForm(),
      );

      setSuccess("Equipment added successfully!");
      setTimeout(() => setSuccess(""), 3000);

      const currentExpandedLabId = selectedLab.id;
      closeEquipmentModals();
      await loadLabs();
      setExpandedLabId(currentExpandedLabId);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to add equipment. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Add equipment error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateEquipment = async () => {
    if (!equipmentForm.name || !equipmentForm.name.trim()) {
      setError("Equipment name is required");
      setTimeout(() => setError(""), 3000);
      return;
    }

    if (
      equipmentForm.status === "OUT_OF_ORDER" &&
      equipmentForm.outOfOrderMode === "TEMPORARY" &&
      !equipmentForm.outOfOrderUntil
    ) {
      setError("Please select when this equipment will be available again");
      setTimeout(() => setError(""), 3000);
      return;
    }

    try {
      setSubmitting(true);
      setError("");

      const response = await labManagementAPI.updateEquipment(
        selectedLab.id,
        selectedEquipment.id,
        getEquipmentPayloadFromForm(),
      );

      const adjustedCount = response.data?.adjustedBookings || 0;
      const cancelledCount = response.data?.cancelledBookings || 0;
      const impactSummary =
        adjustedCount > 0 || cancelledCount > 0
          ? ` ${adjustedCount} session(s) were updated, ${cancelledCount} session(s) were cancelled.`
          : "";

      setSuccess(`Equipment updated successfully!${impactSummary}`);
      setTimeout(() => setSuccess(""), 3000);

      const currentExpandedLabId = selectedLab.id;
      closeEquipmentModals();
      await loadLabs();
      setExpandedLabId(currentExpandedLabId);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update equipment. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Update equipment error:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteEquipment = async (lab, equipment) => {
    if (
      !window.confirm(
        `Are you sure you want to delete ${equipment.name}? This action cannot be undone.`,
      )
    ) {
      return;
    }

    try {
      await labManagementAPI.deleteEquipment(lab.id, equipment.id);

      setSuccess("Equipment deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);

      const currentExpandedLabId = lab.id;
      await loadLabs();
      setExpandedLabId(currentExpandedLabId);
    } catch (err) {
      if (err.response?.data?.warnings) {
        setError(
          `${err.response.data.message}\n\n${err.response.data.warnings.join(
            "\n",
          )}\n\n${err.response.data.suggestion}`,
        );
      } else {
        setError(
          err.response?.data?.message ||
            "Failed to delete equipment. Please try again.",
        );
      }
      setTimeout(() => setError(""), 8000);
      console.error("Delete equipment error:", err);
    }
  };

  const toggleLabExpansion = (labId) => {
    setExpandedLabId(expandedLabId === labId ? null : labId);
  };

  const getStatusBadgeColor = (status) => {
    switch (status) {
      case "AVAILABLE":
        return "bg-green-100 text-green-800";
      case "OUT_OF_ORDER":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Lab Agreement Functions
  const openAgreementModal = async (lab) => {
    setSelectedLabForAgreement(lab);
    setShowAgreementModal(true);

    try {
      const response = await labManagementAPI.getAgreementFiles(lab.id);
      setAgreementFiles(response.data.files);
      setSignatureCount(response.data.signatureCount);
    } catch (err) {
      console.error("Load agreement files error:", err);
      setAgreementFiles([]);
      setSignatureCount(0);
    }
  };

  const closeAgreementModal = () => {
    setShowAgreementModal(false);
    setSelectedLabForAgreement(null);
    setAgreementFiles([]);
    setSignatureCount(0);
    setUploadingFile(false);
    setDeletingFileId(null);
    setPendingFile(null);
    setShowUploadConfirmation(false);
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = [
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "image/jpeg",
      "image/png",
      "image/jpg",
    ];

    if (!allowedTypes.includes(file.type)) {
      setError("Invalid file type. Only PDF, DOCX, and images are allowed.");
      setTimeout(() => setError(""), 5000);
      event.target.value = "";
      return;
    }

    // Validate file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      setError("File size must be less than 10MB");
      setTimeout(() => setError(""), 5000);
      event.target.value = "";
      return;
    }

    // Check if signatures exist - if yes, show confirmation
    if (signatureCount > 0) {
      setPendingFile({ file, inputEvent: event });
      setShowUploadConfirmation(true);
    } else {
      // No signatures exist, proceed with upload
      await performFileUpload(file, event);
    }
  };

  const performFileUpload = async (file, inputEvent) => {
    try {
      setUploadingFile(true);
      setError("");

      const response = await labManagementAPI.uploadAgreementFile(
        selectedLabForAgreement.id,
        file,
      );

      // Show different message based on invalidated signatures
      if (response.data.invalidatedSignatures > 0) {
        setSuccess(
          `Agreement file uploaded successfully! ${response.data.invalidatedSignatures} user(s) will need to re-sign the updated agreement.`,
        );
      } else {
        setSuccess("Agreement file uploaded successfully!");
      }
      setTimeout(() => setSuccess(""), 5000);

      // Reload agreement files
      const updatedResponse = await labManagementAPI.getAgreementFiles(
        selectedLabForAgreement.id,
      );
      setAgreementFiles(updatedResponse.data.files);
      setSignatureCount(updatedResponse.data.signatureCount);

      // Reset file input
      if (inputEvent && inputEvent.target) {
        inputEvent.target.value = "";
      }

      // Reload labs to update agreement status
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to upload file. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Upload agreement file error:", err);
    } finally {
      setUploadingFile(false);
    }
  };

  const handleConfirmUpload = async () => {
    if (!pendingFile) return;

    setShowUploadConfirmation(false);
    await performFileUpload(pendingFile.file, pendingFile.inputEvent);
    setPendingFile(null);
  };

  const handleCancelUpload = () => {
    if (
      pendingFile &&
      pendingFile.inputEvent &&
      pendingFile.inputEvent.target
    ) {
      pendingFile.inputEvent.target.value = ""; // Reset file input
    }
    setPendingFile(null);
    setShowUploadConfirmation(false);
  };

  const handleToggleAgreementRequired = async (enabled) => {
    if (!selectedLabForAgreement) return;

    // If disabling and signatures exist, show warning
    if (!enabled && signatureCount > 0) {
      if (
        !window.confirm(
          `Warning: ${signatureCount} user(s) have signed this agreement.\n\nDisabling the agreement requirement will not invalidate existing signatures, but new users will not be required to sign.\n\nAre you sure you want to disable the agreement requirement?`,
        )
      ) {
        return;
      }
    }

    // If enabling without files, show info
    if (enabled && agreementFiles.length === 0) {
      if (
        !window.confirm(
          `You are enabling the agreement requirement without any uploaded files.\n\nUsers will see a message that they need to sign an agreement, but there will be no files to view.\n\nIt's recommended to upload agreement files first.\n\nDo you want to continue?`,
        )
      ) {
        return;
      }
    }

    try {
      setTogglingAgreement(true);
      setError("");

      await labManagementAPI.toggleAgreementRequired(
        selectedLabForAgreement.id,
        enabled,
      );

      setSuccess(
        `Agreement requirement ${enabled ? "enabled" : "disabled"} for ${
          selectedLabForAgreement.name
        }`,
      );
      setTimeout(() => setSuccess(""), 3000);

      // Update the selected lab's agreement status
      setSelectedLabForAgreement({
        ...selectedLabForAgreement,
        agreementRequired: enabled,
      });

      // Reload labs to update the list
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update agreement requirement. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Toggle agreement requirement error:", err);
    } finally {
      setTogglingAgreement(false);
    }
  };

  const handleDeleteAgreementFile = async (fileId, fileName) => {
    if (
      !window.confirm(
        `Are you sure you want to delete "${fileName}"?\n\nThis action cannot be undone.`,
      )
    ) {
      return;
    }

    try {
      setDeletingFileId(fileId);
      setError("");

      const response = await labManagementAPI.deleteAgreementFile(
        selectedLabForAgreement.id,
        fileId,
      );

      setSuccess("Agreement file deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);

      // Reload agreement files
      const updatedResponse = await labManagementAPI.getAgreementFiles(
        selectedLabForAgreement.id,
      );
      setAgreementFiles(updatedResponse.data.files);
      setSignatureCount(updatedResponse.data.signatureCount);

      // If no files remain, close modal and reload labs
      if (response.data.remainingFiles === 0) {
        closeAgreementModal();
      }

      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to delete agreement file. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Delete agreement file error:", err);
    } finally {
      setDeletingFileId(null);
    }
  };

  // Lab Agreement Signers & Cancellation Functions
  const openSignersModal = async (lab) => {
    setSelectedLabForSigners(lab);
    setSignersSearchTerm("");
    setShowSignersModal(true);
  };

  const closeSignersModal = () => {
    setShowSignersModal(false);
    setSelectedLabForSigners(null);
    setLabSigners([]);
    setSignersSearchTerm("");
  };

  const loadLabSigners = async (labId, search = "") => {
    try {
      setLoadingSigners(true);
      const params = search ? { search } : {};
      const response = await labManagementAPI.getLabAgreementSigners(
        labId,
        params,
      );
      setLabSigners(response.data.signers);
    } catch (err) {
      console.error("Load lab signers error:", err);
      setError("Failed to load signers. Please try again.");
      setTimeout(() => setError(""), 5000);
    } finally {
      setLoadingSigners(false);
    }
  };

  const openCancelAgreementModal = (lab, signer) => {
    setSelectedLabForSigners(lab);
    setSelectedSignerForCancel(signer);
    setCancellationReason("");
    setShowCancelAgreementModal(true);
  };

  const closeCancelAgreementModal = () => {
    setShowCancelAgreementModal(false);
    setSelectedSignerForCancel(null);
    setCancellationReason("");
  };

  const handleCancelLabAgreement = async () => {
    if (!selectedLabForSigners || !selectedSignerForCancel) return;

    if (
      !window.confirm(
        `Are you sure you want to cancel the lab agreement for ${selectedSignerForCancel.user.name}?\n\nThis will require them to sign again before using this lab.`,
      )
    ) {
      return;
    }

    try {
      setCancellingAgreement(true);
      setError("");

      await labManagementAPI.cancelLabAgreement(
        selectedLabForSigners.id,
        selectedSignerForCancel.userId,
        {
          reason: cancellationReason.trim() || null,
        },
      );

      setSuccess(
        `Lab agreement cancelled for ${selectedSignerForCancel.user.name}`,
      );
      setTimeout(() => setSuccess(""), 5000);

      closeCancelAgreementModal();

      // Reload signers list
      await loadLabSigners(selectedLabForSigners.id, signersSearchTerm);

      // Reload labs to update signature count
      loadLabs();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to cancel agreement. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Cancel lab agreement error:", err);
    } finally {
      setCancellingAgreement(false);
    }
  };

  const openAgreementHistoryModal = async (lab, signer) => {
    setSelectedLabForSigners(lab);
    setSelectedUserForHistory(signer);
    setShowAgreementHistoryModal(true);
    await loadAgreementHistory(lab.id, signer.userId);
  };

  const closeAgreementHistoryModal = () => {
    setShowAgreementHistoryModal(false);
    setSelectedUserForHistory(null);
    setAgreementHistory([]);
    setEditingCancellationId(null);
    setEditingReason("");
    setHistoryPagination({
      total: 0,
      limit: 10,
      offset: 0,
      hasMore: false,
    });
  };

  const loadAgreementHistory = async (labId, userId, reset = true) => {
    try {
      if (reset) {
        setLoadingHistory(true);
        setAgreementHistory([]); // Clear existing history on reset
      } else {
        setLoadingMoreHistory(true);
      }

      const params = {
        limit: historyPagination.limit,
        offset: reset ? 0 : historyPagination.offset + historyPagination.limit,
      };

      const response = await labManagementAPI.getLabAgreementHistory(
        labId,
        userId,
        params,
      );

      if (reset) {
        setAgreementHistory(response.data.history);
      } else {
        // Append new records to existing ones
        setAgreementHistory((prev) => [...prev, ...response.data.history]);
      }

      setHistoryPagination(response.data.pagination);
    } catch (err) {
      console.error("Load agreement history error:", err);
      setError("Failed to load history. Please try again.");
      setTimeout(() => setError(""), 5000);
    } finally {
      setLoadingHistory(false);
      setLoadingMoreHistory(false);
    }
  };

  const loadMoreHistory = async () => {
    if (!selectedLabForSigners || !selectedUserForHistory) return;
    await loadAgreementHistory(
      selectedLabForSigners.id,
      selectedUserForHistory.userId,
      false,
    );
  };

  const startEditingReason = (cancellation) => {
    setEditingCancellationId(cancellation.id);
    setEditingReason(cancellation.reason || "");
  };

  const cancelEditingReason = () => {
    setEditingCancellationId(null);
    setEditingReason("");
  };

  const handleUpdateCancellationReason = async (cancellationId) => {
    if (!selectedLabForSigners || !selectedUserForHistory) return;

    try {
      setUpdatingReason(true);
      setError("");

      await labManagementAPI.updateLabAgreementCancellationReason(
        selectedLabForSigners.id,
        selectedUserForHistory.userId,
        cancellationId,
        { reason: editingReason.trim() || null },
      );

      setSuccess("Cancellation reason updated successfully");
      setTimeout(() => setSuccess(""), 3000);

      // Reload history
      await loadAgreementHistory(
        selectedLabForSigners.id,
        selectedUserForHistory.userId,
      );

      cancelEditingReason();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to update reason. Please try again.",
      );
      setTimeout(() => setError(""), 5000);
      console.error("Update cancellation reason error:", err);
    } finally {
      setUpdatingReason(false);
    }
  };

  const formatLastUpdated = (date) => {
    if (!date) return "Never";

    const now = new Date();
    const diff = Math.floor((now - date) / 1000); // Difference in seconds

    if (diff < 60) return "Just now";
    if (diff < 3600) return `${Math.floor(diff / 60)} minute(s) ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hour(s) ago`;

    return date.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="lab-management" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="min-w-0">
                <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                  Lab & Equipment Management
                </h2>
                <div className="mt-2 flex items-center space-x-3">
                  <p className="text-sm text-blue-100">
                    Manage labs and their equipment across the system
                  </p>
                  {lastUpdated && (
                    <>
                      <span className="text-blue-200">•</span>
                      <p className="text-xs text-blue-100">
                        Last updated: {formatLastUpdated(lastUpdated)}
                      </p>
                    </>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handleRefreshStats}
                  disabled={refreshing || loading}
                  className="inline-flex items-center rounded-lg border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-50"
                  title="Refresh lab statistics"
                >
                  {refreshing ? <>Refreshing...</> : <>Refresh Stats</>}
                </button>

                <button
                  onClick={openCreateLabModal}
                  className="inline-flex items-center rounded-lg bg-emerald-500 px-4 py-2 text-sm font-medium text-white transition hover:bg-emerald-600"
                >
                  Create New Lab
                </button>
              </div>
            </div>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Filters */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Search */}
              <div>
                <label
                  htmlFor="search"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Search Labs
                </label>
                <input
                  type="text"
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by name, location, or description..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>

              {/* Status Filter */}
              <div>
                <label
                  htmlFor="status"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Status
                </label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              </div>

              {/* Agreement Filter */}
              <div>
                <label
                  htmlFor="agreement"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Agreement
                </label>
                <select
                  id="agreement"
                  value={agreementFilter}
                  onChange={(e) => setAgreementFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Labs</option>
                  <option value="REQUIRED">Agreement Required</option>
                  <option value="NOT_REQUIRED">No Agreement Required</option>
                </select>
              </div>
            </div>

            {/* Active Filters Summary */}
            {(searchTerm ||
              statusFilter !== "ALL" ||
              agreementFilter !== "ALL") && (
              <div className="mt-3 flex items-center space-x-2 text-sm">
                <span className="text-slate-600">Active filters:</span>
                {searchTerm && (
                  <span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded-md">
                    Search: "{searchTerm}"
                  </span>
                )}
                {statusFilter !== "ALL" && (
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-md">
                    Status: {statusFilter}
                  </span>
                )}
                {agreementFilter !== "ALL" && (
                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded-md">
                    Agreement:{" "}
                    {agreementFilter === "REQUIRED"
                      ? "Required"
                      : "Not Required"}
                  </span>
                )}
                <button
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("ALL");
                    setAgreementFilter("ALL");
                  }}
                  className="text-indigo-600 hover:text-indigo-800 underline"
                >
                  Clear all
                </button>
              </div>
            )}
          </section>

          {/* Labs List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading labs...
              </span>
            </div>
          ) : labs.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No labs found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Get started by creating a new lab.
              </p>
              <div className="mt-6">
                <button
                  onClick={openCreateLabModal}
                  className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  Create New Lab
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {labs.map((lab) => (
                <div
                  key={lab.id}
                  className="rounded-2xl border border-slate-200 bg-white shadow-sm"
                >
                  {/* Lab Header */}
                  <div className="px-6 py-4 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <h3 className="text-lg font-medium text-gray-900">
                            {lab.name}
                          </h3>
                          <span
                            className={`px-2 py-1 text-xs font-medium rounded-full ${
                              lab.isActive
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {lab.isActive ? "Active" : "Inactive"}
                          </span>
                          {!lab.isActive && (
                            <span className="px-2 py-1 text-xs font-medium rounded-full bg-amber-100 text-amber-800">
                              {lab.deactivationNever
                                ? "Unavailable (No Reactivation)"
                                : lab.unavailableUntil
                                  ? `Unavailable until ${new Date(
                                      lab.unavailableUntil,
                                    ).toLocaleString()}`
                                  : "Unavailable"}
                            </span>
                          )}
                          {lab.agreementRequired && (
                            <span
                              className={`px-2 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${
                                lab.agreement.fileCount === 0
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              <span>📄</span>
                              <span>Agreement Required</span>
                              {lab.agreement.fileCount === 0 && (
                                <span
                                  className="text-yellow-900 font-bold"
                                  title="No files uploaded"
                                >
                                  ⚠️
                                </span>
                              )}
                            </span>
                          )}
                        </div>
                        {lab.location && (
                          <p className="text-sm text-gray-600 mt-1">
                            <span className="font-medium">Location:</span>{" "}
                            {lab.location}
                          </p>
                        )}
                        {lab.description && (
                          <p className="text-sm text-gray-500 mt-1">
                            {lab.description}
                          </p>
                        )}

                        {/* Stats */}
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                          <span
                            title={
                              lab.stats.activeEquipment ===
                              lab.stats.totalEquipment
                                ? `${lab.stats.totalEquipment} equipment items (all active)`
                                : `${
                                    lab.stats.activeEquipment
                                  } active equipment items, ${
                                    lab.stats.totalEquipment -
                                    lab.stats.activeEquipment
                                  } inactive`
                            }
                          >
                            {lab.stats.activeEquipment ===
                            lab.stats.totalEquipment ? (
                              // All equipment is active
                              <>{lab.stats.totalEquipment} equipment item(s)</>
                            ) : (
                              // Some equipment is inactive - show breakdown
                              <>
                                <span className="text-green-700 font-medium">
                                  {lab.stats.activeEquipment} active
                                </span>
                                <span className="text-gray-400 mx-1">/</span>
                                <span>{lab.stats.totalEquipment} total</span>
                                <span> equipment</span>
                              </>
                            )}
                          </span>
                          <span>•</span>
                          <span>{lab.stats.totalProjects} project(s)</span>
                          <span>•</span>
                          <span>{lab.stats.totalBookings} booking(s)</span>
                          <span>•</span>
                          <span>{lab.stats.totalTimeSlots} time slot(s)</span>
                          {lab.agreementRequired && (
                            <>
                              <span>•</span>
                              <span className="text-blue-600">
                                {lab.agreement.fileCount} agreement file(s),{" "}
                                {lab.agreement.signatureCount} signature(s)
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => toggleLabExpansion(lab.id)}
                          className="px-3 py-1.5 text-sm text-indigo-600 hover:bg-indigo-50 rounded-md font-medium transition-colors"
                        >
                          {expandedLabId === lab.id ? "Hide" : "Show"} Equipment
                        </button>

                        {lab.agreementRequired && (
                          <div className="flex items-center border border-blue-400 rounded-md overflow-hidden bg-blue-50">
                            <button
                              onClick={() => openAgreementModal(lab)}
                              className="px-3 py-1.5 text-sm text-blue-800 hover:bg-blue-100 transition-colors border-r border-blue-400 flex items-center space-x-2"
                            >
                              <span>📄</span>
                              <span>Agreement</span>
                              {lab.agreement.fileCount > 0 ? (
                                <span className="px-1.5 py-0.5 bg-blue-200 text-blue-900 rounded text-xs font-semibold">
                                  {lab.agreement.fileCount}
                                </span>
                              ) : (
                                <span
                                  className="px-1.5 py-0.5 bg-yellow-200 text-yellow-900 rounded text-xs font-semibold"
                                  title="No files uploaded"
                                >
                                  ⚠️
                                </span>
                              )}
                            </button>
                            <button
                              onClick={() => openSignersModal(lab)}
                              className="px-2 py-1.5 text-sm text-blue-800 hover:bg-blue-100 transition-colors flex items-center space-x-1"
                              title="View Signers"
                            >
                              <span>👥</span>
                              <span className="text-xs font-semibold">
                                {lab.agreement.signatureCount}
                              </span>
                            </button>
                          </div>
                        )}

                        {!lab.agreementRequired && (
                          <button
                            onClick={() => openAgreementModal(lab)}
                            className="px-3 py-1.5 text-sm border border-gray-300 text-gray-600 rounded-md hover:bg-gray-50 transition-colors flex items-center space-x-1"
                          >
                            <span>📄</span>
                            <span>Agreement</span>
                            <span className="text-xs text-gray-400">
                              (Not Required)
                            </span>
                          </button>
                        )}

                        <div className="relative group">
                          <button className="px-3 py-1.5 text-sm border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors flex items-center space-x-1">
                            <span>Actions</span>
                            <svg
                              className="w-4 h-4"
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path
                                fillRule="evenodd"
                                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                clipRule="evenodd"
                              />
                            </svg>
                          </button>

                          <div className="absolute right-0 mt-1 w-44 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-10 border border-gray-200">
                            <button
                              onClick={() => openEditLabModal(lab)}
                              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-600 transition-colors"
                            >
                              ✏️ Edit Details
                            </button>
                            {lab.isActive ? (
                              <button
                                onClick={() => openDeactivationModal(lab)}
                                className="block w-full text-left px-4 py-2 text-sm transition-colors text-gray-700 hover:bg-yellow-50 hover:text-yellow-700"
                              >
                                ⏸️ Deactivate
                              </button>
                            ) : (
                              <>
                                <button
                                  onClick={() => openDeactivationModal(lab)}
                                  className="block w-full text-left px-4 py-2 text-sm transition-colors text-gray-700 hover:bg-amber-50 hover:text-amber-700"
                                >
                                  🛠 Edit Unavailable Settings
                                </button>
                                <button
                                  onClick={() => handleActivateLab(lab)}
                                  className="block w-full text-left px-4 py-2 text-sm transition-colors text-gray-700 hover:bg-green-50 hover:text-green-700"
                                >
                                  ▶️ Activate
                                </button>
                              </>
                            )}
                            <div className="border-t border-gray-200 my-1"></div>
                            <button
                              onClick={() => handleDeleteLab(lab)}
                              className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                            >
                              🗑️ Delete Lab
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Equipment Section (Expandable) */}
                  {expandedLabId === lab.id && (
                    <div className="px-6 py-4">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="text-md font-medium text-gray-900">
                          Equipment ({lab.equipment.length})
                        </h4>
                        <button
                          onClick={() => openAddEquipmentModal(lab)}
                          className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700"
                        >
                          Add Equipment
                        </button>
                      </div>

                      {lab.equipment.length === 0 ? (
                        <p className="text-sm text-gray-500 italic">
                          No equipment added yet.
                        </p>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {lab.equipment.map((equipment) => (
                            <div
                              key={equipment.id}
                              className={`border rounded-md p-3 ${
                                equipment.isActive
                                  ? "border-gray-200"
                                  : "border-gray-300 bg-gray-50"
                              }`}
                            >
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex-1">
                                  <div className="flex items-center space-x-2">
                                    <p
                                      className={`font-medium text-sm ${
                                        equipment.isActive
                                          ? "text-gray-900"
                                          : "text-gray-500"
                                      }`}
                                    >
                                      {" "}
                                      {equipment.name}
                                    </p>
                                    {!equipment.isActive && (
                                      <span className="px-2 py-0.5 text-xs font-medium rounded bg-gray-200 text-gray-600">
                                        Inactive
                                      </span>
                                    )}
                                  </div>
                                  {equipment.description && (
                                    <p className="text-xs text-gray-500 mt-1">
                                      {equipment.description}
                                    </p>
                                  )}
                                  {normalizeEquipmentStatus(
                                    equipment.status,
                                  ) === "OUT_OF_ORDER" && (
                                    <p className="text-xs text-amber-700 mt-1">
                                      {formatOutOfOrderWindowLabel(equipment)}
                                    </p>
                                  )}
                                </div>
                                <span
                                  className={`px-2 py-0.5 text-xs font-medium rounded ${getStatusBadgeColor(
                                    normalizeEquipmentStatus(equipment.status),
                                  )}`}
                                >
                                  {normalizeEquipmentStatus(equipment.status)}
                                </span>
                              </div>
                              <div className="flex space-x-2 mt-2">
                                <button
                                  onClick={() =>
                                    openEditEquipmentModal(lab, equipment)
                                  }
                                  className="text-xs text-indigo-600 hover:text-indigo-800"
                                >
                                  Edit
                                </button>
                                <button
                                  onClick={() =>
                                    handleDeleteEquipment(lab, equipment)
                                  }
                                  className="text-xs text-red-600 hover:text-red-800"
                                >
                                  Delete
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Lab Deactivation Modal */}
      {showDeactivationModal && selectedLabForDeactivation && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-lg shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Lab Unavailability Settings
                  </h3>
                  <p className="text-sm text-gray-600">
                    {selectedLabForDeactivation.name}
                  </p>
                </div>
                <button
                  onClick={closeDeactivationModal}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={updatingDeactivation}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-gray-700">
                  Until when will this lab be unavailable?
                </p>

                <div className="space-y-2">
                  <label className="flex items-center space-x-2 text-sm text-gray-700">
                    <input
                      type="radio"
                      name="deactivationMode"
                      value="TEMPORARY"
                      checked={deactivationForm.mode === "TEMPORARY"}
                      onChange={(e) =>
                        setDeactivationForm((prev) => ({
                          ...prev,
                          mode: e.target.value,
                        }))
                      }
                      disabled={updatingDeactivation}
                    />
                    <span>Until a specific date and time</span>
                  </label>

                  <label className="flex items-center space-x-2 text-sm text-gray-700">
                    <input
                      type="radio"
                      name="deactivationMode"
                      value="NEVER"
                      checked={deactivationForm.mode === "NEVER"}
                      onChange={(e) =>
                        setDeactivationForm((prev) => ({
                          ...prev,
                          mode: e.target.value,
                        }))
                      }
                      disabled={updatingDeactivation}
                    />
                    <span>Never</span>
                  </label>
                </div>

                {deactivationForm.mode === "TEMPORARY" && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Reactivate at
                    </label>
                    <input
                      type="datetime-local"
                      value={deactivationForm.unavailableUntil}
                      onChange={(e) =>
                        setDeactivationForm((prev) => ({
                          ...prev,
                          unavailableUntil: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      disabled={updatingDeactivation}
                    />
                  </div>
                )}

                <div className="rounded-md bg-amber-50 border border-amber-200 p-3">
                  <p className="text-xs text-amber-800">
                    All affected confirmed lab sessions during the unavailable
                    window will be cancelled automatically and notifications
                    will be sent to students and assigned lab mentors.
                  </p>
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleSaveDeactivation}
                  disabled={updatingDeactivation}
                  className="flex-1 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 disabled:opacity-50"
                >
                  {updatingDeactivation ? "Saving..." : "Save Settings"}
                </button>
                <button
                  onClick={closeDeactivationModal}
                  disabled={updatingDeactivation}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Lab Modal */}
      {showCreateLabModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  Create New Lab
                </h3>
                <button
                  onClick={closeLabModals}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={submitting}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Lab Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={labForm.name}
                    onChange={(e) =>
                      setLabForm({ ...labForm, name: e.target.value })
                    }
                    placeholder="e.g., 3D Printing Lab"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location (Optional)
                  </label>
                  <input
                    type="text"
                    value={labForm.location}
                    onChange={(e) =>
                      setLabForm({ ...labForm, location: e.target.value })
                    }
                    placeholder="e.g., Building A, Room 101"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description (Optional)
                  </label>
                  <textarea
                    value={labForm.description}
                    onChange={(e) =>
                      setLabForm({ ...labForm, description: e.target.value })
                    }
                    placeholder="Brief description of the lab..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleCreateLab}
                  disabled={submitting || !labForm.name.trim()}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                >
                  {submitting ? "Creating..." : "Create Lab"}
                </button>
                <button
                  onClick={closeLabModals}
                  disabled={submitting}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Lab Modal */}
      {showEditLabModal && selectedLab && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Edit Lab</h3>
                <button
                  onClick={closeLabModals}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={submitting}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Lab Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={labForm.name}
                    onChange={(e) =>
                      setLabForm({ ...labForm, name: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location (Optional)
                  </label>
                  <input
                    type="text"
                    value={labForm.location}
                    onChange={(e) =>
                      setLabForm({ ...labForm, location: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description (Optional)
                  </label>
                  <textarea
                    value={labForm.description}
                    onChange={(e) =>
                      setLabForm({ ...labForm, description: e.target.value })
                    }
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleUpdateLab}
                  disabled={submitting || !labForm.name.trim()}
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                >
                  {submitting ? "Updating..." : "Update Lab"}
                </button>
                <button
                  onClick={closeLabModals}
                  disabled={submitting}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Equipment Modal */}
      {showAddEquipmentModal && selectedLab && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Add Equipment
                  </h3>
                  <p className="text-sm text-gray-600">{selectedLab.name}</p>
                </div>
                <button
                  onClick={closeEquipmentModals}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={submitting}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Equipment Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={equipmentForm.name}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        name: e.target.value,
                      })
                    }
                    placeholder="e.g., 3D Printer - Prusa i3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description (Optional)
                  </label>
                  <textarea
                    value={equipmentForm.description}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        description: e.target.value,
                      })
                    }
                    placeholder="Brief description or specifications..."
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={equipmentForm.status}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        status: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  >
                    <option value="AVAILABLE">Available</option>
                    <option value="OUT_OF_ORDER">Out of Order</option>
                  </select>
                </div>

                {equipmentForm.status === "OUT_OF_ORDER" && (
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Equipment Unavailability Settings
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-700">
                      <input
                        type="radio"
                        name="addOutOfOrderMode"
                        value="TEMPORARY"
                        checked={equipmentForm.outOfOrderMode === "TEMPORARY"}
                        onChange={(e) =>
                          setEquipmentForm({
                            ...equipmentForm,
                            outOfOrderMode: e.target.value,
                          })
                        }
                        disabled={submitting}
                      />
                      <span>Until a specific date and time</span>
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-700">
                      <input
                        type="radio"
                        name="addOutOfOrderMode"
                        value="NEVER"
                        checked={equipmentForm.outOfOrderMode === "NEVER"}
                        onChange={(e) =>
                          setEquipmentForm({
                            ...equipmentForm,
                            outOfOrderMode: e.target.value,
                          })
                        }
                        disabled={submitting}
                      />
                      <span>Until further notice</span>
                    </label>

                    {equipmentForm.outOfOrderMode === "TEMPORARY" && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Available again at
                        </label>
                        <input
                          type="datetime-local"
                          value={equipmentForm.outOfOrderUntil}
                          onChange={(e) =>
                            setEquipmentForm({
                              ...equipmentForm,
                              outOfOrderUntil: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          disabled={submitting}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleAddEquipment}
                  disabled={
                    submitting ||
                    !equipmentForm.name.trim() ||
                    (equipmentForm.status === "OUT_OF_ORDER" &&
                      equipmentForm.outOfOrderMode === "TEMPORARY" &&
                      !equipmentForm.outOfOrderUntil)
                  }
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
                >
                  {submitting ? "Adding..." : "Add Equipment"}
                </button>
                <button
                  onClick={closeEquipmentModals}
                  disabled={submitting}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Equipment Modal */}
      {showEditEquipmentModal && selectedLab && selectedEquipment && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Edit Equipment
                  </h3>
                  <p className="text-sm text-gray-600">{selectedLab.name}</p>
                </div>
                <button
                  onClick={closeEquipmentModals}
                  className="text-gray-400 hover:text-gray-600"
                  disabled={submitting}
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Equipment Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={equipmentForm.name}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        name: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description (Optional)
                  </label>
                  <textarea
                    value={equipmentForm.description}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        description: e.target.value,
                      })
                    }
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={equipmentForm.status}
                    onChange={(e) =>
                      setEquipmentForm({
                        ...equipmentForm,
                        status: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={submitting}
                  >
                    <option value="AVAILABLE">Available</option>
                    <option value="OUT_OF_ORDER">Out of Order</option>
                  </select>
                </div>

                {equipmentForm.status === "OUT_OF_ORDER" && (
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Equipment Unavailability Settings
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-700">
                      <input
                        type="radio"
                        name="editOutOfOrderMode"
                        value="TEMPORARY"
                        checked={equipmentForm.outOfOrderMode === "TEMPORARY"}
                        onChange={(e) =>
                          setEquipmentForm({
                            ...equipmentForm,
                            outOfOrderMode: e.target.value,
                          })
                        }
                        disabled={submitting}
                      />
                      <span>Until a specific date and time</span>
                    </label>
                    <label className="flex items-center space-x-2 text-sm text-gray-700">
                      <input
                        type="radio"
                        name="editOutOfOrderMode"
                        value="NEVER"
                        checked={equipmentForm.outOfOrderMode === "NEVER"}
                        onChange={(e) =>
                          setEquipmentForm({
                            ...equipmentForm,
                            outOfOrderMode: e.target.value,
                          })
                        }
                        disabled={submitting}
                      />
                      <span>Until further notice</span>
                    </label>

                    {equipmentForm.outOfOrderMode === "TEMPORARY" && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Available again at
                        </label>
                        <input
                          type="datetime-local"
                          value={equipmentForm.outOfOrderUntil}
                          onChange={(e) =>
                            setEquipmentForm({
                              ...equipmentForm,
                              outOfOrderUntil: e.target.value,
                            })
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          disabled={submitting}
                        />
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Active State
                  </label>
                  <div className="flex items-center space-x-3 p-3 border border-gray-300 rounded-md bg-gray-50">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={equipmentForm.isActive}
                      onChange={(e) =>
                        setEquipmentForm({
                          ...equipmentForm,
                          isActive: e.target.checked,
                        })
                      }
                      className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                      disabled={submitting}
                    />
                    <label
                      htmlFor="isActive"
                      className="text-sm text-gray-700 cursor-pointer"
                    >
                      Equipment is active (visible for selection)
                    </label>
                  </div>

                  {!equipmentForm.isActive && (
                    <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded">
                      <p className="text-xs text-yellow-800">
                        <strong>Warning:</strong> Inactive equipment will not be
                        available for new bookings or projects.
                      </p>
                    </div>
                  )}

                  <p className="text-xs text-gray-500 mt-1">
                    Equipment must be both active and in Available status to be
                    selectable in bookings and projects.
                  </p>
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleUpdateEquipment}
                  disabled={
                    submitting ||
                    !equipmentForm.name.trim() ||
                    (equipmentForm.status === "OUT_OF_ORDER" &&
                      equipmentForm.outOfOrderMode === "TEMPORARY" &&
                      !equipmentForm.outOfOrderUntil)
                  }
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                >
                  {submitting ? "Updating..." : "Update Equipment"}
                </button>
                <button
                  onClick={closeEquipmentModals}
                  disabled={submitting}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lab Agreement Modal */}
      {showAgreementModal && selectedLabForAgreement && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-3xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Lab Agreement - {selectedLabForAgreement.name}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {selectedLabForAgreement.location}
                  </p>
                </div>
                <button
                  onClick={closeAgreementModal}
                  disabled={uploadingFile || deletingFileId !== null}
                  className="text-gray-400 hover:text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  ✕
                </button>
              </div>

              {/* Agreement Status & Toggle */}
              <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <h4 className="text-sm font-medium text-blue-900">
                        Agreement Requirement
                      </h4>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() =>
                            handleToggleAgreementRequired(
                              !selectedLabForAgreement.agreementRequired,
                            )
                          }
                          disabled={
                            togglingAgreement ||
                            uploadingFile ||
                            deletingFileId !== null
                          }
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed ${
                            selectedLabForAgreement.agreementRequired
                              ? "bg-indigo-600"
                              : "bg-gray-200"
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              selectedLabForAgreement.agreementRequired
                                ? "translate-x-6"
                                : "translate-x-1"
                            }`}
                          />
                        </button>
                        <span className="text-sm text-blue-900 font-medium">
                          {selectedLabForAgreement.agreementRequired
                            ? "Required"
                            : "Not Required"}
                        </span>
                      </div>
                    </div>

                    {selectedLabForAgreement.agreementRequired && (
                      <div className="mt-2">
                        <p className="text-sm text-blue-700">
                          {agreementFiles.length > 0 ? (
                            <>
                              {agreementFiles.length} file(s) uploaded •{" "}
                              {signatureCount} user(s) have signed
                            </>
                          ) : (
                            <>
                              <span className="text-yellow-700 font-medium">
                                ⚠️ No files uploaded yet
                              </span>{" "}
                              - Users will be required to sign, but cannot view
                              any files
                            </>
                          )}
                        </p>
                      </div>
                    )}

                    {!selectedLabForAgreement.agreementRequired &&
                      agreementFiles.length > 0 && (
                        <p className="text-sm text-blue-600 mt-2">
                          {agreementFiles.length} file(s) uploaded, but
                          agreement is not required
                        </p>
                      )}
                  </div>
                </div>
              </div>

              {/* Upload Section */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Upload Agreement Files
                  {uploadingFile && (
                    <span className="ml-2 text-xs text-indigo-600 font-normal">
                      (Uploading...)
                    </span>
                  )}
                  {!selectedLabForAgreement.agreementRequired && (
                    <span className="ml-2 text-xs text-gray-500 font-normal">
                      (Agreement not required - enable requirement above to
                      enforce signatures)
                    </span>
                  )}
                </label>
                <div className="flex items-center space-x-3">
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    accept=".pdf,.docx,image/*"
                    className="block w-full text-sm text-gray-500
file:mr-4 file:py-2 file:px-4
file:rounded file:border-0
file:text-sm file:font-semibold
file:bg-indigo-50 file:text-indigo-700
hover:file:bg-indigo-100
disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={uploadingFile || deletingFileId !== null}
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Accepted formats: PDF, DOCX, JPG, PNG (Max 10MB)
                </p>
              </div>

              {/* Agreement Files List */}
              <div className="mb-4">
                <h4 className="text-md font-medium text-gray-900 mb-3">
                  Agreement Files ({agreementFiles.length})
                </h4>

                {agreementFiles.length === 0 ? (
                  <p className="text-sm text-gray-500 italic text-center py-4">
                    No agreement files uploaded yet. Upload files to enable
                    agreement requirement.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {agreementFiles.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
                      >
                        <div className="flex items-center space-x-3 flex-1">
                          <span className="text-2xl">
                            {getFileIcon(file.fileType)}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {file.fileName}
                            </p>
                            <p className="text-xs text-gray-500">
                              Uploaded{" "}
                              {new Date(file.uploadedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <a
                            href={getAgreementFileDownloadUrl(
                              selectedLabForAgreement.id,
                              file.id,
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`px-3 py-1 text-xs border border-blue-300 text-blue-700 rounded hover:bg-blue-50 transition-colors ${
                              deletingFileId === file.id
                                ? "opacity-50 pointer-events-none"
                                : ""
                            }`}
                          >
                            View
                          </a>
                          <button
                            onClick={() =>
                              handleDeleteAgreementFile(file.id, file.fileName)
                            }
                            disabled={
                              deletingFileId === file.id || uploadingFile
                            }
                            className="px-3 py-1 text-xs border border-red-300 text-red-700 rounded hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            {deletingFileId === file.id
                              ? "Deleting..."
                              : "Delete"}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Info Box */}
              {agreementFiles.length > 0 && (
                <div className="mt-4 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                  <p className="text-xs text-gray-600">
                    <strong>Note:</strong>{" "}
                    {selectedLabForAgreement.agreementRequired
                      ? "Users will need to sign this agreement before they can use this lab."
                      : "Agreement requirement is currently disabled. Enable it above to require signatures."}
                  </p>
                </div>
              )}

              <div className="mt-6">
                <button
                  onClick={closeAgreementModal}
                  disabled={uploadingFile || deletingFileId !== null}
                  className="w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lab Agreement Signers Modal */}
      {showSignersModal && selectedLabForSigners && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-4xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    Agreement Signers - {selectedLabForSigners.name}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {labSigners.length} user(s) have signed this agreement
                  </p>
                </div>
                <button
                  onClick={closeSignersModal}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>

              {/* Search */}
              <div className="mb-4">
                <input
                  type="text"
                  value={signersSearchTerm}
                  onChange={(e) => setSignersSearchTerm(e.target.value)}
                  placeholder="Search by name or email..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>

              {/* Signers List */}
              {loadingSigners ? (
                <div className="flex justify-center items-center p-8">
                  <Spinner />
                  <span className="ml-2">Loading signers...</span>
                </div>
              ) : labSigners.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No signers found</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {labSigners.map((signer) => (
                    <div
                      key={signer.id}
                      className={`flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 ${
                        signer.signed
                          ? "border-gray-200"
                          : "border-yellow-300 bg-yellow-50"
                      }`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <p className="text-sm font-medium text-gray-900">
                            {signer.user.name}
                          </p>
                          <span
                            className={`px-2 py-0.5 text-xs font-medium rounded ${
                              signer.user.role === "ADMIN"
                                ? "bg-purple-100 text-purple-800"
                                : signer.user.role === "SUPERVISOR"
                                  ? "bg-blue-100 text-blue-800"
                                  : signer.user.role === "PEER_MENTOR"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {signer.user.role}
                          </span>
                          {/* Signed/Unsigned Badge */}
                          <span
                            className={`px-2 py-0.5 text-xs font-medium rounded ${
                              signer.signed
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {signer.signed ? "✓ Signed" : "⚠ Unsigned"}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          {signer.user.email}
                        </p>
                        {signer.signed && signer.signedAt ? (
                          <p className="text-xs text-gray-500 mt-1">
                            Signed: {formatDateTime(signer.signedAt)}
                          </p>
                        ) : (
                          <p className="text-xs text-yellow-700 mt-1 font-medium">
                            Has not signed the current agreement
                          </p>
                        )}
                        {signer.cancellations > 0 && (
                          <p className="text-xs text-orange-600 mt-1">
                            Cancelled {signer.cancellations} time(s)
                            {signer.lastCancelledAt &&
                              ` - Last: ${formatDateTime(
                                signer.lastCancelledAt,
                              )}`}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        {signer.cancellations > 0 && (
                          <button
                            onClick={() =>
                              openAgreementHistoryModal(
                                selectedLabForSigners,
                                signer,
                              )
                            }
                            className="px-3 py-1 text-xs border border-gray-300 text-gray-700 rounded hover:bg-gray-50"
                          >
                            View History
                          </button>
                        )}
                        {/* Only show Cancel Agreement button if actually signed */}
                        {signer.signed && (
                          <button
                            onClick={() =>
                              openCancelAgreementModal(
                                selectedLabForSigners,
                                signer,
                              )
                            }
                            className="px-3 py-1 text-xs border border-red-300 text-red-700 rounded hover:bg-red-50"
                          >
                            Cancel Agreement
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-6">
                <button
                  onClick={closeSignersModal}
                  className="w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Lab Agreement Modal */}
      {showCancelAgreementModal &&
        selectedSignerForCancel &&
        selectedLabForSigners && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
              <div className="mt-3">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Cancel Lab Agreement
                  </h3>
                  <button
                    onClick={closeCancelAgreementModal}
                    className="text-gray-400 hover:text-gray-600"
                    disabled={cancellingAgreement}
                  >
                    ✕
                  </button>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-700">
                    <strong>Lab:</strong> {selectedLabForSigners.name}
                  </p>
                  <p className="text-sm text-gray-700 mt-1">
                    <strong>User:</strong> {selectedSignerForCancel.user.name}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedSignerForCancel.user.email}
                  </p>
                </div>

                <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    This user will need to sign the agreement again before using
                    this lab.
                  </p>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Reason for Cancellation (Optional)
                  </label>
                  <textarea
                    value={cancellationReason}
                    onChange={(e) => setCancellationReason(e.target.value)}
                    placeholder="e.g., Safety violation, equipment misuse..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={cancellingAgreement}
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={handleCancelLabAgreement}
                    disabled={cancellingAgreement}
                    className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-50"
                  >
                    {cancellingAgreement ? "Cancelling..." : "Cancel Agreement"}
                  </button>
                  <button
                    onClick={closeCancelAgreementModal}
                    disabled={cancellingAgreement}
                    className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 disabled:opacity-50"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      {/* Lab Agreement History Modal */}
      {showAgreementHistoryModal &&
        selectedUserForHistory &&
        selectedLabForSigners && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
            <div className="relative top-10 mx-auto p-6 border w-full max-w-3xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
              <div className="mt-3">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">
                      Agreement Cancellation History
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {selectedUserForHistory.user.name} -{" "}
                      {selectedLabForSigners.name}
                    </p>
                  </div>
                  <button
                    onClick={closeAgreementHistoryModal}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ✕
                  </button>
                </div>

                {loadingHistory ? (
                  <div className="flex justify-center items-center p-8">
                    <Spinner />
                    <span className="ml-2">Loading history...</span>
                  </div>
                ) : agreementHistory.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No cancellation history found</p>
                  </div>
                ) : (
                  <>
                    <div className="mb-3 text-sm text-gray-600 flex justify-between items-center">
                      <span>
                        Showing {agreementHistory.length} of{" "}
                        {historyPagination.total} cancellation(s)
                      </span>
                    </div>

                    <div className="space-y-4">
                      {agreementHistory.map((record) => (
                        <div
                          key={record.id}
                          className="border border-gray-200 rounded-lg p-4"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-900">
                                Cancelled by: {record.cancelledByUser.name}
                              </p>
                              <p className="text-xs text-gray-500">
                                {record.cancelledByUser.email} (
                                {record.cancelledByUser.role})
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                {formatDateTime(record.createdAt)}
                              </p>
                            </div>
                          </div>

                          <div className="mt-3">
                            {editingCancellationId === record.id ? (
                              <div>
                                <label className="block text-xs font-medium text-gray-700 mb-1">
                                  Reason:
                                </label>
                                <textarea
                                  value={editingReason}
                                  onChange={(e) =>
                                    setEditingReason(e.target.value)
                                  }
                                  rows={2}
                                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md"
                                  disabled={updatingReason}
                                />
                                <div className="flex space-x-2 mt-2">
                                  <button
                                    onClick={() =>
                                      handleUpdateCancellationReason(record.id)
                                    }
                                    disabled={updatingReason}
                                    className="px-3 py-1 text-xs bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:opacity-50"
                                  >
                                    {updatingReason ? "Saving..." : "Save"}
                                  </button>
                                  <button
                                    onClick={cancelEditingReason}
                                    disabled={updatingReason}
                                    className="px-3 py-1 text-xs bg-gray-300 text-gray-700 rounded hover:bg-gray-400 disabled:opacity-50"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div>
                                <p className="text-xs font-medium text-gray-700">
                                  Reason:
                                </p>
                                {record.reason ? (
                                  <p className="text-sm text-gray-600 mt-1">
                                    {record.reason}
                                  </p>
                                ) : (
                                  <p className="text-sm text-gray-400 italic mt-1">
                                    No reason provided
                                  </p>
                                )}
                                <button
                                  onClick={() => startEditingReason(record)}
                                  className="text-xs text-indigo-600 hover:text-indigo-800 mt-2"
                                >
                                  Edit Reason
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {historyPagination.hasMore && (
                      <div className="mt-4 text-center">
                        <button
                          onClick={loadMoreHistory}
                          disabled={loadingMoreHistory}
                          className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                        >
                          {loadingMoreHistory ? (
                            <span className="flex items-center">
                              <Spinner
                                size="sm"
                                color="border-white"
                                className="mr-2"
                              />
                              Loading more...
                            </span>
                          ) : (
                            `Load More (${
                              historyPagination.total - agreementHistory.length
                            } remaining)`
                          )}
                        </button>
                      </div>
                    )}
                  </>
                )}

                <div className="mt-6">
                  <button
                    onClick={closeAgreementHistoryModal}
                    className="w-full px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      {/* Upload Confirmation Modal */}
      {showUploadConfirmation && pendingFile && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-6 border w-full max-w-md shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex items-center justify-center mb-4">
                <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100">
                  <svg
                    className="h-6 w-6 text-yellow-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                    />
                  </svg>
                </div>
              </div>

              <h3 className="text-lg font-medium text-gray-900 text-center mb-4">
                Confirm Agreement File Upload
              </h3>

              <div className="mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800 mb-2">
                  <strong>Warning:</strong> Uploading a new agreement file will
                  invalidate all existing signatures.
                </p>
                <p className="text-sm text-yellow-700">
                  <strong>{signatureCount}</strong> user(s) will need to re-sign
                  the updated agreement before they can use this lab.
                </p>
              </div>

              <div className="mb-4 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <p className="text-xs text-gray-600 mb-1">
                  <strong>File to upload:</strong>
                </p>
                <p className="text-sm text-gray-900 truncate">
                  {pendingFile.file.name}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Size: {(pendingFile.file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>

              <p className="text-sm text-gray-600 mb-6 text-center">
                Are you sure you want to proceed with this upload?
              </p>

              <div className="flex space-x-3">
                <button
                  onClick={handleConfirmUpload}
                  className="flex-1 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 font-medium transition-colors"
                >
                  Yes, Upload File
                </button>
                <button
                  onClick={handleCancelUpload}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LabManagement;
