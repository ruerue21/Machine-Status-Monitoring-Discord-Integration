export const getLocalDateString = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

export const filterPastTimeSlots = (timeSlots, selectedDate) => {
  if (!timeSlots || timeSlots.length === 0) {
    return [];
  }

  const todayDateString = getLocalDateString();

  if (selectedDate !== todayDateString) {
    return timeSlots;
  }

  const now = new Date();
  const currentTimeInMinutes = now.getHours() * 60 + now.getMinutes();

  return timeSlots.filter((slot) => {
    const [hoursPart, minutesPart] = String(slot.startTime).split(":");
    const hours = parseInt(hoursPart, 10);
    const minutes = parseInt(minutesPart, 10);
    return hours * 60 + minutes > currentTimeInMinutes;
  });
};
