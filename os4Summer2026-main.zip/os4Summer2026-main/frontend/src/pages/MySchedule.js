import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { adminAPI } from "../services/api";
import { getUserFromToken } from "../services/auth";
import {
  DAYS_OF_WEEK,
  formatDate,
  formatTime,
  getDayDisplayName,
} from "../services/utils";

const PREVIEW_SLOT_COUNT = 8;
const DATE_RANGE_OPTIONS = [
  { value: "7", label: "Next 7 days" },
  { value: "14", label: "Next 14 days" },
  { value: "30", label: "Next 30 days" },
  { value: "ALL", label: "All upcoming" },
];

function slotTypeLabel(slotType, role) {
  if (role === "SUPERVISOR" && slotType === "CONSULTATION") {
    return "Supervisor";
  }
  return slotType === "LAB" ? "Lab" : "Consultation";
}

function slotTypeBadgeClasses(slotType, role) {
  if (role === "SUPERVISOR" && slotType === "CONSULTATION") {
    return "bg-violet-100 text-violet-800 border-violet-200";
  }
  return slotType === "LAB"
    ? "bg-cyan-100 text-cyan-800 border-cyan-200"
    : "bg-amber-100 text-amber-800 border-amber-200";
}

function summarizeWorkItems(workItems = [], role) {
  if (!Array.isArray(workItems) || workItems.length === 0) {
    return "Available";
  }

  return workItems
    .map((item) => {
      const prefix =
        item.type === "LAB_BOOKING"
          ? "Lab"
          : role === "SUPERVISOR"
            ? "Supervisor"
            : "Consult";
      return `${prefix}: ${item.projectName}`;
    })
    .join(" | ");
}

function getBookedPercent(booked, total) {
  if (!total) return 0;
  return Math.round((booked / total) * 100);
}

function MySchedule() {
  const navigate = useNavigate();
  const user = getUserFromToken();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [assignments, setAssignments] = useState([]);
  const [expandedAssignments, setExpandedAssignments] = useState({});
  const [selectedLab, setSelectedLab] = useState("ALL");
  const [selectedType, setSelectedType] = useState("ALL");
  const [selectedRange, setSelectedRange] = useState("14");

  const hasAccess = ["PEER_MENTOR", "SUPERVISOR", "ADMIN"].includes(user?.role);

  useEffect(() => {
    if (!hasAccess) {
      navigate("/dashboard");
      return;
    }

    loadSchedule();
  }, [hasAccess, navigate]);

  const nextShift = useMemo(() => {
    let next = null;

    for (const assignment of assignments) {
      for (const slot of assignment.upcomingSlots || []) {
        if (!next || new Date(slot.date) < new Date(next.slot.date)) {
          next = {
            slot,
            assignment,
          };
        }
      }
    }

    return next;
  }, [assignments]);

  const labOptions = useMemo(() => {
    const labels = new Map();
    for (const assignment of assignments) {
      labels.set(String(assignment.lab.id), assignment.lab.name);
    }
    return Array.from(labels.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [assignments]);

  const filteredAssignments = useMemo(() => {
    const now = new Date();
    const windowEnd =
      selectedRange === "ALL"
        ? null
        : new Date(now.getTime() + Number(selectedRange) * 24 * 60 * 60 * 1000);

    const inWindow = (slotDate) => {
      if (!windowEnd) return true;
      const d = new Date(slotDate);
      return d >= now && d <= windowEnd;
    };

    return assignments
      .filter((assignment) => {
        if (selectedLab !== "ALL" && String(assignment.lab.id) !== selectedLab)
          return false;
        if (selectedType !== "ALL" && assignment.slotType !== selectedType)
          return false;
        return true;
      })
      .map((assignment) => {
        const upcomingSlots = (assignment.upcomingSlots || []).filter((slot) =>
          inWindow(slot.date),
        );
        const bookedSlots = upcomingSlots.filter(
          (slot) => slot.workItems?.length > 0,
        ).length;

        return {
          ...assignment,
          upcomingSlots,
          totalSlots: upcomingSlots.length,
          bookedSlots,
        };
      })
      .filter((assignment) => assignment.upcomingSlots.length > 0);
  }, [assignments, selectedLab, selectedType, selectedRange]);

  const filteredStats = useMemo(() => {
    const totalAssignments = filteredAssignments.length;
    const totalUpcomingSlots = filteredAssignments.reduce(
      (sum, assignment) => sum + assignment.upcomingSlots.length,
      0,
    );
    const totalBookedSlots = filteredAssignments.reduce(
      (sum, assignment) => sum + assignment.bookedSlots,
      0,
    );
    return { totalAssignments, totalUpcomingSlots, totalBookedSlots };
  }, [filteredAssignments]);

  const loadSchedule = async () => {
    try {
      setLoading(true);
      setError("");
      const response = await adminAPI.getMySchedule();
      setAssignments(response.data.assignments || []);
    } catch (err) {
      setError("Failed to load your schedule. Please try again.");
      console.error("Load my schedule error:", err);
    } finally {
      setLoading(false);
    }
  };

  const toggleExpanded = (assignmentKey) => {
    setExpandedAssignments((prev) => ({
      ...prev,
      [assignmentKey]: !prev[assignmentKey],
    }));
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <Navbar activePage="my-schedule" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {error && (
          <Alert type="error" message={error} onClose={() => setError("")} />
        )}

        <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 text-white shadow-lg">
          <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-blue-300/20 blur-2xl" />
          <div className="absolute -bottom-20 -left-12 w-64 h-64 rounded-full bg-sky-300/10 blur-3xl" />
          <div className="relative p-6 md:p-8">
            <p className="text-xs uppercase tracking-[0.2em] text-blue-100">
              Staff Schedule
            </p>
            <h1 className="mt-2 text-3xl md:text-4xl font-semibold">
              My Work Schedule
            </h1>
            <p className="mt-2 text-sm text-blue-100">
              View exactly when you are scheduled and what work is assigned for
              each slot.
            </p>

            {nextShift && (
              <div className="mt-5 inline-flex flex-wrap items-center gap-2 rounded-lg border border-white/20 bg-white/10 px-3 py-2 text-sm">
                <span className="font-semibold text-blue-100">Next shift:</span>
                <span>
                  {formatDate(nextShift.slot.date)} |{" "}
                  {formatTime(nextShift.slot.startTime)} -{" "}
                  {formatTime(nextShift.slot.endTime)}
                </span>
                <span className="text-blue-100">
                  at {nextShift.assignment.lab.name}
                </span>
              </div>
            )}
          </div>
        </section>

        {loading ? (
          <Spinner />
        ) : (
          <>
            <section className="rounded-xl border border-slate-200 bg-white p-4 md:p-5 shadow-sm">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-slate-500 mb-1">
                    Lab
                  </label>
                  <select
                    value={selectedLab}
                    onChange={(e) => setSelectedLab(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
                  >
                    <option value="ALL">All labs</option>
                    {labOptions.map((lab) => (
                      <option key={lab.value} value={lab.value}>
                        {lab.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-slate-500 mb-1">
                    Type
                  </label>
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
                  >
                    <option value="ALL">All types</option>
                    <option value="CONSULTATION">Consultation</option>
                    <option value="LAB">Lab</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide text-slate-500 mb-1">
                    Date Window
                  </label>
                  <select
                    value={selectedRange}
                    onChange={(e) => setSelectedRange(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-300"
                  >
                    {DATE_RANGE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </section>

            <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="rounded-xl bg-white border border-slate-200 shadow-sm p-5">
                <p className="text-xs uppercase tracking-wide text-slate-500">
                  Assignments
                </p>
                <p className="mt-2 text-3xl font-semibold text-slate-900">
                  {filteredStats.totalAssignments}
                </p>
                <p className="mt-1 text-sm text-slate-500">
                  Labs or contexts you cover
                </p>
              </div>
              <div className="rounded-xl bg-white border border-slate-200 shadow-sm p-5">
                <p className="text-xs uppercase tracking-wide text-slate-500">
                  Upcoming Slots
                </p>
                <p className="mt-2 text-3xl font-semibold text-slate-900">
                  {filteredStats.totalUpcomingSlots}
                </p>
                <p className="mt-1 text-sm text-slate-500">
                  Scheduled in the upcoming timeline
                </p>
              </div>
              <div className="rounded-xl bg-white border border-slate-200 shadow-sm p-5">
                <p className="text-xs uppercase tracking-wide text-slate-500">
                  Booked Work
                </p>
                <p className="mt-2 text-3xl font-semibold text-slate-900">
                  {filteredStats.totalBookedSlots}
                </p>
                <p className="mt-1 text-sm text-slate-500">
                  Slots already assigned to students/projects
                </p>
              </div>
            </section>

            {filteredAssignments.length === 0 ? (
              <section className="rounded-xl bg-white border border-slate-200 shadow-sm p-10 text-center text-slate-600">
                No slots match your filters.
              </section>
            ) : (
              <section className="space-y-5">
                {filteredAssignments.map((assignment) => {
                  const isExpanded =
                    !!expandedAssignments[assignment.assignmentKey];
                  const displayedSlots = isExpanded
                    ? assignment.upcomingSlots
                    : assignment.upcomingSlots.slice(0, PREVIEW_SLOT_COUNT);

                  const bookedPercent = getBookedPercent(
                    assignment.bookedSlots,
                    assignment.totalSlots,
                  );

                  return (
                    <article
                      key={assignment.assignmentKey}
                      className="rounded-2xl bg-white border border-slate-200 shadow-sm overflow-hidden"
                    >
                      <div className="p-5 md:p-6 border-b border-slate-100">
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <h2 className="text-xl md:text-2xl font-semibold text-slate-900">
                                {assignment.lab.name}
                              </h2>
                              <span
                                className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ${slotTypeBadgeClasses(assignment.slotType, user?.role)}`}
                              >
                                {slotTypeLabel(assignment.slotType, user?.role)}
                              </span>
                            </div>
                            <p className="mt-1 text-sm text-slate-600">
                              {assignment.lab.location}
                            </p>
                          </div>

                          <div className="w-full md:w-72">
                            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                              <span>Booked utilization</span>
                              <span>{bookedPercent}%</span>
                            </div>
                            <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-teal-500 to-cyan-500"
                                style={{ width: `${bookedPercent}%` }}
                              />
                            </div>
                            <p className="mt-2 text-xs text-slate-500">
                              {assignment.bookedSlots}/{assignment.totalSlots}{" "}
                              slots booked
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="p-5 md:p-6 grid grid-cols-1 xl:grid-cols-2 gap-6">
                        <div>
                          <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-700 mb-3">
                            Weekly Pattern
                          </h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {DAYS_OF_WEEK.map((day) => {
                              const daySlots =
                                assignment.weeklySchedule?.[day] || [];
                              return (
                                <div
                                  key={`${assignment.assignmentKey}-${day}`}
                                  className="rounded-lg border border-slate-200 bg-slate-50/70 p-3"
                                >
                                  <p className="text-sm font-semibold text-slate-800 mb-1">
                                    {getDayDisplayName(day)}
                                  </p>
                                  <p className="text-xs text-slate-600 leading-relaxed">
                                    {daySlots.length > 0
                                      ? daySlots
                                          .map(
                                            (slot) =>
                                              `${formatTime(slot.startTime)}-${formatTime(slot.endTime)}`,
                                          )
                                          .join(", ")
                                      : "No scheduled time"}
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        <div>
                          <div className="mb-3 flex items-center justify-between gap-3">
                            <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-700">
                              Upcoming Slots ({assignment.upcomingSlots.length})
                            </h3>
                            {assignment.upcomingSlots.length >
                              PREVIEW_SLOT_COUNT && (
                              <button
                                type="button"
                                onClick={() =>
                                  toggleExpanded(assignment.assignmentKey)
                                }
                                className="text-xs font-semibold text-cyan-700 hover:text-cyan-900"
                              >
                                {isExpanded
                                  ? "Show less"
                                  : `Show all (${assignment.upcomingSlots.length})`}
                              </button>
                            )}
                          </div>

                          {displayedSlots.length === 0 ? (
                            <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4 text-sm text-slate-600">
                              No upcoming slots.
                            </div>
                          ) : (
                            <div className="space-y-2 max-h-[28rem] overflow-auto pr-1">
                              {displayedSlots.map((slot) => (
                                <div
                                  key={slot.id}
                                  className="rounded-lg border border-slate-200 p-3 bg-white hover:bg-slate-50 transition-colors"
                                >
                                  <div className="flex flex-wrap items-center justify-between gap-2">
                                    <p className="text-sm font-semibold text-slate-800">
                                      {formatDate(slot.date)}
                                    </p>
                                    <span
                                      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${
                                        slot.workItems.length > 0
                                          ? "bg-emerald-100 text-emerald-800"
                                          : "bg-slate-100 text-slate-700"
                                      }`}
                                    >
                                      {slot.workItems.length > 0
                                        ? "Assigned"
                                        : "Open"}
                                    </span>
                                  </div>
                                  <p className="mt-1 text-sm text-slate-700">
                                    {formatTime(slot.startTime)} -{" "}
                                    {formatTime(slot.endTime)}
                                  </p>
                                  <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                                    {summarizeWorkItems(
                                      slot.workItems,
                                      user?.role,
                                    )}
                                  </p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </section>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default MySchedule;
