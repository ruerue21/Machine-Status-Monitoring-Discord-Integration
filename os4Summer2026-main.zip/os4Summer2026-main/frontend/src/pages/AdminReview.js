import { useState, useEffect } from "react";
import { getUserFromToken, isEmployee } from "../services/auth";
import { useNavigate, useSearchParams } from "react-router-dom";
import { adminAPI, bookingAPI, labAPI, archiveAPI } from "../services/api";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import {
  formatDate,
  formatTime,
  getStatusColor,
  getStatusLabel,
} from "../services/utils";
import {
  filterPastTimeSlots,
  getLocalDateString,
} from "./shared/timeSlotUtils";

function AdminReview() {
  const navigate = useNavigate();
  const user = getUserFromToken();
  const [searchParams] = useSearchParams();

  // State management
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loadingSlots, setLoadingSlots] = useState(false);

  // Filter and search states
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState(
    searchParams.get("filter") || "ALL",
  );
  const [labFilter, setLabFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("newest");

  // Modal states
  const [selectedProject, setSelectedProject] = useState(null);
  const [reviewAction, setReviewAction] = useState(""); // "approve" or "decline"
  const [reviewComment, setReviewComment] = useState("");
  const [submittingReview, setSubmittingReview] = useState(false);

  const [archiving, setArchiving] = useState(false);

  // Mentor change modal states
  const [showMentorChangeModal, setShowMentorChangeModal] = useState(false);
  const [selectedProjectForMentorChange, setSelectedProjectForMentorChange] =
    useState(null);
  const [availableMentors, setAvailableMentors] = useState([]);
  const [currentMentor, setCurrentMentor] = useState(null);
  const [selectedNewMentorId, setSelectedNewMentorId] = useState("");
  const [changingMentor, setChangingMentor] = useState(false);
  const [loadingMentors, setLoadingMentors] = useState(false);

  // Booking modal states
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [bookingData, setBookingData] = useState({
    selectedTimeSlots: [],
    timeSlotEquipment: {},
    notes: "",
    allLabEquipment: [],
    availableSlots: [],
  });
  const [creatingBooking, setCreatingBooking] = useState(false);

  // Comment editing states
  const [editingComment, setEditingComment] = useState(null); // consultation ID being edited
  const [editCommentText, setEditCommentText] = useState("");

  // Cancel consultation modal states
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [cancellingProject, setCancellingProject] = useState(null);

  // Absent modal states
  const [showNoShowModal, setShowNoShowModal] = useState(false);
  const [absentReason, setAbsentReason] = useState("");
  const [noShowProject, setNoShowProject] = useState(null);

  const [selectedConsultation, setSelectedConsultation] = useState(null);

  const canAccessReview = isEmployee(user);
  const getAssignedLabIds = () => {
    const assignmentLabIds = (
      Array.isArray(user?.labAssignments) ? user.labAssignments : []
    )
      .map((assignment) => assignment?.labId)
      .filter((labId) => Number.isInteger(labId));

    const legacyAssignedLabIds = Array.isArray(user?.assignedLabIds)
      ? user.assignedLabIds.filter((labId) => Number.isInteger(labId))
      : [];

    return [...new Set([...assignmentLabIds, ...legacyAssignedLabIds])];
  };

  const getMentorTypesForLab = (labId) => {
    const types = new Set(
      (Array.isArray(user?.labAssignments) ? user.labAssignments : [])
        .filter((assignment) => assignment?.labId === labId)
        .map((assignment) => assignment?.mentorType)
        .filter(
          (mentorType) => mentorType === "CONSULTATION" || mentorType === "LAB",
        ),
    );

    if (types.size === 0 && Array.isArray(user?.assignedLabIds)) {
      if (user.assignedLabIds.includes(labId)) {
        if (user?.mentorType === "CONSULTATION" || user?.mentorType === "LAB") {
          types.add(user.mentorType);
        }
      }
    }

    return types;
  };

  const canPeerMentorManageOwnProject = (project) => {
    if (user?.role !== "PEER_MENTOR") return false;

    const labId = project?.lab?.id;
    if (!Number.isInteger(labId)) return false;

    const assignedLabIds = getAssignedLabIds();
    if (!assignedLabIds.includes(labId)) return false;

    return project?.user?.id === user?.id;
  };

  const canPeerMentorManageConsultationAction = (project, consultation) => {
    if (user?.role !== "PEER_MENTOR") return false;

    const labId = project?.lab?.id;
    if (!Number.isInteger(labId)) return false;

    const assignedLabIds = getAssignedLabIds();
    if (!assignedLabIds.includes(labId)) return false;

    const mentorTypes = getMentorTypesForLab(labId);
    const canManageAssignedConsultation =
      mentorTypes.has("CONSULTATION") && consultation?.mentorId === user?.id;

    if (canManageAssignedConsultation) return true;

    return canPeerMentorManageOwnProject(project);
  };

  const canModifyConsultation = (project, consultation) => {
    if (typeof consultation?.permissions?.canModify === "boolean") {
      return consultation.permissions.canModify;
    }

    if (["ADMIN", "SUPERVISOR"].includes(user?.role)) {
      return true;
    }

    return canPeerMentorManageConsultationAction(project, consultation);
  };

  const canReviewProject = (project) => {
    if (typeof project?.permissions?.canReview === "boolean") {
      return project.permissions.canReview;
    }

    if (["ADMIN", "SUPERVISOR"].includes(user?.role)) {
      return true;
    }

    if (user?.role !== "PEER_MENTOR") {
      return false;
    }

    const consultations = Array.isArray(project?.consultations)
      ? project.consultations
      : [];

    if (
      consultations.some((consultation) =>
        canPeerMentorManageConsultationAction(project, consultation),
      )
    ) {
      return true;
    }

    return canPeerMentorManageOwnProject(project);
  };

  const canArchiveByRole = (project) => {
    if (typeof project?.permissions?.canArchive === "boolean") {
      return project.permissions.canArchive;
    }
    return ["ADMIN", "SUPERVISOR"].includes(user?.role);
  };

  useEffect(() => {
    if (!canAccessReview) {
      navigate("/dashboard");
      return;
    }

    // Set initial filter from URL parameter
    const filterParam = searchParams.get("filter");
    if (
      filterParam &&
      ["approved", "declined", "in_process"].includes(filterParam.toLowerCase())
    ) {
      const statusValue =
        filterParam.toLowerCase() === "approved"
          ? "APPROVED"
          : filterParam.toLowerCase() === "declined"
            ? "DECLINED"
            : "IN_PROCESS";
      setStatusFilter(statusValue);
    }
  }, [canAccessReview, navigate, searchParams]);

  // Separate useEffect for loading data when filters change
  useEffect(() => {
    if (canAccessReview) {
      loadProjects();
    }
  }, [statusFilter, labFilter, searchTerm, sortBy, canAccessReview]);

  const loadProjects = async () => {
    try {
      setLoading(true);
      const params = {
        status: statusFilter,
        lab: labFilter,
        search: searchTerm,
        sortBy: sortBy,
      };

      const response = await adminAPI.getAllProjects(params);
      setProjects(response.data.data);
    } catch (err) {
      setError("Failed to load projects. Please try again.");
      console.error("Load projects error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleProjectReview = async (projectId, action, comment) => {
    try {
      setSubmittingReview(true);
      await adminAPI.reviewProject(projectId, { action, comment });

      setSelectedProject(null);
      setReviewAction("");
      setReviewComment("");

      const actionText =
        action === "approve"
          ? "approved"
          : action === "decline"
            ? "declined"
            : "";
      setSuccess(`Project ${actionText} successfully!`);
      setTimeout(() => setSuccess(""), 5000);

      // Reload projects to get updated status and hide buttons
      await loadProjects();
      return true;
    } catch (err) {
      setError(`Failed to ${action} project. Please try again.`);
      console.error("Review project error:", err);
      return false;
    } finally {
      setSubmittingReview(false);
    }
  };

  const openReviewModal = async (project, action) => {
    // Approving always requires creating booking(s), so skip confirmation modal
    if (action === "approve") {
      setSelectedProject(project);
      setReviewAction(action);
      setReviewComment(
        project.consultations?.[0]?.mentorFeedback ||
          project.consultation?.mentorFeedback ||
          "",
      );

      try {
        setLoadingSlots(true);

        // Fetch all equipment for the project's lab
        const labEquipmentResponse = await labAPI.getLabEquipment(
          project.lab?.id || project.labId,
        );
        const allLabEquipment = labEquipmentResponse.data.equipment;

        // Fetch available lab mentor time slots for this lab
        const slotsResponse = await bookingAPI.getAvailableSlots(
          project.lab?.id || project.labId,
          {
            startDate: getLocalDateString(),
          },
        );
        let availableSlots = slotsResponse.data.availableSlots;

        // Filter out past time slots for each slot's date
        availableSlots = availableSlots.filter((slot) => {
          return filterPastTimeSlots([slot], slot.date).length > 0;
        });

        setBookingData({
          selectedTimeSlots: [],
          timeSlotEquipment: {},
          notes: "",
          allLabEquipment: allLabEquipment,
          availableSlots: availableSlots,
        });
        setShowBookingModal(true);
      } catch (err) {
        setError("Failed to load booking options. Please try again.");
        console.error("Load booking options error:", err);
      } finally {
        setLoadingSlots(false);
      }
      return;
    }

    setSelectedProject(project);
    setReviewAction(action);
    setReviewComment(
      project.consultations?.[0]?.mentorFeedback ||
        project.consultation?.mentorFeedback ||
        "",
    );
  };

  const closeReviewModal = () => {
    setSelectedProject(null);
    setReviewAction("");
    setReviewComment("");
  };

  const closeBookingModal = () => {
    setShowBookingModal(false);
    setBookingData({
      selectedTimeSlots: [],
      timeSlotEquipment: {},
      notes: "",
      allLabEquipment: [],
      availableSlots: [],
    });
    setSelectedProject(null);
    setReviewAction("");
  };

  const handleCreateBooking = async () => {
    try {
      // Validate booking data
      if (bookingData.selectedTimeSlots.length === 0) {
        setError("Please select at least one time slot");
        setTimeout(() => setError(""), 3000);
        return;
      }

      // Validate each selected time slot has equipment
      for (const timeSlotId of bookingData.selectedTimeSlots) {
        const equipment = bookingData.timeSlotEquipment[timeSlotId] || [];
        if (equipment.length === 0) {
          setError(`Please select at least one equipment for each time slot`);
          setTimeout(() => setError(""), 3000);
          return;
        }
      }

      setCreatingBooking(true);

      await adminAPI.reviewProject(selectedProject.id, {
        action: "approve",
        comment:
          reviewComment || "Project approved with lab booking(s) created",
      });

      // Construct complete booking objects with all required fields
      const bookings = bookingData.selectedTimeSlots.map((timeSlotId) => {
        const slot = bookingData.availableSlots.find(
          (s) => s.id === parseInt(timeSlotId),
        );

        if (!slot) {
          throw new Error(`Time slot ${timeSlotId} not found`);
        }

        // Combine date and time to create proper datetime strings
        const startDate = new Date(`${slot.date}T${slot.startTime}`);
        const endDate = new Date(`${slot.date}T${slot.endTime}`);

        return {
          timeSlotId: parseInt(timeSlotId),
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          labId: slot.lab.id,
          equipmentIds: bookingData.timeSlotEquipment[timeSlotId] || [],
          notes: bookingData.notes || null,
        };
      });

      const batchBookingPayload = {
        projectId: selectedProject.id,
        bookings: bookings,
      };

      await bookingAPI.createBatchBooking(batchBookingPayload);

      // Update local state
      setProjects((prev) =>
        prev.map((project) =>
          project.id === selectedProject.id
            ? {
                ...project,
                status: "APPROVED",
              }
            : project,
        ),
      );

      setSuccess(
        `Project approved and ${bookings.length} booking(s) created successfully!`,
      );
      setTimeout(() => setSuccess(""), 5000);

      // Close modals
      closeBookingModal();
      setSelectedProject(null);
      setReviewAction("");
      setReviewComment("");

      // Reload projects
      loadProjects();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to approve project or create booking(s). Please try again.",
      );
      console.error("Approval and booking error:", err);
      setTimeout(() => setError(""), 5000);
    } finally {
      setCreatingBooking(false);
    }
  };

  const openMentorChangeModal = async (project, consultation) => {
    setSelectedProjectForMentorChange(project);
    setSelectedConsultation(consultation);
    setShowMentorChangeModal(true);
    setLoadingMentors(true);
    setSelectedNewMentorId("");

    try {
      // Get mentors available for this project's lab
      const response = await adminAPI.getAvailableMentorsForProject(
        project.id,
        consultation.id,
      );

      setCurrentMentor(response.data.currentMentor || null);

      setAvailableMentors(response.data.availableMentors || []);
    } catch (err) {
      setError("Failed to load available mentors. Please try again.");
      console.error("Load mentors error:", err);
    } finally {
      setLoadingMentors(false);
    }
  };

  const closeMentorChangeModal = () => {
    setShowMentorChangeModal(false);
    setSelectedProjectForMentorChange(null);
    setSelectedConsultation(null);
    setAvailableMentors([]);
    setCurrentMentor(null);
    setSelectedNewMentorId("");
  };

  const handleChangeMentor = async () => {
    try {
      setChangingMentor(true);
      setError("");

      // Change mentor for specific consultation
      await adminAPI.changeConsultationMentor(
        selectedConsultation.id,
        selectedNewMentorId,
      );

      setSuccess("Consultation mentor changed successfully!");
      setTimeout(() => setSuccess(""), 5000);

      closeMentorChangeModal();
      loadProjects();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to change mentor. Please try again.",
      );
      console.error("Change mentor error:", err);
    } finally {
      setChangingMentor(false);
    }
  };

  const handleCancelConsultation = async () => {
    if (!cancellingProject || !selectedConsultation) return;

    try {
      setLoading(true);
      setError("");

      // Cancel specific consultation, not entire project
      await adminAPI.cancelSpecificConsultation(
        selectedConsultation.id,
        cancelReason,
      );

      setSuccess(`Session ${selectedConsultation.id} cancelled successfully!`);
      setTimeout(() => setSuccess(""), 3000);

      setShowCancelModal(false);
      setCancelReason("");
      setCancellingProject(null);
      setSelectedConsultation(null);

      // Refresh projects to get updated data
      await loadProjects();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to cancel consultation");
      setTimeout(() => setError(""), 5000);
    } finally {
      setLoading(false);
    }
  };

  const openCancelModal = (project, consultation) => {
    setCancellingProject(project);
    setSelectedConsultation(consultation);
    setCancelReason("");
    setShowCancelModal(true);
  };

  const handleMarkAbsent = async () => {
    if (!noShowProject || !selectedConsultation) return;

    try {
      setLoading(true);
      setError("");

      // Mark specific consultation absent
      await adminAPI.markConsultationAbsent(
        selectedConsultation.id,
        absentReason,
      );

      setSuccess(
        `Session ${selectedConsultation.id} marked as absent successfully!`,
      );
      setTimeout(() => setSuccess(""), 3000);

      setShowNoShowModal(false);
      setAbsentReason("");
      setNoShowProject(null);
      setSelectedConsultation(null);

      // Refresh projects to get updated data
      await loadProjects();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to mark as absent");
      setTimeout(() => setError(""), 5000);
    } finally {
      setLoading(false);
    }
  };

  const openNoShowModal = (project, consultation) => {
    setNoShowProject(project);
    setSelectedConsultation(consultation);
    setAbsentReason("");
    setShowNoShowModal(true);
  };

  const handleTimeSlotToggle = (timeSlotId) => {
    setBookingData((prev) => {
      const isCurrentlySelected = prev.selectedTimeSlots.includes(timeSlotId);

      if (isCurrentlySelected) {
        // Remove time slot
        const newSelectedSlots = prev.selectedTimeSlots.filter(
          (id) => id !== timeSlotId,
        );
        const newTimeSlotEquipment = { ...prev.timeSlotEquipment };
        delete newTimeSlotEquipment[timeSlotId];

        return {
          ...prev,
          selectedTimeSlots: newSelectedSlots,
          timeSlotEquipment: newTimeSlotEquipment,
        };
      } else {
        // Add time slot with default equipment (project's equipment)
        const defaultEquipment = selectedProject.equipment.map((e) => e.id);

        return {
          ...prev,
          selectedTimeSlots: [...prev.selectedTimeSlots, timeSlotId],
          timeSlotEquipment: {
            ...prev.timeSlotEquipment,
            [timeSlotId]: defaultEquipment,
          },
        };
      }
    });
  };

  const handleEquipmentToggleForSlot = (timeSlotId, equipmentId) => {
    setBookingData((prev) => {
      const currentEquipment = prev.timeSlotEquipment[timeSlotId] || [];
      const newEquipment = currentEquipment.includes(equipmentId)
        ? currentEquipment.filter((id) => id !== equipmentId)
        : [...currentEquipment, equipmentId];

      return {
        ...prev,
        timeSlotEquipment: {
          ...prev.timeSlotEquipment,
          [timeSlotId]: newEquipment,
        },
      };
    });
  };

  const selectAllEquipmentForSlot = (timeSlotId) => {
    setBookingData((prev) => ({
      ...prev,
      timeSlotEquipment: {
        ...prev.timeSlotEquipment,
        [timeSlotId]: bookingData.allLabEquipment
          .filter((e) => e.status === "AVAILABLE")
          .map((e) => e.id),
      },
    }));
  };

  const clearAllEquipmentForSlot = (timeSlotId) => {
    setBookingData((prev) => ({
      ...prev,
      timeSlotEquipment: {
        ...prev.timeSlotEquipment,
        [timeSlotId]: [],
      },
    }));
  };

  const handleEditComment = (consultation) => {
    setEditingComment(consultation.id);
    setEditCommentText(consultation.mentorFeedback || "");
  };

  const cancelEditComment = () => {
    setEditingComment(null);
    setEditCommentText("");
  };

  const saveEditComment = async (consultationId) => {
    try {
      await adminAPI.updateConsultationComment(consultationId, editCommentText);

      setEditingComment(null);
      setEditCommentText("");
      setSuccess("Comment updated successfully!");
      setTimeout(() => setSuccess(""), 3000);

      // Reload projects to get updated comments
      await loadProjects();
    } catch (err) {
      setError("Failed to update comment. Please try again.");
      console.error("Update comment error:", err);
    }
  };

  const handleArchiveProject = async (projectId, projectName) => {
    if (
      !window.confirm(
        `Are you sure you want to archive "${projectName}"? This will move it to the Archive page.`,
      )
    ) {
      return;
    }

    try {
      setArchiving(true);
      setError("");

      await archiveAPI.archiveProject(projectId);

      setSuccess(`Project "${projectName}" has been archived`);
      setTimeout(() => setSuccess(""), 3000);

      // Reload projects
      await loadProjects();
    } catch (err) {
      console.error("Archive project error:", err);
      setError(err.response?.data?.message || "Failed to archive project");
      setTimeout(() => setError(""), 5000);
    } finally {
      setArchiving(false);
    }
  };

  // Helper function to check if project can be archived
  const canArchiveProject = (project) => {
    // Can archive if project is approved or declined
    if (project.status === "APPROVED" || project.status === "DECLINED") {
      return true;
    }

    // Can archive if project status indicates all consultations are done
    if (
      project.status === "CONSULTATION_CANCELLED" ||
      project.status === "CONSULTATION_ABSENT"
    ) {
      return true;
    }

    // Can archive if all consultations are completed, cancelled, or absent
    if (
      project.consultations &&
      project.consultations.length > 0 &&
      project.consultations.every((c) =>
        ["COMPLETED", "CANCELLED", "ABSENT"].includes(c.status),
      )
    ) {
      return true;
    }

    return false;
  };

  // Helper function to check if project is actively in review
  const isProjectInReview = (project) => {
    // Only projects with IN_PROCESS status can be reviewed
    return project.status === "IN_PROCESS";
  };

  const sortConsultationsByDateTime = (consultations = []) => {
    return [...consultations].sort((a, b) => {
      const aHasDateTime = a?.date && a?.startTime;
      const bHasDateTime = b?.date && b?.startTime;

      if (!aHasDateTime && !bHasDateTime) {
        return (a?.id || 0) - (b?.id || 0);
      }
      if (!aHasDateTime) return 1;
      if (!bHasDateTime) return -1;

      const aDate = String(a.date).split("T")[0];
      const bDate = String(b.date).split("T")[0];
      const aDateTime = new Date(`${aDate}T${a.startTime}`);
      const bDateTime = new Date(`${bDate}T${b.startTime}`);
      return aDateTime - bDateTime;
    });
  };

  // Filter and sort projects
  const filteredProjects = projects
    .filter((project) => {
      const matchesSearch =
        project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.lab.name.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "ALL" || project.status === statusFilter;
      const matchesLab = labFilter === "ALL" || project.lab.name === labFilter;

      return matchesSearch && matchesStatus && matchesLab;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.createdAt) - new Date(a.createdAt);
        case "oldest":
          return new Date(a.createdAt) - new Date(b.createdAt);
        case "name":
          return a.name.localeCompare(b.name);
        case "status":
          return a.status.localeCompare(b.status);
        default:
          return 0;
      }
    });

  // Get unique labs for filter
  const uniqueLabs = ["ALL", ...new Set(projects.map((p) => p.lab.name))];

  if (!canAccessReview) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="admin-review" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {/* Page Header */}
          <section className="rounded-2xl bg-gradient-to-r from-sky-700 via-indigo-700 to-blue-800 px-6 py-7 text-white shadow-lg">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="min-w-0">
                <h2 className="text-2xl font-bold leading-tight sm:text-3xl">
                  Project Review
                </h2>
                <p className="mt-2 max-w-3xl text-sm text-blue-100">
                  Review and manage project proposals from students.
                </p>
              </div>
              <div className="flex">
                <button
                  onClick={() => navigate("/dashboard")}
                  className="inline-flex items-center rounded-lg border border-white/30 bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-white/40"
                >
                  Back to Dashboard
                </button>
              </div>
            </div>
          </section>

          {/* Alerts */}
          {error && <Alert type="error">{error}</Alert>}

          {success && <Alert type="success">{success}</Alert>}

          {/* Filters */}
          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label
                  htmlFor="search"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Search Projects
                </label>
                <input
                  type="text"
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by project, user, or lab..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>

              <div>
                <label
                  htmlFor="status"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Status
                </label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Status</option>
                  <option value="IN_PROCESS">Awaiting Review</option>
                  <option value="CONSULTATION_CANCELLED">
                    All Sessions Cancelled
                  </option>
                  <option value="CONSULTATION_ABSENT">
                    All Sessions Absent
                  </option>
                  <option value="APPROVED">Approved</option>
                  <option value="DECLINED">Declined</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="lab"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Filter by Lab
                </label>
                <select
                  id="lab"
                  value={labFilter}
                  onChange={(e) => setLabFilter(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  {uniqueLabs.map((lab) => (
                    <option key={lab} value={lab}>
                      {lab === "ALL" ? "All Labs" : lab}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="sort"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Sort by
                </label>
                <select
                  id="sort"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                  <option value="name">Project Name</option>
                  <option value="status">Status</option>
                </select>
              </div>
            </div>
          </section>

          {/* Projects List */}
          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading projects...
              </span>
            </div>
          ) : filteredProjects.length === 0 ? (
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center shadow-sm">
              <h3 className="text-sm font-semibold text-slate-900">
                No projects found
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                {projects.length === 0
                  ? "No projects have been submitted yet."
                  : "Try adjusting your search or filter criteria."}
              </p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              <ul className="divide-y divide-slate-200">
                {filteredProjects.map((project) => {
                  const sortedConsultations = sortConsultationsByDateTime(
                    project.consultations || [],
                  );
                  const canReview = canReviewProject(project);
                  const canApprove =
                    typeof project?.permissions?.canApprove === "boolean"
                      ? project.permissions.canApprove
                      : canReview && isProjectInReview(project);
                  const canDecline =
                    typeof project?.permissions?.canDecline === "boolean"
                      ? project.permissions.canDecline
                      : canReview && isProjectInReview(project);
                  const canArchive =
                    canArchiveByRole(project) && canArchiveProject(project);

                  return (
                    <li key={project.id}>
                      <div className="px-4 py-4 sm:px-6">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="text-lg font-medium text-indigo-600 truncate">
                                {project.name}
                              </p>
                              <div className="flex items-center text-sm text-gray-500 space-x-4">
                                <span
                                  className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                                    project.status,
                                  )}`}
                                >
                                  {getStatusLabel(project.status)}
                                </span>
                                <span>
                                  Created {formatDate(project.createdAt)}
                                </span>
                              </div>
                            </div>

                            {/* Project Details */}
                            <div className="mt-3 p-4 bg-gray-50 border border-gray-200 rounded-md">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                <div className="space-y-2">
                                  <div>
                                    <span className="font-medium text-gray-700">
                                      Student:
                                    </span>
                                    <span className="ml-2 text-gray-600">
                                      {project.user.name}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-700">
                                      Email:
                                    </span>
                                    <span className="ml-2 text-gray-600">
                                      {project.user.email}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="font-medium text-gray-700">
                                      Lab:
                                    </span>
                                    <span className="ml-2 text-gray-600">
                                      {project.lab.name} ({project.lab.location}
                                      )
                                    </span>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <div>
                                    <span className="font-medium text-gray-700">
                                      Equipment:
                                    </span>
                                    <div className="ml-2 text-gray-600">
                                      {project.equipment.map((equip, index) => (
                                        <span key={equip.id}>
                                          {equip.name}
                                          {index <
                                            project.equipment.length - 1 &&
                                            ", "}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="mt-3">
                                <span className="font-medium text-gray-700">
                                  Description:
                                </span>
                                <p className="ml-2 text-gray-600 mt-1">
                                  {project.description}
                                </p>
                              </div>

                              {/* Consultation Sessions Section */}
                              <div className="mt-4 pt-3 border-t border-gray-300">
                                <div className="flex items-center justify-between mb-3">
                                  <h4 className="font-semibold text-gray-700">
                                    Consultation Sessions (
                                    {sortedConsultations.length})
                                  </h4>
                                  {sortedConsultations.length > 0 && (
                                    <div className="text-xs text-gray-500">
                                      {sortedConsultations.filter(
                                        (c) => c.status === "COMPLETED",
                                      ).length || 0}{" "}
                                      completed •{" "}
                                      {sortedConsultations.filter(
                                        (c) => c.status === "SCHEDULED",
                                      ).length || 0}{" "}
                                      upcoming
                                    </div>
                                  )}
                                </div>

                                {sortedConsultations.length > 0 ? (
                                  <div className="space-y-3">
                                    {sortedConsultations.map(
                                      (consultation, index) => {
                                        const getCancellationInfo = () => {
                                          if (
                                            consultation.status ===
                                              "CANCELLED" &&
                                            consultation.cancelledBy
                                          ) {
                                            let whoDisplayName = "Admin";
                                            if (
                                              consultation.cancelledBy ===
                                              project.user.id
                                            ) {
                                              whoDisplayName =
                                                project.user.name;
                                            } else if (
                                              consultation.cancelledByUser
                                            ) {
                                              whoDisplayName =
                                                consultation.cancelledByUser
                                                  .name;
                                            }
                                            return {
                                              type: "cancelled",
                                              who: whoDisplayName,
                                              reason: consultation.cancelReason,
                                              when: consultation.cancelledAt,
                                            };
                                          }
                                          if (
                                            consultation.status === "ABSENT" &&
                                            consultation.markedAbsentBy
                                          ) {
                                            let whoDisplayName = "Admin";
                                            if (
                                              consultation.markedAbsentByUser
                                            ) {
                                              whoDisplayName =
                                                consultation.markedAbsentByUser
                                                  .name;
                                            }
                                            return {
                                              type: "absent",
                                              who: whoDisplayName,
                                              reason: consultation.absentReason,
                                              when: consultation.absentAt,
                                            };
                                          }
                                          return null;
                                        };

                                        const cancellationInfo =
                                          getCancellationInfo();

                                        return (
                                          <div
                                            key={consultation.id}
                                            className={`p-3 rounded-lg border ${
                                              index === 0
                                                ? "bg-indigo-50 border-indigo-200"
                                                : "bg-gray-50 border-gray-200"
                                            }`}
                                          >
                                            {/* Session Header */}
                                            <div className="flex justify-between items-start mb-2">
                                              <div>
                                                <h5 className="font-medium text-gray-900 text-sm">
                                                  Session {index + 1}
                                                </h5>
                                              </div>
                                              <span
                                                className={`text-xs px-2 py-0.5 rounded font-medium ${
                                                  consultation.status ===
                                                  "SCHEDULED"
                                                    ? "bg-blue-100 text-blue-800"
                                                    : consultation.status ===
                                                        "COMPLETED"
                                                      ? "bg-green-100 text-green-800"
                                                      : consultation.status ===
                                                          "CANCELLED"
                                                        ? "bg-yellow-100 text-yellow-800"
                                                        : "bg-red-100 text-red-800"
                                                }`}
                                              >
                                                {consultation.status}
                                              </span>
                                            </div>

                                            {/* Cancellation/Absent Info */}
                                            {cancellationInfo && (
                                              <div
                                                className={`mb-2 p-2 rounded ${
                                                  cancellationInfo.type ===
                                                  "cancelled"
                                                    ? "bg-yellow-50 border border-yellow-200"
                                                    : "bg-red-50 border border-red-200"
                                                }`}
                                              >
                                                <p
                                                  className={`text-xs font-semibold ${
                                                    cancellationInfo.type ===
                                                    "cancelled"
                                                      ? "text-yellow-800"
                                                      : "text-red-800"
                                                  }`}
                                                >
                                                  {cancellationInfo.type ===
                                                  "cancelled"
                                                    ? "Cancelled"
                                                    : "Marked Absent"}{" "}
                                                  by {cancellationInfo.who}
                                                </p>
                                                <p className="text-xs text-gray-600 mt-1">
                                                  Reason:{" "}
                                                  {cancellationInfo.reason ||
                                                    "Not Provided"}
                                                </p>
                                                {cancellationInfo.when && (
                                                  <p className="text-xs text-gray-500 mt-0.5">
                                                    {new Date(
                                                      cancellationInfo.when,
                                                    ).toLocaleString()}
                                                  </p>
                                                )}
                                              </div>
                                            )}

                                            {/* Consultation Details */}
                                            <div className="space-y-1 text-sm">
                                              <div>
                                                <span className="font-medium text-gray-700">
                                                  Time:
                                                </span>
                                                <span className="ml-2 text-gray-600">
                                                  {consultation.date &&
                                                  consultation.startTime
                                                    ? `${formatDate(consultation.date)} at ${formatTime(
                                                        consultation.startTime,
                                                      )}`
                                                    : "[Time Released]"}
                                                </span>
                                              </div>
                                              <div>
                                                <span className="font-medium text-gray-700">
                                                  Peer Mentor:
                                                </span>
                                                <span className="ml-2 text-gray-600">
                                                  {consultation.timeSlot?.mentor
                                                    ?.name ||
                                                    consultation.mentor ||
                                                    "[Not Assigned]"}
                                                </span>
                                                {/* Change Mentor button - only for scheduled consultations with timeSlot */}
                                                {[
                                                  "ADMIN",
                                                  "SUPERVISOR",
                                                ].includes(user.role) &&
                                                  consultation.status ===
                                                    "SCHEDULED" && (
                                                    <button
                                                      onClick={() =>
                                                        openMentorChangeModal(
                                                          project,
                                                          consultation,
                                                        )
                                                      }
                                                      className="ml-2 text-xs text-indigo-600 hover:text-indigo-800 underline"
                                                    >
                                                      Change Mentor
                                                    </button>
                                                  )}
                                              </div>

                                              {/* Mentor Feedback for this consultation */}
                                              {consultation.mentorFeedback && (
                                                <div className="mt-2 pt-2 border-t border-gray-200">
                                                  <span className="font-medium text-gray-700 text-xs">
                                                    Mentor Feedback:
                                                  </span>
                                                  {editingComment ===
                                                  consultation.id ? (
                                                    <div className="mt-1">
                                                      <textarea
                                                        value={editCommentText}
                                                        onChange={(e) =>
                                                          setEditCommentText(
                                                            e.target.value,
                                                          )
                                                        }
                                                        rows={2}
                                                        className="w-full px-2 py-1 border border-gray-300 rounded text-xs focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                                        placeholder="Enter feedback..."
                                                      />
                                                      <div className="mt-1 space-x-2">
                                                        <button
                                                          onClick={() =>
                                                            saveEditComment(
                                                              consultation.id,
                                                            )
                                                          }
                                                          className="px-2 py-0.5 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                                                        >
                                                          Save
                                                        </button>
                                                        <button
                                                          onClick={
                                                            cancelEditComment
                                                          }
                                                          className="px-2 py-0.5 bg-gray-500 text-white text-xs rounded hover:bg-gray-600"
                                                        >
                                                          Cancel
                                                        </button>
                                                      </div>
                                                    </div>
                                                  ) : (
                                                    <div>
                                                      <p className="text-gray-600 text-xs mt-1 italic">
                                                        "
                                                        {
                                                          consultation.mentorFeedback
                                                        }
                                                        "
                                                      </p>
                                                      {canModifyConsultation(
                                                        project,
                                                        consultation,
                                                      ) && (
                                                        <button
                                                          onClick={() =>
                                                            handleEditComment(
                                                              consultation,
                                                            )
                                                          }
                                                          className="mt-0.5 text-xs text-indigo-600 hover:text-indigo-800"
                                                        >
                                                          Edit feedback
                                                        </button>
                                                      )}
                                                    </div>
                                                  )}
                                                </div>
                                              )}
                                              {/* Add feedback button if none exists */}
                                              {!consultation.mentorFeedback &&
                                                canModifyConsultation(
                                                  project,
                                                  consultation,
                                                ) &&
                                                editingComment !==
                                                  consultation.id && (
                                                  <div className="mt-2 pt-2 border-t border-gray-200">
                                                    <button
                                                      onClick={() =>
                                                        handleEditComment(
                                                          consultation,
                                                        )
                                                      }
                                                      className="text-xs text-indigo-600 hover:text-indigo-800"
                                                    >
                                                      Add feedback
                                                    </button>
                                                  </div>
                                                )}
                                              {editingComment ===
                                                consultation.id &&
                                                !consultation.mentorFeedback && (
                                                  <div className="mt-2 pt-2 border-t border-gray-200">
                                                    <textarea
                                                      value={editCommentText}
                                                      onChange={(e) =>
                                                        setEditCommentText(
                                                          e.target.value,
                                                        )
                                                      }
                                                      rows={2}
                                                      className="w-full px-2 py-1 border border-gray-300 rounded text-xs focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                                      placeholder="Enter feedback..."
                                                    />
                                                    <div className="mt-1 space-x-2">
                                                      <button
                                                        onClick={() =>
                                                          saveEditComment(
                                                            consultation.id,
                                                          )
                                                        }
                                                        className="px-2 py-0.5 bg-green-600 text-white text-xs rounded hover:bg-green-700"
                                                      >
                                                        Save
                                                      </button>
                                                      <button
                                                        onClick={
                                                          cancelEditComment
                                                        }
                                                        className="px-2 py-0.5 bg-gray-500 text-white text-xs rounded hover:bg-gray-600"
                                                      >
                                                        Cancel
                                                      </button>
                                                    </div>
                                                  </div>
                                                )}
                                            </div>

                                            {/* Action Buttons - Only for scheduled consultations */}
                                            {consultation.status ===
                                              "SCHEDULED" &&
                                              canModifyConsultation(
                                                project,
                                                consultation,
                                              ) && (
                                                <div className="mt-2 pt-2 border-t border-gray-200 flex gap-2">
                                                  <button
                                                    onClick={() =>
                                                      openCancelModal(
                                                        project,
                                                        consultation,
                                                      )
                                                    }
                                                    className="px-2 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600 text-xs"
                                                  >
                                                    Cancel Session {index + 1}
                                                  </button>
                                                  <button
                                                    onClick={() =>
                                                      openNoShowModal(
                                                        project,
                                                        consultation,
                                                      )
                                                    }
                                                    className="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-xs"
                                                  >
                                                    Mark Absent
                                                  </button>
                                                </div>
                                              )}
                                          </div>
                                        );
                                      },
                                    )}
                                  </div>
                                ) : (
                                  <p className="text-gray-500 text-sm">
                                    No consultations found
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="ml-4 min-w-[140px]">
                            {/* Only show review buttons if project is IN_PROCESS */}
                            {isProjectInReview(project) &&
                              (canApprove || canDecline) && (
                                <div className="space-y-2">
                                  {/* Approve Button */}
                                  {canApprove && (
                                    <button
                                      onClick={() =>
                                        openReviewModal(project, "approve")
                                      }
                                      className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md shadow-sm transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                    >
                                      Approve
                                    </button>
                                  )}

                                  {/* Decline Button */}
                                  {canDecline && (
                                    <button
                                      onClick={() =>
                                        openReviewModal(project, "decline")
                                      }
                                      className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-md shadow-sm transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                    >
                                      Decline
                                    </button>
                                  )}
                                </div>
                              )}

                            {/* Archive Button - shown when project can be archived */}
                            {canArchive && (
                              <button
                                onClick={() =>
                                  handleArchiveProject(project.id, project.name)
                                }
                                disabled={archiving}
                                className="w-full mt-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-md shadow-sm transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Move to Archive"
                              >
                                📦 Archive
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
      </main>

      {/* Review Modal (decline only) */}
      {selectedProject && !showBookingModal && reviewAction === "decline" && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Decline Project
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Are you sure you want to decline "{selectedProject.name}"?
              </p>

              <div className="mb-4">
                <label
                  htmlFor="comment"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Comment (required)
                </label>
                <textarea
                  id="comment"
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  rows={3}
                  placeholder="Enter reason for declining..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() =>
                    handleProjectReview(
                      selectedProject.id,
                      "decline",
                      reviewComment,
                    )
                  }
                  disabled={submittingReview || !reviewComment.trim()}
                  className="flex-1 px-4 py-2 text-sm font-medium rounded-md text-white focus:outline-none focus:ring-2 focus:ring-offset-2 bg-red-600 hover:bg-red-700 focus:ring-red-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingReview ? "Processing..." : "Decline Project"}
                </button>
                <button
                  onClick={closeReviewModal}
                  disabled={submittingReview}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Booking Modal (for employees approving projects) */}
      {showBookingModal && selectedProject && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-6 border w-full max-w-6xl shadow-lg rounded-md bg-white max-h-[90vh] overflow-y-auto">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Create Lab Booking(s) for "{selectedProject.name}"
              </h3>
              <p className="text-sm text-gray-600 mb-6">
                To approve this project, you must create lab booking(s) for the
                student. Select one or more time slots and assign equipment to
                each.
              </p>

              {/* Booking Form */}
              <div className="space-y-4">
                {/* Time Slot Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Peer Mentor Time Slot(s){" "}
                    <span className="text-red-500">*</span>
                  </label>

                  {loadingSlots ? (
                    <div className="flex justify-center items-center p-4">
                      <Spinner size="md" />
                      <span className="ml-2 text-sm text-gray-600">
                        Loading available slots...
                      </span>
                    </div>
                  ) : bookingData.availableSlots?.length === 0 ? (
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                      <p className="text-sm text-yellow-800">
                        No available time slots found for this lab. Please
                        contact an administrator to set up peer mentor
                        schedules.
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="border border-gray-300 rounded-md max-h-96 overflow-y-auto">
                        {bookingData.availableSlots?.map((slot) => {
                          const [year, month, day] = slot.date
                            .split("-")
                            .map(Number);
                          const slotDate = new Date(year, month - 1, day);
                          const isSelected =
                            bookingData.selectedTimeSlots.includes(slot.id);

                          return (
                            <div
                              key={slot.id}
                              className="border-b border-gray-200 last:border-b-0"
                            >
                              {/* Time Slot Header */}
                              <div
                                onClick={() => handleTimeSlotToggle(slot.id)}
                                className={`p-3 cursor-pointer hover:bg-gray-50 ${
                                  isSelected ? "bg-indigo-50" : ""
                                }`}
                              >
                                <div className="flex items-start justify-between">
                                  <div className="flex items-start space-x-3">
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={() =>
                                        handleTimeSlotToggle(slot.id)
                                      }
                                      className="mt-1 h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                    />
                                    <div>
                                      <p className="text-sm font-medium text-gray-900">
                                        {slotDate.toLocaleDateString("en-US", {
                                          weekday: "long",
                                          year: "numeric",
                                          month: "long",
                                          day: "numeric",
                                        })}
                                      </p>
                                      <p className="text-sm text-gray-600">
                                        {slot.startTime} - {slot.endTime}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm font-medium text-indigo-600">
                                      {slot.mentor.name}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                      {slot.lab.location}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              {/* Equipment Selection for This Slot */}
                              {isSelected && (
                                <div className="px-3 pb-3 bg-gray-50 border-t border-gray-200">
                                  <div className="flex items-center justify-between mb-2 pt-2">
                                    <p className="text-xs font-semibold text-gray-700 uppercase">
                                      Equipment for this time slot:
                                    </p>
                                    <div className="space-x-2">
                                      <button
                                        onClick={() =>
                                          selectAllEquipmentForSlot(slot.id)
                                        }
                                        className="text-xs text-indigo-600 hover:text-indigo-800"
                                      >
                                        Select All
                                      </button>
                                      <button
                                        onClick={() =>
                                          clearAllEquipmentForSlot(slot.id)
                                        }
                                        className="text-xs text-red-600 hover:text-red-800"
                                      >
                                        Clear All
                                      </button>
                                    </div>
                                  </div>

                                  {/* Project's Requested Equipment */}
                                  <div className="mb-2">
                                    <p className="text-xs text-gray-600 mb-1">
                                      Requested by student:
                                    </p>
                                    <div className="space-y-1">
                                      {selectedProject.equipment.map(
                                        (equip) => (
                                          <div
                                            key={equip.id}
                                            className="flex items-center"
                                          >
                                            <input
                                              type="checkbox"
                                              id={`slot-${slot.id}-equip-${equip.id}`}
                                              checked={
                                                bookingData.timeSlotEquipment[
                                                  slot.id
                                                ]?.includes(equip.id) || false
                                              }
                                              onChange={() =>
                                                handleEquipmentToggleForSlot(
                                                  slot.id,
                                                  equip.id,
                                                )
                                              }
                                              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                            />
                                            <label
                                              htmlFor={`slot-${slot.id}-equip-${equip.id}`}
                                              className="ml-2 text-sm text-gray-700"
                                            >
                                              {equip.name}
                                              {equip.description && (
                                                <span className="text-gray-500 text-xs ml-1">
                                                  ({equip.description})
                                                </span>
                                              )}
                                            </label>
                                          </div>
                                        ),
                                      )}
                                    </div>
                                  </div>

                                  {/* Additional Available Equipment */}
                                  {bookingData.allLabEquipment &&
                                    bookingData.allLabEquipment.filter(
                                      (equip) =>
                                        !selectedProject.equipment.some(
                                          (pe) => pe.id === equip.id,
                                        ) && equip.status === "AVAILABLE",
                                    ).length > 0 && (
                                      <div>
                                        <p className="text-xs text-gray-600 mb-1">
                                          Additional available equipment:
                                        </p>
                                        <div className="space-y-1">
                                          {bookingData.allLabEquipment
                                            .filter(
                                              (equip) =>
                                                !selectedProject.equipment.some(
                                                  (pe) => pe.id === equip.id,
                                                ) &&
                                                equip.status === "AVAILABLE",
                                            )
                                            .map((equip) => (
                                              <div
                                                key={equip.id}
                                                className="flex items-center"
                                              >
                                                <input
                                                  type="checkbox"
                                                  id={`slot-${slot.id}-extra-${equip.id}`}
                                                  checked={
                                                    bookingData.timeSlotEquipment[
                                                      slot.id
                                                    ]?.includes(equip.id) ||
                                                    false
                                                  }
                                                  onChange={() =>
                                                    handleEquipmentToggleForSlot(
                                                      slot.id,
                                                      equip.id,
                                                    )
                                                  }
                                                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                                                />
                                                <label
                                                  htmlFor={`slot-${slot.id}-extra-${equip.id}`}
                                                  className="ml-2 text-sm text-gray-700"
                                                >
                                                  {equip.name}
                                                  {equip.description && (
                                                    <span className="text-gray-500 text-xs ml-1">
                                                      ({equip.description})
                                                    </span>
                                                  )}
                                                </label>
                                              </div>
                                            ))}
                                        </div>
                                      </div>
                                    )}

                                  {/* Equipment Count */}
                                  <p className="text-xs text-gray-500 mt-2">
                                    {bookingData.timeSlotEquipment[slot.id]
                                      ?.length || 0}{" "}
                                    equipment selected for this slot
                                  </p>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>

                      <p className="text-xs text-gray-500 mt-2">
                        {bookingData.selectedTimeSlots.length} time slot(s)
                        selected • {bookingData.availableSlots.length} available
                        for {selectedProject.lab.name}
                      </p>
                    </>
                  )}
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes (Optional)
                  </label>
                  <textarea
                    value={bookingData.notes}
                    onChange={(e) =>
                      setBookingData((prev) => ({
                        ...prev,
                        notes: e.target.value,
                      }))
                    }
                    rows={3}
                    placeholder="Add any special instructions or notes for the lab booking(s)..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>

                {/* Approval Comment */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Approval Comment (Optional)
                  </label>
                  <textarea
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    rows={2}
                    placeholder="Add a comment about the project approval..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex space-x-3">
                <button
                  onClick={handleCreateBooking}
                  disabled={
                    creatingBooking ||
                    bookingData.selectedTimeSlots.length === 0 ||
                    bookingData.selectedTimeSlots.some(
                      (slotId) =>
                        !bookingData.timeSlotEquipment[slotId] ||
                        bookingData.timeSlotEquipment[slotId].length === 0,
                    )
                  }
                  className="flex-1 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {creatingBooking
                    ? "Creating Booking(s)..."
                    : `Create ${bookingData.selectedTimeSlots.length} Booking(s) & Approve Project`}
                </button>
                <button
                  onClick={closeBookingModal}
                  disabled={creatingBooking}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>

              <p className="mt-3 text-xs text-red-600">
                * Note: Canceling will not approve the project. You must create
                at least one booking to approve.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Mentor Change Modal */}
      {showMentorChangeModal && selectedProjectForMentorChange && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Change Consultation Peer Mentor
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Change the peer mentor for consultation session in "
                {selectedProjectForMentorChange.name}"
              </p>

              {loadingMentors ? (
                <div className="flex justify-center items-center p-4">
                  <Spinner size="md" />
                  <span className="ml-2 text-sm">Loading peer mentors...</span>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Current Mentor */}
                  {currentMentor && (
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p className="text-xs font-medium text-gray-700 mb-1">
                        Current Peer Mentor:
                      </p>
                      <p className="text-sm font-medium text-gray-900">
                        {currentMentor.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {currentMentor.email}
                      </p>
                    </div>
                  )}

                  {/* New Mentor Selection */}
                  <div>
                    <label
                      htmlFor="newMentor"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Select New Peer Mentor
                    </label>
                    <select
                      id="newMentor"
                      value={selectedNewMentorId}
                      onChange={(e) => setSelectedNewMentorId(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    >
                      <option value="">-- Select a peer mentor --</option>
                      {availableMentors
                        .filter((mentor) => mentor.id !== currentMentor?.id)
                        .map((mentor) => (
                          <option key={mentor.id} value={mentor.id}>
                            {mentor.name} ({mentor.email})
                          </option>
                        ))}
                    </select>
                    {availableMentors.filter((m) => m.id !== currentMentor?.id)
                      .length === 0 && (
                      <p className="text-xs text-red-600 mt-1">
                        No other peer mentors available for this lab
                      </p>
                    )}
                  </div>

                  {/* Info */}
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                    <p className="text-xs text-blue-800">
                      <strong>Note:</strong> The consultation will be reassigned
                      only if the new mentor has the exact same date/time slot.
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-3 mt-6">
                <button
                  onClick={handleChangeMentor}
                  disabled={
                    changingMentor || !selectedNewMentorId || loadingMentors
                  }
                  className="flex-1 px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {changingMentor
                    ? "Changing Peer Mentor..."
                    : "Change Peer Mentor"}
                </button>
                <button
                  onClick={closeMentorChangeModal}
                  disabled={changingMentor}
                  className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cancel Consultation Modal */}
      {showCancelModal && cancellingProject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">Cancel Consultation</h3>

            <p className="text-gray-600 mb-4">
              Are you sure you want to cancel the consultation for{" "}
              <span className="font-semibold">{cancellingProject.name}</span>?
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for Cancellation (Optional)
              </label>
              <textarea
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Enter reason for cancellation..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows="3"
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowCancelModal(false);
                  setCancelReason("");
                  setCancellingProject(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                onClick={handleCancelConsultation}
                className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 disabled:opacity-50"
                disabled={loading}
              >
                {loading ? "Cancelling..." : "Confirm Cancellation"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mark Absent Modal */}
      {showNoShowModal && noShowProject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4">Mark as Absent</h3>

            <p className="text-gray-600 mb-4">
              Are you sure you want to mark the consultation for{" "}
              <span className="font-semibold">{noShowProject.name}</span> as
              absent?
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason (Optional)
              </label>
              <textarea
                value={absentReason}
                onChange={(e) => setAbsentReason(e.target.value)}
                placeholder="Enter reason for marking as absent..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                rows="3"
              />
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowNoShowModal(false);
                  setAbsentReason("");
                  setNoShowProject(null);
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                onClick={handleMarkAbsent}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50"
                disabled={loading}
              >
                {loading ? "Marking..." : "Confirm Absent"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminReview;
