import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Spinner from "../components/Spinner";
import Alert from "../components/Alert";
import { adminAPI, bookingAPI } from "../services/api";
import { getUserFromToken } from "../services/auth";
import { formatTime, getStatusColor, getStatusLabel } from "../services/utils";

const WEEKDAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const ACTIVITY_TYPES = {
  LAB: "LAB",
  CONSULTATION: "CONSULTATION",
};

const STATUS_OPTIONS = {
  [ACTIVITY_TYPES.LAB]: [
    { value: "ALL", label: "All Statuses" },
    { value: "CONFIRMED", label: "Confirmed" },
    { value: "COMPLETED", label: "Completed" },
    { value: "CANCELLED", label: "Cancelled" },
    { value: "ABSENT", label: "Absent" },
  ],
  [ACTIVITY_TYPES.CONSULTATION]: [
    { value: "ALL", label: "All Statuses" },
    { value: "SCHEDULED", label: "Scheduled" },
    { value: "COMPLETED", label: "Completed" },
    { value: "CANCELLED", label: "Cancelled" },
    { value: "ABSENT", label: "Absent" },
  ],
};

const toDateInputValue = (date) => {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const parseDateOnly = (dateString) => {
  if (!dateString) return null;
  const normalized = String(dateString).split("T")[0];
  const [year, month, day] = normalized.split("-").map(Number);
  if (!year || !month || !day) return null;
  return new Date(year, month - 1, day);
};

const startOfWeek = (date) => {
  const base = new Date(date);
  const day = base.getDay();
  base.setHours(0, 0, 0, 0);
  base.setDate(base.getDate() - day);
  return base;
};

const addDays = (date, days) => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

const isSameDay = (left, right) =>
  left.getFullYear() === right.getFullYear() &&
  left.getMonth() === right.getMonth() &&
  left.getDate() === right.getDate();

const formatDayHeading = (date) =>
  date.toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  });

const getConsultationStatusLabel = (status) => {
  switch (status) {
    case "SCHEDULED":
      return "Scheduled";
    case "COMPLETED":
      return "Completed";
    case "CANCELLED":
      return "Cancelled";
    case "ABSENT":
      return "Absent";
    default:
      return status || "Unknown";
  }
};

const getConsultationStatusColor = (status) => {
  switch (status) {
    case "SCHEDULED":
      return "bg-blue-100 text-blue-800";
    case "COMPLETED":
      return "bg-gray-100 text-gray-800";
    case "CANCELLED":
      return "bg-red-100 text-red-800";
    case "ABSENT":
      return "bg-orange-100 text-orange-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

const parseEventDateTime = (dateString, timeString) => {
  const dateOnly = String(dateString || "").split("T")[0];
  if (!dateOnly) return null;

  const value = timeString ? `${dateOnly}T${timeString}` : `${dateOnly}T00:00`;
  const parsed = new Date(value);
  if (!Number.isNaN(parsed.getTime())) {
    return parsed;
  }

  return parseDateOnly(dateOnly);
};

const fetchAllPages = async (
  fetchPage,
  { limit = 100, maxPages = 1000 } = {},
) => {
  const result = [];
  let page = 1;

  while (page <= maxPages) {
    const response = await fetchPage({ page, limit });
    const data = response?.data?.data || [];
    result.push(...data);

    const pagination = response?.data?.pagination;
    if (!pagination || !pagination.hasNextPage) {
      break;
    }

    page += 1;
  }

  return result;
};

const fetchAllProjectsForCalendar = () =>
  fetchAllPages(({ page, limit }) =>
    adminAPI.getAllProjects({ page, limit, sortBy: "newest" }),
  );

const fetchAllBookingsForCalendar = () =>
  fetchAllPages(({ page, limit }) =>
    bookingAPI.getAllBookings({ page, limit, sortBy: "oldest" }),
  );

function AdminCalendar() {
  const navigate = useNavigate();
  const user = getUserFromToken();
  const canAccess = ["ADMIN", "SUPERVISOR", "PEER_MENTOR"].includes(user?.role);
  const isAdmin = user?.role === "ADMIN";

  const [bookings, setBookings] = useState([]);
  const [consultations, setConsultations] = useState([]);
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [activityType, setActivityType] = useState(ACTIVITY_TYPES.LAB);
  const [viewMode, setViewMode] = useState("week");
  const [selectedDate, setSelectedDate] = useState(
    toDateInputValue(new Date()),
  );
  const [statusFilter, setStatusFilter] = useState("CONFIRMED");
  const [labFilter, setLabFilter] = useState("ALL");
  const [personFilter, setPersonFilter] = useState("");

  useEffect(() => {
    if (!canAccess) {
      navigate("/dashboard");
      return;
    }
    loadCalendarData();
  }, [canAccess, navigate]);

  useEffect(() => {
    const defaultStatus =
      activityType === ACTIVITY_TYPES.LAB ? "CONFIRMED" : "SCHEDULED";
    setStatusFilter(defaultStatus);
  }, [activityType]);

  const loadCalendarData = async () => {
    try {
      setLoading(true);
      setError("");

      const [labsResponse, bookingsData, projects] = await Promise.all([
        adminAPI.getLabsForFilter(),
        fetchAllBookingsForCalendar(),
        fetchAllProjectsForCalendar(),
      ]);

      const consultationEvents = [];

      projects.forEach((project) => {
        const projectConsultations = project.consultations || [];

        projectConsultations.forEach((consultation) => {
          if (!consultation?.date) {
            return;
          }

          const startDate = parseEventDateTime(
            consultation.date,
            consultation.startTime,
          );

          if (!startDate) {
            return;
          }

          consultationEvents.push({
            id: `consultation-${consultation.id}`,
            consultationId: consultation.id,
            status: consultation.status,
            project: project.name,
            projectId: project.id,
            lab: project.lab?.name || "Unknown Lab",
            labId: project.lab?.id || null,
            student: project.user?.name || "Unknown Student",
            studentEmail: project.user?.email || "",
            studentId: project.user?.id || null,
            mentorName: consultation.mentor || "Unassigned",
            mentorEmail: consultation.mentorEmail || "",
            startTime: consultation.startTime,
            endTime: consultation.endTime,
            startDate,
          });
        });
      });

      setLabs(labsResponse.data.labs || []);
      setBookings(bookingsData);
      setConsultations(consultationEvents);
    } catch (err) {
      console.error("Load admin calendar data error:", err);
      setError("Failed to load calendar data. Please refresh and try again.");
    } finally {
      setLoading(false);
    }
  };

  const selectedDateObject = useMemo(() => {
    const parsed = parseDateOnly(selectedDate);
    return parsed || new Date();
  }, [selectedDate]);

  const visibleDates = useMemo(() => {
    if (viewMode === "day") {
      return [selectedDateObject];
    }

    const start = startOfWeek(selectedDateObject);
    return Array.from({ length: 7 }, (_, index) => addDays(start, index));
  }, [viewMode, selectedDateObject]);

  const normalizedEvents = useMemo(() => {
    if (activityType === ACTIVITY_TYPES.CONSULTATION) {
      return consultations.map((item) => ({
        id: item.id,
        kind: ACTIVITY_TYPES.CONSULTATION,
        status: item.status,
        project: item.project,
        projectId: item.projectId,
        lab: item.lab,
        labId: item.labId,
        student: item.student,
        studentEmail: item.studentEmail,
        studentId: item.studentId,
        mentorName: item.mentorName,
        mentorEmail: item.mentorEmail,
        startTime: item.startTime,
        endTime: item.endTime,
        startDate: item.startDate,
      }));
    }

    return bookings.map((booking) => ({
      id: `booking-${booking.id}`,
      kind: ACTIVITY_TYPES.LAB,
      status: booking.status,
      project: booking.project,
      projectId: booking.projectId,
      lab: booking.lab,
      labId: booking.labId,
      student: booking.student,
      studentEmail: booking.studentEmail,
      studentId: booking.studentId,
      mentorName: booking.labMentor?.name || "Unassigned",
      mentorEmail: booking.labMentor?.email || "",
      startTime: booking.timeSlot?.startTime || null,
      endTime: booking.timeSlot?.endTime || null,
      startDate: new Date(booking.startDate),
    }));
  }, [activityType, consultations, bookings]);

  const filteredEvents = useMemo(() => {
    const personQuery = personFilter.trim().toLowerCase();

    return normalizedEvents
      .filter((event) => {
        if (statusFilter !== "ALL" && event.status !== statusFilter) {
          return false;
        }

        if (labFilter !== "ALL" && String(event.labId) !== labFilter) {
          return false;
        }

        if (personQuery) {
          const subject = [
            event.student,
            event.studentEmail,
            event.mentorName,
            event.mentorEmail,
            event.project,
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();

          if (!subject.includes(personQuery)) {
            return false;
          }
        }

        if (
          !(event.startDate instanceof Date) ||
          Number.isNaN(event.startDate.getTime())
        ) {
          return false;
        }

        return visibleDates.some((date) => isSameDay(date, event.startDate));
      })
      .sort((left, right) => left.startDate - right.startDate);
  }, [normalizedEvents, statusFilter, labFilter, personFilter, visibleDates]);

  const eventsByDay = useMemo(() => {
    return visibleDates.map((date) => {
      const entries = filteredEvents.filter((event) =>
        isSameDay(event.startDate, date),
      );

      return { date, entries };
    });
  }, [visibleDates, filteredEvents]);

  const summary = useMemo(() => {
    const activeLabs = new Set();
    const activeMentors = new Map();
    const mentorNames = new Map();
    const activeStudents = new Set();

    filteredEvents.forEach((event) => {
      if (event.labId) {
        activeLabs.add(event.labId);
      }

      const mentorKey = event.mentorEmail || event.mentorName;
      if (mentorKey && event.mentorName && event.mentorName !== "Unassigned") {
        const currentCount = activeMentors.get(mentorKey) || 0;
        activeMentors.set(mentorKey, currentCount + 1);
        mentorNames.set(mentorKey, event.mentorName);
      }

      if (event.studentId) {
        activeStudents.add(event.studentId);
      }
    });

    return {
      events: filteredEvents.length,
      labsInUse: activeLabs.size,
      mentorsWorking: activeMentors.size,
      studentsScheduled: activeStudents.size,
      mentors: Array.from(activeMentors.entries())
        .map(([mentorKey, sessions]) => ({
          id: mentorKey,
          name: mentorNames.get(mentorKey) || "Unknown Mentor",
          sessions,
        }))
        .sort((left, right) => right.sessions - left.sessions),
      labLoad: Object.values(
        filteredEvents.reduce((accumulator, event) => {
          if (!event.labId) return accumulator;
          const key = String(event.labId);
          if (!accumulator[key]) {
            accumulator[key] = {
              id: event.labId,
              name: event.lab,
              sessions: 0,
            };
          }
          accumulator[key].sessions += 1;
          return accumulator;
        }, {}),
      ).sort((left, right) => right.sessions - left.sessions),
    };
  }, [filteredEvents]);

  const activityLabel =
    activityType === ACTIVITY_TYPES.LAB ? "Lab Sessions" : "Consultations";

  if (!canAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activePage="calendar" />

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0 space-y-6">
          {error && <Alert type="error">{error}</Alert>}

          <section className="rounded-2xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-700 p-6 text-white shadow-lg">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
                <p className="mt-2 text-sm text-blue-100">
                  Track lab sessions and consultations, including who is
                  mentoring and where activity is happening.
                </p>
              </div>

              {isAdmin && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  <div className="rounded-xl bg-white/15 px-4 py-3">
                    <p className="text-blue-100">{activityLabel}</p>
                    <p className="text-2xl font-bold">{summary.events}</p>
                  </div>
                  <div className="rounded-xl bg-white/15 px-4 py-3">
                    <p className="text-blue-100">Labs In Use</p>
                    <p className="text-2xl font-bold">{summary.labsInUse}</p>
                  </div>
                  <div className="rounded-xl bg-white/15 px-4 py-3">
                    <p className="text-blue-100">Mentors Working</p>
                    <p className="text-2xl font-bold">
                      {summary.mentorsWorking}
                    </p>
                  </div>
                  <div className="rounded-xl bg-white/15 px-4 py-3">
                    <p className="text-blue-100">Students</p>
                    <p className="text-2xl font-bold">
                      {summary.studentsScheduled}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-6">
              <div>
                <label
                  htmlFor="calendar-activity"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Activity Type
                </label>
                <div className="inline-flex w-full rounded-lg border border-slate-200 bg-slate-50 p-1">
                  <button
                    type="button"
                    onClick={() => setActivityType(ACTIVITY_TYPES.LAB)}
                    className={`w-1/2 rounded-md px-2 py-2 text-sm font-medium transition-colors ${
                      activityType === ACTIVITY_TYPES.LAB
                        ? "bg-indigo-600 text-white"
                        : "text-slate-600 hover:text-indigo-600"
                    }`}
                  >
                    Labs
                  </button>
                  <button
                    type="button"
                    onClick={() => setActivityType(ACTIVITY_TYPES.CONSULTATION)}
                    className={`w-1/2 rounded-md px-2 py-2 text-sm font-medium transition-colors ${
                      activityType === ACTIVITY_TYPES.CONSULTATION
                        ? "bg-indigo-600 text-white"
                        : "text-slate-600 hover:text-indigo-600"
                    }`}
                  >
                    Consult
                  </button>
                </div>
              </div>

              <div>
                <label
                  htmlFor="calendar-view"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  View
                </label>
                <div className="inline-flex w-full rounded-lg border border-slate-200 bg-slate-50 p-1">
                  <button
                    type="button"
                    onClick={() => setViewMode("day")}
                    className={`w-1/2 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                      viewMode === "day"
                        ? "bg-indigo-600 text-white"
                        : "text-slate-600 hover:text-indigo-600"
                    }`}
                  >
                    Day
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode("week")}
                    className={`w-1/2 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                      viewMode === "week"
                        ? "bg-indigo-600 text-white"
                        : "text-slate-600 hover:text-indigo-600"
                    }`}
                  >
                    Week
                  </button>
                </div>
              </div>

              <div>
                <label
                  htmlFor="calendar-date"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Date
                </label>
                <input
                  id="calendar-date"
                  type="date"
                  value={selectedDate}
                  onChange={(event) => setSelectedDate(event.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>

              <div>
                <label
                  htmlFor="calendar-status"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Status
                </label>
                <select
                  id="calendar-status"
                  value={statusFilter}
                  onChange={(event) => setStatusFilter(event.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  {STATUS_OPTIONS[activityType].map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="calendar-lab"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Lab
                </label>
                <select
                  id="calendar-lab"
                  value={labFilter}
                  onChange={(event) => setLabFilter(event.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                >
                  <option value="ALL">All Labs</option>
                  {labs.map((lab) => (
                    <option key={lab.id} value={String(lab.id)}>
                      {lab.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="calendar-person"
                  className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500"
                >
                  Person or Project
                </label>
                <input
                  id="calendar-person"
                  type="text"
                  value={personFilter}
                  onChange={(event) => setPersonFilter(event.target.value)}
                  placeholder="Mentor, student, or project"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                />
              </div>
            </div>
          </section>

          {loading ? (
            <div className="flex items-center justify-center rounded-xl border border-slate-200 bg-white p-10">
              <Spinner />
              <span className="ml-2 text-sm text-slate-600">
                Loading calendar data...
              </span>
            </div>
          ) : (
            <section className="grid grid-cols-1 gap-6 xl:grid-cols-3">
              <div className="xl:col-span-2 rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold text-slate-900">
                    {viewMode === "day" ? "Daily Schedule" : "Weekly Schedule"}
                  </h3>
                  <p className="text-sm text-slate-500">
                    {activityLabel} •{" "}
                    {viewMode === "day"
                      ? formatDayHeading(selectedDateObject)
                      : `${formatDayHeading(visibleDates[0])} - ${formatDayHeading(visibleDates[visibleDates.length - 1])}`}
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-2 lg:grid-cols-3">
                  {eventsByDay.map(({ date, entries }) => (
                    <div
                      key={toDateInputValue(date)}
                      className="rounded-xl border border-slate-200 bg-slate-50/70 p-3"
                    >
                      <div className="mb-2 flex items-center justify-between">
                        <p className="text-sm font-semibold text-slate-800">
                          {WEEKDAY_LABELS[date.getDay()]}
                        </p>
                        <p className="text-xs text-slate-500">
                          {date.toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                      </div>

                      {entries.length === 0 ? (
                        <p className="rounded-md border border-dashed border-slate-300 bg-white px-3 py-4 text-center text-xs text-slate-500">
                          No{" "}
                          {activityType === ACTIVITY_TYPES.LAB
                            ? "sessions"
                            : "consultations"}
                        </p>
                      ) : (
                        <div className="space-y-2">
                          {entries.map((event) => (
                            <article
                              key={event.id}
                              className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm"
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="text-sm font-semibold text-slate-900">
                                    {event.project}
                                  </p>
                                  <p className="text-xs text-slate-500">
                                    {event.startTime
                                      ? formatTime(event.startTime)
                                      : "Time N/A"}
                                    {event.endTime
                                      ? ` - ${formatTime(event.endTime)}`
                                      : ""}
                                  </p>
                                </div>
                                <span
                                  className={`rounded-full px-2 py-1 text-[11px] font-semibold ${
                                    event.kind === ACTIVITY_TYPES.CONSULTATION
                                      ? getConsultationStatusColor(event.status)
                                      : getStatusColor(event.status)
                                  }`}
                                >
                                  {event.kind === ACTIVITY_TYPES.CONSULTATION
                                    ? getConsultationStatusLabel(event.status)
                                    : getStatusLabel(event.status)}
                                </span>
                              </div>

                              <div className="mt-2 space-y-1 text-xs text-slate-600">
                                <p>
                                  <span className="font-semibold text-slate-700">
                                    Lab:
                                  </span>{" "}
                                  {event.lab}
                                </p>
                                <p>
                                  <span className="font-semibold text-slate-700">
                                    {event.kind === ACTIVITY_TYPES.CONSULTATION
                                      ? "Consultation Mentor"
                                      : "Lab Mentor"}
                                    :
                                  </span>{" "}
                                  {event.mentorName || "Unassigned"}
                                </p>
                                <p>
                                  <span className="font-semibold text-slate-700">
                                    Student:
                                  </span>{" "}
                                  {event.student}
                                </p>
                              </div>
                            </article>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                    {activityType === ACTIVITY_TYPES.CONSULTATION
                      ? "Consultation Mentors"
                      : "Who Is Working"}
                  </h3>
                  {summary.mentors.length === 0 ? (
                    <p className="mt-3 text-sm text-slate-500">
                      No mentors scheduled.
                    </p>
                  ) : (
                    <ul className="mt-3 space-y-2">
                      {summary.mentors.slice(0, 8).map((mentor) => (
                        <li
                          key={mentor.id}
                          className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2"
                        >
                          <span className="text-sm text-slate-800">
                            {mentor.name}
                          </span>
                          <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700">
                            {mentor.sessions}{" "}
                            {activityType === ACTIVITY_TYPES.CONSULTATION
                              ? "consultations"
                              : "sessions"}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                  <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">
                    Lab Utilization
                  </h3>
                  {summary.labLoad.length === 0 ? (
                    <p className="mt-3 text-sm text-slate-500">
                      No lab usage in this range.
                    </p>
                  ) : (
                    <div className="mt-3 space-y-3">
                      {summary.labLoad.slice(0, 8).map((labUsage) => {
                        const width =
                          summary.events > 0
                            ? Math.round(
                                (labUsage.sessions / summary.events) * 100,
                              )
                            : 0;

                        return (
                          <div key={labUsage.id}>
                            <div className="mb-1 flex items-center justify-between text-xs text-slate-600">
                              <span>{labUsage.name}</span>
                              <span>{labUsage.sessions} sessions</span>
                            </div>
                            <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-indigo-600"
                                style={{ width: `${width}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

export default AdminCalendar;
